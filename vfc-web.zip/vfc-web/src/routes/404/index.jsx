import React from 'react'

import './index.less'

const NotFoundPage = () => (
  <div className="lb-not-found-page">
    <div className="image-block">
      <div className="image" />
    </div>
    <div className="content">
      <h1>404</h1>
      <div className="desc">抱歉，你访问的页面不存在</div>
    </div>
  </div>
)

export default NotFoundPage
