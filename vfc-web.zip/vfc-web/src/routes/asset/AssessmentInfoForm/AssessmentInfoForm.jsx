import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import InputField from '../../../components/form/inputs/InputField'
import RadioField from '../../../components/form/inputs/RadioField'
import DatePickerField from '../../../components/form/inputs/DatePickerField'
import SelectField from '../../../components/form/inputs/SelectField'
import MoneyField from '../../../components/form/inputs/MoneyField'
import InputNumberField from '../../../components/form/inputs/InputNumberField'
import { validTerm, validTermMessage } from '../../../validators/lease'
import RateField from '../../../components/form/inputs/RateField'
import { currencyTypeSelectOptions } from '../../../components/columnRenders/currencyType'

class AssessmentInfo extends Component {
  constructor(props) {
    super(props)

    this.state = {
      rentPayModCd: [
        { title: '自用', value: '00', key: '00' },
        { title: '出租', value: '01', key: '01' },
        { title: '闲置', value: '02', key: '02' },
      ],
    }

    this.isRentOut = [
      { label: '否', value: '00', key: '00' },
      { label: '是', value: '01', key: '01' },
    ]
  }

  render() {
    const { form, data, authority, readOnly = true, buyerPrc } = this.props

    return (
      <div>
        <Form>
          <Row>
            <MoneyField
              form={form}
              authority={authority}
              name="buyerPrc"
              key="buyerPrc"
              formItemProps={{ label: '购买价格' }}
              fieldProps={{
                initialValue: buyerPrc || data.buyerPrc,
              }}
              inputProps={{
                placeholder: !readOnly ? '请输入' : '',
                disabled: readOnly,
              }}
            />
            <MoneyField
              form={form}
              authority={authority}
              name="sysEvaluate"
              key="sysEvaluate"
              formItemProps={{ label: '系统评估价值' }}
              fieldProps={{
                initialValue: data.sysEvaluate,
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="evalManager"
              key="evalManager"
              formItemProps={{ label: '评估人' }}
              fieldProps={{
                initialValue: data.evalManager,
                rules: [
                  { min: 2, max: 32, message: '长度为2-32' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                maxLength: 32,
              }}
            />
            <MoneyField
              form={form}
              authority={authority}
              name="evalVal"
              key="evalVal"
              formItemProps={{ label: '评估价值' }}
              fieldProps={{
                initialValue: data.evalVal,
                rules: [
                  { required: true, message: '请输入评估价值' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <MoneyField
              form={form}
              authority={authority}
              name="aval"
              key="aval"
              formItemProps={{ label: '认定价值' }}
              fieldProps={{
                initialValue: data.aval,
                rules: [
                  { required: true, message: '请输入认定价值' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="evalCrcy"
              key="evalCrcy"
              formItemProps={{ label: '评估币种' }}
              fieldProps={{
                initialValue: data.evalCrcy,
                rules: [
                  { required: true, message: '请输入评估币种' },
                ],
              }}
              inputProps={{
                placeholder: '请选择',
                options: currencyTypeSelectOptions,
              }}
            />
            <DatePickerField
              form={form}
              authority={authority}
              name="evalDate"
              key="evalDate"
              formItemProps={{ label: '评估时间' }}
              fieldProps={{
                initialValue: data.evalDate,
                rules: [
                  { required: true, message: '请选择评估时间' },
                ],
              }}
              inputProps={{
                placeholder: '请选择',
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="evalOfc"
              key="evalOfc"
              formItemProps={{ label: '评估机构' }}
              fieldProps={{
                initialValue: data.evalOfc,
                rules: [
                  { min: 2, max: 64, message: '长度为2-64' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                maxLength: 64,
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="isRentOut"
              formItemProps={{ label: '状态' }}
              fieldProps={{
                      initialValue: data.isRentOut,
                      // rules: [{ required: true, message: '还款日规则为必选项！' }],
                  }}
              inputProps={{
                      // onChange: this.repayRuleChange,
                      options: this.state.rentPayModCd,
                      placeholder: '请选择',
                  }}
            />
            {/* <RadioField */}
            {/* form={form} */}
            {/* authority={authority} */}
            {/* name="isRentOut" */}
            {/* key="isRentOut" */}
            {/* formItemProps={{ label: '是否出租' }} */}
            {/* fieldProps={{ */}
            {/* initialValue: data.isRentOut, */}
            {/* }} */}
            {/* inputProps={{ */}
            {/* placeholder: '请选择', */}
            {/* options: this.isRentOut, */}
            {/* }} */}
            {/* /> */}
            <InputNumberField
              form={form}
              authority={authority}
              name="durYears"
              formItemProps={{ label: '使用年限' }}
              fieldProps={{
                initialValue: data.durYears,
                rules: [
                  { pattern: validTerm, message: validTermMessage },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                format: false,
              }}
            />
            <RateField
              form={form}
              authority={authority}
              name="morPlRate"
              key="morPlRate"
              formItemProps={{ label: '抵质押率' }}
              fieldProps={{
                initialValue: data.morPlRate,
              }}
              inputProps={{
                placeholder: '抵押贷款额度/抵押物估价价值',
              }}
            />
            <RateField
              form={form}
              authority={authority}
              name="discPct"
              key="discPct"
              formItemProps={{ label: '折扣比例' }}
              fieldProps={{
                initialValue: data.discPct,
              }}
              inputProps={{
                placeholder: '评估价格/购买价格',
              }}
            />
            <RateField
              form={form}
              authority={authority}
              name="decrRate"
              key="decrRate"
              formItemProps={{ label: '减值率' }}
              fieldProps={{
                initialValue: data.decrRate,
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
          </Row>
        </Form>
      </div>
    )
  }
}

AssessmentInfo.propTypes = {
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  data: PropTypes.object,
  readOnly: PropTypes.bool,
  buyerPrc: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
  ]),
}

export default AssessmentInfo
