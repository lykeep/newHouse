
export default {
  changeLibraryOutInfo: 'CARPAGE_CHANGE_LIBRARY_OUT_INFO',
  changeLibraryInInfo: 'CARPAGE_CHANGE_LIBRARY_IN_INFO',
  insuranceInfo: 'CARPAGE_INSURANCE_INFO',
  mortgageInfo: 'CARPAGE_MORTGAGE_INFO',
  signInfo: 'CARPAGE_SIGN_INFO',
  outEnterInfo: 'CARPAGE_OUTENTER_INFO',
  pledgeInfo: 'CARPAGE_PLEDGE_INFO',
  assessmentInfo: 'CARPAGE_ASSESSMENT_INFO',
  attachmentInfo: 'CARPAGE_ATTACHMENT_INFO',
  approvalInfo: 'CARPAGE_APPROVALPAGE_INFO',
  GPSInfo: 'CARPAGE_GPS_INFO',
  circulationRecordInfo: 'CARPAGE_CIRCLE_RECORD_INFO',
  flowChartInfo: 'CARPAGE_FLOW_CHART_INFO',
}

export const tabTitleMap = {
  CARPAGE_CHANGE_LIBRARY_OUT_INFO: '变更信息',
  CARPAGE_CHANGE_LIBRARY_IN_INFO: '变更信息',
  CARPAGE_INSURANCE_INFO: '保险信息',
  CARPAGE_MORTGAGE_INFO: '抵/解押信息',
  CARPAGE_SIGN_INFO: '抵/解押信息',
  CARPAGE_OUTENTER_INFO: '出入库信息',
  CARPAGE_PLEDGE_INFO: '押品信息',
  CARPAGE_ASSESSMENT_INFO: '评估信息',
  CARPAGE_ATTACHMENT_INFO: '附件信息',
  CARPAGE_APPROVALPAGE_INFO: '审批信息',
  CARPAGE_GPS_INFO: 'GPS信息',
  CARPAGE_CIRCLE_RECORD_INFO: '流转信息',
  CARPAGE_FLOW_CHART_INFO: '流程图',
}
