const formIds = {
  pledgeInfo: 'CARPAGE_PLEDGE_INFO',
  carInfo: 'CARPAGE_CAR_INFO',
  assessmentInfo: 'CARPAGE_ASSESSMENT_INFO',
  insuranceInfo: 'CARPAGE_INSURANCE_INFO',
  GPSInfo: 'CARPAGE_GPS_INFO',
  mortgageInfo: 'CARPAGE_MORTGAGE_INFO',
  signInfo: 'CARPAGE_SIGN_INFO',
  outEnterInfo: 'CARPAGE_OUTENTER_INFO',
  approvalInfo: 'CARPAGE_APPROVALPAGE_INFO',
  changeLibraryOutInfo: 'CARPAGE_CHANGE_LIBRARY_OUT_INFO',
  changeLibraryInInfo: 'CARPAGE_CHANGE_LIBRARY_IN_INFO',
  circulationRecordInfo: 'CARPAGE_CARPAGE_CIRCULATION_INFO',
  flowChartInfo: 'CARPAGE_CFLOW_CHART_INFO',
  attachmentInfo: 'CARPAGE_ATTACHMENT_INFO',
}

export const formTitleMap = {
  [formIds.pledgeInfo]: '押品信息',
  [formIds.carInfo]: '押品信息',
  [formIds.assessmentInfo]: '评估信息',
  [formIds.insuranceInfo]: '保险信息',
  [formIds.GPSInfo]: 'GPS信息',
  [formIds.mortgageInfo]: '抵/解押信息',
  [formIds.signInfo]: '抵/解押信息',
  [formIds.outEnterInfo]: '出入库信息',
  [formIds.approvalInfo]: '审批信息',
  [formIds.changeLibraryOutInfo]: '变更信息（出入库）',
  [formIds.changeLibraryInInfo]: '变更信息（出入库）',
  [formIds.circulationRecordInfo]: '流转信息',
  [formIds.flowChartInfo]: '流程图',
  [formIds.attachmentInfo]: '附件信息',
}

export default formIds
