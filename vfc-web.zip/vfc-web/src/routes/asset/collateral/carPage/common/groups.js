import groupIds, { idTitleMap } from './groupIds'
import tabIds, { tabTitleMap } from './tabIds'

import PledgeInfo from '../components/PledgeInfoForm/PledgeInfoTab'
import AssessmentInfo from '../components/AssessmentInfoForm/AssessmentInfoForm'
import GPSInfo from '../components/GPSInfoForm/GPSInfoFormWrapper'
import InsuranceInfo from '../components/InsuranceInfoForm/InsuranceInfoFormWrapper'
import MortSignInfo from '../components/MortSignInfoForm/MortSingTab'
import OutEnterInfo from '../components/OutEnterLibraryInfoForm/OutEnterLibraryInfoFormWrapper'
import ApprovalInfo from '../components/ApprovalForm/ApprovalForm'
import CirculationInfo from '../components/CirculationRecordTable/CirculationRecordTable'
import FlowChartInfo from '../components/FlowChartInfo/FlowChartInfo'
import ChangeInInfo from '../components/ChangeLibraryInfoForm/ChangeInfoTableWrapper'
import ChangeOutInfo from '../components/ChangeLibraryInfoForm/ChangeInfoFormWrapper'
import AttachmentInfo from '../components/AttachmentInfoForm/AttachmentInfoFormWrapper'

import { PERMISSIONS } from '../../../../../components/form/utils/calPermission'

const CarPageGroups = [
  {
    groupId: tabIds.pledgeInfo,
    title: tabTitleMap[tabIds.pledgeInfo],
    forceRender: true,
    path: 'PledgeInfoForm/PledgeInfoTab',
    component: () => PledgeInfo,
  },
  {
    groupId: tabIds.assessmentInfo,
    title: tabTitleMap[tabIds.assessmentInfo],
    forceRender: true,
    path: 'AssessmentInfoForm/AssessmentInfoForm',
    component: () => AssessmentInfo,
  },
  {
    groupId: tabIds.insuranceInfo,
    title: tabTitleMap[tabIds.insuranceInfo],
    forceRender: true,
    path: 'InsuranceInfoForm/InsuranceInfoTable',
    component: () => InsuranceInfo,
  },
  {
    groupId: tabIds.GPSInfo,
    title: tabTitleMap[tabIds.GPSInfo],
    forceRender: true,
    path: 'GPSInfoForm/GPSInfoForm',
    component: () => GPSInfo,
  },
  {
    groupId: tabIds.mortgageInfo,
    title: tabTitleMap[tabIds.mortgageInfo],
    forceRender: true,
    path: 'MortSignInfoForm/MortSingTab',
    component: () => MortSignInfo,
  },
  {
    groupId: tabIds.outEnterInfo,
    title: tabTitleMap[tabIds.outEnterInfo],
    forceRender: true,
    path: 'OutEnterLibraryInfoForm/OutEnterLibraryInfoForm',
    component: () => OutEnterInfo,
  },
  {
    groupId: tabIds.attachmentInfo,
    title: tabTitleMap[tabIds.attachmentInfo],
    forceRender: false,
    path: 'AttachmentInfoForm/AttachmentInfoForm',
    component: () => AttachmentInfo,
  },
]

export const OutEnterInfoGroup = {
  groupId: tabIds.outEnterInfo,
  title: tabTitleMap[tabIds.outEnterInfo],
  forceRender: true,
  path: 'OutEnterLibraryInfoForm/OutEnterLibraryInfoForm',
  component: () => OutEnterInfo,
}

export const ChangeInfoInGroup = {
  groupId: tabIds.changeLibraryInInfo,
  title: tabTitleMap[tabIds.changeLibraryInInfo],
  forceRender: true,
  path: 'ChangeLibraryInfoForm/ChangeInfoIn',
  component: () => ChangeInInfo,
}

export const ChangeInfoOutGroup = {
  groupId: tabIds.changeLibraryOutInfo,
  title: tabTitleMap[tabIds.changeLibraryOutInfo],
  forceRender: true,
  path: 'ChangeLibraryInfoForm/ChangeInfoOut',
  component: () => ChangeOutInfo,
}
export const approvalGroup = {
  groupId: tabIds.approvalInfo,
  title: tabTitleMap[tabIds.approvalInfo],
  forceRender: true,
  path: 'ApprovalForm/ApprovalForm',
  authority: PERMISSIONS.MODIFY,
  component: () => ApprovalInfo,
}

export const circulationGroup = {
  groupId: tabIds.circulationRecordInfo,
  title: tabTitleMap[tabIds.circulationRecordInfo],
  forceRender: false,
  path: 'BankAccountForm/BankAccountTable',
  authority: PERMISSIONS.READ,
  component: () => CirculationInfo,
}

export const flowChartGroup = {
  groupId: tabIds.flowChartInfo,
  title: tabTitleMap[tabIds.flowChartInfo],
  forceRender: false,
  path: 'BankAccountForm/BankAccountTable',
  component: () => FlowChartInfo,
}

export default CarPageGroups
