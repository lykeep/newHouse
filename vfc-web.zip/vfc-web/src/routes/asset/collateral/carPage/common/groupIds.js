import formIds from './formIds'

export const idTitleMap = {
  [formIds.pledgeInfo]: '押品信息',
  [formIds.carInfo]: '押品信息',
  [formIds.assessmentInfo]: '评估信息',
  [formIds.insuranceInfo]: '保险信息',
  [formIds.GPSInfo]: 'GPS信息',
  [formIds.mortgageInfo]: '抵/解押信息',
  [formIds.signInfo]: '抵/解押信息',
  [formIds.outEnterInfo]: '入库信息',
  [formIds.approvalInfo]: '审批信息',
  [formIds.changeLibraryOutInfo]: '变更信息（出入库）',
  [formIds.changeLibraryInInfo]: '变更信息（出入库）',
  [formIds.circulationRecordInfo]: '流转信息',
  [formIds.flowChartInfo]: '流程图',
  [formIds.attachmentInfo]: '附件信息',
}

export default formIds
