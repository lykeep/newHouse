import formIds from './formIds'

export const detailDataMap = {
  [formIds.pledgeInfo]: 'collateralInfo',
  [formIds.carInfo]: 'vehLeaseBaseInfo',
  [formIds.assessmentInfo]: 'collateralEvalInfo',
  [formIds.insuranceInfo]: 'collateralInsInfoList',
  [formIds.GPSInfo]: 'vehLeaseGpsInfo',
  [formIds.mortgageInfo]: 'vehLeaseMortInfo',
  [formIds.signInfo]: 'vehLeasetCustodyInfo',
  [formIds.outEnterInfo]: 'collateralOutStoInfo',
  [formIds.changeLibraryOutInfo]: 'grnteeChangeInfo',
  [formIds.changeLibraryInInfo]: 'grnteeChangeInfo',
  [formIds.approvalInfo]: 'approvalInfo',
  // [formIds.changeInfo]: 'changeInfo',
  // [formIds.circulationRecordInfo]: 'circulationRecordInfo',
  // [formIds.flowChartInfo]: 'flowChartInfo',
}

/*
 * 提交数据时，formId和request中的Map的Key的对应关系
 */
export default {
  [formIds.pledgeInfo]: 'collateralInfo',
  [formIds.carInfo]: 'vehLeaseBaseInfo',
  [formIds.assessmentInfo]: 'collateralEvalInfo',
  [formIds.insuranceInfo]: 'collateralInsInfoList',
  [formIds.GPSInfo]: 'vehLeaseGpsInfo',
  [formIds.mortgageInfo]: 'vehLeaseMortInfo',
  [formIds.signInfo]: 'vehLeasetCustodyInfo',
  [formIds.outEnterInfo]: 'collateralOutStoInfo',
  [formIds.changeLibraryOutInfo]: 'grnteeChangeInfo',
  [formIds.changeLibraryInInfo]: 'grnteeChangeInfo',
  [formIds.approvalInfo]: 'approvalInfo',
  // [formIds.changeInfo]: 'changeInfo',
  // [formIds.circulationRecordInfo]: 'circulationRecordInfo',
  // [formIds.flowChartInfo]: 'flowChartInfo',
}
