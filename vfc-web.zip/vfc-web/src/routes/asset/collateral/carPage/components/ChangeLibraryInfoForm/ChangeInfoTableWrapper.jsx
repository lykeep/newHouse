import React, { Component } from 'react'
import ChangeInfoTable from './ChangeInfoTable'

export default class ChangeInfoTableWrapper extends Component {
  shouldComponentUpdate() {
    return false
  }

  render() {
    return (<ChangeInfoTable {...this.props} />)
  }
}
