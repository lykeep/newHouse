import { createFetchAction } from 'modules/common'

const ASSET_COLLATERAL_OTHER_SAVE_MORTSIGN_INFO = 'ASSET_COLLATERAL_OTHER_SAVE_MORTSIGN_INFO'
const ASSET_COLLATERAL_OTHER_SAVE_ADD_MORTSIGN_INFO = 'ASSET_COLLATERAL_OTHER_SAVE_ADD_MORTSIGN_INFO'
export const saveMortSignInfo = createFetchAction(ASSET_COLLATERAL_OTHER_SAVE_MORTSIGN_INFO, 'vfc-intf-ent-asset.updateVehLeaseMortCustodyInfo')
export const saveAddMortSignInfo = createFetchAction(ASSET_COLLATERAL_OTHER_SAVE_ADD_MORTSIGN_INFO, 'vfc-intf-ent-asset.saveVehLeaseMortCustodyInfo')

export default {
  saveMortSignInfo,
  saveAddMortSignInfo,
}
