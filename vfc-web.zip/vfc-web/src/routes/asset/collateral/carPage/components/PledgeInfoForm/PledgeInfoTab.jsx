import React, { Component } from 'react'
import message from 'lbc-wrapper/lib/message'
import PledgeInfoForm from './PledgeInfoForm'
import CarInfoForm from './CarInfoForm'
import pageMode from '../../../../../../common/pageMode'
import pageType from '../../../../../../common/pageType'
import tabPageWrapper from '../../../../../../components/form/tabs/tabPageWrapper'
import GroupActions from '../../../../../../components/form/groups/GroupActions'
import PledgeInfoActionAjax from './PledgeInfoModule'
import reqMapIds from '../../common/reqMapIds'
import tabIds from '../../common/tabIds'
import { formTitleMap } from '../../common/formIds'

class PledgeInfoTab extends Component {
  constructor(props) {
    super(props)

    this.onSubmit = this.onSubmit.bind(this)

    this.actions = [
      {
        comp_id: 'submit',
        label: '保存',
        type: 'primary',
        onClick: this.onSubmit,
        id: 'submit',
      },
    ]
  }

  shouldComponentUpdate() {
    return false
  }

  onSubmit() {
    const { grnteeNbr, activeForms, saveCarPagePledgeInfo, addCarPagePledgeInfo, tabhelper } = this.props
    const resData = {}
    const parsed = tabhelper.getsearch()

    const promises = Object.keys(activeForms).map((key) => {
      return new Promise((resolve, reject) => {
        activeForms[key]().validateFields((errors, values) => {
          const type = key.split('@')[2]
          if (errors) {
            reject(formTitleMap[type])
          } else {
            resolve(Object.assign(resData, { [reqMapIds[type]]: Object.assign(values, { grnteeNbr }), grnteeNbr }))
          }
        })
      })
    })
    Promise.all(promises).then(() => {
      Object.assign(resData, { grnteeInsInfo: {
        grnteeType: parsed.grnteeType,
        grnteeObjType: '01',
      } })
      let retPromise = null
      if (parsed.m === pageMode.MODIFY && parsed.t === pageType.RECORD) {
        retPromise = saveCarPagePledgeInfo(resData)
      } else if (parsed.m === pageMode.CREATE && parsed.t === pageType.DRAFT) {
        retPromise = addCarPagePledgeInfo(resData)
      }
      retPromise.then(() => {
        message.success('保存成功')
      })
    }, (errMsgs) => {
      message.error(`${errMsgs}中的字段有错误，请检查`)
    })
  }

  render() {
    const parsed = this.props.tabhelper.getsearch()
    return (
      <div>
        <PledgeInfoForm {...this.props} />
        <CarInfoForm {...this.props} />
        {
          parsed.pt ? null : <GroupActions actions={this.actions} authority={this.props.authority} />
        }
      </div>
    )
  }
}

export default tabPageWrapper(tabIds.pledgeInfo, PledgeInfoActionAjax)(PledgeInfoTab)
