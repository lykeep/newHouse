import React, { Component } from 'react'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import PropTypes from 'prop-types'
import SelectField from '../../../../../../components/form/inputs/SelectField'
import InputField from '../../../../../../components/form/inputs/InputField'
import RadioField from '../../../../../../components/form/inputs/RadioField'
import DatePicker from '../../../../../../components/form/inputs/DatePickerField'

class ChangeInfoModal extends Component {
  constructor(props) {
    super(props)

    this.insAccountCreateName = [
      { key: '04', title: '机动车登记证', value: '04' },
      { key: '02', title: '存单', value: '02' },
      { key: '03', title: '票据', value: '03' },
      { key: '01', title: '保单', value: '01' },
      { key: '00', title: '房产证/土地证/不动产证/他项权利证', value: '00' },
      { key: '05', title: '国债', value: '05' },
      { key: '06', title: '股权/股票', value: '06' },
      { key: '07', title: '其它权利', value: '07' },
    ]

    this.priority = [
      { label: '原件', value: '00', key: '00' },
      { label: '复印件', value: '01', key: '01' },
    ]
  }

  render() {
    const { form, authority } = this.props
    return (
      <div>
        <Form>
          <Row gutter={16} type="flex" align="top">
            <InputField
              colSpan={12}
              form={form}
              authority={authority}
              name="grnteeVorNbr"
              key="grnteeVorNbr"
              formItemProps={{ label: '抵质押物凭证编号' }}
              fieldProps={{
                rules: [
                  { required: true, message: '抵质押物凭证编号是必输项！' },
                  { min: 1, max: 32, message: '长度为1-32' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                maxLength: 32,
              }}
            />
            <SelectField
              colSpan={12}
              key="grnteeVorType"
              form={form}
              name="grnteeVorType"
              authority={authority}
              formItemProps={{ label: '抵质押物凭证类型' }}
              fieldProps={{
                rules: [
                  { required: true, message: '抵质押物凭证类型是必输项！' },
                ],
              }}
              inputProps={{
                options: this.insAccountCreateName,
              }}
            />
            <RadioField
              colSpan={12}
              form={form}
              authority={authority}
              name="artType"
              key="artType"
              formItemProps={{ label: '交付物类型' }}
              fieldProps={{
                rules: [
                  { required: true, message: '交付物类型是必输项！' },
                ],
              }}
              inputProps={{
                placeholder: '请选择',
                options: this.priority,
              }}
            />
            <DatePicker
              colSpan={12}
              form={form}
              authority={authority}
              name="storageDate"
              key="storageDate"
              formItemProps={{ label: '入库时间' }}
              fieldProps={{
                rules: [
                  { required: true, message: '入库时间是必输项！' },
                ],
              }}
              inputProps={{
                placeholder: '请选择',
              }}
            />
          </Row>
        </Form>
      </div>
    )
  }
}

ChangeInfoModal.propTypes = {
  form: PropTypes.shape({
    getFieldDecorator: PropTypes.func.isRequired,
  }).isRequired,
  authority: PropTypes.string.isRequired,
}

export default Form.create()(ChangeInfoModal)
