import { createFetchAction } from 'modules/common'

const ASSET_COLLATERAL_SAVE_CARPAGE_INFO = 'ASSET_COLLATERAL_SAVE_CARPAGE_INFO'
const ASSET_COLLATEPAL_ADD_CARPAGE_INFO = 'ASSET_COLLATEPAL_ADD_CARPAGE_INFO'

export const saveCarPagePledgeInfo = createFetchAction(ASSET_COLLATERAL_SAVE_CARPAGE_INFO, 'vfc-intf-ent-asset.updateCollateralInfoCar')
export const addCarPagePledgeInfo = createFetchAction(ASSET_COLLATEPAL_ADD_CARPAGE_INFO, 'vfc-intf-ent-asset.saveCollateralInfoCar')

export default {
  saveCarPagePledgeInfo,
  addCarPagePledgeInfo,
}
