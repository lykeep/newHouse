import PropTypes from 'prop-types'
import React, { Component } from 'react'
import message from 'lbc-wrapper/lib/message'
import MortgageInfoForm from './MortgageInfoForm'
import SignInfoForm from './SignInfoForm'
import pageMode from '../../../../../../common/pageMode'
import pageType from '../../../../../../common/pageType'
import tabPageWrapper from '../../../../../../components/form/tabs/tabPageWrapper'
import GroupActions from '../../../../../../components/form/groups/GroupActions'
import saveMortSignAjax from './MortSignModule'
import reqMapIds from '../../common/reqMapIds'
import tabIds, { tabTitleMap } from '../../common/tabIds'

class MortSignTab extends Component {
  constructor(props) {
    super(props)

    this.onSubmit = this.onSubmit.bind(this)

    const parsed = props.tabhelper.getsearch()
    this.actions = parsed.m === pageMode.CREATE && parsed.t === pageType.DRAFT ? [] : [
      {
        comp_id: 'submit',
        label: '保存',
        type: 'primary',
        onClick: this.onSubmit,
        id: 'submit',
      },
    ]
  }

  onSubmit() {
    const { grnteeNbr, activeForms, saveMortSignInfo, saveAddMortSignInfo, tabhelper } = this.props
    const resData = {}
    const parsed = tabhelper.getsearch()
    const promises = Object.keys(activeForms).map((key) => {
      return new Promise((resolve, reject) => {
        activeForms[key]().validateFields((errors, values) => {
          const type = key.split('@')[2]
          if (errors) {
            reject(tabTitleMap[type])
          } else {
            resolve(Object.assign(resData, { [reqMapIds[type]]: values }, { grnteeNbr }))
          }
        })
      })
    })
    Promise.all(promises).then(() => {
      let retPromise = null
      if (parsed.m === pageMode.MODIFY && parsed.t === pageType.RECORD) {
        retPromise = saveMortSignInfo(resData)
      } else if (parsed.m === pageMode.CREATE && parsed.t === pageType.DRAFT) {
        retPromise = saveAddMortSignInfo(resData)
      }
      retPromise.then(() => {
        message.success('保存成功')
      })
    }, (errMsgs) => {
      message.error(`${errMsgs}中的字段有错误，请检查`)
    })
  }

  render() {
    const parsed = this.props.tabhelper.getsearch()
    return (
      <div>
        <MortgageInfoForm {...this.props} />
        <SignInfoForm {...this.props} />
        {
          parsed.pt ? null : <GroupActions actions={this.actions} authority={this.props.authority} />
        }
      </div>
    )
  }
}

MortSignTab.propTypes = {
  saveAddMortSignInfo: PropTypes.func,
  saveMortSignInfo: PropTypes.func,
  updatePledgeInfo: PropTypes.func,
  grnteeNbr: PropTypes.string,
  authority: PropTypes.string,
  tabhelper: PropTypes.shape({
    getsearch: PropTypes.func,
  }),
  activeForms: PropTypes.object,
}

export default tabPageWrapper(tabIds.mortgageInfo, saveMortSignAjax)(MortSignTab)
