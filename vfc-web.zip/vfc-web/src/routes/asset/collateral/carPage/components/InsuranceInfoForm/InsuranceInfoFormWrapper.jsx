import React, { Component } from 'react'
import InsuranceInfoForm from './InsuranceInfoTable'

export default class InsuranceInfoFormWrapper extends Component {
  shouldComponentUpdate() {
    return false
  }

  render() {
    return (<InsuranceInfoForm {...this.props} />)
  }
}
