import React, { Component } from 'react'
import PropTypes from 'prop-types'
import message from 'lbc-wrapper/lib/message'
import pageMode from '../../../../../../common/pageMode'
import pageType from '../../../../../../common/pageType'

import AssessmentInfo from '../../../../AssessmentInfoForm/AssessmentInfoForm'
import GroupActions from '../../../../../../components/form/groups/GroupActions'

import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import formIds from '../../common/formIds'
import AssessmentInfoAjaxActions from './AssessmentInfoModule'

class AssessmentInfocarInfo extends Component {
  constructor(props) {
    super(props)

    this.onSave = this.onSave.bind(this)
    const parsed = props.tabhelper.getsearch()
    this.actions = parsed.m === pageMode.CREATE && parsed.t === pageType.DRAFT ? [] : [
      {
        comp_id: 'submit',
        label: '保存',
        type: 'primary',
        onClick: this.onSave,
        id: 'submit',
      },
    ]
  }

  onSave() {
    const { grnteeNbr, form, saveCarPageAssessmentInfo, addCarPageAssessmentInfo } = this.props

    const { tabhelper } = this.props
    const parsed = tabhelper.getsearch()

    form.validateFields((errors, data) => {
      if (errors) {
        return
      }
      let retPromise = null
      if (parsed.m === pageMode.MODIFY && parsed.t === pageType.RECORD) {
        retPromise = saveCarPageAssessmentInfo({ collateralEvalInfo: Object.assign({}, data, { grnteeNbr }) })
      } else if (parsed.m === pageMode.CREATE && parsed.t === pageType.DRAFT) {
        retPromise = addCarPageAssessmentInfo({
          collateralEvalInfo: Object.assign({}, data, { grnteeNbr }),
        })
      }
      retPromise.then(() => {
        message.success('保存成功')
      })
    })
  }

  render() {
    const { authority, tabhelper, buyerPrc } = this.props

    const parsed = tabhelper.getsearch()
    return (
      <div>
        <AssessmentInfo buyerPrc={buyerPrc} {...this.props} readOnly />
        {
          parsed.pt ? null : <GroupActions actions={this.actions} authority={authority} />
        }
      </div>
    )
  }
}

AssessmentInfocarInfo.propTypes = {
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  data: PropTypes.object,
  buyerPrc: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
  ]),
  saveCarPageAssessmentInfo: PropTypes.func.isRequired,
  addCarPageAssessmentInfo: PropTypes.func.isRequired,
  tabhelper: PropTypes.shape({
    getsearch: PropTypes.func,
  }),
}

export default wrapFormContainer(formIds.assessmentInfo, '评估信息', AssessmentInfoAjaxActions, undefined, true)(AssessmentInfocarInfo)
