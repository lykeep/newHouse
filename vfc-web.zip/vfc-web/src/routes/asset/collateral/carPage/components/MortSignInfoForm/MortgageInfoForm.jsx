import MortgageInfoForm from '../../../MortSignComponent/MortgageInfoForm'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'

import formIds from '../../common/formIds'

export default wrapFormContainer(formIds.mortgageInfo, '抵押信息', true)(MortgageInfoForm)
