import React, { Component } from 'react'
import PledgeInfoContent from '../../../otherHypothecation/components/PledgeInfoForm/PledgeInfoContent'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import PledgeInfoAjaxActions from './PledgeInfoModule'

import formIds from '../../common/formIds'

class PledgeInfoForm extends Component {
  constructor(props) {
    super(props)

    this.state = {}
  }

  render() {
    return (
      <div>
        <PledgeInfoContent {...this.props} />
      </div>
    )
  }
}

export default wrapFormContainer(formIds.pledgeInfo, '押品信息', PledgeInfoAjaxActions, undefined, true)(PledgeInfoForm)
