import SignInfoForm from '../../../MortSignComponent/SignInfoForm'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'

import formIds from '../../common/formIds'

export default wrapFormContainer(formIds.signInfo, '解抵押信息', true)(SignInfoForm)
