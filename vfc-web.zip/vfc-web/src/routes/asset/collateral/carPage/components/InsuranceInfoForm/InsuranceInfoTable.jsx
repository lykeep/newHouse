import React, { Component } from 'react'
import PropTypes from 'prop-types'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import InsuranceInfoTable from '../../../../InsuranceInfoComponent/InsuranceInfoTable'
import InsInfoActions from './InsuranceInfoModule'

import formIds from '../../common/formIds'
import reqMapIds from '../../common/reqMapIds'

class InsuranceInfoForm extends Component {
  constructor(props) {
    super(props)

    this.createInsInfo = this.createInsInfo.bind(this)
    this.modifyInsInfo = this.modifyInsInfo.bind(this)
    this.deleteInsInfo = this.deleteInsInfo.bind(this)

    this.state = {
    }
  }

  createInsInfo(data) {
    const { grnteeNbr, createInsInfo, updateApplyList } = this.props

    return createInsInfo({
      collateralInsInfo: Object.assign({}, data, { grnteeNbr }),
      grnteeNbr,
    }).then((res) => {
      // 操作成功后，更新申请列表
      updateApplyList()
      return Promise.resolve(res)
    })
  }

  modifyInsInfo(data) {
    const { grnteeNbr, modifyInsInfo } = this.props
    return modifyInsInfo({
      collateralInsInfo: Object.assign({}, data, { grnteeNbr }),
    }).then((res) => {
      // 操作成功后，更新申请列表
      return Promise.resolve(res)
    })
  }

  deleteInsInfo(data) {
    const { grnteeNbr, deleteInsInfo, updateApplyList } = this.props

    return deleteInsInfo({
      grnteeNbr,
      plcyNbr: data.plcyNbr,
    }).then((res) => {
      updateApplyList()
      return Promise.resolve(res)
    })
  }

  render() {
    const { form, data, authority, tabhelper } = this.props

    const parsed = tabhelper.getsearch()
    return (
      <div>
        {parsed.pt ? <InsuranceInfoTable
          useAjax={false}
          form={form}
          authority={authority}
          data={data}
          name={reqMapIds[formIds.insuranceInfo]}
          getAssetNbr={this.props.getAssetNbr}
        /> : <InsuranceInfoTable
          useAjax
          rowKey="plcyNbr"
          form={form}
          authority={authority}
          data={data}
          createInsInfo={this.createInsInfo}
          modifyInsInfo={this.modifyInsInfo}
          deleteInsInfo={this.deleteInsInfo}
        />}
      </div>
    )
  }
}


InsuranceInfoForm.propTypes = {
  data: PropTypes.oneOfType([
    PropTypes.array,
    PropTypes.object,
  ]),
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  createInsInfo: PropTypes.func.isRequired,
  modifyInsInfo: PropTypes.func.isRequired,
  deleteInsInfo: PropTypes.func.isRequired,
  updateApplyList: PropTypes.func,
  grnteeNbr: PropTypes.string,
  getAssetNbr: PropTypes.func.isRequired,
  tabhelper: PropTypes.shape({
    getsearch: PropTypes.func,
  }),
}

export default wrapFormContainer(formIds.insuranceInfo, { title: '保险信息', mapActionCreators: InsInfoActions, dataIsArray: true })(InsuranceInfoForm)
