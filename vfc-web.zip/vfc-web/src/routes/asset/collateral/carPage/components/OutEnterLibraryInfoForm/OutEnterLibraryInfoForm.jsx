import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import Col from 'lbc-wrapper/lib/col'
import Table from 'lbc-wrapper/lib/table'
import InputField from '../../../../../../components/form/inputs/InputField'
import MoneyField from '../../../../../../components/form/inputs/MoneyField'
import SelectField from '../../../../../../components/form/inputs/SelectField'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import { currencyTypeSelectOptions } from '../../../../../../components/columnRenders/currencyType'
import formIds from '../../common/formIds'
import artTypeRender from '../../../../../../components/columnRenders/artType'
import grnteeVorTypeRender from '../../../../../../components/columnRenders/grnteeVorType'

class OutEnterLibraryInfoForm extends Component {
  constructor(props) {
    super(props)

    this.state = {
    }
    this.columns = [
      {
        title: '抵质押物凭证编号',
        dataIndex: 'grnteeVorNbr',
        key: 'grnteeVorNbr',
      }, {
        title: '抵质押物凭证类型',
        dataIndex: 'grnteeVorType',
        key: 'grnteeVorType',
        render: grnteeVorTypeRender,
      }, {
        title: '交付物类型',
        dataIndex: 'artType',
        key: 'artType',
        render: artTypeRender,
      }, {
        title: '入库时间',
        dataIndex: 'storageDate',
        key: 'storageDate',
      }, {
        title: '出库时间',
        dataIndex: 'outDate',
        key: 'outDate',
      }]
  }

  render() {
    const { form, data } = this.props
    const authority = '1'
    return (
      <div>
        <Form>
          <Row>
            <InputField
              form={form}
              authority={authority}
              name="grnteeName"
              key="grnteeName"
              formItemProps={{ label: '押品名称' }}
              fieldProps={{
                initialValue: data.grnteeName,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="relateUserName"
              key="relateUserName"
              formItemProps={{ label: '押品产权人' }}
              fieldProps={{
                initialValue: data.relateUserName,
              }}
            />
            <MoneyField
              form={form}
              authority={authority}
              name="aval"
              key="aval"
              formItemProps={{ label: '押品认定金额' }}
              fieldProps={{
                initialValue: data.aval,
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="currency"
              key="currency"
              formItemProps={{ label: '币种' }}
              fieldProps={{
                initialValue: data.currency,
              }}
              inputProps={{
                options: currencyTypeSelectOptions,
              }}
            />
            <Col span={24}>
              <Table
                dataSource={data.outStoInfo}
                columns={this.columns}
                rowKey="index"
                position="left"
                size="default"
                bordered
              />
            </Col>
          </Row>
        </Form>
      </div>
    )
  }
}

OutEnterLibraryInfoForm.propTypes = {
  form: PropTypes.object.isRequired,
  data: PropTypes.object,
}

export default wrapFormContainer(formIds.outEnterInfo, '入库信息', true)(OutEnterLibraryInfoForm)
