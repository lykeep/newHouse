import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import InputField from '../../../../../../components/form/inputs/InputField'
import InputNumberField from '../../../../../../components/form/inputs/InputNumberField'
import SelectField from '../../../../../../components/form/inputs/SelectField'
import RadioField from '../../../../../../components/form/inputs/RadioField'
import MoneyField from '../../../../../../components/form/inputs/MoneyField'
import DatePickerField from '../../../../../../components/form/inputs/DatePickerField'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import { validFrameNum, validFrameNumMessage, validMotorNum, validMotorNumMessage, validDrivingLicense, validDrivingLicenseMessage, validMileageDisplacement, validMileageDisplacementMessage, validYearAmt, validYearAmtMessage, validCarYear, validCarYearMessage, validMortgageCount, validMortgageCountMessage, validPlateNbr, validPlateNbrMessage } from '../../../../../../validators/common'

import formIds from '../../common/formIds'

class CarInfoForm extends Component {
  constructor(props) {
    super(props)

    this.buyerPrcChange = this.buyerPrcChange.bind(this)

    this.state = {}

    // 车辆类型-数据字典
    this.vehType = [
      { title: '大型车', value: '00', key: '00' },
      { title: '中型车', value: '01', key: '01' },
      { title: '小型车', value: '02', key: '02' },
      { title: '微型车', value: '03', key: '03' },
    ]
    // 内饰状况-数据字典
    this.trimCondition = [
      { title: '优', value: '01', key: '01' },
      { title: '良', value: '02', key: '02' },
      { title: '中', value: '03', key: '03' },
      { title: '差', value: '04', key: '04' },
      { title: '缺失', value: '05', key: '05' },
    ]
    // 漆面状况-数据字典
    this.paintCondition = [
      { title: '优', value: '01', key: '01' },
      { title: '良', value: '02', key: '02' },
      { title: '中', value: '03', key: '03' },
      { title: '差', value: '04', key: '04' },
      { title: '缺失', value: '05', key: '05' },
    ]
    // 工况状况-数据字典
    this.operatingCondition = [
      { title: '优', value: '01', key: '01' },
      { title: '良', value: '02', key: '02' },
      { title: '中', value: '03', key: '03' },
      { title: '差', value: '04', key: '04' },
      { title: '缺失', value: '05', key: '05' },
    ]
    // 是否本地牌照-数据字典
    this.localPlate = [
      { label: '是', value: '00', key: '00' },
      { label: '否', value: '01', key: '01' },
    ]
  }

  // 购买价格回显
  buyerPrcChange(value) {
    this.props.updateShopPrice(value)
  }

  render() {
    const { form, data, authority } = this.props

    return (
      <div>
        <Form>
          <Row gutter={16} type="flex" align="top">
            <SelectField
              form={form}
              authority={authority}
              name="vehType"
              key="vehType"
              formItemProps={{ label: '车辆类型' }}
              fieldProps={{
                initialValue: data.vehType,
              }}
              inputProps={{
                placeholder: '请选择',
                options: this.vehType,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="vinNbr"
              key="vinNbr"
              formItemProps={{ label: '车架号' }}
              fieldProps={{
                initialValue: data.vinNbr,
                rules: [
                  { required: true, message: '车架号是必输项！' },
                  { pattern: validFrameNum, message: validFrameNumMessage },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="vehBrand"
              key="vehBrand"
              formItemProps={{ label: '车辆品牌' }}
              fieldProps={{
                initialValue: data.vehBrand,
                rules: [
                  { required: true, message: '车辆品牌是必输项！' },
                  { min: 2, max: 32, message: '长度为2-32' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                maxLength: 32,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="plateNbr"
              formItemProps={{ label: '车牌号' }}
              fieldProps={{
                initialValue: data.plateNbr,
                rules: [
                  { pattern: validPlateNbr, message: validPlateNbrMessage },
                  { min: 4, max: 10, message: '长度为4-10' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                maxLength: 16,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="vehModel"
              key="vehModel"
              formItemProps={{ label: '车辆型号' }}
              fieldProps={{
                initialValue: data.vehModel,
                rules: [
                  { required: true, message: '车辆型号是必输项！' },
                  { min: 1, max: 128, message: '长度为1-128' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                maxLength: 128,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="scale"
              key="scale"
              formItemProps={{ label: '规格' }}
              fieldProps={{
                initialValue: data.scale,
                rules: [
                  { min: 2, max: 32, message: '长度为2-32' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                maxLength: 32,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="engineNbr"
              key="engineNbr"
              formItemProps={{ label: '发动机号' }}
              fieldProps={{
                initialValue: data.engineNbr,
                rules: [
                  { required: true, message: '发动机号是必输项！' },
                  { pattern: validMotorNum, message: validMotorNumMessage },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="drivLicense"
              key="drivLicense"
              formItemProps={{ label: '行驶证号' }}
              fieldProps={{
                initialValue: data.drivLicense,
                rules: [
                  { pattern: validDrivingLicense, message: validDrivingLicenseMessage },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <DatePickerField
              form={form}
              authority={authority}
              name="drivLicenseDue"
              key="drivLicenseDue"
              formItemProps={{ label: '行驶证有效期' }}
              fieldProps={{
                initialValue: data.drivLicenseDue,
              }}
              inputProps={{
                placeholder: '请选择',
              }}
            />
            <MoneyField
              form={form}
              authority={authority}
              name="buyerPrc"
              key="buyerPrc"
              formItemProps={{ label: '购买价格' }}
              fieldProps={{
                initialValue: data.buyerPrc,
                // rules: [
                //   { required: true, message: '购买价格是必输项！' },
                // ],
              }}
              inputProps={{
                placeholder: '请输入',
                onChange: this.buyerPrcChange,
              }}
            />
            <MoneyField
              form={form}
              authority={authority}
              name="nakedCarBuyPrice"
              key="nakedCarBuyPrice"
              formItemProps={{ label: '裸车价' }}
              fieldProps={{
                initialValue: data.nakedCarBuyPrice,
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <MoneyField
              form={form}
              authority={authority}
              name="guidePrice"
              key="guidePrice"
              formItemProps={{ label: '指导价' }}
              fieldProps={{
                initialValue: data.guidePrice,
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <InputNumberField
              form={form}
              authority={authority}
              name="roadHaul"
              key="roadHaul"
              formItemProps={{ label: '里程数(公里)' }}
              fieldProps={{
                initialValue: data.roadHaul,
                rules: [
                  { pattern: validMileageDisplacement, message: validMileageDisplacementMessage },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <InputNumberField
              form={form}
              authority={authority}
              name="vehDispl"
              key="vehDispl"
              formItemProps={{ label: '排量(L)' }}
              fieldProps={{
                initialValue: data.vehDispl,
                rules: [
                  { pattern: validMileageDisplacement, message: validMileageDisplacementMessage },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <DatePickerField
              form={form}
              authority={authority}
              name="carBuyDate"
              key="carBuyDate"
              formItemProps={{ label: '车辆购买日期' }}
              fieldProps={{
                initialValue: data.carBuyDate,
              }}
              inputProps={{
                placeholder: '请选择',
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="modelYear"
              key="modelYear"
              formItemProps={{ label: '年款' }}
              fieldProps={{
                initialValue: data.modelYear,
                rules: [
                  { pattern: validYearAmt, message: validYearAmtMessage },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <InputNumberField
              form={form}
              authority={authority}
              name="vehAge"
              key="vehAge"
              formItemProps={{ label: '车龄' }}
              fieldProps={{
                initialValue: data.vehAge,
                rules: [
                  { pattern: validCarYear, message: validCarYearMessage },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="vehOutColour"
              key="vehOutColour"
              formItemProps={{ label: '颜色-外观' }}
              fieldProps={{
                initialValue: data.vehOutColour,
                rules: [
                  { min: 2, max: 8, message: '长度为2-8' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                maxLength: 8,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="vehInColour"
              key="vehInColour"
              formItemProps={{ label: '颜色-内饰' }}
              fieldProps={{
                initialValue: data.vehInColour,
                rules: [
                  { min: 2, max: 8, message: '长度为2-8' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                maxLength: 8,
              }}
            />
            <DatePickerField
              form={form}
              authority={authority}
              name="releaseDate"
              key="releaseDate"
              formItemProps={{ label: '出厂日期' }}
              fieldProps={{
                initialValue: data.releaseDate,
              }}
              inputProps={{
                placeholder: '请选择',
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="trimCondition"
              key="trimCondition"
              formItemProps={{ label: '内饰状况' }}
              fieldProps={{
                initialValue: data.trimCondition,
              }}
              inputProps={{
                placeholder: '请选择',
                options: this.trimCondition,
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="paintCondition"
              key="paintCondition"
              formItemProps={{ label: '漆面状况' }}
              fieldProps={{
                initialValue: data.paintCondition,
              }}
              inputProps={{
                placeholder: '请选择',
                options: this.paintCondition,
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="operatingCondition"
              key="operatingCondition"
              formItemProps={{ label: '工况状态' }}
              fieldProps={{
                initialValue: data.operatingCondition,
              }}
              inputProps={{
                placeholder: '请选择',
                options: this.operatingCondition,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="vehOwnerAddr"
              key="vehOwnerAddr"
              formItemProps={{ label: '车辆归属地' }}
              fieldProps={{
                initialValue: data.vehOwnerAddr,
                rules: [
                  { min: 2, max: 128, message: '长度为2-128' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                maxLength: 128,
              }}
            />
            <RadioField
              form={form}
              authority={authority}
              name="localPlate"
              key="localPlate"
              formItemProps={{ label: '是否本地牌照' }}
              fieldProps={{
                initialValue: data.localPlate,
              }}
              inputProps={{
                placeholder: '请输入',
                options: this.localPlate,
              }}
            />
            <DatePickerField
              form={form}
              authority={authority}
              name="firstRegDate"
              key="firstRegDate"
              formItemProps={{ label: '初次上牌日期' }}
              fieldProps={{
                initialValue: data.firstRegDate,
              }}
              inputProps={{
                placeholder: '请选择',
              }}
            />
            <DatePickerField
              form={form}
              authority={authority}
              name="lastRegDate"
              key="lastRegDate"
              formItemProps={{ label: '最后上牌日期' }}
              fieldProps={{
                initialValue: data.lastRegDate,
              }}
              inputProps={{
                placeholder: '请选择',
              }}
            />
            <InputNumberField
              form={form}
              authority={authority}
              name="pledgeNo"
              key="pledgeNo"
              formItemProps={{ label: '抵押次数' }}
              fieldProps={{
                initialValue: data.pledgeNo,
                rules: [
                  { pattern: validMortgageCount, message: validMortgageCountMessage },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <InputNumberField
              form={form}
              authority={authority}
              name="transferNo"
              key="transferNo"
              formItemProps={{ label: '过户次数' }}
              fieldProps={{
                initialValue: data.transferNo,
                rules: [
                  { pattern: validMortgageCount, message: validMortgageCountMessage },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
          </Row>
        </Form>
      </div>
    )
  }
}

CarInfoForm.propTypes = {
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  data: PropTypes.object,
  updateShopPrice: PropTypes.func,
}

export default wrapFormContainer(formIds.carInfo, { title: '车辆信息', mustValidate: true })(CarInfoForm)
