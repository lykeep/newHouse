import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import FileUploadTree from '../../../../../../components/form/fileUpload/FileUploadTree'
import operType from '../../../../../../common/filesOperType'

class AttachmentInfoForm extends PureComponent {
  render() {
    const { authority, grnteeNbr } = this.props

    const operTypeCurr = operType.COLLATERAL_CAR_DETAIL
    return (
      <FileUploadTree
        authority={authority}
        bizKey={grnteeNbr}
        operType={operTypeCurr}
      />
    )
  }
}

AttachmentInfoForm.propTypes = {
  authority: PropTypes.string.isRequired,
  grnteeNbr: PropTypes.string.isRequired,
}

export default AttachmentInfoForm
