import React, { Component } from 'react'
import OutEnterLibraryInfoForm from './OutEnterLibraryInfoForm'

export default class OutEnterLibraryInfoFormWrapper extends Component {
  shouldComponentUpdate() {
    return false
  }

  render() {
    return (<OutEnterLibraryInfoForm {...this.props} />)
  }
}
