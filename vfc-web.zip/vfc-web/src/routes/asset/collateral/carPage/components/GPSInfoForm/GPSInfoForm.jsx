import React, { Component } from 'react'
import PropTypes from 'prop-types'
import message from 'lbc-wrapper/lib/message'
import pageMode from '../../../../../../common/pageMode'
import pageType from '../../../../../../common/pageType'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import GroupActions from '../../../../../../components/form/groups/GroupActions'
import GPSInfoAjaxActions from './GPSInfoModule'
import GPSInfoForm from '../../../../GPSInfoComponent/GPSInfoForm'

import formIds from '../../common/formIds'

class GPSInfoFormCom extends Component {
  constructor(props) {
    super(props)

    this.onSave = this.onSave.bind(this)

    this.state = {
    }

    const parsed = props.tabhelper.getsearch()
    this.actions = parsed.m === pageMode.CREATE && parsed.t === pageType.DRAFT ? [] : [
      {
        id: 'save',
        label: '保存',
        type: 'primary',
        onClick: this.onSave,
      },
    ]
  }

  onSave() {
    const { grnteeNbr, form, saveCarPageGPSInfo, addCarPageGPSInfo } = this.props
    const { tabhelper } = this.props
    const parsed = tabhelper.getsearch()

    form.validateFields((errors, data) => {
      if (errors) {
        return
      }
      let retPromise = null
      if (parsed.m === pageMode.MODIFY && parsed.t === pageType.RECORD) {
        retPromise = saveCarPageGPSInfo({ vehLeaseGpsInfo: Object.assign({}, data, { grnteeNbr }) })
      } else if (parsed.m === pageMode.CREATE && parsed.t === pageType.DRAFT) {
        retPromise = addCarPageGPSInfo({
          vehLeaseGpsInfo: Object.assign({}, data, { grnteeNbr }),
        })
      }
      retPromise.then(() => {
        message.success('保存成功')
      })
    })
  }

  render() {
    const { form, data, authority, tabhelper } = this.props
    const parsed = tabhelper.getsearch()
    return (
      <div>
        <GPSInfoForm
          form={form}
          data={data}
          authority={authority}
        />
        {
          parsed.pt ? null : <GroupActions actions={this.actions} authority={authority} />
        }
      </div>
    )
  }
}

GPSInfoFormCom.propTypes = {
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  data: PropTypes.object,
  grnteeNbr: PropTypes.string,
  saveCarPageGPSInfo: PropTypes.func,
  addCarPageGPSInfo: PropTypes.func,
  tabhelper: PropTypes.shape({
    getsearch: PropTypes.func,
  }),
}

export default wrapFormContainer(formIds.GPSInfo, 'GPS信息', GPSInfoAjaxActions)(GPSInfoFormCom)
