import { createFetchAction } from 'modules/common'

const ASSET_COLLATERAL_SAVE_CARPAGE_ASSESSMENT_INFO = 'ASSET_COLLATERAL_SAVE_CARPAGE_ASSESSMENT_INFO'
const ASSET_COLLATERAL_ADD_CARPAGE_ASSESSMENT_INFO = 'ASSET_COLLATERAL_ADD_CARPAGE_ASSESSMENT_INFO'

export const saveCarPageAssessmentInfo = createFetchAction(ASSET_COLLATERAL_SAVE_CARPAGE_ASSESSMENT_INFO, 'vfc-intf-ent-asset.updateCollateralEvalInfo')
export const addCarPageAssessmentInfo = createFetchAction(ASSET_COLLATERAL_ADD_CARPAGE_ASSESSMENT_INFO, 'vfc-intf-ent-asset.saveCollateralEvalInfo')

export default {
  saveCarPageAssessmentInfo,
  addCarPageAssessmentInfo,
}
