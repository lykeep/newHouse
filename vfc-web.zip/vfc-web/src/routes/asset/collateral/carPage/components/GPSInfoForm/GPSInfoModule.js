import { createFetchAction } from 'modules/common'

const ASSET_LEASEITEM_SAVE_GPS_INFO = 'ASSET_LEASEITEM_SAVE_GPS_INFO'
const ASSET_LEASEITEM_ADD_GPS_INFO = 'ASSET_LEASEITEM_ADD_GPS_INFO'

export const addCarPageGPSInfo = createFetchAction(ASSET_LEASEITEM_ADD_GPS_INFO, 'vfc-intf-ent-asset.saveGPSInfo')
export const saveCarPageGPSInfo = createFetchAction(ASSET_LEASEITEM_SAVE_GPS_INFO, 'vfc-intf-ent-asset.updateGPSInfo')

export default {
  addCarPageGPSInfo,
  saveCarPageGPSInfo,
}
