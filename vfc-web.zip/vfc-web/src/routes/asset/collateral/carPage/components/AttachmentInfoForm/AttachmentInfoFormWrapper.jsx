import React, { Component } from 'react'
import AttachmentInfoForm from './AttachmentInfoForm'

export default class AttachmentInfoFormWrapper extends Component {
  shouldComponentUpdate() {
    return false
  }

  render() {
    return (<AttachmentInfoForm {...this.props} />)
  }
}
