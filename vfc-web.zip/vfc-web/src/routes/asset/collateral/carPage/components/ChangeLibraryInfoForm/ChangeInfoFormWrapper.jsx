import React, { Component } from 'react'
import ChangeInfoForm from './ChangeInfoForm'

export default class ChangeInfoFormWrapper extends Component {
  shouldComponentUpdate() {
    return false
  }

  render() {
    return (<ChangeInfoForm {...this.props} />)
  }
}
