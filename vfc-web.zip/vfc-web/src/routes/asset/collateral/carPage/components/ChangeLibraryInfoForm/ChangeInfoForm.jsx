import React, { Component } from 'react'
import PropTypes from 'prop-types'
import _debug from 'lb-debug'
import message from 'lbc-wrapper/lib/message'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import operType from '../../../../../../common/filesOperType'
import pageMode from '../../../../../../common/pageMode'
import pageType from '../../../../../../common/pageType'
import formIds from '../../common/formIds'
import { PERMISSIONS } from '../../../../../../components/form/utils/calPermission'
import SelectField from '../../../../../../components/form/inputs/SelectField'
import TextareaField from '../../../../../../components/form/inputs/TextareaField'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import GroupActions from '../../../../../../components/form/groups/GroupActions'
import ChangeInfoAjaxActions from './ChangeInfoModule'

import { assetCollateralApplyType } from '../../../../../../common/bizApplyType/asset'

import FileUploadModal from '../../../../../../components/form/fileUpload/FileUploadModal'

const debug = _debug('MortSignTab')

class ChangeInfoForm extends Component {
  constructor(props) {
    super(props)

    this.onSave = this.onSave.bind(this)

    this.applyType = [
      { title: '入库', value: '02', key: '02' },
      { title: '出库', value: '01', key: '01' },
    ]

    this.actions = [
      {
        comp_id: 'submit',
        label: '保存',
        type: 'primary',
        onClick: this.onSave,
        id: 'submit',
      },
    ]
  }

  onSave() {
    const { grnteeNbr, applyType, businessKey, addChangeInfo, editChangeInfo, tabhelper, form } = this.props
    const parsed = tabhelper.getsearch()

    form.validateFields((errors, data) => {
      if (errors) {
        debug(errors)
        return
      }
      let retPromise = null
      if (parsed.m === pageMode.CREATE && (assetCollateralApplyType.IN || parsed.at === assetCollateralApplyType.OUT)) {
        retPromise = addChangeInfo(Object.assign({}, data, { grnteeNbr, applyType, businessKey }))
      } else if (parsed.m === pageMode.MODIFY && (assetCollateralApplyType.IN || parsed.at === assetCollateralApplyType.OUT)) {
        retPromise = editChangeInfo(Object.assign({}, data, { grnteeNbr, applyType, businessKey }))
      }
      retPromise.then(() => {
        message.success('保存成功')
      })
    })
  }

  render() {
    const { form, data, applyType, grnteeNbr, businessKey, authority } = this.props
    const operTypeCurr = operType.COLLATERAL_OTHER_OUT
    return (
      <div>
        <Form>
          <Row gutter={16} type="flex" align="top">
            <SelectField
              form={form}
              authority={PERMISSIONS.READ}
              name="applyType"
              key="applyType"
              formItemProps={{ label: '变更类型' }}
              fieldProps={{
                initialValue: applyType,
              }}
              inputProps={{
                placeholder: '请选择',
                options: this.applyType,
                disabled: true,
              }}
            />
          </Row>
          <Row>
            <Form.Item label="附件上传" read={authority}>
              {
                <FileUploadModal
                  authority={authority}
                  bizKey={grnteeNbr}
                  processKey={businessKey}
                  operType={operTypeCurr}
                />
              }
            </Form.Item>
            <TextareaField
              colSpan={24}
              form={form}
              authority={authority}
              name="remark"
              key="remark"
              formItemProps={{ label: '备注' }}
              fieldProps={{
                initialValue: data.remark,
                rules: [
                  { min: 1, max: 512, message: '长度在1-512位之间' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                maxLength: 512,
              }}
            />
          </Row>
          <GroupActions actions={this.actions} authority={authority} />
        </Form>
      </div>
    )
  }
}

ChangeInfoForm.propTypes = {
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  data: PropTypes.object,
  grnteeNbr: PropTypes.string,
  applyType: PropTypes.string,
  businessKey: PropTypes.string,
  addChangeInfo: PropTypes.func,
  editChangeInfo: PropTypes.func,
  tabhelper: PropTypes.object,
}

export default wrapFormContainer(formIds.changeLibraryOutInfo, '变更信息', ChangeInfoAjaxActions, undefined, true)(ChangeInfoForm)
