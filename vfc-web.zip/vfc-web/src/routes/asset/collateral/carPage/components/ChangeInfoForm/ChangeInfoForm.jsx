import ChangeInfoForm from '../../../../../../components/workflow/ChangeInfoForm'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import basicInfoAjaxActions from './ChangeInfoModule'
import formIds from '../../common/formIds'

export default wrapFormContainer(formIds.changeInfo, '变更信息', basicInfoAjaxActions, undefined, true)(ChangeInfoForm)
