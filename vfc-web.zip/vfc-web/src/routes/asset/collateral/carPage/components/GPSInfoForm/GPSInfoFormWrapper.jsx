import React, { Component } from 'react'
import GPSInfoForm from './GPSInfoForm'

export default class GPSInfoFormWrapper extends Component {
  shouldComponentUpdate() {
    return false
  }

  render() {
    return (<GPSInfoForm {...this.props} />)
  }
}
