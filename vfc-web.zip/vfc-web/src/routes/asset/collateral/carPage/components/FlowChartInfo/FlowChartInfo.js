import ChangeInfoForm from '../../../../../../components/workflow/FlowChartForm/FlowChartTab'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import formIds from '../../common/formIds'

export default wrapFormContainer(formIds.flowChartInfo, '流程图')(ChangeInfoForm)
