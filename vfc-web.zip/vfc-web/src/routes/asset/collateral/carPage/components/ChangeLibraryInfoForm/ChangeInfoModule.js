import { createFetchAction, createAction } from '../../../../../../modules/common'

const ASSET_COLLATERAL_ADD_CHANGE_INFO = 'ASSET_COLLATERAL_ADD_CHANGE_INFO'
const ASSET_COLLATERAL_EDIT_CHANGE_INFO = 'ASSET_COLLATERAL_EDIT_CHANGE_INFO'
const ASSET_COLLATERAL_CREATE_CHANGE_INFO = 'ASSET_COLLATERAL_CREATE_CHANGE_INFO'
const ASSET_COLLATERAL_MODIFY_CHANGE_INFO = 'ASSET_COLLATERAL_MODIFY_CHANGE_INFO'
const ASSET_COLLATERAL_DELETE_CHANGE_INFO = 'ASSET_COLLATERAL_DELETE_CHANGE_INFO'

export const addChangeInfo = createFetchAction(ASSET_COLLATERAL_ADD_CHANGE_INFO, 'vfc-intf-ent-asset.saveGrnteeDraft')
export const editChangeInfo = createFetchAction(ASSET_COLLATERAL_EDIT_CHANGE_INFO, 'vfc-intf-ent-asset.updateGrnteeDraft')
export const createChangeInfo = createAction(ASSET_COLLATERAL_CREATE_CHANGE_INFO)
export const modifyChangeInfo = createAction(ASSET_COLLATERAL_MODIFY_CHANGE_INFO)
export const deleteChangeInfo = createAction(ASSET_COLLATERAL_DELETE_CHANGE_INFO)

export default {
  addChangeInfo,
  editChangeInfo,
  createChangeInfo,
  modifyChangeInfo,
  deleteChangeInfo,
}
