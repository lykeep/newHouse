import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'

import CarInfoComp from '../components/CarApprovalPage'

import pageActions from '../modules/approvalPageModules'

import {
  taskCompleted,
  queryWorkflowDetail,
} from '../../../../../../modules/workflow'

const mapActionCreators = {
  ...pageActions,
  taskCompleted,
  queryWorkflowDetail,
}

const mapStateToProps = () => ({})

export default withRouter(connect(mapStateToProps, mapActionCreators)(CarInfoComp))
