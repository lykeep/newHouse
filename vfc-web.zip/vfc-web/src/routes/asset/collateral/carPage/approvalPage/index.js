import loadable from '../../../../../utils/loadable'

export default () =>
// 必需返回Loadable这个High order component
// 在这里动态更新store和加载相应的组件
  loadable(() => import('./containers/approvalPageContainers'))
