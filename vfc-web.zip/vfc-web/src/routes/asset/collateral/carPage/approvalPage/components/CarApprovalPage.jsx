import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import _debug from 'lb-debug'
import message from 'lbc-wrapper/lib/message'
import Spin from 'lbc-wrapper/lib/spin'

import pageContainerWrapper from '../../../../../../components/form/page/PageContainerWrapper'
import PageContainerHeader from '../../../../../../components/form/page/PageContainerHeader'

import PageLoader from '../../../../../../components/form/page/PageLoader'
import pageMode from '../../../../../../common/pageMode'
import { formTitleMap } from '../../common/formIds'
import { PERMISSIONS } from '../../../../../../components/form/utils/calPermission'
import groups, { ChangeInfoOutGroup, ChangeInfoInGroup, OutEnterInfoGroup, approvalGroup, circulationGroup, flowChartGroup } from '../../common/groups'
import calculateGroups, { shouldCallBigSive } from '../../../../../../components/form/groups/calculateGroups'
import SubmitFlow, { shouldOpenSubmitModal } from '../../../../../../components/workflow/submitFlow/SubmitFlow'
import reqMapIds, { detailDataMap } from '../../common/reqMapIds'
import groupIds from '../../common/groupIds'
import { handleStatus } from '../../../../../../common/workflow'
import emptyFunc from '../../../../../../utils/emptyFunc'

import { COLLATERAL_UPDATE_APPROVE_LIST } from '../../../common/tabAction'
import { PID_ASSET_CARPAGE_INFO_APPROVAL } from '../../../../../../common/pageIds'
import { assetCollateralApplyType, assetCollateralApplyTypeLabels } from '../../../../../../common/bizApplyType/asset'
import makeTitle from '../../../../../../utils/makeTitle'

const debug = _debug('CarApprovalPage')

class CarApprovalPage extends PureComponent {
  constructor(props) {
    super(props)

    this.onSubmit = this.onSubmit.bind(this)
    this.updateApproveList = this.updateApproveList.bind(this)
    this.doSubmit = this.doSubmit.bind(this)
    this.submitDone = this.submitDone.bind(this)
    this.nextStepOK = this.nextStepOK.bind(this)
    this.updateShopPrice = this.updateShopPrice.bind(this)

    const parsed = props.tabhelper.getsearch()

    this.tabItem = groups

    /*
     * 如果是变更页面，则加入变更信息tab页
     */
    if (parsed.at === assetCollateralApplyType.OUT) {
      this.tabItem = this.tabItem.concat(ChangeInfoOutGroup)
    } else if (parsed.at === assetCollateralApplyType.IN) {
      this.tabItem = this.tabItem.concat(ChangeInfoInGroup)
    }

    if (parsed.m !== pageMode.VIEW) {
      this.tabItem = this.tabItem.concat(approvalGroup)
    }

    if (parsed.pt) {
      this.tabItem = this.tabItem.filter(g => g.groupId !== OutEnterInfoGroup.groupId)
    }

    this.tabItem = this.tabItem.concat(circulationGroup, flowChartGroup)

    this.state = {
      loading: true,
      submiting: false,
      grnteeNbr: parsed.bid,
      groups: [], // 页面tab信息
      data: {}, // 业务数据
      workflowActions: [], // 流程可进行操作
      backNodeList: [], // 可退回节点
      businessKey: '',
      applyType: '',
      nextActivity: {
        assignStrategy: '',
        nodeList: [],
        userList: [],
      }, // 下一节点处理策略
      callBigSave: false, // 默认不调用大保存
      buyerPrc: '',
    }

    this.actions = parsed.m === pageMode.VIEW ? [] : [
      {
        comp_id: 'submit',
        label: '提交',
        type: 'primary',
        onClick: this.onSubmit,
        key: 'submit',
      },
    ]
  }

  componentDidMount() {
    /*
     * 页面开始后，需要去后台取相关信息：
     * 1，group 信息
     * 2，业务数据
     * 3，流程流转信息
     */
    const { queryWorkflowDetail, tabhelper, querycarPageDetailOutChange, querycarPageDetailInChange } = this.props
    tabhelper.closeothersamepathtab()
    const parsed = this.props.tabhelper.getsearch()

    const queryFunc = parsed.at === assetCollateralApplyType.OUT ? querycarPageDetailOutChange : querycarPageDetailInChange

    /*
     * 如果pageMode是view，则从申请列表进入
     * 否则是从审核列表进入
     */
    if (parsed.m === pageMode.VIEW) {
      // 从申请列表进入，调用查询草稿接口查详情
      querycarPageDetailOutChange({
        businessKey: parsed.bpid,
      }).then((data) => {
        this.setState({
          data: data.grnteeDetUnit,
          loading: false,
          applyType: parsed.at,
          grnteeNbr: parsed.bid,
          businessKey: parsed.bpid,
          procInstanceId: parsed.pid,
          groups: this.tabItem.map(t => ({ group_id: t.groupId, authority: PERMISSIONS.READ })),
        })
      })
    } else {
      const queryDetailPro = queryFunc({
        businessKey: parsed.bpid,
      })
      const queryFlowPro = queryWorkflowDetail({
        taskInstanceId: parsed.tid,
      })

      Promise.all([queryDetailPro, queryFlowPro]).then((result) => {
        const [bizObj, data] = result

        const commonGroups = data.statusType === handleStatus.NOT_DONE ? [approvalGroup, circulationGroup, flowChartGroup] : [circulationGroup, flowChartGroup]
        this.actions = handleStatus.NOT_DONE === data.statusType ? this.actions : []

        this.setState({
          loading: false,
          procInstanceId: parsed.pid,
          taskInstanceId: parsed.tid,
          businessProcessNo: parsed.bpid,
          groups: calculateGroups(this.tabItem, data.formControl.inputElementList).concat(commonGroups), // 页面tab信息
          data: bizObj.grnteeDetUnit, // 业务数据
          workflowActions: data.actionTypeAllowed, // 流程可进行操作
          backNodeList: data.backNodeList, // 可退回节点
          businessKey: parsed.bpid,
          applyType: parsed.at,
          callBigSave: shouldCallBigSive(data.formControl.inputElementList),
          nextActivity: data.nextActivityVO, // 下一节点处理策略
        })
      }).catch(() => {
      })
    }
  }

  // onSubmit() {
  //   const { activeForms } = this.props
  //
  //   this.setState({
  //     submiting: true,
  //   })
  //
  //   const promises = Object.keys(this.props.activeForms).map(key => new Promise((resolve, reject) => {
  //     activeForms[key]().validateFields((errors, values) => {
  //       if (errors) {
  //         reject(formTitleMap[key])
  //       } else {
  //         resolve({
  //           [reqMapIds[key]]: Object.assign({}, values, { grnteeNbr: this.state.data.grnteeNbr }),
  //         })
  //       }
  //     })
  //   }))
  //
  //   Promise.all(promises).then(this.doSubmit, (errMsgs) => {
  //     this.setState({
  //       submiting: false,
  //     })
  //     message.error(`${errMsgs}中的字段有错误，请检查`)
  //   }).catch((e) => { debug(e) })
  // }

  onSubmit() {
    const { activeForms, mustValidateForms, retrieveAllData, tabhelper } = this.props
    const parsed = tabhelper.getsearch()

    this.setState({
      submiting: true,
    })

    const promises = retrieveAllData(activeForms, mustValidateForms, reqMapIds, formTitleMap, values => Object.assign({}, values, { grnteeNbr: this.state.data.grnteeNbr, grnteeType: parsed.grnteeType }))

    Promise.all(promises).then(this.doSubmit, (errMsgs) => {
      this.setState({
        submiting: false,
      })
      this.pageLoader.displayMe(errMsgs.key)
      message.error(`${errMsgs.message}中的字段有错误，请检查`)
    }).catch((e) => { debug(e) })
  }

  updateShopPrice(values) {
    this.setState({
      buyerPrc: values,
    })
  }

  doSubmit(values) {
    const { nextActivity } = this.state
    const { bigSave, tabhelper } = this.props
    const parsed = tabhelper.getsearch()

    let reqValue = {}
    values.forEach((v) => {
      reqValue = Object.assign(reqValue, v)
    })

    const reqData = reqValue.grnteeChangeInfo
    /*
     * 先做大保存
     * 然后再提交流程
     */
    const savePromise = this.state.callBigSave ? bigSave({
      ...reqData,
      businessKey: this.state.businessKey,
      applyType: parsed.at,
      grnteeNbr: parsed.bid,
      ...reqValue,
    }) : Promise.resolve()

    savePromise.then(() => {
      const approvalData = reqValue[reqMapIds[groupIds.approvalInfo]]
      /*
       * 如果后续分配策略是自动分配或收工领取，则直接可以结束了
       * 否则，就显示人工选择的弹框
       */
      if (!shouldOpenSubmitModal(nextActivity, approvalData.actionType)) {
        this.props.taskCompleted({
          actionType: approvalData.actionType,
          assignStrategy: this.state.nextActivity.assignStrategy,
          comment: approvalData.comment,
          targetTaskDefKey: approvalData.targetTaskDefKey,
          orgPath: approvalData.orgPath, // 2018-09-17, 标识是否退回提交后原路返回
          taskInstanceId: this.state.taskInstanceId,
        }).then(() => {
          this.submitDone()
        }).catch(() => {
          this.setState({
            submiting: false,
          })
        })
      } else {
        this.submitModal.open({
          backNodeList: this.state.backNodeList,
          assignStrategy: this.state.nextActivity.assignStrategy,
          nextNodeList: this.state.nextActivity.nodeList,
          userList: this.state.nextActivity.userList,
          actionTypeAllowed: approvalData.actionType,
          comment: approvalData.comment,
          successCallback: this.submitDone,
          failCallback: () => this.setState({ submiting: false }),
          taskInstId: parsed.tid,
        })
      }
    }).catch(() => {
      this.setState({
        submiting: false,
      })
    })
  }

  nextStepOK(value) {
    this.submitDone(value)
  }

  submitDone(data) {
    this.setState({
      submiting: false,
    }, () => {
      this.updateApproveList(data)
      message.success('提交成功')
      this.props.tabhelper.closetab()
    })
  }

  /*
   * 在提交的时候，要刷新审批列表
   */
  updateApproveList() {
    const { tabhelper } = this.props

    tabhelper.dispatch(COLLATERAL_UPDATE_APPROVE_LIST)
  }

  render() {
    const { loading, backNodeList, workflowActions, procInstanceId } = this.state
    const { tabhelper } = this.props
    const parsed = tabhelper.getsearch()
    return (
      <div>
        <Spin spinning={this.state.submiting} delay={20}>
          <PageContainerHeader title={makeTitle('车辆页', assetCollateralApplyTypeLabels[parsed.at], true, this.state.businessProcessNo, this.state.bizKey)} actions={this.actions} loading={this.state.loading} submiting={this.state.submiting} />
          <PageLoader
            ref={r => (this.pageLoader = r)}
            tabs={this.tabItem}
            groups={this.state.groups}
            data={this.state.data}
            loading={loading}
            grnteeNbr={this.state.grnteeNbr}
            businessKey={this.state.businessKey}
            applyType={this.state.applyType}
            updateApproveList={this.updateApproveList}
            updateApplyList={emptyFunc}
            workflowActions={workflowActions}
            procInstanceId={procInstanceId}
            backNodeList={backNodeList}
            groupIdToDataMap={detailDataMap}
            defaultSelectedKey={approvalGroup.groupId}
            tabhelper={this.props.tabhelper}
            buyerPrc={this.state.buyerPrc}
            updateShopPrice={this.updateShopPrice}
          />
          <SubmitFlow
            ref={r => (this.submitModal = r)}
            loading={loading}
            taskCompleteAction={this.props.submitApproval}
            successCallback={this.submitDone}
            failCallback={this.submitDone}
          />
        </Spin>
      </div>
    )
  }
}

CarApprovalPage.propTypes = {
  submitApproval: PropTypes.func.isRequired,
  queryWorkflowDetail: PropTypes.func,
  querycarPageDetailOutChange: PropTypes.func,
  querycarPageDetailInChange: PropTypes.func,
  bigSave: PropTypes.func,
  taskCompleted: PropTypes.func,
  tabhelper: PropTypes.shape({
    closetab: PropTypes.func,
    subscribe: PropTypes.func,
    dispatch: PropTypes.func,
    getsearch: PropTypes.func,
  }),
  activeForms: PropTypes.object,
  mustValidateForms: PropTypes.object,
  retrieveAllData: PropTypes.func,
}

export default pageContainerWrapper({ name: PID_ASSET_CARPAGE_INFO_APPROVAL })(CarApprovalPage)
