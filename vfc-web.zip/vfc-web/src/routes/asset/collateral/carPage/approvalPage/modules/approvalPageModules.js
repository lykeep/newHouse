import { createFetchAction } from '../../../../../../modules/common'

// 新建草稿取业务id和流程id
const ASSET_COLLATEARL_CARPAGE_INFO_QUERY_WORK_FLOW_DETAIL = 'ASSET_COLLATEARL_CARPAGE_INFO_QUERY_WORK_FLOW_DETAIL'

// 提交审批
const ASSET_COLLATEARL_CARPAGE_INFO_SUBMIT_APPROVAL = 'ASSET_COLLATEARL_CARPAGE_INFO_SUBMIT_APPROVAL'

const ASSET_COLLATERAL_CARPAGE_IN_INFO_QUERY_WORK_FLOW_DETAIL = 'ASSET_COLLATERAL_CARPAGE_IN_INFO_QUERY_WORK_FLOW_DETAIL'
const ASSET_COLLATERAL_CARPAGE_OUT_INFO_QUERY_WORK_FLOW_DETAIL = 'ASSET_COLLATERAL_CARPAGE_OUT_INFO_QUERY_WORK_FLOW_DETAIL'


export const bigSave = createFetchAction(ASSET_COLLATEARL_CARPAGE_INFO_QUERY_WORK_FLOW_DETAIL, 'vfc-intf-ent-asset.updateGrnteeDraft')
export const querycarPageDetailInChange = createFetchAction(ASSET_COLLATERAL_CARPAGE_IN_INFO_QUERY_WORK_FLOW_DETAIL, 'vfc-intf-ent-asset.inStorageDetail')
export const querycarPageDetailOutChange = createFetchAction(ASSET_COLLATERAL_CARPAGE_OUT_INFO_QUERY_WORK_FLOW_DETAIL, 'vfc-intf-ent-asset.outStorageDetail')

export const submitApproval = createFetchAction(ASSET_COLLATEARL_CARPAGE_INFO_SUBMIT_APPROVAL, 'vfc-intf-ent-base.taskCompleted')

export default {
  querycarPageDetailInChange,
  querycarPageDetailOutChange,
  bigSave,
  submitApproval,
}
