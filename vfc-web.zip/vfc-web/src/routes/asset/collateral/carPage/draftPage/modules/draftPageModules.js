import { createFetchAction } from '../../../../../../modules/common'

// 新建草稿 -- 获取资产编号
const ASSET_COLLATERAL_CARPAGE_INFO_QUERY_CARPAGE_ID = 'ASSET_COLLATERAL_CARPAGE_INFO_QUERY_CARPAGE_ID'

// 根据资产编号查询详情
const ASSET_COLLATERAL_CARPAGE_INFO_QUERY_CARPAGE_DETAIL_RECORD = 'ASSET_COLLATERAL_CARPAGE_INFO_QUERY_CARPAGE_DETAIL_RECORD'
// 查询出库详情
const ASSET_COLLATERAL_CARPAGE_INFO_QUERY_OUT_DETAIL_RECORD = 'ASSET_COLLATERAL_CARPAGE_INFO_QUERY_OUT_DETAIL_RECORD'
// 查询入库库详情
const ASSET_COLLATERAL_CARPAGE_INFO_QUERY_IN_DETAIL_RECORD = 'ASSET_COLLATERAL_CARPAGE_INFO_QUERY_IN_DETAIL_RECORD'
// 新增草稿接口
const ASSET_COLLATERAL_CARPAGE_INFO_DRAFT_SUBMIT = 'ASSET_COLLATERAL_CARPAGE_INFO_DRAFT_SUBMIT'
// 变更提交接口
const ASSET_COLLATERAL_CARPAGE_INFO_CHANGE_SUBMIT = 'ASSET_COLLATERAL_CARPAGE_INFO_CHANGE_SUBMIT'
// 草稿补充信息-提交保存
const ASSET_COLLATERAL_CARPAGE_INFO_UPDATE = 'ASSET_COLLATERAL_CARPAGE_INFO_UPDATE'
// 变更编辑-提交保存
const ASSET_COLLATERAL_CARPAGE_INFO_CHANGE_UPDATE = 'ASSET_COLLATERAL_CARPAGE_INFO_CHANGE_UPDATE'

const ASSET_COLLATERAL_CARPAGE_INFO_COMPLETE_TASK = 'ASSET_COLLATERAL_CARPAGE_INFO_COMPLETE_TASK'

export const completeTask = createFetchAction(ASSET_COLLATERAL_CARPAGE_INFO_COMPLETE_TASK, 'vfc-intf-ent-base.taskCompleted')

export const querycarPageId = createFetchAction(ASSET_COLLATERAL_CARPAGE_INFO_QUERY_CARPAGE_ID, 'vfc-intf-ent-asset.getAssetNbrList')
export const querycarPageDetailRecord = createFetchAction(ASSET_COLLATERAL_CARPAGE_INFO_QUERY_CARPAGE_DETAIL_RECORD, 'vfc-intf-ent-asset.selectGrntee')
export const querycarPageOutDetail = createFetchAction(ASSET_COLLATERAL_CARPAGE_INFO_QUERY_OUT_DETAIL_RECORD, 'vfc-intf-ent-asset.outStorageDetail')
export const querycarPageInDetail = createFetchAction(ASSET_COLLATERAL_CARPAGE_INFO_QUERY_IN_DETAIL_RECORD, 'vfc-intf-ent-asset.inStorageDetail')
export const carPageDraftSubmit = createFetchAction(ASSET_COLLATERAL_CARPAGE_INFO_DRAFT_SUBMIT, 'vfc-intf-ent-asset.saveGrnteeInfo')
export const carPageDraftUpdateSubmit = createFetchAction(ASSET_COLLATERAL_CARPAGE_INFO_UPDATE, 'vfc-intf-ent-asset.updateGrnteeInfo')
export const carPageChangeSubmit = createFetchAction(ASSET_COLLATERAL_CARPAGE_INFO_CHANGE_SUBMIT, 'vfc-intf-ent-asset.saveGrnteeDraft')
export const carPageChangeUpdateSubmit = createFetchAction(ASSET_COLLATERAL_CARPAGE_INFO_CHANGE_UPDATE, 'vfc-intf-ent-asset.updateGrnteeDraft')


export default {
  querycarPageId,
  carPageDraftUpdateSubmit,
  querycarPageInDetail,
  querycarPageOutDetail,
  querycarPageDetailRecord,
  carPageDraftSubmit,
  completeTask,
  carPageChangeSubmit,
  carPageChangeUpdateSubmit,
}
