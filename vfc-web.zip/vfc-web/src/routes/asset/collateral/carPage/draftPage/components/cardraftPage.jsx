import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import _debug from 'lb-debug'
import message from 'lbc-wrapper/lib/message'
import Spin from 'lbc-wrapper/lib/spin'
import makeTitle from '../../../../../../utils/makeTitle'
import pageContainerWrapper from '../../../../../../components/form/page/PageContainerWrapper'
import PageContainerHeader from '../../../../../../components/form/page/PageContainerHeader'

import PageLoader from '../../../../../../components/form/page/PageLoader'
import SubmitFlow, { shouldOpenSubmitModal } from '../../../../../../components/workflow/submitFlow/SubmitFlow'

import pageMode from '../../../../../../common/pageMode'
import pageType from '../../../../../../common/pageType'
import { PERMISSIONS } from '../../../../../../components/form/utils/calPermission'
import reqMapIds, { detailDataMap } from '../../common/reqMapIds'
import formIds, { formTitleMap } from '../../common/formIds'
import groups, { ChangeInfoOutGroup, ChangeInfoInGroup, OutEnterInfoGroup } from '../../common/groups'
import { flowActions } from '../../../../../../common/workflow'

import CarPageDraftPageAjax from '../modules/draftPageModules'

import { CARPAGE_INFO_UPDATE_APPLICATION_LIST, CARPAGE_INFO_UPDATE_APPROVE_LIST, CARPAGE_INFO_UPDATE_QUERY_LIST } from '../../common/tabAction'
import bizTypeCode from '../../../../../../common/bizTypeCode'
import { assetCollateralApplyType, assetCollateralApplyTypeLabels } from '../../../../../../common/bizApplyType/asset'

const debug = _debug('CarPageDraftPage')

const PAGE_ID = 'asset_collateral_carPageInfo'

class CarPageDraftPage extends PureComponent {
  constructor(props) {
    super(props)

    this.onSubmit = this.onSubmit.bind(this)
    this.updateApplyList = this.updateApplyList.bind(this)
    this.updateApproveList = this.updateApproveList.bind(this)
    this.doSubmit = this.doSubmit.bind(this)
    this.submitDone = this.submitDone.bind(this)
    this.isReadOnly = this.isReadOnly.bind(this)
    this.updateShopPrice = this.updateShopPrice.bind(this)

    /*
     * 每个页面都要通过search传几个参数：
     * m: 页面的模式：新增／编辑／只读
     * t: 页面的类型：草稿／变更／审批
     * n: 该页面的唯一id
     */
    const parsed = props.tabhelper.getsearch() // queryString.parse(props.location.search)

    /*
     * 如果是新增
       DRAFT: '01', // 草稿
       CHANGE: '02', // 变更
       APPROVAL: '03', // 审批
       RECORD: '04', // 真实记录
     */
    const authority = parsed.m === pageMode.VIEW || parsed.at === assetCollateralApplyType.IN || parsed.at === assetCollateralApplyType.OUT ? PERMISSIONS.READ : PERMISSIONS.MODIFY

    /*
     * 定义了这个页面有哪些tab
     * {
     *   groupId, 对应后台配置的groupId，不能为空，必须唯一
     *   title, 页面显示的tab标题
     *   forceRender, 在页面展示时，是否强制渲染tab中的内容。如果这个tab中包含了form，则必须为true
     *   path, tab内容组件的路径，在动态加载的时候会用
     *   authority, 权限，查看／编辑／隐藏
     *   component, tab内容的组件，必须是一个返回组件的方法
     * }
     *
     * 创建草稿和变更信息页面，group信息是前台写死的。流程的是从后台取的
     */
    this.tabItem = groups

    /*
     * 如果是变更页面，则加入变更信息tab页
     */
    if (parsed.at === assetCollateralApplyType.OUT) {
      this.tabItem = this.tabItem.concat(ChangeInfoOutGroup)
    } else if (parsed.at === assetCollateralApplyType.IN) {
      this.tabItem = this.tabItem.concat(ChangeInfoInGroup)
    }

    if (parsed.pt) {
      this.tabItem = this.tabItem.filter(g => g.groupId !== OutEnterInfoGroup.groupId)
    }


    this.state = {
      loading: true,
      submiting: false,
      applyType: parsed.at, // 申请类型--入库-出库变更
      businessKey: '', // 业务流程编号
      groups: this.tabItem.map(t => ({ group_id: t.groupId, authority: this.isReadOnly(t.groupId, authority) })),
      data: {
      },
      buyerPrc: '',
    }

    this.actions = parsed.m === pageMode.VIEW ? [] : [
      {
        comp_id: 'submit',
        label: '提交',
        type: 'primary',
        onClick: this.onSubmit,
        key: 'submit',
      },
    ]
  }

  componentDidMount() {
    /*
     * 页面开始后，需要去后台取相关信息：
     * 1，新增草稿时，需要去后台取业务系统的ID，附件树
     * 2，新增变更时，需要去后台取原数据（包含新的业务id），附件树
     * 3，审批时，需要去后台取原数据，附件树，group信息，审批信息
     * 4，编辑／查看时，需要去后台取原数据，附件树
     * 不同操作调用不同接口，但一个接口会返回所有需要的数据
     */
    const { querycarPageInDetail, querycarPageOutDetail, querycarPageId, getBidAndBpid, querycarPageDetailRecord, tabhelper } = this.props

    tabhelper.closeothersamepathtab()
    const parsed = tabhelper.getsearch()

    if (parsed.m === pageMode.CREATE) {
      if (parsed.t === pageType.DRAFT) {
        // 新增草稿 -- 获取资产编号
        querycarPageId({
          assetNbrType: 'warrantNbr',
          total: '1',
        }).then((data) => {
          this.setState({
            data: {
              grnteeNbr: data.assetNbrList[0],
            },
            loading: false,
          })
        })
      } else if (parsed.at === assetCollateralApplyType.IN || parsed.at === assetCollateralApplyType.OUT) {
        // 新增变更 -- 获取业务流程id
        const getBpidPro = getBidAndBpid({
          busiApplyType: this.state.applyType,
          busiType: bizTypeCode.ASSET_COLLATERAL_CAR,
          businessNo: parsed.bid,
        })
        const queryDetailPro = querycarPageDetailRecord({
          grnteeNbr: parsed.bid,
        })

        Promise.all([getBpidPro, queryDetailPro]).then((results) => {
          const [bpid, data] = results

          this.setState({
            data: Object.assign({}, data.grnteeDetUnit, { grnteeNbr: parsed.bid }),
            businessKey: bpid.businessKey, // 返回获取业务流程id
            loading: false,
          })
        })
      }
    } else if (parsed.m === pageMode.MODIFY || parsed.m === pageMode.VIEW) {
      // 编辑或查看
      let retPromise = null
      if (parsed.at === assetCollateralApplyType.IN) { // 变更
        retPromise = querycarPageInDetail({
          businessKey: parsed.bpid,
        })
      } else if (parsed.at === assetCollateralApplyType.OUT) {
        retPromise = querycarPageOutDetail({
          businessKey: parsed.bpid,
        })
      } else {
        retPromise = querycarPageDetailRecord({ // 补充信息或查看草稿详情查询原始数据
          grnteeNbr: parsed.bid,
        })
      }

      retPromise.then((data) => {
        this.setState({
          data: Object.assign({}, data.grnteeDetUnit, { grnteeNbr: parsed.bid }),
          applyType: parsed.at,
          businessKey: parsed.bpid,
          loading: false,
        })
      })
    }
  }

  onSubmit() {
    const { activeForms, mustValidateForms, retrieveAllData, tabhelper } = this.props
    const parsed = tabhelper.getsearch()

    this.setState({
      submiting: true,
    })

    // const promises = Object.keys(this.props.activeForms).map(key => new Promise((resolve, reject) => {
    //   activeForms[key]().validateFields((errors, values) => {
    //     let type = key
    //     if (key.indexOf('@') > -1) {
    //       type = key.split('@')[2]
    //     }
    //     if (errors) {
    //       debug('error')
    //       reject(formTitleMap[type])
    //     } else {
    //       resolve({
    //         [reqMapIds[type]]: Object.assign({}, values, { grnteeNbr: this.state.data.grnteeNbr }),
    //       })
    //     }
    //   })
    // }))

    const promises = retrieveAllData(activeForms, mustValidateForms, reqMapIds, formTitleMap, values => Object.assign({}, values, { grnteeNbr: this.state.data.grnteeNbr, grnteeType: parsed.grnteeType }))

    Promise.all(promises).then(this.doSubmit, (errMsgs) => {
      this.setState({
        submiting: false,
      })
      this.pageLoader.displayMe(errMsgs.key)
      message.error(`${errMsgs.message}中的字段有错误，请检查`)
    }).catch((e) => { debug(e) })
  }

  updateShopPrice(values) {
    this.setState({
      buyerPrc: values,
    })
  }

  doSubmit(values) {
    const { tabhelper, carPageDraftSubmit, carPageChangeSubmit, processDefStart, carPageDraftUpdateSubmit, carPageChangeUpdateSubmit } = this.props
    const parsed = tabhelper.getsearch()

    let reqValue = {}
    values.forEach((v) => {
      reqValue = Object.assign(reqValue, v, { grnteeInsInfo: { grnteeObjType: '01', grnteeType: parsed.grnteeType } })
    })

    debug(reqValue)

    /*
     * 先提交，
     * 后台先保存，然后返回后续节点的分配策略
     * 如果后续节点数量大于1
     * 或者后续节点的分配策略是收工选择或会签
     * 则弹出流程选择对话框
     * 否则直接关闭页面
     */
    let subMitPromise = null
    if (parsed.m === pageMode.CREATE) {
      if (parsed.t === pageType.DRAFT) {
        subMitPromise = carPageDraftSubmit({
          grnteeNbr: this.state.data.grnteeNbr,
          grnteeInsInfo: {
            grnteeType: parsed.grnteeType,
            grnteeObjType: '01',
          },
          ...reqValue,
        })
      } else if (parsed.at === assetCollateralApplyType.IN || parsed.at === assetCollateralApplyType.OUT) {
        delete reqValue.grnteeInsInfo
        subMitPromise = carPageChangeSubmit(Object.assign({}, reqValue.grnteeChangeInfo, { businessKey: this.state.businessKey }, { grnteeNbr: this.state.data.grnteeNbr }, { applyType: this.state.applyType }))
      }
    } else if (parsed.m === pageMode.MODIFY) {
      if (parsed.t === pageType.RECORD) {
        subMitPromise = carPageDraftUpdateSubmit({
          grnteeNbr: this.state.data.grnteeNbr,
          ...reqValue,
        })
      } else if (parsed.at === assetCollateralApplyType.IN || parsed.at === assetCollateralApplyType.OUT) {
        subMitPromise = carPageChangeUpdateSubmit(Object.assign({}, reqValue.grnteeChangeInfo, { businessKey: this.state.businessKey }, { grnteeNbr: this.state.data.grnteeNbr }, { applyType: this.state.applyType }))
      }
    }

    subMitPromise.then(() => {
      if (parsed.at === assetCollateralApplyType.IN || parsed.at === assetCollateralApplyType.OUT) {
        processDefStart({
          businessKey: this.state.businessKey,
          busiApplyType: this.state.applyType,
          busiType: bizTypeCode.ASSET_COLLATERAL_CAR,
          completeFirstTaskFlag: true,
          firstComments: '出入库变更',
        }).then((data) => {
          if (shouldOpenSubmitModal(data, flowActions.submit)) {
            this.submitModal.open({
              backNodeList: [], // 提交，没有回退节点
              assignStrategy: data.assignStrategy,
              nextNodeList: data.nodeList,
              userList: data.userList,
              actionTypeAllowed: flowActions.submit, // 固定提交操作
              taskInstId: data.taskInstId,
              successCallback: this.submitDone,
              failCallback: () => this.setState({ submiting: false }),
            })
          } else {
            this.submitDone()
          }
        }).catch(() => {
          this.setState({
            submiting: false,
          })
        })
      } else {
        this.submitDone()
      }
    }).catch(() => {
      this.setState({
        submiting: false,
      })
    })
  }

  isReadOnly(groupId, authority) {
    if (groupId === formIds.changeLibraryInInfo || groupId === formIds.changeLibraryOutInfo) {
      return PERMISSIONS.MODIFY
    }

    return authority
  }

  submitDone(reqValue) {
    /*
     * 提交成功，
     * 则更新申请列表
     * 更新审批列表
     * 弹出提交成功提示
     * 关闭当前tab页
     */
    this.setState({
      submiting: false,
    })
    this.updateApplyList(reqValue)
    this.updateApproveList(reqValue)
    message.success('提交成功')
    this.props.tabhelper.closetab()
  }

  /*
   * 在保存／提交／删除／修改的时候，都要更新申请列表
   */

  updateQueryList() {
    const { tabhelper } = this.props

    tabhelper.dispatch(CARPAGE_INFO_UPDATE_QUERY_LIST)
  }

  updateApplyList() {
    const { tabhelper } = this.props

    tabhelper.dispatch(CARPAGE_INFO_UPDATE_APPLICATION_LIST)
  }


  /*
   * 在提交的时候，要刷新审批列表
   */
  updateApproveList() {
    const { tabhelper } = this.props

    tabhelper.dispatch(CARPAGE_INFO_UPDATE_APPROVE_LIST)
  }

  render() {
    const { tabhelper } = this.props
    const parsed = tabhelper.getsearch()
    const defaultSelectedKey = parsed.at === assetCollateralApplyType.IN ? ChangeInfoInGroup.groupId : ChangeInfoOutGroup.groupId
    return (
      <div>
        <Spin spinning={this.state.submiting} delay={20}>
          <PageContainerHeader title={makeTitle('车辆页', assetCollateralApplyTypeLabels[parsed.at], true, this.state.businessKey, this.state.grnteeNbr)} actions={this.actions} loading={this.state.loading} submiting={this.state.submiting} />
          <PageLoader
            ref={r => (this.pageLoader = r)}
            tabs={this.tabItem}
            groups={this.state.groups}
            data={this.state.data}
            loading={this.state.loading}
            grnteeNbr={this.state.data.grnteeNbr}
            businessKey={this.state.businessKey}
            updateApplyList={this.updateApplyList}
            groupIdToDataMap={detailDataMap}
            applyType={this.state.applyType}
            tabhelper={this.props.tabhelper}
            buyerPrc={this.state.buyerPrc}
            defaultSelectedKey={defaultSelectedKey}
            updateShopPrice={this.updateShopPrice}
          />
          <SubmitFlow
            ref={r => (this.submitModal = r)}
            loading={this.state.loading}
            successCallback={this.submitDone}
            failCallback={this.submitDone}
            taskCompleteAction={this.props.completeTask}
          />
        </Spin>
      </div>
    )
  }
}

CarPageDraftPage.propTypes = {
  getBidAndBpid: PropTypes.func,
  querycarPageId: PropTypes.func,
  querycarPageInDetail: PropTypes.func,
  querycarPageOutDetail: PropTypes.func,
  querycarPageDetailRecord: PropTypes.func,
  carPageDraftUpdateSubmit: PropTypes.func,
  carPageChangeSubmit: PropTypes.func,
  carPageDraftSubmit: PropTypes.func,
  carPageChangeUpdateSubmit: PropTypes.func,
  processDefStart: PropTypes.func,
  completeTask: PropTypes.func,
  tabhelper: PropTypes.shape({
    closetab: PropTypes.func,
    subscribe: PropTypes.func,
    dispatch: PropTypes.func,
    getsearch: PropTypes.func,
  }),
  activeForms: PropTypes.object,
  mustValidateForms: PropTypes.object,
  retrieveAllData: PropTypes.func,
}

export default pageContainerWrapper({ name: PAGE_ID }, CarPageDraftPageAjax)(CarPageDraftPage)
