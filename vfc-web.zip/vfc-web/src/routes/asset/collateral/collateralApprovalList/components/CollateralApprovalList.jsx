import React, { Component } from 'react'
import ACTIONS from '../../../../../components/queryTable/consts'
import PageContainerHeader from '../../../../../components/form/page/PageContainerHeader'
import ApprovalTable from '../../../../../components/ApprovalTable'
import { assetCollateralApplyTypeLabels } from '../../../../../common/bizApplyType/asset'
import { assetGrnteeObjTypeRender, assetGrnteeTypeRender } from '../../../../../components/columnRenders/AssetCollateralType'
import { actionRouter } from '../../../../../common/ListCommon/listFunctionCommon'
import { SearchMakerParams } from '../../../../../common/ListCommon/listCommonUtils'
import { COLLATERAL_UPDATE_APPROVE_LIST } from '../../common/tabAction'

class CollateralApprovalList extends Component {
  constructor(props) {
    super(props)
    this.bizKeyUrl = this.bizKeyUrl.bind(this)
    this.onApprove = this.onApprove.bind(this)
    this.columns = [
      {
        title: '担保编号',
        dataIndex: 'grnteeNbr',
        key: 'grnteeNbr',
        // render: (value, record) => (<ApplyNoWrapper value={value} to={this.bizKeyUrl(value, record)} />),
      },
      {
        title: '关联合同编号',
        dataIndex: 'contractNbr',
        key: 'contractNbr',
      },
      {
        title: '担保名称',
        dataIndex: 'grnteeName',
        key: 'grnteeName',
      },
      {
        title: '担保类型',
        dataIndex: 'grnteeType',
        key: 'grnteeType',
        render: assetGrnteeTypeRender,
      },
      {
        title: '押品类型',
        dataIndex: 'grnteeObjType',
        key: 'grnteeObjType',
        render: assetGrnteeObjTypeRender,
      },
      {
        title: '押品所有权人',
        dataIndex: 'grnteeRelateUserName',
        key: 'grnteeRelateUserName',
      },
    ]

    this.actions = [
      {
        ...ACTIONS.APPROVAL,
        action: this.onApprove,
      },
    ]
  }
  componentDidMount() {
    const { tabhelper } = this.props
    tabhelper.subscribe((type) => {
      if (type === COLLATERAL_UPDATE_APPROVE_LIST) {
        this.table && this.table.refresh()
      }
    })
  }
  // 审批按钮
  onApprove(selectedRowKeys, selectedRows) {
    const { history } = this.props
    history.push(this.bizKeyUrl('', selectedRows[0]))
  }
  bizKeyUrl(value, record) {
    let search = null
    search = actionRouter(record, record.grnteeNbr, record.busiApplyType, SearchMakerParams.APPROVALDetail)
    return `/dashboard/asset/collateral/${record.uiName}${search}`
  }
  render() {
    return (
      <div>
        <PageContainerHeader title="审批列表" />
        <ApprovalTable
          ref={r => (this.table = r)}
          columns={this.columns}
          actions={this.actions}
          query={this.props.collateralApprovalListQuery}
          // rowKey="businessKey"
          listKey="list"
          bizKeyUrl={this.bizKeyUrl}
          bizApplyTypeLabels={assetCollateralApplyTypeLabels}
          tabhelper={this.props.tabhelper}
        />
      </div>

    )
  }
}

export default CollateralApprovalList
