import { createReducer, createFetchAction } from 'modules/common'


const ASSET_COLLATERAL_APPROVAL_LIST_QUERY = 'ASSET_COLLATERAL_APPROVAL_LIST_QUERY'

export const collateralApprovalListQuery = createFetchAction(ASSET_COLLATERAL_APPROVAL_LIST_QUERY, 'vfc-intf-ent-asset.auditTaskPending')

const intialState = {
}

export default createReducer(intialState, {})
