import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'

import CollateralApprovalList from '../components/CollateralApprovalList'

import {
  collateralApprovalListQuery,
} from '../modules/collateralApprovalListInfo'

const mapActionCreators = {
  collateralApprovalListQuery,
}

const mapStateToProps = () => ({})

export default withRouter(connect(mapStateToProps, mapActionCreators)(CollateralApprovalList))
