import groupIds, { idTitleMap } from './groupIds'

import GuaranteeInfo from '../components/GuaranteeInfoForm/GuaranteeInfoForm'
import SecurityDepositInfo from '../components/SecurityDepositInfoForm/SecurityDepositInfoForm'
import AttachmentInfo from '../components/AttachmentInfoForm/AttachmentInfoForm'

const guaranteeGroups = [
  {
    groupId: groupIds.guaranteeInfo,
    title: idTitleMap[groupIds.guaranteeInfo],
    forceRender: true,
    path: 'GuaranteeInfoForm',
    component: () => GuaranteeInfo,
  },
  {
    groupId: groupIds.securityDepositInfo,
    title: idTitleMap[groupIds.securityDepositInfo],
    forceRender: true,
    path: 'SecurityDepositInfoForm',
    component: () => SecurityDepositInfo,
  },
  {
    groupId: groupIds.attachmentInfo,
    title: idTitleMap[groupIds.attachmentInfo],
    forceRender: true,
    path: 'AttachmentInfoForm',
    component: () => AttachmentInfo,
  },
]

export default guaranteeGroups
