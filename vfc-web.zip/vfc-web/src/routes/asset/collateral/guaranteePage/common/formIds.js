const formIds = {
  guaranteeInfo: 'GUARANTEE_BASIC_INFO',
  securityDepositInfo: 'GUARANTEE_SECURITY_DEPOSIT_INFO',
  attachmentInfo: 'GUARANTEE_ATTACHMENT_INFO',
}

export const formTitleMap = {
  [formIds.guaranteeInfo]: '保证信息',
  [formIds.securityDepositInfo]: '保证金信息',
  [formIds.attachmentInfo]: '附件信息',
}
export default formIds
