import formIds from './formIds'

export const idTitleMap = {
  [formIds.guaranteeInfo]: '保证信息',
  [formIds.securityDepositInfo]: '保证金信息',
  [formIds.attachmentInfo]: '附件信息',
}

export default formIds
