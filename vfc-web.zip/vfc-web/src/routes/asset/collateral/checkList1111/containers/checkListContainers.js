import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'

import CheckList from '../components/CheckList'

import {
  checkListInfo,
  listInfoCheck,
} from '../modules/checkListInfo'

const mapActionCreators = {
  checkListInfo,
  listInfoCheck,
}

const mapStateToProps = state => ({})

export default withRouter(connect(mapStateToProps, mapActionCreators)(CheckList))
