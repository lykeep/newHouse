import React, { Component } from 'react'
import Modal from 'lbc-wrapper/lib/modal'
import Form from 'lbc-wrapper/lib/form'
import PropTypes from 'prop-types'
import QueryTable from '../../../../../components/queryTable'


class GetCheckList extends Component {
  constructor(props) {
    super(props)
    this.query = this.query.bind(this)
    this.onOk = this.onOk.bind(this)
    this.onCancel = this.onCancel.bind(this)
    this.data = [
      {
        applyNO: 32424,
        leaseItemName: '测试1',
        leaseItemType: '车辆',
        leaseItemNumber: 'ZL10000021',
        applyType:' 变更车架号',
        setuper: '创建人1',
        node: '额度审核',
        status: '审批中',
        choose: '选择'
      },
      {
        applyNO: 32424,
        leaseItemName: '测试1',
        leaseItemType: '车辆',
        leaseItemNumber: 'ZL10000021',
        applyType:' 变更车架号',
        setuper: '创建人1',
        node: '额度审核',
        status: '审批中',
        choose: '选择'
      },
      {
        applyNO: 32424,
        leaseItemName: '测试1',
        leaseItemType: '车辆',
        leaseItemNumber: 'ZL10000021',
        applyType:' 变更车架号',
        setuper: '创建人1',
        node: '额度审核',
        status: '审批中',
        choose: '选择'
      },
      {
        applyNO: 32424,
        leaseItemName: '测试1',
        leaseItemType: '车辆',
        leaseItemNumber: 'ZL10000021',
        applyType:' 变更车架号',
        setuper: '创建人1',
        node: '额度审核',
        status: '审批中',
        choose: '选择'
      },
    ]
    this.columns = [
      {
        title: '申请编号',
        dataIndex: 'applyNO',
        key: 'applyNO',
      },
      {
        title: '租赁物名称',
        dataIndex: 'leaseItemName',
        key: 'leaseItemName',
      },
      {
        title: '租赁物类型',
        dataIndex: 'leaseItemType',
        key: 'leaseItemType',
      },
      {
        title: '租赁物编号',
        dataIndex: 'leaseItemNumber',
        key: 'leaseItemNumber',
      },
      {
        title: '申请类型',
        dataIndex: 'applyType',
        key: 'applyType',
      },
      {
        title: '流程创建人',
        dataIndex: 'setuper',
        key: 'setuper',
      },
      {
        title: '流程节点',
        dataIndex: 'node',
        key: 'node',
      },
      {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
      },
      {
        key: 'opr',
        title: '操作',
        dataIndex: 'opr',
        width: 100,
        render: (text, record) => {
          return (
            <span onClick={() => this.onClick(record)} className="opr" >
              选择
            </span>
          )
        },
        // render: (value, record)=> (<Link to={`/dashboard/securityDeposit/creditSecurity/accountDetails/${record.choose}`}>{value}</Link>),
      },
    ]
    this.applyType = [
      { title: '全部', value: '0', key: '0' },
      { title: '额度生效', value: '1', key: '1' },
      { title: '额度申请', value: '2', key: '2' },
      { title: '额度增加', value: '3', key: '3' },
    ]
    this.fields = [
      [
        { id: '00001', label: '申请编号', component: 'Input', placeholder: '请输入' },
        { id: 'applyType', label: '申请类型', type: 'Select', options: this.applyType ,defaultValue :"全部"},
        { id: '00002', label: '创建人', component: 'Input', placeholder: '请输入' },
      ],
    ]
    this.state = {
      data: [],
    }

    this.marginAccountType = [
      {
        title: '标准保证金',
        value: '1',
        key: '1',
      }, {
        title: '非标准保证金',
        value: '0',
        key: '0',
      },
    ]
  }
  // 查询
  query(params) {
  }
  onOk(e) {
    e.preventDefault()
    this.props.form.validateFields((err, values) => {
      if (!err) {
        console.log('Received values of form: ', values)
        this.props.openAccountOk(
          Object.assign({}, values, { insuranceAmount: values.insuranceAmount }))
      }
    })
  }
  onCancel() {
    this.props.openAccountCancel()
  }

  onClick = (record) => {
    // const { name } = this.props
    // this.setState({ inputValue: '' })
    this.props.receiveTask(record)
  }
  render() {
    const { form, authority = '2', action } = this.props
    console.log('form', form)
    const queryTable =  <QueryTable
                          data={this.data}
                          rowSelection = {null}
                          columns={this.columns}
                          fields={this.fields}
                          // actions={this.actions}
                          query={this.query}
                          rowKey="productNo"
                          totalCount={this.state.totalCount}
                        />
    return (
      <Modal
        visible={this.props.openAccountVisible}
        title={this.props.title}
        footer={null}
        closable={false}
        width={1200}
        destroyOnClose
      >
        {queryTable}
      </Modal>
    )
  }
}

GetCheckList.propTypes = {
  form: PropTypes.shape({
    getFieldDecorator: PropTypes.func.isRequired,
    validateFields: PropTypes.func,
  }).isRequired,
  openAccountVisible: PropTypes.bool,
  authority: PropTypes.string.isRequired,
}

export default Form.create()(GetCheckList)
