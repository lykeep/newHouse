import React, { Component } from 'react'
import QueryTable from '../../../../../components/queryTable'
import ACTIONS from '../../../../../components/queryTable/consts'
import PageContainerHeader from '../../../../../components/form/page/PageContainerHeader'
import GetCheckList from './GetCheckList'

const newColumns = [
  {
    title: '申请编号',
    dataIndex: 'applyNO',
    key: 'applyNO',
  },
  {
    title: '租赁物名称',
    dataIndex: 'leaseItemName',
    key: 'leaseItemName',
  },
  {
    title: '租赁物类型',
    dataIndex: 'leaseItemType',
    key: 'leaseItemType',
  },
  {
    title: '租赁物编号',
    dataIndex: 'leaseItemNumber',
    key: 'leaseItemNumber',
  },
  {
    title: '申请类型',
    dataIndex: 'applyType',
    key: 'applyType',
  },
  {
    title: '流程创建人',
    dataIndex: 'setuper',
    key: 'setuper',
  },
  {
    title: '流程节点',
    dataIndex: 'node',
    key: 'node',
  },
  {
    key: 'uploadTime',
    dataIndex: 'uploadTime',
    title: '上传时间',
  },
  {
    title: '状态',
    dataIndex: 'status',
    key: 'status',
  },
]

class CheckList extends Component {
  constructor(props) {
    super(props)
    this.query = this.query.bind(this)
    this.onCheck = this.onCheck.bind(this)
    this.receiveTask = this.receiveTask.bind(this)
    this.getTask = this.getTask.bind(this)
    this.columns = [
      {
        title: '申请编号',
        dataIndex: 'applyNO',
        key: 'applyNO',
      },
      {
        title: '租赁物名称',
        dataIndex: 'leaseItemName',
        key: 'leaseItemName',
      },
      {
        title: '租赁物类型',
        dataIndex: 'leaseItemType',
        key: 'leaseItemType',
      },
      {
        title: '租赁物编号',
        dataIndex: 'leaseItemNumber',
        key: 'leaseItemNumber',
      },
      {
        title: '申请类型',
        dataIndex: 'applyType',
        key: 'applyType',
      },
      {
        title: '流程创建人',
        dataIndex: 'setuper',
        key: 'setuper',
      },
      {
        title: '流程节点',
        dataIndex: 'node',
        key: 'node',
      },
      {
        key: 'uploadTime',
        dataIndex: 'uploadTime',
        title: '上传时间',
      },
      {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
      },
    ]
    this.applyType = [
      { title: '全部', value: '0', key: '0' },
      { title: '额度生效', value: '1', key: '1' },
      { title: '额度申请', value: '2', key: '2' },
      { title: '额度增加', value: '3', key: '3' },
    ]
    this.dealStateType = [
      { title: '待处理', value: '0', key: '0' },
      { title: '已处理', value: '1', key: '1' },
      { title: '已撤销', value: '2', key: '2' },
    ]
    this.flowStateType = [
      { title: '全部', value: '0', key: '0' },
      { title: '审批中', value: '1', key: '1' },
      { title: '撤销', value: '2', key: '2' },
      { title: '完成', value: '3', key: '3' },
      { title: '否决', value: '4', key: '4' },
    ]
    this.fields = [
      [
        { id: '00001', label: '申请编号', component: 'Input', placeholder: '请输入' },
        { id: 'applyType', label: '申请类型', type: 'Select', options: this.applyType },
        { id: '00003', label: '创建人', component: 'Input', placeholder: '请输入' },
        { id: 'dealStateType', label: '处理状态', type: 'Select', options: this.dealStateType },
        { id: 'flowStateType', label: '流程状态', type: 'Select', options: this.flowStateType },
      ],
    ]

    this.actions = [
      {
        ...ACTIONS.GET_APPROVETASK,
        key: 'task',
        action: this.getTask,
      },
      {
        label: '审核',
        key: 'check',
        action: this.onCheck,
      },
    ]

    this.state = {
      openAccountVisible: false,
      data: [],
    }
  }

  // 审核
  onCheck() {
  }
  //点击获取任务
  getTask() {
    this.setState({
      openAccountVisible: true,
    })
  }
  receiveTask(record) {
    const newRecord = record
    newRecord["uploadTime"] =  new Date().toLocaleTimeString()
    this.setState({
      openAccountVisible: false,
      data: [...this.state.data,newRecord],
    })
  }
  // 查询
  query(params) {
  }

  render() {
    return (
      <div>
        <PageContainerHeader title="审批列表" />
        <QueryTable
          data={this.state.data}
          columns={newColumns}
          fields={this.fields}
          actions={this.actions}
          query={this.query}
          rowKey="productNo"
          rowSelection = {null}
          totalCount={this.state.totalCount}
        />
        <GetCheckList
          openAccountVisible={this.state.openAccountVisible}
          receiveTask = {this.receiveTask}
          title="审批列表"
        />
      </div>

    )
  }
}

export default CheckList
