import { createReducer, createFetchAction } from 'modules/common'

const PRODUCT_CHECK_LIST_INFO = 'PRODUCT_CHECK_LIST_INFO'
const PRODUCT_CHECK_LIST_ADD = 'PRODUCT_CHECK_LIST_ADD'

export const checkListInfo = createFetchAction(PRODUCT_CHECK_LIST_INFO, 'loongblock-admin.cuishouInfoQuotation')
export const listInfoCheck = createFetchAction(PRODUCT_CHECK_LIST_ADD, 'loongblock-admin.latepaymentInfoQuotation')

const intialState = {
}

export default createReducer(intialState, {})
