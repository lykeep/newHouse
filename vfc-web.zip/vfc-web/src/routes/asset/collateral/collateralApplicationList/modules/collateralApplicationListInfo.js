import { createReducer, createFetchAction } from 'modules/common'

const COLLATERAL_APPLY_LIST = 'COLLATERAL_APPLY_LIST'
const COLLATERAL_APPLY_LIST_DELETE = 'COLLATERAL_APPLY_LIST_DELETE'
export const queryCollateralApplyTaskPending = createFetchAction(COLLATERAL_APPLY_LIST, 'vfc-intf-ent-asset.applyTaskPending') // 担保管理 申请列表
export const deleteGrnteeDraft = createFetchAction(COLLATERAL_APPLY_LIST_DELETE, 'vfc-intf-ent-asset.deleteGrnteeDraft')
const intialState = {
}

export default createReducer(intialState, {})
