import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'

import CollateralApplicationList from '../components/CollateralApplicationList'

import {
  queryCollateralApplyTaskPending,
  deleteGrnteeDraft,
} from '../modules/collateralApplicationListInfo'

const mapActionCreators = {
  queryCollateralApplyTaskPending,
  deleteGrnteeDraft,
}

const mapStateToProps = () => ({})

export default withRouter(connect(mapStateToProps, mapActionCreators)(CollateralApplicationList))
