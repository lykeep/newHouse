import React, { Component } from 'react'
import ACTIONS from '../../../../../components/queryTable/consts'
import PageContainerHeader from '../../../../../components/form/page/PageContainerHeader'
import ApplicationTable from '../../../../../components/ApplicationTable'
import { assetGrnteeObjTypeRender, assetGrnteeObjTypeType, assetGrnteeTypeRender, assetGrnteeTypeType } from '../../../../../components/columnRenders/AssetCollateralType';
import CollateralInfoAddModal from '../../../../order/common/components/CollateralInfoForm/CollateralInfoAddModal'
import { isDraft } from '../../../../../common/isDraft';
import { actionRouter } from '../../../../../common/ListCommon/listFunctionCommon';
import { SearchMakerParams } from '../../../../../common/ListCommon/listCommonUtils';
import { assetCollateralATSelectOptions, assetCollateralATTypeRender } from '../../../../../common/bizApplyType/asset';
import { COLLATERAL_UPDATE_APPLICATION_LIST } from '../../common/tabAction';

class CollateralApplicationList extends Component {
  constructor(props) {
    super(props)
    this.bizKeyUrl = this.bizKeyUrl.bind(this)
    this.onModify = this.onModify.bind(this)
    this.onDelete = this.onDelete.bind(this)
    this.onCancel = this.onCancel.bind(this)
    this.onCreate = this.onCreate.bind(this)
    this.receiveCallBack = this.receiveCallBack.bind(this)
    this.columns = [
      {
        title: '担保编号',
        dataIndex: 'grnteeNbr',
        key: 'grnteeNbr',
        // render: (value, record) => (<ApplyNoWrapper value={value} to={this.bizKeyUrl(value, record)} />),
      },
      {
        title: '关联合同编号',
        dataIndex: 'contractNbr',
        key: 'contractNbr',
      },
      {
        title: '担保名称',
        dataIndex: 'grnteeName',
        key: 'grnteeName',
      },
      {
        title: '担保类型',
        dataIndex: 'grnteeType',
        key: 'grnteeType',
        render: assetGrnteeTypeRender,
      },
      {
        title: '押品类型',
        dataIndex: 'grnteeObjType',
        key: 'grnteeObjType',
        render: assetGrnteeObjTypeRender,
      },
      {
        title: '押品所有权人',
        dataIndex: 'grnteeRelateUserName',
        key: 'grnteeRelateUserName',
      },
    ]

    this.fields = [
      { id: 'grnteeNbr', label: '担保编号', component: 'Input', placeholder: '请输入' },
      { id: 'businessNo', label: '合同编号', component: 'Input', placeholder: '请输入' },
    ]


    this.actions = [
      {
        ...ACTIONS.MODIFY,
        action: this.onModify,
      },
      {
        ...ACTIONS.REMOVE,
        action: this.onDelete,
      },
    ]
    this.state = {
      addCollnInfoVisible: false,
    }
  }
  componentDidMount() {
    const { tabhelper } = this.props
    tabhelper.subscribe((type) => {
      if (type === COLLATERAL_UPDATE_APPLICATION_LIST) {
        // this.table.refresh()
        this.table && this.table.refresh()
      }
    })
  }

  onCreate() {
    this.setState({
      addCollnInfoVisible: true,
    })
  }
  // 编辑
  onModify(selectedRowKeys, selectedRows) {
    let subNode = null
    const { history } = this.props
    if (selectedRows[0].grnteeType === assetGrnteeTypeType.Grntee) {
      subNode = 'guaranteePage'
    } else {
      switch (selectedRows[0].grnteeObjType) {
        case assetGrnteeObjTypeType.CarInfo:
          subNode = 'carPageInfo'
          break;
        case assetGrnteeObjTypeType.HousePropertyInfo:
          subNode = 'housePropertyInfo'
          break;
        case assetGrnteeObjTypeType.OtherHypothecation:
          subNode = 'otherHypothecation'
          break;
        default:
      }
    }
    const search = actionRouter(selectedRows[0], selectedRows[0].grnteeNbr, selectedRows[0].busiApplyType, SearchMakerParams.paramsEdit, {
      grnteeType: selectedRows[0].grnteeType,
    })
    history.push(`${subNode}${search}`)
  }
  // 删除
  onDelete(selectedRowKeys, selectedRows) {
    this.props.deleteGrnteeDraft({
      businessKeyList: [selectedRows[0].businessKey],
    }).then(() => this.table.refresh())
  }
  onCancel({ type }) {
    type === '1' ? this.setState({
      addCollnInfoVisible: false,
    }) : this.setState({
      visible: false,
    })
  }
  // 新增modal回调
  receiveCallBack(fieldsValue) {
    let subNode = null
    const { history } = this.props
    if (fieldsValue.grnteeType === assetGrnteeTypeType.Grntee) {
      subNode = 'guaranteePage'
    } else {
      switch (fieldsValue.grnteeObjType) {
        case assetGrnteeObjTypeType.CarInfo:
          subNode = 'carPageInfo'
          break;
        case assetGrnteeObjTypeType.HousePropertyInfo:
          subNode = 'housePropertyInfo'
          break;
        case assetGrnteeObjTypeType.OtherHypothecation:
          subNode = 'otherHypothecation'
          break;
        default:
      }
    }
    const search = actionRouter(fieldsValue, fieldsValue.grnteeNbr, '', SearchMakerParams.Create, {
      grnteeType: fieldsValue.grnteeType,
    })
    history.push(`${subNode}${search}`)
  }

  bizKeyUrl(value, record) {
    let search = null
    let subNode = ''
    let path = null
    switch (record.grnteeObjType) {
      case assetGrnteeObjTypeType.CarInfo:
        subNode = 'carPageInfo'
        break;
      case assetGrnteeObjTypeType.HousePropertyInfo:
        subNode = 'housePropertyInfo'
        break;
      case assetGrnteeObjTypeType.OtherHypothecation:
        subNode = 'otherHypothecation'
        break;
      default:
    }
    if (record.isDraft === isDraft.YES) {
      search = actionRouter(record, record.grnteeNbr, record.busiApplyType, SearchMakerParams.DraftDetail)
      path = `/dashboard/asset/collateral/${subNode}${search}`
    } else {
      search = actionRouter(record, record.grnteeNbr, record.busiApplyType, SearchMakerParams.FlowDetail)
      path = `/dashboard/asset/collateral/${record.uiName}${search}`
    }
    return path
  }
  render() {
    return (
      <div>
        <PageContainerHeader title="申请列表" />
        <ApplicationTable
          ref={r => (this.table = r)}
          columns={this.columns}
          fields={this.fields}
          actions={this.actions}
          query={this.props.queryCollateralApplyTaskPending}
          rowKey="businessKey"
          bizKeyUrl={this.bizKeyUrl}
          applyTypeRender={assetCollateralATTypeRender}
          SelectOptions={assetCollateralATSelectOptions}
          listName="grnteeDraftInfoList"
        />
        <CollateralInfoAddModal
          visible={this.state.addCollnInfoVisible}
          onCancel={this.onCancel}
          receiveCallBack={this.receiveCallBack}
          authority="2"
          type="1"
          fromPage="collateralApplylist"
        />
      </div>

    )
  }
}

export default CollateralApplicationList
