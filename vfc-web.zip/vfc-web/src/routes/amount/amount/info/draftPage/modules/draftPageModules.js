import { createFetchAction } from 'modules/common'

const AMOUNT_AMOUNT_INFO_QUERY_CREDIT_DETAIL_RECORD = 'AMOUNT_AMOUNT_INFO_QUERY_CREDIT_DETAIL_RECORD'

// 调减变更
const AMOUNT_AMOUNT_CHANGE_CUT_SAVE_INFO = 'AMOUNT_AMOUNT_CHANGE_CUT_SAVE_INFO'

// 冻结 解冻 失效
const AMOUNT_AMOUNT_FREEZE_LOSE_SAVE_INFO = 'AMOUNT_AMOUNT_FREEZE_LOSE_SAVE_INFO'

// 查询-调减变更 详情
const AMOUNT_AMOUNT_CHANGE_CUT_QUERY_DETAIL_INFO = 'AMOUNT_AMOUNT_CHANGE_CUT_QUERY_DETAIL_INFO'

// 查询-冻结 解冻 失效 详情
const AMOUNT_AMOUNT_FREEZE_LOSE_DETAIL_QUERY_INFO = 'AMOUNT_AMOUNT_FREEZE_LOSE_DETAIL_QUERY_INFO'

export const queryAmountDetailRecord = createFetchAction(AMOUNT_AMOUNT_INFO_QUERY_CREDIT_DETAIL_RECORD, 'vfc-intf-ent-contract.qryFullCreditDetail')

export const changeCutSaveInfo = createFetchAction(AMOUNT_AMOUNT_CHANGE_CUT_SAVE_INFO, 'vfc-intf-ent-contract.saveCreditReduce')

export const freezeLoseSaveInfo = createFetchAction(AMOUNT_AMOUNT_FREEZE_LOSE_SAVE_INFO, 'vfc-intf-ent-contract.saveCreditChangeCommon')

export const changeCutQueryDetailInfo = createFetchAction(AMOUNT_AMOUNT_CHANGE_CUT_QUERY_DETAIL_INFO, 'vfc-intf-ent-contract.qryCreditReduce')

export const freezeLoseQueryDetailInfo = createFetchAction(AMOUNT_AMOUNT_FREEZE_LOSE_DETAIL_QUERY_INFO, 'vfc-intf-ent-contract.qryCreditChangeCommon')

export default {
  queryAmountDetailRecord,
  changeCutSaveInfo,
  freezeLoseSaveInfo,
  changeCutQueryDetailInfo,
  freezeLoseQueryDetailInfo,
}
