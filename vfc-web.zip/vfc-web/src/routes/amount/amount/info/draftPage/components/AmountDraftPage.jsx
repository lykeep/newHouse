import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import _debug from 'lb-debug'
import message from 'lbc-wrapper/lib/message'
import Spin from 'lbc-wrapper/lib/spin'

import pageContainerWrapper from '../../../../../../components/form/page/PageContainerWrapper'
import PageContainerHeader from '../../../../../../components/form/page/PageContainerHeader'

import PageLoader from '../../../../../../components/form/page/PageLoader'
import SubmitFlow, { shouldOpenSubmitModal } from '../../../../../../components/workflow/submitFlow/SubmitFlow'

import pageMode from '../../../../../../common/pageMode'
import pageType from '../../../../../../common/pageType'
import { PERMISSIONS } from '../../../../../../components/form/utils/calPermission'
import reqMapIds, { detailDataMap } from '../../../common/reqMapIds'
// import { idTitleMap } from '../../../common/groupIds'
import formIds, { formTitleMap } from '../../../common/formIds'
import groups, { ChangeInfoGroup } from '../../../common/groups'
import { flowActions } from '../../../../../../common/workflow'

import { AMOUNT_AMOUNT_UPDATE_APPLICATION_LIST, AMOUNT_AMOUNT_UPDATE_APPROVE_LIST } from '../../../common/tabAction'
import bizTypeCode from '../../../../../../common/bizTypeCode'
import { amountApplyType, amountApplyTypeLabels } from '../../../../../../common/bizApplyType/amount'
import makeTitle from '../../../../../../utils/makeTitle'

const debug = _debug('AmountDraftPage')

const PAGE_ID = 'amount_amount_draft_page'

class AmountDraftPage extends PureComponent {
  constructor(props) {
    super(props)

    this.onSubmit = this.onSubmit.bind(this)
    this.updateApplyList = this.updateApplyList.bind(this)
    this.updateApproveList = this.updateApproveList.bind(this)
    this.doSubmit = this.doSubmit.bind(this)
    this.submitDone = this.submitDone.bind(this)

    /*
     * 每个页面都要通过search传几个参数：
     * m: 页面的模式：新增／编辑／只读
     * t: 页面的类型：草稿／变更／审批
     */
    const parsed = props.tabhelper.getsearch() // queryString.parse(props.location.search)

    /*
     * 如果是新增
     */
    // const authority = PERMISSIONS.MODIFY
    const authority = parsed.m === pageMode.VIEW ? PERMISSIONS.READ : PERMISSIONS.MODIFY
    /*
     * 定义了这个页面有哪些tab
     * {
     *   groupId, 对应后台配置的groupId，不能为空，必须唯一
     *   title, 页面显示的tab标题
     *   forceRender, 在页面展示时，是否强制渲染tab中的内容。如果这个tab中包含了form，则必须为true
     *   path, tab内容组件的路径，在动态加载的时候会用
     *   authority, 权限，查看／编辑／隐藏
     *   component, tab内容的组件，必须是一个返回组件的方法
     * }
     *
     * 创建草稿和变更信息页面，group信息是前台写死的。流程的是从后台取的
     */
    this.tabItem = groups

    const allGroups = this.tabItem.map(t => ({ group_id: t.groupId, authority: t.authority }))

    // CHANGE_CUT: '01', // 调减
    // FREEZE: '02', // 冻结
    // UNFREEZE: '03', // 解冻
    // LOSE_EFFICACY: '04', // 失效

    // if (parsed.at === amountApplyType.CHANGE_CUT || parsed.at === amountApplyType.FREEZE || parsed.at === amountApplyType.UNFREEZE || parsed.at === amountApplyType.LOSE_EFFICACY) {
    //   this.tabItem = this.tabItem.concat(ChangeInfoGroup)
    //   allGroups.push({
    //     ...ChangeInfoGroup,
    //     group_id: ChangeInfoGroup.groupId,
    //     authority,
    //   })
    // }
    if (parsed.at) {
      this.tabItem = this.tabItem.concat(ChangeInfoGroup)
      allGroups.push({
        ...ChangeInfoGroup,
        group_id: ChangeInfoGroup.groupId,
        authority,
      })
    }

    this.state = {
      loading: true,
      submiting: false,
      businessProcessNo: '',
      bizKey: '',
      groups: allGroups,
      data: {
      },
      applyType: parsed.at,
    }

    this.actions = parsed.m === pageMode.VIEW ? [] : [
      {
        comp_id: 'submit',
        label: '提交',
        type: 'primary',
        onClick: this.onSubmit,
        key: 'submit',
      },
    ]
  }

  componentDidMount() {
    /*
     * 页面开始后，需要去后台取相关信息：
     * 1，新增草稿时，需要去后台取业务系统的ID，附件树
     * 2，新增变更时，需要去后台取原数据（包含新的业务id），附件树
     * 3，审批时，需要去后台取原数据，附件树，group信息，审批信息
     * 4，编辑／查看时，需要去后台取原数据，附件树
     * 不同操作调用不同接口，但一个接口会返回所有需要的数据
     */
    const { queryLegalDetailNew, queryAmountDetailRecord, tabhelper, getBidAndBpid, changeCutQueryDetailInfo, freezeLoseQueryDetailInfo } = this.props
    tabhelper.closeothersamepathtab()
    const parsed = tabhelper.getsearch()

    // 创建
    if (parsed.m === pageMode.CREATE) {
      if (parsed.at) {
        /*
         * 这里要调用2个接口：
         * 1，获取流程id接口
         * 2，获取记录详情接口
         */
        getBidAndBpid({
          busiApplyType: this.state.applyType,
          busiType: bizTypeCode.AMOUNT_CHANGE,
          businessNo: parsed.bid,
        }).then((data) => {
          const queryDetailPro = queryAmountDetailRecord({
            creditNum: parsed.bid,
          })
          let queryChangeDetail = null
          if (parsed.at === amountApplyType.CHANGE_CUT) {
            queryChangeDetail = changeCutQueryDetailInfo({
              businessKey: data.businessKey,
            })
          } else {
            queryChangeDetail = freezeLoseQueryDetailInfo({
              busiApplyType: parsed.at,
              businessKey: data.businessKey,
            })
          }
          Promise.all([queryDetailPro, queryChangeDetail]).then((results) => {
            const [bpid, cData] = results
            this.setState({
              data: { changeInfo: cData, ...bpid },
              businessProcessNo: data.businessKey,
              bizKey: parsed.bid,
              loading: false,
            })
          })
        })
      }
    } else if (parsed.m === pageMode.MODIFY || parsed.m === pageMode.VIEW) {
      let retPromise = null
      if (parsed.t === pageType.RECORD) {
        // 查看记录
        retPromise = queryAmountDetailRecord({
          creditNum: parsed.bid,
        })
      } else {
        // 查看草稿
        if (parsed.at === amountApplyType.NEW) {
          retPromise = queryLegalDetailNew({
            businessKey: parsed.bpid,
          })
        } else {
          retPromise = queryAmountDetailRecord({
            businessKey: parsed.bpid,
            creditNum: parsed.bid,
          })
          let queryChangeDetail = null
          if (parsed.at === amountApplyType.CHANGE_CUT) {
            queryChangeDetail = changeCutQueryDetailInfo({
              businessKey: parsed.bpid,
            })
          } else {
            queryChangeDetail = freezeLoseQueryDetailInfo({
              busiApplyType: parsed.at,
              businessKey: parsed.bpid,
            })
          }
          Promise.all([retPromise, queryChangeDetail]).then((results) => {
            const [bpid, cData] = results
            this.setState({
              data: { changeInfo: cData, ...bpid },
              businessProcessNo: parsed.bpid,
              bizKey: parsed.bid,
              loading: false,
            })
          })
        }
      }

      retPromise.then((data) => {
        this.setState({
          data,
          loading: false,
          bizKey: parsed.bid,
          businessProcessNo: parsed.bpid,
        })
      })
    }
  }


  onSubmit() {
    const { activeForms, mustValidateForms, retrieveAllData } = this.props
    this.setState({
      submiting: true,
    })
    const promises = retrieveAllData(activeForms, mustValidateForms, reqMapIds, formTitleMap, value => Object.assign({}, value))

    Promise.all(promises).then(this.doSubmit, (err) => {
      this.setState({
        submiting: false,
      })
      this.pageLoader.displayMe(err.key)
      message.error(`${err.key}中的字段有错误，请检查`)
    }).catch((e) => { debug(e) })
  }

  doSubmit(values) {
    const { changeCutSaveInfo, freezeLoseSaveInfo, tabhelper, processDefStart } = this.props

    const parsed = tabhelper.getsearch()

    let reqValue = {}
    values.forEach((v) => {
      reqValue = Object.assign(reqValue, v)
    })

    debug(reqValue)

    /*
     * 先调用大保存，
     * 然后调用发起流程接口，返回后续节点的分配策略
     * 如果后续节点数量大于1
     * 或者后续节点的分配策略是收工选择或会签
     * 则弹出流程选择对话框
     * 否则直接关闭页面
     */
    const subMitPromise = parsed.at === amountApplyType.CHANGE_CUT ? changeCutSaveInfo : freezeLoseSaveInfo

    subMitPromise({
      businessKey: this.state.businessProcessNo,
      busiApplyType: this.state.applyType,
      ...reqValue[reqMapIds[formIds.changeInfo]],
    }).then(() => processDefStart({
      businessKey: this.state.businessProcessNo,
      busiApplyType: this.state.applyType,
      busiType: bizTypeCode.AMOUNT_CHANGE,
      completeFirstTaskFlag: true,
      firstComments: '额度变更',
    })).then((data) => {
      if (shouldOpenSubmitModal(data, flowActions.submit)) {
        this.submitModal.open({
          backNodeList: [], // 提交，没有回退节点
          assignStrategy: data.assignStrategy,
          nextNodeList: data.nodeList,
          userList: data.userList,
          actionTypeAllowed: flowActions.submit, // 固定提交操作
          taskInstId: data.taskInstId,
          successCallback: this.submitDone,
          failCallback: () => this.setState({ submiting: false }),
        })
      } else {
        this.submitDone()
      }
    }, () => {
      this.setState({
        submiting: false,
      })
    })
  }

  submitDone(reqValue) {
    /*
     * 提交成功，
     * 则更新申请列表
     * 更新审批列表
     * 弹出提交成功提示
     * 关闭当前tab页
     */
    this.setState({
      submiting: false,
    })
    this.updateApplyList(reqValue)
    this.updateApproveList(reqValue)
    message.success('提交成功')
    this.props.tabhelper.closetab()
  }

  /*
   * 在保存／提交／删除／修改的时候，都要更新申请列表
   */
  updateApplyList() {
    const { tabhelper } = this.props

    tabhelper.dispatch(AMOUNT_AMOUNT_UPDATE_APPLICATION_LIST)
  }


  /*
   * 在提交的时候，要刷新审批列表
   */
  updateApproveList() {
    const { tabhelper } = this.props

    tabhelper.dispatch(AMOUNT_AMOUNT_UPDATE_APPROVE_LIST)
  }

  render() {
    return (
      <div>
        <Spin spinning={this.state.submiting} delay={20}>
          <PageContainerHeader title={makeTitle('额度详情-草稿', amountApplyTypeLabels[this.state.applyType], true, this.state.businessProcessNo, this.state.bizKey)} actions={this.actions} loading={this.state.loading} submiting={this.state.submiting} />
          <PageLoader
            ref={r => (this.pageLoader = r)}
            tabs={this.tabItem}
            groups={this.state.groups}
            data={this.state.data}
            loading={this.state.loading}
            bizKey={this.state.bizKey}
            businessKey={this.state.businessProcessNo}
            // processKey={this.state.businessProcessNo}
            updateApplyList={this.updateApplyList}
            groupIdToDataMap={detailDataMap}
            defaultSelectedKey={ChangeInfoGroup.groupId}
            applyType={this.state.applyType}
            tabhelper={this.props.tabhelper}
          />
          <SubmitFlow
            ref={r => (this.submitModal = r)}
            loading={this.state.loading}
            successCallback={this.submitDone}
            failCallback={this.submitDone}
            taskCompleteAction={this.props.completeTask}
          />
        </Spin>
      </div>
    )
  }
}

AmountDraftPage.propTypes = {
  processDefStart: PropTypes.func,
  queryLegalDetailNew: PropTypes.func,
  getBidAndBpid: PropTypes.func,
  queryAmountDetailRecord: PropTypes.func,
  completeTask: PropTypes.func,
  changeCutSaveInfo: PropTypes.func,
  freezeLoseSaveInfo: PropTypes.func,
  changeCutQueryDetailInfo: PropTypes.func,
  freezeLoseQueryDetailInfo: PropTypes.func,
  tabhelper: PropTypes.shape({
    closetab: PropTypes.func,
    subscribe: PropTypes.func,
    dispatch: PropTypes.func,
    getsearch: PropTypes.func,
  }),
  activeForms: PropTypes.object,
  mustValidateForms: PropTypes.object,
  retrieveAllData: PropTypes.func,
}

export default pageContainerWrapper({ name: PAGE_ID })(AmountDraftPage)
