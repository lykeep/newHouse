import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import _debug from 'lb-debug'
import message from 'lbc-wrapper/lib/message'
import Spin from 'lbc-wrapper/lib/spin'

import pageContainerWrapper from '../../../../../../components/form/page/PageContainerWrapper'
import PageContainerHeader from '../../../../../../components/form/page/PageContainerHeader'

import PageLoader from '../../../../../../components/form/page/PageLoader'
import SubmitFlow, { shouldOpenSubmitModal } from '../../../../../../components/workflow/submitFlow/SubmitFlow'
import calculateGroups, { shouldCallBigSive } from '../../../../../../components/form/groups/calculateGroups'
import pageMode from '../../../../../../common/pageMode'
import { PERMISSIONS } from '../../../../../../components/form/utils/calPermission'
import reqMapIds, { detailDataMap } from '../../../common/reqMapIds'
// import { idTitleMap } from '../../../common/groupIds'
import formIds, { formTitleMap } from '../../../common/formIds'
import groups, { ChangeInfoGroup, circulationGroup, flowChartGroup, approvalGroup } from '../../../common/groups'
import { handleStatus } from '../../../../../../common/workflow'
import groupIds from '../../../common/groupIds'

import { AMOUNT_AMOUNT_UPDATE_APPLICATION_LIST, AMOUNT_AMOUNT_UPDATE_APPROVE_LIST } from '../../../common/tabAction'
import { amountApplyType, amountApplyTypeLabels } from '../../../../../../common/bizApplyType/amount'
import makeTitle from '../../../../../../utils/makeTitle'

const debug = _debug('AmountApprovalPage')

const PAGE_ID = 'amount_amount_approval_page'

class AmountApprovalPage extends PureComponent {
  constructor(props) {
    super(props)

    this.onSubmit = this.onSubmit.bind(this)
    this.updateApplyList = this.updateApplyList.bind(this)
    this.updateApproveList = this.updateApproveList.bind(this)
    this.doSubmit = this.doSubmit.bind(this)
    this.submitDone = this.submitDone.bind(this)

    /*
     * 每个页面都要通过search传几个参数：
     * m: 页面的模式：新增／编辑／只读
     * t: 页面的类型：草稿／变更／审批
     */
    const parsed = props.tabhelper.getsearch()
    this.basicTabItem = groups
    this.tabItem = groups

    /*
      * 如果是变更页面，则加入变更信息tab页
    */
    if (parsed.at === amountApplyType.CHANGE_CUT || parsed.at === amountApplyType.FREEZE || parsed.at === amountApplyType.UNFREEZE || parsed.at === amountApplyType.LOSE_EFFICACY) {
      this.tabItem = this.tabItem.concat(ChangeInfoGroup)
    }

    if (parsed.m !== pageMode.VIEW) {
      this.tabItem = this.tabItem.concat(approvalGroup)
    }

    this.tabItem = this.tabItem.concat(circulationGroup, flowChartGroup)
    // this.alwaysGroups = this.tabItem.map(t => ({ group_id: t.groupId, authority: t.authority }))

    this.state = {
      loading: true,
      submiting: false,
      groups: [], // 页面tab信息
      data: {}, // 业务数据
      workflowActions: [], // 流程可进行操作
      backNodeList: [], // 可退回节点
      businessKey: '',
      applyType: parsed.at,
      nextActivity: {
        assignStrategy: '',
        nodeList: [],
        userList: [],
      }, // 下一节点处理策略
      // creditNum: parsed.bid,
      bizKey: '',
    }

    this.actions = parsed.m === pageMode.VIEW ? [] : [
      {
        comp_id: 'submit',
        label: '提交',
        type: 'primary',
        onClick: this.onSubmit,
        key: 'submit',
      },
    ]
  }

  componentDidMount() {
    /*
     * 页面开始后，需要去后台取相关信息：
     * 1，新增草稿时，需要去后台取业务系统的ID，附件树
     * 2，新增变更时，需要去后台取原数据（包含新的业务id），附件树
     * 3，审批时，需要去后台取原数据，附件树，group信息，审批信息
     * 4，编辑／查看时，需要去后台取原数据，附件树
     * 不同操作调用不同接口，但一个接口会返回所有需要的数据
     */
    const { queryWorkflowDetail, queryAmountDetailRecord, tabhelper, changeCutQueryDetailInfo, freezeLoseQueryDetailInfo } = this.props
    tabhelper.closeothersamepathtab()
    const parsed = tabhelper.getsearch()

    const queryFunc = parsed.at === amountApplyType.CHANGE_CUT ? changeCutQueryDetailInfo : freezeLoseQueryDetailInfo

    if (parsed.m === pageMode.VIEW) {
      // 从申请列表进入，调用查询草稿接口查详情
      const queryAmountDetailApply = queryAmountDetailRecord({ // 查tab页详情
        creditNum: parsed.bid,
      })
      const queryDetailApply = queryFunc({// 查变更页详情
        businessKey: parsed.bpid,
        busiApplyType: parsed.at,
      })
      Promise.all([queryAmountDetailApply, queryDetailApply]).then((result) => {
        const [allTabDetail, changeInfos] = result
        this.setState({
          data: { changeInfo: changeInfos, ...allTabDetail },
          loading: false,
          applyType: parsed.at,
          bizKey: parsed.bid,
          businessKey: parsed.bpid,
          procInstanceId: parsed.pid,
          groups: this.tabItem.map(t => ({ group_id: t.groupId, authority: PERMISSIONS.READ })),
        })
      })
    } else {
      const queryAmountDetail = queryAmountDetailRecord({ // 查tab页详情
        creditNum: parsed.bid,
      })
      const queryDetailPro = queryFunc({// 查变更页详情
        businessKey: parsed.bpid,
        busiApplyType: parsed.at,
      })
      const queryFlowPro = queryWorkflowDetail({
        taskInstanceId: parsed.tid,
      })

      Promise.all([queryAmountDetail, queryDetailPro, queryFlowPro]).then((result) => {
        const [allTabDetail, bizObj, data] = result

        // 根据流程状态处理决定是否展示审批信息和操作按钮
        const commonGroups = data.statusType === handleStatus.NOT_DONE ? [approvalGroup, circulationGroup, flowChartGroup] : [circulationGroup, flowChartGroup]
        this.actions = handleStatus.NOT_DONE === data.statusType ? this.actions : []
        // this.alwaysGroups.concat(
        const calTabitem = calculateGroups(this.tabItem, data.formControl.inputElementList)
        this.setState({
          loading: false,
          bizKey: parsed.bid,
          procInstanceId: parsed.pid,
          taskInstanceId: parsed.tid,
          businessProcessNo: parsed.bpid,
          groups: this.basicTabItem.concat(calTabitem, commonGroups),
          data: Object.assign(allTabDetail, { changeInfo: bizObj }), // 业务数据
          workflowActions: data.actionTypeAllowed, // 流程可进行操作
          backNodeList: data.backNodeList, // 可退回节点
          businessKey: parsed.bpid,
          applyType: parsed.at,
          callBigSave: shouldCallBigSive(data.formControl.inputElementList),
          nextActivity: data.nextActivityVO, // 下一节点处理策略
        })
      }).catch(() => {
      })
    }
  }

  onSubmit() {
    const { activeForms, mustValidateForms, retrieveAllData } = this.props

    this.setState({
      submiting: true,
    })

    const promises = retrieveAllData(activeForms, mustValidateForms, reqMapIds, formTitleMap, value => Object.assign({}, value))

    Promise.all(promises).then(this.doSubmit, (err) => {
      this.setState({
        submiting: false,
      })
      this.pageLoader.displayMe(err.key)
      message.error(`${err.key}中的字段有错误，请检查`)
    }).catch((e) => { debug(e) })
  }

  doSubmit(values) {
    const { changeCutSaveInfo, freezeLoseSaveInfo, tabhelper } = this.props
    const { nextActivity } = this.state
    const parsed = tabhelper.getsearch()

    let reqValue = {}
    values.forEach((v) => {
      reqValue = Object.assign(reqValue, v)
    })

    debug(reqValue)
    this.reqData = reqValue

    /*
     * 先调用大保存，
     * 然后调用发起流程接口，返回后续节点的分配策略
     * 如果后续节点数量大于1
     * 或者后续节点的分配策略是收工选择或会签
     * 则弹出流程选择对话框
     * 否则直接关闭页面
     */

    const subMitPromise = parsed.at === amountApplyType.CHANGE_CUT ? changeCutSaveInfo : freezeLoseSaveInfo

    subMitPromise({
      businessKey: this.state.businessProcessNo,
      busiApplyType: this.state.applyType,
      ...reqValue[reqMapIds[formIds.changeInfo]],
    }).then(() => {
      const approvalData = reqValue[reqMapIds[groupIds.approvalInfo]]
      if (!shouldOpenSubmitModal(nextActivity, approvalData.actionType)) {
        this.props.taskCompleted({
          actionType: approvalData.actionType,
          assignStrategy: this.state.nextActivity.assignStrategy,
          comment: approvalData.comment,
          taskInstanceId: this.state.taskInstanceId,
          targetTaskDefKey: approvalData.targetTaskDefKey,
          orgPath: approvalData.orgPath, // 2018-09-17, 标识是否退回提交后原路返回
        }).then(() => {
          this.submitDone()
        }).catch(() => {
          this.setState({
            submiting: false,
          })
        })
      } else {
        this.submitModal.open({
          backNodeList: this.state.backNodeList,
          assignStrategy: this.state.nextActivity.assignStrategy,
          nextNodeList: this.state.nextActivity.nodeList,
          userList: this.state.nextActivity.userList,
          actionTypeAllowed: approvalData.actionType,
          comment: approvalData.comment,
          successCallback: this.submitDone,
          failCallback: () => this.setState({ submiting: false }),
          taskInstId: parsed.tid,
        })
      }
    }).catch(() => {
      this.submitDone()
    })
  }

  submitDone(reqValue) {
    /*
     * 提交成功，
     * 则更新申请列表
     * 更新审批列表
     * 弹出提交成功提示
     * 关闭当前tab页
     */
    this.setState({
      submiting: false,
    })
    this.updateApplyList(reqValue)
    this.updateApproveList(reqValue)
    message.success('提交成功')
    this.props.tabhelper.closetab()
  }

  /*
   * 在保存／提交／删除／修改的时候，都要更新申请列表
   */
  updateApplyList() {
    const { tabhelper } = this.props

    tabhelper.dispatch(AMOUNT_AMOUNT_UPDATE_APPLICATION_LIST)
  }


  /*
   * 在提交的时候，要刷新审批列表
   */
  updateApproveList() {
    const { tabhelper } = this.props

    tabhelper.dispatch(AMOUNT_AMOUNT_UPDATE_APPROVE_LIST)
  }

  render() {
    const { loading, backNodeList, workflowActions, procInstanceId } = this.state
    const { tabhelper } = this.props
    const parsed = tabhelper.getsearch()

    return (
      <div>
        <Spin spinning={this.state.submiting} delay={20}>
          <PageContainerHeader title={makeTitle('额度变更详情-审批', amountApplyTypeLabels[parsed.at], true, this.state.businessProcessNo, this.state.businessKey, this.state.bizKey)} actions={this.actions} loading={this.state.loading} submiting={this.state.submiting} />
          <PageLoader
            ref={r => (this.pageLoader = r)}
            tabs={this.tabItem}
            loading={loading}
            groups={this.state.groups}
            data={this.state.data}
            bizKey={this.state.bizKey}
            processKey={this.state.businessProcessNo}
            updateApplyList={this.updateApplyList}
            groupIdToDataMap={detailDataMap}
            applyType={this.state.applyType}
            tabhelper={this.props.tabhelper}
            workflowActions={workflowActions}
            procInstanceId={procInstanceId}
            backNodeList={backNodeList}
            defaultSelectedKey={approvalGroup.groupId}
          />
          <SubmitFlow
            ref={r => (this.submitModal = r)}
            loading={this.state.loading}
            successCallback={this.submitDone}
            failCallback={this.submitDone}
            taskCompleteAction={this.props.completeTask}
          />
        </Spin>
      </div>
    )
  }
}

AmountApprovalPage.propTypes = {
  queryAmountDetailRecord: PropTypes.func,
  queryWorkflowDetail: PropTypes.func,
  changeCutSaveInfo: PropTypes.func,
  freezeLoseSaveInfo: PropTypes.func,
  changeCutQueryDetailInfo: PropTypes.func,
  freezeLoseQueryDetailInfo: PropTypes.func,
  completeTask: PropTypes.func,
  taskCompleted: PropTypes.func,
  tabhelper: PropTypes.shape({
    closetab: PropTypes.func,
    subscribe: PropTypes.func,
    dispatch: PropTypes.func,
    getsearch: PropTypes.func,
  }),
  activeForms: PropTypes.object,
  mustValidateForms: PropTypes.object,
  retrieveAllData: PropTypes.func,
}

export default pageContainerWrapper({ name: PAGE_ID })(AmountApprovalPage)
