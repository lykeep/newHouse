import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import _debug from 'lb-debug'
import message from 'lbc-wrapper/lib/message'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import GroupActions from '../../../../../../components/form/groups/GroupActions'
import InputField from '../../../../../../components/form/inputs/InputField'
import DatePickerField from '../../../../../../components/form/inputs/DatePickerField'
import SelectField from '../../../../../../components/form/inputs/SelectField'
import MoneyField from '../../../../../../components/form/inputs/MoneyField'
import quotaInfoAjaxActions from './QuotaInfoModule'
import formIds from '../../../common/formIds'
import { currencyTypeSelectOptions } from '../../../../../../components/columnRenders/currencyType'
import { amountStatusSelectOptions } from '../../../../../../components/columnRenders/amountStatusList'

const debug = _debug('AssessmentInfoForm')

class QuotaInfo extends Component {
  constructor(props) {
    super(props)

    this.onDownloadNotice = this.onDownloadNotice.bind(this)
    this.save = this.save.bind(this)

    this.state = {
    }

    this.stateType = [
      { title: '正常', value: '00', key: '00' },
      { title: '失效', value: '01', key: '01' },
      { title: '冻结', value: '02', key: '02' },
      { title: '到期', value: '03', key: '03' },
    ]

    this.actions = [
      {
        id: 'save',
        label: '保存',
        type: 'primary',
        onClick: this.save,
      },
      {
        id: 'download',
        label: '下载额度生效通知书',
        type: 'primary',
        onClick: this.onDownloadNotice,
      },
    ]
  }

  onDownloadNotice() {
    // 下载额度通知书
    this.props.downloadNotice().then((res) => {
      debug('下载完成')
    })
  }

  save() {
    const { form, saveQuotaInfo, processKey, bizKey, applyType } = this.props

    form.validateFields((errors, values) => {
      if (errors) {
        console.log(errors)
        return
      }

      saveQuotaInfo({
        ...values,
      }).then(res => {
        message.success('保存成功')
      })
    })
  }

  render() {
    const { form, data, authority } = this.props

    return (
      <div>
        <Form>
          <Row gutter={16} type="flex" align="top">
            <InputField
              form={form}
              authority={authority}
              name="creditNum"
              formItemProps={{ label: '额度编号' }}
              fieldProps={{
                initialValue: data.creditNum,
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="creditState"
              formItemProps={{ label: '状态' }}
              fieldProps={{
                initialValue: data.creditState,
              }}
              inputProps={{
                placeholder: '请选择',
                options: amountStatusSelectOptions,
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="crcyCd"
              formItemProps={{ label: '币种' }}
              fieldProps={{
                initialValue: data.crcyCd,
              }}
              inputProps={{
                placeholder: '请选择',
                options: currencyTypeSelectOptions,
              }}
            />
            <MoneyField
              form={form}
              authority={authority}
              name="crTotalAmt"
              formItemProps={{ label: '总额度' }}
              fieldProps={{
                initialValue: data.crTotalAmt,
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <MoneyField
              form={form}
              authority={authority}
              name="availableAmt"
              formItemProps={{ label: '可用额度' }}
              fieldProps={{
                initialValue: data.availableAmt,
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <DatePickerField
              form={form}
              authority={authority}
              name="effectDate"
              formItemProps={{ label: '额度生效日期' }}
              fieldProps={{
                initialValue: data.effectDate,
              }}
              inputProps={{
                placeholder: '请选择',
              }}
            />
            <DatePickerField
              form={form}
              authority={authority}
              name="expiredDate"
              formItemProps={{ label: '额度失效日期' }}
              fieldProps={{
                initialValue: data.expiredDate,
              }}
              inputProps={{
                placeholder: '请选择',
              }}
            />
          </Row>
          <GroupActions actions={this.actions} authority={authority} />
        </Form>
      </div>
    )
  }
}

QuotaInfo.propTypes = {
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  data: PropTypes.object,
  saveQuotaInfo: PropTypes.func,
  downloadNotice: PropTypes.func,
}

export default wrapFormContainer(formIds.quotaInfo, '额度信息', quotaInfoAjaxActions)(QuotaInfo)
