import ChargeInfoForm from '../../../../../order/ApplyInfoChildComponent/ChargeInfoTable'
import wrapTableContainer from '../../../../../../components/form/groups/wrapFormContainer'

export default wrapTableContainer('ChargeInfoForm', '费用信息')(ChargeInfoForm)
