import React, { Component } from 'react'
import tabPageWrapper from '../../../../../../components/form/tabs/tabPageWrapper'
import GroupActions from '../../../../../../components/form/groups/GroupActions'

import BorrowBasicInfoForm from './BorrowBasinInfoForm'
import ChargeInfoForm from './ChargeInfoForm'
import SecurityDepositInfoForm from './SecurityDepositInfoForm'

class ApplyInfoTab extends Component {
  constructor(props) {
    super(props)

    this.onSubmit = this.onSubmit.bind(this)
    this.changeAmt = this.changeAmt.bind(this)

    this.state = {
      borrowAmt: '',
    }

    this.actions = [
      {
        comp_id: 'submit',
        label: '保存',
        type: 'primary',
        onClick: this.onSubmit,
        id: 'submit',
      },
    ]
  }

  onSubmit() {
    const { activeForms } = this.props
    const resData = {}
    Object.keys(activeForms).map((key) => {
      activeForms[key]().validateFields((errors, values) => {
        const type = key.split('@')[2]
        if (errors) {
          console.log('error')
          return
        }
        console.log(values)
        // Object.assign(resData, { [reqMapIds[type]]: values }, { grnteeNbr })
      })
    })
  }

  changeAmt(val) {
    this.setState({
      borrowAmt: val,
    }, () => {
      const { activeForms } = this.props
      const { borrowAmt } = this.state
      let chargeInfoList = []
      let securityInfoList = []
      Object.keys(activeForms).map((key) => {
        activeForms[key]().validateFields((errors, values) => {
          const type = key.split('@')[2]
          if (key.split('@')[2] === 'formIds.applySecurityInfo') { // 'formIds.applyChargeInfo' 对应 formIds定义的费用信息
            chargeInfoList = values
          } else if (key.split('@')[2] === 'formIds.applySecurityInfo') { // 'formIds.applyChargeInfo' 对应 formIds定义的保证金信息
            securityInfoList = values
          }
        })
      })
      chargeInfoList.map((key, index) => {
        if (key.way === '01') {
          key.fixedAmt = borrowAmt * (key.percent / 100)
          chargeInfoList[index] = key
        }
      })
      securityInfoList.map((key, index) => {
        if (key.way === '01') {
          key.fixedAmt = borrowAmt * (key.percent / 100)
          securityInfoList[index] = key
        }
      })
      Object.keys(activeForms).map((key) => {
        if (key.split('@')[2] === 'formIds.applySecurityInfo') { // 'formIds.applyChargeInfo' 对应 formIds定义的费用信息
          this.props.activeForms[key]().setFieldsValue({ chargeInfoList })
        } else if (key.split('@')[2] === 'formIds.applySecurityInfo') { // 'formIds.applyChargeInfo' 对应 formIds定义的保证金信息
          this.props.activeForms[key]().setFieldsValue({ securityInfoList })
        }
      })
    })
  }


  render() {
    console.log('-----render ApplyInfoTab -------', this.props)
    const { chargeInfo, securityDepositInfo } = this.props
    return (
      <div>
        <BorrowBasicInfoForm {...this.props} onChange={this.changeAmt} />
        {
          chargeInfo ? (
            <ChargeInfoForm
              {...this.props}
              borrowAmt={this.state.borrowAmt}
            />
          ) : null
        }
        {
          securityDepositInfo ? (
            <SecurityDepositInfoForm
              {...this.props}
              borrowAmt={this.state.borrowAmt}
            />
          ) : null
        }
        {/* <ChargeInfoForm {...this.props} borrowAmt={this.state.borrowAmt} />
        <SecurityDepositInfoForm {...this.props} borrowAmt={this.state.borrowAmt} /> */}
        <GroupActions actions={this.actions} authority={this.props.authority} />
      </div>
    )
  }
}

export default tabPageWrapper('ApplyInfoTab')(ApplyInfoTab)
