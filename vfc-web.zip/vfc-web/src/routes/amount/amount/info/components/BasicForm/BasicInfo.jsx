import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import InputField from '../../../../../../components/form/inputs/InputField'
import MoneyField from '../../../../../../components/form/inputs/MoneyField'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import formIds from '../../../common/formIds'


class BasicInfoForm extends Component {
  constructor(props) {
    super(props)
    this.state = {

    }
  }

  render() {
    const { form, data, authority, disabled } = this.props

    return (
      <div>
        <Form>
          <Row gutter={16} type="flex" align="top">
            <InputField
              form={form}
              authority={authority}
              name="creditNum"
              formItemProps={{ label: '额度编号' }}
              fieldProps={{
                initialValue: data.creditNum,
              }}
              inputProps={{
                placeholder: '请输入',
                disabled,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="contractNum"
              formItemProps={{ label: '合同编号' }}
              fieldProps={{
                initialValue: data.contractNum,
              }}
              inputProps={{
                placeholder: '请选择',
                disabled,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="projectName"
              formItemProps={{ label: '项目名称' }}
              fieldProps={{
                initialValue: data.projectName,
              }}
              inputProps={{
                placeholder: '请输入',
                disabled,
              }}
            />
            <MoneyField
              form={form}
              authority={authority}
              name="totalAmt"
              formItemProps={{ label: '总额度' }}
              fieldProps={{
                initialValue: data.totalAmt,
              }}
              inputProps={{
                placeholder: '请输入',
                disabled,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="borrowerName"
              formItemProps={{ label: '借款人' }}
              fieldProps={{
                initialValue: data.borrowerName,
              }}
              inputProps={{
                placeholder: '请输入',
                disabled,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="term"
              formItemProps={{ label: '期限（月）' }}
              fieldProps={{
                initialValue: data.term,
              }}
              inputProps={{
                placeholder: '请输入',
                disabled,
              }}
            />
          </Row>
        </Form>
      </div>
    )
  }
}

BasicInfoForm.propTypes = {
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  data: PropTypes.object,
  disabled: PropTypes.bool,
}

export default wrapFormContainer(formIds.basicInfo, '基本信息', true)(BasicInfoForm)
