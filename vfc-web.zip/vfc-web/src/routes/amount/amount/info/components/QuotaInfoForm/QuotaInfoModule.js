import { createFetchAction, createAction } from '../../../../../../modules/common'

const AMOUNT_DETAILS_QUOTA_INFO_SAVE = 'AMOUNT_DETAILS_QUOTA_INFO_SAVE'
const AMOUNT_DETAILS_QUOTA_INFO_DOWNLOAD = 'AMOUNT_DETAILS_QUOTA_INFO_DOWNLOAD'

export const saveQuotaInfo = createFetchAction(AMOUNT_DETAILS_QUOTA_INFO_SAVE, 'vfc-intf-ent-asset.saveGrnteeDraft')
export const downloadNotice = createFetchAction(AMOUNT_DETAILS_QUOTA_INFO_DOWNLOAD, 'vfc-intf-ent-asset.saveGrnteeDraft')

export default {
  saveQuotaInfo,
  downloadNotice,
}
