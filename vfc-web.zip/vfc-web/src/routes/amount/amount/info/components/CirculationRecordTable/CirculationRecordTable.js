import ChangeInfoForm from '../../../../../../components/workflow/circulationRecord/components/CirculationRecordTable'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import formIds from '../../../common/formIds'

export default wrapFormContainer(formIds.circulationRecordInfo, '流转信息')(ChangeInfoForm)
