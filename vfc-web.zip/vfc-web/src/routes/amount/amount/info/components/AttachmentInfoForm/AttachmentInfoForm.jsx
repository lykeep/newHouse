import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import FileUploadTree from '../../../../../../components/form/fileUpload/FileUploadTree'
import operType from '../../../../../../common/filesOperType'

class AttachmentInfoForm extends PureComponent {
  render() {
    const { authority, bizKey, processKey } = this.props

    const operTypeCurr = operType.AMOUNT_DETAIL

    return (
      <FileUploadTree
        authority={authority}
        bizKey={bizKey}
        applyFormId={processKey}
        operType={operTypeCurr}
      />
    )
  }
}

AttachmentInfoForm.propTypes = {
  authority: PropTypes.string.isRequired,
  bizKey: PropTypes.string.isRequired,
  processKey: PropTypes.string,
}

export default AttachmentInfoForm
