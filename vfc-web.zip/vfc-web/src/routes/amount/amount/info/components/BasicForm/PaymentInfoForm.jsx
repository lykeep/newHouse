
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import PaymentInfo from '../../../../../contract/commonComponents/basicInfoForm/AccountInfoForm'
import formIds from '../../../common/formIds'

export default wrapFormContainer(formIds.paymentInfo, '收款账户信息')(PaymentInfo)
