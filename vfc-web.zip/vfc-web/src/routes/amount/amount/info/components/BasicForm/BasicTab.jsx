import React, { Component } from 'react'
import message from 'lbc-wrapper/lib/message'
import BasicInfo from './BasicInfo'
import PaymentInfoForm from './PaymentInfoForm'
import RePaymentInfoForm from './RePaymentInfoForm'
import tabPageWrapper from '../../../../../../components/form/tabs/tabPageWrapper'
import tabIds from '../../../common/tabIds'

class PledgeInfoTab extends Component {
  constructor(props) {
    super(props)

    this.actions = [
      {
        comp_id: 'submit',
        label: '保存',
        type: 'primary',
        onClick: this.onSubmit,
        id: 'submit',
      },
    ]
  }
  render() {
    return (
      <div>
        <BasicInfo {...this.props} />
        <PaymentInfoForm {...this.props} />
        <RePaymentInfoForm {...this.props} />
      </div>
    )
  }
}

export default tabPageWrapper(tabIds.pledgeInfo)(PledgeInfoTab)
