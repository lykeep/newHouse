import React, { Component } from 'react'
import PropTypes from 'prop-types'
import BigNum from 'utils/math'
import message from 'lbc-wrapper/lib/message'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import formIds from '../../../common/formIds'
import InputField from '../../../../../../components/form/inputs/InputField'
import SelectField from '../../../../../../components/form/inputs/SelectField'
import TextareaField from '../../../../../../components/form/inputs/TextareaField'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import GroupActions from '../../../../../../components/form/groups/GroupActions'
import { amountApplyType } from '../../../../../../common/bizApplyType/amount'
import FileUploadModal from '../../../../../../components/form/fileUpload/FileUploadModal'
import operType from '../../../../../../common/filesOperType'

class ChangeInfoForm extends Component {
  constructor(props) {
    super(props)

    this.crReduceAmtChange = this.crReduceAmtChange.bind(this)

    this.busiApplyType = [
      {
        value: '01',
        key: '01',
        title: '调减',
      },
      {
        value: '02',
        key: '02',
        title: '冻结',
      },
      {
        value: '03',
        key: '03',
        title: '解冻',
      },
      {
        value: '04',
        key: '04',
        title: '失效',
      },
    ]

    this.state = {
    }
  }

  crReduceAmtChange(e) {
    const { data, form } = this.props
    const crReduceAmt = e.target.value
    const balanceAmt = BigNum.minus(data.crTotalAmt, crReduceAmt)
    form.setFieldsValue({ crReduceAfterTotalAmt: balanceAmt })
  }

  render() {
    const parsed = this.props.tabhelper.getsearch()
    const { form, data, applyType, businessKey, applyTypeOptions, bizKey, authority } = this.props

    let operTypeCurr = null
    if (applyType === amountApplyType.CHANGE_CUT) {
      operTypeCurr = operType.AMOUNT_DECREASE
    } else if (applyType === amountApplyType.FREEZE) {
      operTypeCurr = operType.AMOUNT_FREEZE
    } else if (applyType === amountApplyType.UNFREEZE) {
      operTypeCurr = operType.AMOUNT_UNFREEZE
    } else if (applyType === amountApplyType.LOSE_EFFICACY) {
      operTypeCurr = operType.AMOUNT_DISABLE
    }
    return (
      <div>
        <Form>
          <Row gutter={16} type="flex" align="top">
            <InputField
              form={form}
              authority={authority}
              name="borrowerName"
              key="borrowerName"
              formItemProps={{ label: '客户姓名' }}
              fieldProps={{
                initialValue: data.borrowerName,
              }}
              inputProps={{
                placeholder: '自动反显',
                disabled: true,
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="busiApplyType"
              key="busiApplyType"
              formItemProps={{ label: '变更类型' }}
              fieldProps={{
                initialValue: parsed.at,
              }}
              inputProps={{
                options: applyTypeOptions || this.busiApplyType,
                placeholder: '请选择',
                disabled: true,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="crTotalAmt"
              key="crTotalAmt"
              show={parsed.at === amountApplyType.CHANGE_CUT}
              formItemProps={{ label: '总额度' }}
              fieldProps={{
                initialValue: data.crTotalAmt,
              }}
              inputProps={{
                placeholder: '自动反显',
                disabled: true,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="crReduceAmt"
              key="crReduceAmt"
              show={parsed.at === amountApplyType.CHANGE_CUT}
              formItemProps={{ label: '调减额度' }}
              fieldProps={{
                initialValue: data.crReduceAmt,
                rules: [
                  { required: true, message: '调减额度必输！' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                onBlur: this.crReduceAmtChange,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="crReduceAfterTotalAmt"
              key="crReduceAfterTotalAmt"
              show={parsed.at === amountApplyType.CHANGE_CUT}
              formItemProps={{ label: '调减后总额度' }}
              fieldProps={{
                initialValue: data.crReduceAfterTotalAmt,
              }}
              inputProps={{
                placeholder: '自动反显',
                disabled: true,
              }}
            />
          </Row>
          <Row>
            <FileUploadModal
              authority={authority}
              bizKey={bizKey}
              processKey={businessKey}
              operType={operTypeCurr}
            />
          </Row>
          <TextareaField
            colSpan={24}
            form={form}
            authority={authority}
            name="remarks"
            key="remarks"
            formItemProps={{ label: '备注' }}
            fieldProps={{
              initialValue: data.remarks,
            }}
            inputProps={{
              placeholder: '请输入',
              maxLength: 512,
            }}
          />
          <GroupActions actions={this.actions} authority={authority} />
        </Form>
      </div>
    )
  }
}

ChangeInfoForm.propTypes = {
  form: PropTypes.object.isRequired,
  data: PropTypes.object,
  bizKey: PropTypes.string,
  applyType: PropTypes.string,
  authority: PropTypes.string,
  businessKey: PropTypes.string,
  applyTypeOptions: PropTypes.string,
}

export default wrapFormContainer(formIds.changeInfo, '变更信息', undefined, undefined, true)(ChangeInfoForm)
