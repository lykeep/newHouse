import ApprovalForm from '../../../../../../components/workflow/ApprovalForm'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import basicInfoAjaxActions from './ApprovalModule'
import formIds from '../../../common/formIds'

export default wrapFormContainer(formIds.approvalInfo, '审批信息', basicInfoAjaxActions)(ApprovalForm)
