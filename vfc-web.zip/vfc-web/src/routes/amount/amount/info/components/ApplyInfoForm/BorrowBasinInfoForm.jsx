import PropTypes from 'prop-types'
import React, { Component } from 'react'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import MoneyField from '../../../../../../components/form/inputs/MoneyField'
import InputField from '../../../../../../components/form/inputs/InputField'
import RadioField from '../../../../../../components/form/inputs/RadioField'
import SelectField from '../../../../../../components/form/inputs/SelectField'
import RateField from '../../../../../../components/form/inputs/RateField'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import DatePickerField from '../../../../../../components/form/inputs/DatePickerField'
import formIds from '../../../common/formIds'
import { dateUnit } from '../../../../../../config/types'
import { repayDateRuleOptions, payCodeOptions, rateFloatTypeIndOp } from '../../../../../contract/commonComponents/FinancialTermsInfoForm/FinancialConsts'
import {
  intCalModeOptions,
  rateFloatTypeOptions,
  rateBaseTypeOptions, // 基准利率类型
} from '../../../../../../components/columnRenders/orderApplyInfoCode'

class BorrowBasinInfoForm extends Component {
  constructor(props) {
    super(props)

    this.changeAmt = this.changeAmt.bind(this)

    this.data = []
    this.drawRpyMthdType = [
      { title: '线上划扣', value: '01', key: '01' },
      { title: '线下扣款', value: '02', key: '02' },
    ]
  }

  changeAmt(e) {
    const amt = (e.target.value).replace(/[^0-9]/ig, '')
    this.props.onChange(amt)
  }

  render() {
    const { form, data, authority } = this.props

    return (
      <div>
        <Form>
          <Row>
            <MoneyField
              key="applyCreditAmt"
              name="applyCreditAmt"
              form={form}
              authority={authority}
              formItemProps={{ label: '额度金额' }}
              fieldProps={{
                initialValue: data.applyCreditAmt,
                rules: [
                  { required: true, message: '申请额度金额是必输项！' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <SelectField
              key="creditTermUnit"
              name="creditTermUnit"
              form={form}
              authority={authority}
              formItemProps={{ label: '额度期限单位:' }}
              fieldProps={{
                initialValue: data.creditTermUnit,
                rules: [
                  { required: true, message: '额度期限是必输项！' },
                ],
              }}
              inputProps={{
                placeholder: '请选择',
                options: dateUnit,
              }}
            />
            <InputField
              key="creditTerm"
              name="creditTerm"
              form={form}
              authority={authority}
              formItemProps={{ label: '额度期限' }}
              fieldProps={{
                initialValue: data.creditTerm,
                rules: [
                  { required: true, message: '额度期限是必输项！' },
                  { validator: this.numbervalidator },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <RadioField
              key="rateFloatTypeInd"
              name="rateFloatTypeInd"
              form={form}
              authority={authority}
              formItemProps={{ label: '是否浮动利率' }}
              fieldProps={{
                initialValue: data.rateFloatTypeInd,
              }}
              inputProps={{
                options: rateFloatTypeIndOp,
              }}
            />
            <SelectField
              key="baseRateType"
              name="baseRateType"
              form={form}
              show={Object.prototype.hasOwnProperty.call(data, 'baseRateType')}
              authority={authority}
              formItemProps={{ label: '基准利率类型' }}
              fieldProps={{
                initialValue: data.baseRateType,
                rules: [
                  { required: true, message: '基准利率类型是必选项！' },
                ],
              }}
              inputProps={{
                disabled: true,
                options: rateBaseTypeOptions,
              }}
            />
            <SelectField
              key="intFloatType"
              name="intFloatType"
              form={form}
              show={Object.prototype.hasOwnProperty.call(data, 'intFloatType')}
              authority={authority}
              formItemProps={{ label: '浮动方式' }}
              fieldProps={{
                initialValue: data.intFloatType,
              }}
              inputProps={{
                options: rateFloatTypeOptions,
              }}
            />
            <RateField
              key="intFloatPercent"
              name="intFloatPercent"
              form={form}
              authority={authority}
              show={Object.prototype.hasOwnProperty.call(data, 'intFloatPercent')}
              formItemProps={{ label: '浮动比例' }}
              fieldProps={{
                initialValue: data.intFloatPercent,
                rules: [
                  { required: true, message: '浮动比例是必输项！' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                onBlur: this.floatCalRate, // 浮动比例--计算借款利率
              }}
            />
            <RateField
              key="intFloatValue"
              name="intFloatValue"
              form={form}
              authority={authority}
              show={Object.prototype.hasOwnProperty.call(data, 'intFloatValue')}
              formItemProps={{ label: '浮动值' }}
              fieldProps={{
                initialValue: data.intFloatValue,
                rules: [
                  { required: true, message: '浮动值是必输项！' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <InputField
              key="executionRate"
              name="executionRate"
              form={form}
              authority={authority}
              formItemProps={{ label: '借款利率(%)' }}
              fieldProps={{
                initialValue: data.executionRate,
                rules: [
                  { required: true, message: '借款利率是必输项！' },
                  { validator: this.numbervalidator },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <SelectField
              key="paymentMethodCode"
              name="paymentMethodCode"
              form={form}
              authority={authority}
              formItemProps={{ label: '付款方式' }}
              fieldProps={{
                initialValue: data.paymentMethodCode,
              }}
              inputProps={{
                placeholder: '请选择',
                options: payCodeOptions,
              }}
            />
            <DatePickerField
              key="grantDate"
              name="grantDate"
              form={form}
              authority={authority}
              formItemProps={{ label: '发放日期' }}
              fieldProps={{
                initialValue: data.grantDate,
              }}
              inputProps={{
                placeholder: '请选择',
              }}
            />
            <SelectField
              key="drawRpyMthdType"
              name="drawRpyMthdType"
              form={form}
              authority={authority}
              formItemProps={{ label: '还款方式' }}
              fieldProps={{
                initialValue: data.drawRpyMthdType,
                rules: [
                  { required: true, message: '还款方式是必选项！' },
                ],
              }}
              inputProps={{
                placeholder: '请选择',
                options: intCalModeOptions,
              }}
            />
            <SelectField
              key="repaymentDateRuleCode"
              name="repaymentDateRuleCode"
              form={form}
              authority={authority}
              show={Object.prototype.hasOwnProperty.call(data, 'repaymentDateRuleCode')}
              formItemProps={{ label: '还款日规则' }}
              fieldProps={{
                initialValue: data.repaymentDateRuleCode,
              }}
              inputProps={{
                placeholder: '请选择',
                options: repayDateRuleOptions,
              }}
            />
            <InputField
              key="pnlRate"
              name="pnlRate"
              form={form}
              authority={authority}
              formItemProps={{ label: '罚息利率(%)' }}
              fieldProps={{
                initialValue: data.pnlRate,
                rules: [
                  { required: true, message: '罚息利率是必选项！' },
                ],
              }}
              inputProps={{
                readOnly: true,
              }}
            />
          </Row>
        </Form>
      </div>
    )
  }
}

BorrowBasinInfoForm.propTypes = {
  form: PropTypes.object,
  data: PropTypes.object,
  authority: PropTypes.string,
  onChange: PropTypes.func,
}
export default wrapFormContainer(formIds.creditBase, '额度基本信息')(BorrowBasinInfoForm)
