
import React, { Component } from 'react'
import Modal from 'lbc-wrapper/lib/modal'
import message from 'lbc-wrapper/lib/message'
import { connect } from 'react-redux'
import { queryCollateralList } from '../../../../../asset/collateral/queryList/modules/queryListInfo'
import { ORDER_UPDATE_COLLATERAL_INFO_LIST } from '../../../../../order/common/tabAction'
import { SearchMakerParams } from '../../../../../../common/ListCommon/listCommonUtils';
import pageMode from '../../../../../../common/pageMode'
import pageType from '../../../../../../common/pageType'
import searchMaker from '../../../../../../utils/makeSearch'
import { approval } from '../../../../../order/common/parameterType'
import ApplyNoWrapper from '../../../../../../components/ApplyNoWrapper/ApplyNoWrapper'
import TablePage from '../../../../../../components/form/inputs/TablePage'
import wrapTableContainer from '../../../../../../components/form/groups/wrapTableContainer'
import formIds from '../../../common/formIds'

import {
  assetGrnteeObjTypeRender,
  assetGrnteeTypeRender,
} from '../../../../../../components/columnRenders/AssetCollateralType';

const confirm = Modal.confirm

class CollateralInfoAmountTable extends Component {
  constructor(props) {
    super(props)

    this.router = this.router.bind(this)

    this.columns = [
      {
        title: '担保编号',
        dataIndex: 'num',
        key: 'num',
        // render: (value, record) =>{
        //   return <ApplyNoWrapper value={value} to={this.router(record)} />
        // },
      },
      {
        title: '担保名称',
        dataIndex: 'name',
        key: 'name',
      },
      {
        title: '担保类型',
        dataIndex: 'catCode',
        key: 'catCode',
        render: assetGrnteeTypeRender,
      },
      {
        title: '押品类型',
        dataIndex: 'typeCode',
        key: 'typeCode',
        render: assetGrnteeObjTypeRender,
      },
      {
        title: '押品所有权人',
        dataIndex: 'guarOwnerName',
        key: 'guarOwnerName',
      },
    ]
    this.state = {
      visible: false,
      data: [

      ],
    }
  }

  componentDidMount() {
    const { tabhelper } = this.props
    tabhelper.subscribe((type, payload) => {
      if (type === ORDER_UPDATE_COLLATERAL_INFO_LIST) {
        this.table && this.table.refresh()
      }
    })
  }

  router(data) {
    const { history, orderId, tabhelper } = this.props
    const parsed = tabhelper.getsearch()
    const mode = parsed.t === pageType.APPROVAL ? pageMode.VIEW : parsed.m
    // bid 订单编号, gId 担保编号
    const search = searchMaker(
      mode,
      parsed.t,
      '',
      { bid: orderId }, // 订单编号
      {
        gid: data.num, // 担保编号
        pt: parsed.pt,
        grnteeType: data.catCode,
        grnteeObjType: data.catCode !== '01' ? data.typeCode : ''
      },
    )
    if (data.catCode === '01') {
      return `/dashboard/amount/amount/addGuaranteeInfo/guaranteePage/${search}`
    } else if (data.typeCode === '01') {
      return `/dashboard/amount/amount/addGuaranteeInfo/carPage/${search}`
    } else if (data.typeCode === '02') {
      return `/dashboard/amount/amount/addGuaranteeInfo/housePropertyPage/${search}`
    } else if (data.typeCode === '99') {
      return `/dashboard/amount/amount/addGuaranteeInfo/otherCollateralPage/${search}`
    }
  }

  render() {
    const parsed = this.props.tabhelper.getsearch()
    const { data } = this.props
    console.log('担保信息', data)
    return (
      <div>
        {/* <TablePage
          fields={this.fields}
          ref={r => (this.table = r)}
          columns={this.columns}
          actions={parsed.t === pageType.RECORD || parsed.t === pageType.APPROVAL ? [] : this.actions}
          // actions={this.actions }
          query={this.query}
          data={this.state.data}
          rowKey="naturalNo"
        /> */}
        <TablePage
          rowSelection={null}
          columns={this.columns}
          dataSource={data}
          query={this.pageInfo}
          doPagination={false}
        />
      </div>
    )
  }
}

export default wrapTableContainer(formIds.guaranteeList, '担保信息')(CollateralInfoAmountTable)
