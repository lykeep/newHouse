// import { createFetchAction, createAction } from '../../../../../../modules/common'
//
// const AMOUNT_AMOUNT_CHANGE_CUT_SAVE_INFO = 'AMOUNT_AMOUNT_CHANGE_CUT_SAVE_INFO'
// const AMOUNT_AMOUNT_FREEZE_LOSE_SAVE_INFO = 'AMOUNT_AMOUNT_FREEZE_LOSE_SAVE_INFO'
//
// export const changeCutSaveInfo = createFetchAction(AMOUNT_AMOUNT_CHANGE_CUT_SAVE_INFO, 'vfc-intf-ent-contract.saveCreditReduce')
// export const freezeLoseSaveInfo = createFetchAction(AMOUNT_AMOUNT_FREEZE_LOSE_SAVE_INFO, 'vfc-intf-ent-contract.saveCreditChangeCommon')
//
// export default {
//   changeCutSaveInfo,
//   freezeLoseSaveInfo,
// }
