import SecurityDepositInfoForm from '../../../../../order/ApplyInfoChildComponent/SecurityDepositInfoTable'
import wrapTableContainer from '../../../../../../components/form/groups/wrapFormContainer'

export default wrapTableContainer('SecurityDepositInfoForm', '保证金信息')(SecurityDepositInfoForm)
