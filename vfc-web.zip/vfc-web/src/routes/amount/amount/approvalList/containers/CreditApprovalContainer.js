import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'

import ApprovalList from '../components/ApprovalList'

import {
  queryAmountApprovalList,
} from '../modules/CreditApprovalTable'

const mapActionCreators = {
  queryAmountApprovalList,
}

const mapStateToProps = () => ({})

export default withRouter(connect(mapStateToProps, mapActionCreators)(ApprovalList))
