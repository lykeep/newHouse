import { createFetchAction } from 'modules/common'

const AMOUNT_GRANT_QUERY_APPROVAL_LIST = 'AMOUNT_GRANT_QUERY_APPROVAL_LIST'
export const queryAmountApprovalList = createFetchAction(AMOUNT_GRANT_QUERY_APPROVAL_LIST, 'vfc-intf-ent-contract.creditChangeTodoList')
