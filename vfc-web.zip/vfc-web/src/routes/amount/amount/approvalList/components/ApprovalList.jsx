import React, { Component } from 'react'
import PropTypes from 'prop-types'
import ACTIONS from '../../../../../components/queryTable/consts'
import PageContainerHeader from '../../../../../components/form/page/PageContainerHeader'
import searchMaker from '../../../../../utils/makeSearch'
import pageMode from '../../../../../common/pageMode'
import pageType from '../../../../../common/pageType'
import ApprovalTable from '../../../../../components/ApprovalTable'
import { amountApplyTypeLabels } from '../../../../../common/bizApplyType/amount'
import moneyFormatter from '../../../../../components/columnRenders/moneyFormatter'
import makeTitle from '../../../../../utils/makeTitle'

import { AMOUNT_AMOUNT_UPDATE_APPROVE_LIST } from '../../common/tabAction'

class GrantApprovalList extends Component {
  constructor(props) {
    super(props)
    this.bizKeyUrl = this.bizKeyUrl.bind(this)
    this.onApprove = this.onApprove.bind(this)

    this.columns = [
      {
        title: '借款人名称',
        dataIndex: 'borrowerName',
        key: 'borrowerName',
      },
      {
        title: '项目名称',
        dataIndex: 'projectName',
        key: 'projectName',
      },
      {
        title: '总额度(元)',
        dataIndex: 'totalCreditAmt',
        key: 'totalCreditAmt',
        render: moneyFormatter,
      },
    ]

    this.actions = [
      {
        ...ACTIONS.APPROVAL,
        action: this.onApprove,
      },
    ]
  }
  componentDidMount() {
    const { tabhelper } = this.props
    this.unsubscribe = tabhelper.subscribe((type) => {
      if (type === AMOUNT_AMOUNT_UPDATE_APPROVE_LIST) {
        this.table && this.table.refresh()
      }
    })
  }

  componentWillUnmount() {
    this.unsubscribe && this.unsubscribe()
  }

  // 审批按钮
  onApprove(selectedRowKeys, selectedRows) {
    const { history } = this.props
    history.push(this.bizKeyUrl('', selectedRows[0]))
  }
  bizKeyUrl(value, record) {
    const search = searchMaker(
      pageMode.MODIFY,
      pageType.APPROVAL,
      record.busiApplyType,
      {
        bid: record.creditNum,
        bpid: record.businessKey,
        pid: record.procInstanceId,
        tid: record.taskInstanceId,
      },
    )
    return `/dashboard/amount/amount/${record.uiName}${search}`
  }
  render() {
    return (
      <div>
        <PageContainerHeader title={makeTitle('额度变更审批列表')} />
        <ApprovalTable
          tabhelper={this.props.tabhelper}
          ref={r => (this.table = r)}
          columns={this.columns}
          actions={this.actions}
          query={this.props.queryAmountApprovalList}
          rowKey="taskInstanceId"
          listKey="qryCreditChangeList"
          bizKeyUrl={this.bizKeyUrl}
          bizApplyTypeLabels={amountApplyTypeLabels}
        />
      </div>

    )
  }
}

GrantApprovalList.propTypes = {
  queryAmountApprovalList: PropTypes.func,
  history: PropTypes.shape({
    push: PropTypes.func,
  }),
  tabhelper: PropTypes.shape({
    subscribe: PropTypes.func,
  }),
}

export default GrantApprovalList
