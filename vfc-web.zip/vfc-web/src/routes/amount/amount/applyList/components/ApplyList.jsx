import React, { Component } from 'react'
import PropTypes from 'prop-types'
import pageMode from '../../../../../common/pageMode'
import pageType from '../../../../../common/pageType'
import searchMaker from '../../../../../utils/makeSearch'
import { isDraft } from '../../../../../common/isDraft'
import ACTIONS from '../../../../../components/queryTable/consts'
import PageContainerHeader from '../../../../../components/form/page/PageContainerHeader'
import ApplicationTable from '../../../../../components/ApplicationTable'
import { amountApplyTypeRender, amountApplyTypeSelectOptions } from '../../../../../common/bizApplyType/amount'
import moneyFormatter from '../../../../../components/columnRenders/moneyFormatter'
import makeTitle from '../../../../../utils/makeTitle'

import { AMOUNT_AMOUNT_UPDATE_APPLICATION_LIST } from '../../common/tabAction'

class CreditApplyList extends Component {
  constructor(props) {
    super(props)
    this.onModify = this.onModify.bind(this)
    this.onDelete = this.onDelete.bind(this)
    this.columns = [
      {
        title: '借款人名称',
        dataIndex: 'borrowerName',
        key: 'borrowerName',
      },
      {
        title: '项目名称',
        dataIndex: 'projectName',
        key: 'projectName',
      },
      {
        title: '总额度(元)',
        dataIndex: 'totalCreditAmt',
        key: 'totalCreditAmt',
        render: moneyFormatter,
      },
    ]

    this.fields = [
      { id: 'borrowerName', label: '借款人名称', component: 'Input', placeholder: '' },
      { id: 'projectName', label: '项目名称', component: 'Input', placeholder: '' },
      // { id: 'busiApplyType', label: '申请类型', component: 'Input', placeholder: amountApplyTypeSelectOptions },
    ]


    this.actions = [
      {
        ...ACTIONS.MODIFY,
        action: this.onModify,
      },
      {
        ...ACTIONS.REMOVE,
        action: this.onDelete,
      },
    ]
    this.state = {
    }
  }
  componentDidMount() {
    const { tabhelper } = this.props
    this.unsubscribe = tabhelper.subscribe((type) => {
      if (type === AMOUNT_AMOUNT_UPDATE_APPLICATION_LIST) {
        this.tableRef && this.tableRef.refresh()
      }
    })
  }

  componentWillUnmount() {
    this.unsubscribe && this.unsubscribe()
  }

  // 编辑
  onModify(selectedRowKeys, selectedRows) {
    const { history } = this.props
    let search = ''
    search = searchMaker(pageMode.MODIFY, pageType.DRAFT, selectedRows[0].busiApplyType, {
      bid: selectedRows[0].creditNum,
      bpid: selectedRows[0].businessKey,
    })
    history.push(`/dashboard/amount/amount/info${search}`)
  }

  // 删除
  onDelete() {
    this.props.deleteAmountDraft({
      // lpNo: selectedRows[0].projectNum,
      // deleteRecordList: selectedRows[0].projectNum,
      // lpBusinessProcessNo: selectedRows[0].businessKey,
    }).then(() => this.table.refresh())
  }

  bizKeyUrl(value, record) {
    let search = null

    if (record.isDraft === isDraft.YES) {
      search = searchMaker(
        pageMode.MODIFY,
        '',
        record.busiApplyType,
        {
          bid: record.creditNum,
          bpid: record.businessKey,
        },
      )

      return `/dashboard/amount/amount/info${search}`
    }

    search = searchMaker(
      pageMode.VIEW,
      pageType.APPROVAL,
      record.busiApplyType,
      {
        bid: record.creditNum,
        bpid: record.businessKey,
        pid: record.procInstanceId,
      },
    )

    return `/dashboard/amount/amount/${record.uiName}${search}`
  }

  render() {
    return (
      <div>
        <PageContainerHeader title={makeTitle('额度变更申请列表')} />
        <ApplicationTable
          ref={r => (this.tableRef = r)}
          columns={this.columns}
          fields={this.fields}
          actions={this.actions}
          bizKeyUrl={this.bizKeyUrl}
          query={this.props.queryAmountGrantApplyList}
          rowKey="businessKey"
          applyTypeRender={amountApplyTypeRender}
          SelectOptions={amountApplyTypeSelectOptions}
          listName="qryCreditChangeList"
        />
      </div>

    )
  }
}

CreditApplyList.propTypes = {
  queryAmountGrantApplyList: PropTypes.func,
  deleteAmountDraft: PropTypes.func,
  history: PropTypes.shape({
    push: PropTypes.func,
  }),
  tabhelper: PropTypes.shape({
    subscribe: PropTypes.func,
  }),
}

export default CreditApplyList
