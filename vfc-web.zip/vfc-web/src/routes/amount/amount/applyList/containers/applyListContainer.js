import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'

import CreditListApplyInfo from '../components/ApplyList'

import {
  queryAmountGrantApplyList,
  deleteAmountDraft,
} from '../modules/applyListInfo'

const mapActionCreators = {
  queryAmountGrantApplyList,
  deleteAmountDraft,
}

const mapStateToProps = () => ({})

export default withRouter(connect(mapStateToProps, mapActionCreators)(CreditListApplyInfo))
