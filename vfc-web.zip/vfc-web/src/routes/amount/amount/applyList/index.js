import loadable from '../../../../utils/loadable'

export default () =>
  loadable(() => import(/* webpackChunkName1111: "amount.amount.application.list" */ './containers/applyListContainer'))
