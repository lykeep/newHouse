import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'

import QueryList from '../components/QueryList'

import {
  queryListInfo,
} from '../modules/queryListInfo'

const mapActionCreators = {
  queryListInfo,
}

const mapStateToProps = state => ({})

export default withRouter(connect(mapStateToProps, mapActionCreators)(QueryList))
