import { createReducer, createFetchAction } from 'modules/common'

const AMOUNT_AMOUNT_QUERY_LIST_INFO = 'AMOUNT_AMOUNT_QUERY_LIST_INFO'

export const queryListInfo = createFetchAction(AMOUNT_AMOUNT_QUERY_LIST_INFO, 'vfc-intf-ent-contract.qryCreditList')
