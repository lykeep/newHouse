import React, { Component } from 'react'
import PropTypes from 'prop-types'
import searchMaker from '../../../../../utils/makeSearch'
import pageMode from '../../../../../common/pageMode'
import pageType from '../../../../../common/pageType'
import makeTitle from '../../../../../utils/makeTitle'
import ACTIONS from '../../../../../components/queryTable/consts'
import QueryTable from '../../../../../components/queryTable'
import PageContainerHeader from '../../../../../components/form/page/PageContainerHeader'
import moneyFormatter from '../../../../../components/columnRenders/moneyFormatter'
import ApplyNoWrapper from '../../../../../components/ApplyNoWrapper/ApplyNoWrapper'
import QueryListAlterModal from './QueryListAlterModal'
import { amountStatusRender, amountStatusSelectOptions } from '../../../../../components/columnRenders/amountStatusList'
import certType from '../../../../../components/columnRenders/certType'

class QueryList extends Component {
  constructor(props) {
    super(props)
    this.query = this.query.bind(this)
    this.onAlter = this.onAlter.bind(this)
    this.onCancel = this.onCancel.bind(this)

    this.state = {
      data: [],
      alertModalVisible: false,
      creditNum: '',
    }

    this.columns = [
      {
        title: '额度编号',
        dataIndex: 'creditNum',
        key: 'creditNum',
        render: (value, record) => {
          const search = searchMaker(pageMode.VIEW, pageType.RECORD, '', { bid: record.creditNum })
          const to = `/dashboard/amount/amount/info${search}`
          return (<ApplyNoWrapper value={value} to={to} />)
        },
      },
      {
        title: '客户姓名',
        dataIndex: 'borrowName',
        key: 'borrowName',
      },
      {
        title: '证件类型',
        dataIndex: 'borrowCertificateTypeCd',
        key: 'borrowCertificateTypeCd',
        render: certType,
      },
      {
        title: '证件号码',
        dataIndex: 'borrowCertificateNum',
        key: 'borrowCertificateNum',
      },
      {
        title: '项目名称',
        dataIndex: 'projectName',
        key: 'projectName',
      },
      {
        title: '项目编号',
        dataIndex: 'projectNum',
        key: 'projectNum',
      },
      {
        title: '总额度(元)',
        dataIndex: 'totalAmt',
        key: 'totalAmt',
        render: moneyFormatter,
      },
      {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: amountStatusRender,
      },
      {
        title: '生效日',
        dataIndex: 'effectDate',
        key: 'effectDate',
      },
      {
        title: '失效日',
        dataIndex: 'dueDate',
        key: 'dueDate',
      },
    ]

    this.fields = [
      [
        { id: 'creditNum', label: '额度编号', component: 'Input' },
        { id: 'borrowerName', label: '客户姓名', component: 'Input' },
      ],
      [
        { id: 'borrowerCertificateNum', label: '证件号码', component: 'Input' },
        { id: 'projectName', label: '项目名称', component: 'Input' },
        { id: 'projectNum', label: '项目编号', component: 'Input' },
        { id: 'creditStatus', label: '额度状态', component: 'Select', options: amountStatusSelectOptions },
      ],
    ]

    this.actions = [
      // 2019-09-23, 额度变更不上
      // {
      //   ...ACTIONS.ALTER,
      //   action: this.onAlter,
      // },
    ]
  }

  // 变更
  onAlter(values, record) {
    this.setState({
      alertModalVisible: true,
      creditNum: record[0].creditNum,
    })
  }

  onCancel() {
    this.setState({
      alertModalVisible: false,
    })
  }

  // 查询
  query(params) {
    this.props.queryListInfo(params).then((data) => {
      this.setState({
        data: data.creditList,
        totalCount: data.total,
      })
    })
  }

  render() {
    return (
      <div>
        <PageContainerHeader title={makeTitle('额度列表')} />
        <QueryTable
          data={this.state.data}
          columns={this.columns}
          fields={this.fields}
          actions={this.actions}
          query={this.query}
          rowKey="accountAddress"
          totalCount={this.state.totalCount}
        />
        <QueryListAlterModal
          visible={this.state.alertModalVisible}
          onCancel={this.onCancel}
          creditNum={this.state.creditNum}
          {...this.props}
        />
      </div>
    )
  }
}

QueryList.propTypes = {
  queryListInfo: PropTypes.func,
  history: PropTypes.shape({
    push: PropTypes.func,
  }),
}

export default QueryList
