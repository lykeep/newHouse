import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import Modal from 'lbc-wrapper/lib/modal'
import SelectField from '../../../../../components/form/inputs/SelectField'
import pageMode from '../../../../../common/pageMode'
import pageType from '../../../../../common/pageType'
import searchMaker from '../../../../../utils/makeSearch'

class QueryListAlterModal extends Component {
  constructor(props) {
    super(props)
    this.onCancel = this.onCancel.bind(this)
    this.onOk = this.onOk.bind(this)

    this.changeType = [
      {
        value: '01',
        key: '01',
        title: '调减',
      },
      {
        value: '02',
        key: '02',
        title: '冻结',
      },
      {
        value: '03',
        key: '03',
        title: '解冻',
      },
      {
        value: '04',
        key: '04',
        title: '失效',
      },
    ]
  }

  onCancel() {
    this.props.onCancel({ type: '1' })
  }

  onOk() {
    const { form, history, creditNum } = this.props
    const { validateFields } = form

    validateFields((errors, values) => {
      // values ---- > {changeType: "02"}
      if (errors) {
        console.log(errors)
        return
      }
      const search = searchMaker(
        pageMode.CREATE,
        pageType.DRAFT,
        values.changeType,
        {
          bid: creditNum,
        },
      )
      history.push(`info/${search}`)
      this.onCancel()
    })
  }

  render() {
    const { form, authority = '2' } = this.props

    return (
      <Modal
        visible={this.props.visible}
        title="选择额度变更类型"
        okText="确定"
        cancelText="取消"
        onCancel={this.onCancel}
        onOk={this.onOk}
        width={800}
        destroyOnClose
      >
        <div>
          <Form>
            <Row>
              <SelectField
                form={form}
                name="changeType"
                colSpan={12}
                authority={authority}
                formItemProps={{ label: '变更类型' }}
                fieldProps={{
                  rules: [
                      { required: true, message: '变更类型是必选项！' },
                  ],
                }}
                inputProps={{
                    options: this.changeType,
                }}
              />
            </Row>
          </Form>
        </div>
      </Modal>
    )
  }
}

QueryListAlterModal.propTypes = {
  onCancel: PropTypes.func.isRequired,
  authority: PropTypes.string,
  visible: PropTypes.bool,
  form: PropTypes.object,
  history: PropTypes.object,
}

export default Form.create()(QueryListAlterModal)
