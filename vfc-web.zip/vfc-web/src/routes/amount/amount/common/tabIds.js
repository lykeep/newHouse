
export default {
  basicInfo: 'AMOUNT_BASIC_INFO',
  guaranteeInfo: 'AMOUNT_GUATANTEE_INFO',
  applyInfo: 'AMOUNT_APPLY_INFO',
  quotaInfo: 'AMOUNT_QUOTA_INFO',
  changeInfo: 'AMOUNT_CHANGE_INFO',
  approvalInfo: 'AMOUNT_APPROVALPAGE_INFO',
  attachmentInfo: 'AMOUNT_ATTACHMENT_INFO',
  circulationRecordInfo: 'AMOUNT_CIRCULATION_INFO',
  flowChartInfo: 'AMOUNT_FLOW_CHART_INFO',
}

export const tabTitleMap = {
  AMOUNT_BASIC_INFO: '基本信息',
  AMOUNT_GUATANTEE_INFO: '担保信息',
  AMOUNT_APPLY_INFO: '申请信息',
  AMOUNT_QUOTA_INFO: '额度信息',
  AMOUNT_CHANGE_INFO: '变更信息',
  AMOUNT_APPROVALPAGE_INFO: '审批信息',
  AMOUNT_ATTACHMENT_INFO: '附件信息',
  AMOUNT_CIRCULATION_INFO: '流转记录',
  AMOUNT_FLOW_CHART_INFO: '流程图',
}
