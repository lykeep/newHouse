import formIds from './formIds'

export const idTitleMap = {
  [formIds.applyInfo]: '申请信息',
  [formIds.quotaInfo]: '额度信息',
  [formIds.changeInfo]: '变更信息',
  [formIds.approvalInfo]: '审批信息',
  [formIds.circulationRecordInfo]: '流转记录',
  [formIds.flowChartInfo]: '流程图',
  [formIds.attachmentInfo]: '附件信息',
  [formIds.basicInfo]: '基本信息',
  [formIds.guaranteeInfo]: '担保信息',
}

export default formIds
