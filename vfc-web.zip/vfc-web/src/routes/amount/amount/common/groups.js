import tabIds, { tabTitleMap } from './tabIds'

import QuotaInfo from '../info/components/QuotaInfoForm/QuotaInfoForm'
import ChangeInfo from '../info/components/ChangeInfoForm/ChangeInfoForm'
import BasicInfo from '../info/components/BasicForm/BasicTab'
import ApprovalInfo from '../info/components/ApprovalForm/ApprovalForm'
import CirculationInfo from '../info/components/CirculationRecordTable/CirculationRecordTable'
import FlowChartInfo from '../info/components/FlowChartInfo/FlowChartInfo'
import ApplyInfoTab from '../info/components/ApplyInfoForm/ApplyInfoTab'
import AttachmentInfoForm from '../info/components/AttachmentInfoForm/AttachmentInfoForm'
import CollateralInfoTable from '../info/components/CollateralInfoTable/CollateralInfoAmountTable'
import { PERMISSIONS } from '../../../../components/form/utils/calPermission'

const GrantGroups = [
  {
    groupId: tabIds.basicInfo,
    title: tabTitleMap[tabIds.basicInfo],
    forceRender: true,
    path: 'BasicInfo',
    authority: PERMISSIONS.READ,
    component: () => BasicInfo,
  },
  {
    groupId: tabIds.applyInfo,
    title: tabTitleMap[tabIds.applyInfo],
    forceRender: true,
    path: 'ApplyInfoTab',
    authority: PERMISSIONS.READ,
    component: () => ApplyInfoTab,
  },
  {
    groupId: tabIds.quotaInfo,
    title: tabTitleMap[tabIds.quotaInfo],
    forceRender: true,
    path: 'QuotaInfoForm/QuotaInfoForm',
    authority: PERMISSIONS.READ,
    component: () => QuotaInfo,
  },
  {
    groupId: tabIds.guaranteeInfo,
    title: tabTitleMap[tabIds.guaranteeInfo],
    forceRender: true,
    path: 'CollateralInfoTable',
    component: () => CollateralInfoTable,
  },
  {
    groupId: tabIds.attachmentInfo,
    title: tabTitleMap[tabIds.attachmentInfo],
    forceRender: true,
    path: 'AttachmentInfoForm',
    authority: PERMISSIONS.READ,
    component: () => AttachmentInfoForm,
  },
]

export const ChangeInfoGroup = {
  groupId: tabIds.changeInfo,
  title: tabTitleMap[tabIds.changeInfo],
  forceRender: true,
  path: 'ChangeInfoForm/ChangeInfoForm',
  component: () => ChangeInfo,
}

export const approvalGroup = {
  groupId: tabIds.approvalInfo,
  title: tabTitleMap[tabIds.approvalInfo],
  forceRender: true,
  path: 'ApprovalInfoForm/ApprovalForm',
  authority: PERMISSIONS.MODIFY,
  component: () => ApprovalInfo,
}

export const circulationGroup = {
  groupId: tabIds.circulationRecordInfo,
  title: tabTitleMap[tabIds.circulationRecordInfo],
  forceRender: false,
  path: 'BankAccountForm/BankAccountTable',
  authority: PERMISSIONS.READ,
  component: () => CirculationInfo,
}

export const flowChartGroup = {
  groupId: tabIds.flowChartInfo,
  title: tabTitleMap[tabIds.flowChartInfo],
  forceRender: false,
  path: 'BankAccountForm/BankAccountTable',
  component: () => FlowChartInfo,
}

export default GrantGroups
