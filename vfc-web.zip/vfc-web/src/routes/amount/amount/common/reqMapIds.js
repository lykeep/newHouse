import formIds from './formIds'

export const detailDataMap = {
  // [formIds.basicInfo]: 'creditBase',
  [formIds.basicInfo]: 'creditBasic',
  [formIds.creditBase]: 'creditBase',
  [formIds.paymentInfo]: 'repaymentAccouts',
  [formIds.rePaymentInfo]: 'trancheAccounts',
  [formIds.guaranteeList]: 'guaranteeList',
  [formIds.quotaInfo]: 'creditDetailMatadata', // 额度信息

  [formIds.changeInfo]: 'changeInfo',
  [formIds.approvalInfo]: 'approvalInfo',
}

/*
 * 提交数据时，formId和request中的Map的Key的对应关系
 */
export default {
  [formIds.changeInfo]: 'changeInfo',
  [formIds.approvalInfo]: 'approvalInfo',
}
