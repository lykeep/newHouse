const formIds = {
  quotaInfo: 'AMOUNT_QUOTA_INFO',
  changeInfo: 'AMOUNT_CHANGE_INFO',
  approvalInfo: 'AMOUNT_APPROVALPAGE_INFO',
  circulationRecordInfo: 'AMOUNT_CIRCULATION_INFO',
  flowChartInfo: 'AMOUNT_FLOW_CHART_INFO',
  applyInfo: 'AMOUNT_APPLY_INFO',
  basicInfo: 'AMOUNT_BASIC_INFO',
  creditBase: 'AMOUNT_BASE_INFO',
  guaranteeInfo: 'AMOUNT_GUATANTEE_INFO',
  paymentInfo: 'AMOUNT_PAYMENTINFO_INFO',
  rePaymentInfo: 'AMOUNT_REPAYMENTINFO_INFO',
  guaranteeList: 'AMOUNT_GUARANTEELIST_INFO',
  attachmentInfo: 'AMOUNT_ATTACHMENT_INFO',
}

export const formTitleMap = {
  [formIds.quotaInfo]: '额度信息',
  [formIds.changeInfo]: '变更信息',
  [formIds.approvalInfo]: '审批信息',
  [formIds.circulationRecordInfo]: '流转记录',
  [formIds.basicInfo]: '基本信息',
  [formIds.guaranteeInfo]: '担保信息',
  [formIds.applyInfo]: '申请信息',
  [formIds.attachmentInfo]: '附件信息',

}

export default formIds
