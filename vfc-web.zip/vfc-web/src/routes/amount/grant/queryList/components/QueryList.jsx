import React, { Component } from 'react'
import PropTypes from 'prop-types'
import QueryTable from '../../../../../components/queryTable'
import PageContainerHeader from '../../../../../components/form/page/PageContainerHeader'
import moneyFormatter from '../../../../../components/columnRenders/moneyFormatter'
import searchMaker from '../../../../../utils/makeSearch'
import pageMode from '../../../../../common/pageMode'
import pageType from '../../../../../common/pageType'
import { amountGrantApplyType } from '../../../../../common/bizApplyType/amount'
import makeTitle from '../../../../../utils/makeTitle'

import { AMOUNT_GRANT_UPDATE_OTHER_QUERY_LIST } from '../../common/tabAction'

class QueryList extends Component {
  constructor(props) {
    super(props)
    this.query = this.query.bind(this)
    this.onGrant = this.onGrant.bind(this)

    this.state = {
      data: [],
    }

    this.columns = [
      {
        title: '借款人',
        dataIndex: 'borrowerName',
        key: 'borrowerName',
      },
      {
        title: '项目名称',
        dataIndex: 'prjNm',
        key: 'prjNm',
      },
      {
        title: '进件编号',
        dataIndex: 'orderNum',
        key: 'orderNum',
      },
      {
        title: '待发放额度(元)',
        dataIndex: 'remainingLimit',
        key: 'remainingLimit',
        render: moneyFormatter,
      },
    ]

    this.fields = [
      [
        { id: 'borrowerName', label: '借款人', component: 'Input', placeholder: '请输入借款人' },
        { id: 'prjNm', label: '项目名称', component: 'Input', placeholder: '请输入项目名称' },
      ],
      [
        { id: 'orderNum', label: '进件编号', component: 'Input', placeholder: '请输入进件编号' },
      ],
    ]

    this.actions = [
      {
        label: '发放',
        minSelect: 1,
        maxSelect: 1,
        key: 'modify',
        action: this.onGrant,
      },
    ]
  }

  componentDidMount() {
    const { tabhelper } = this.props
    this.unsubscribe = tabhelper.subscribe((type) => {
      if (type === AMOUNT_GRANT_UPDATE_OTHER_QUERY_LIST) {
        this.table && this.table.refresh()
      }
    })
  }

  componentWillUnmount() {
    this.unsubscribe && this.unsubscribe()
  }

  // 发放
  onGrant(selectedRowKeys, selectedRows) {
    const { history } = this.props
    const search = searchMaker(pageMode.CREATE, pageType.DRAFT, amountGrantApplyType.GRANT, {
      bid: selectedRows[0].orderNum,
    })
    history.push(`/dashboard/amount/grant/info${search}`)
  }
  // 查询
  query(params) {
    this.props.queryListInfo(params).then((data) => {
      this.setState({
        data: data.limitGrantList,
      })
    })
  }

  render() {
    return (
      <div>
        <PageContainerHeader title={makeTitle('额度发放列表')} />
        <QueryTable
          ref={r => (this.table = r)}
          data={this.state.data}
          columns={this.columns}
          fields={this.fields}
          actions={this.actions}
          query={this.query}
          rowKey="orderNum"
          totalCount={this.state.totalCount}
        />
      </div>
    )
  }
}

QueryList.propTypes = {
  queryListInfo: PropTypes.func,
  history: PropTypes.shape({
    push: PropTypes.func,
  }),
  tabhelper: PropTypes.shape({
    subscribe: PropTypes.func,
  }),
}

export default QueryList
