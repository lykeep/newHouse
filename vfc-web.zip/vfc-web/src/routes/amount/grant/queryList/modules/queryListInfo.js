import { createFetchAction } from 'modules/common'

const AMOUNT_GRANT_QUERY_LIST_INFO = 'AMOUNT_GRANT_QUERY_LIST_INFO'

export const queryListInfo = createFetchAction(AMOUNT_GRANT_QUERY_LIST_INFO, 'vfc-intf-ent-contract.qryLimitGrantList')
