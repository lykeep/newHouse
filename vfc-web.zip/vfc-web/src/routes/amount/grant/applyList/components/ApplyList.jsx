/* eslint-disable no-undef */
import React, { Component } from 'react'
import PropTypes from 'prop-types'
import ACTIONS from '../../../../../components/queryTable/consts'
import PageContainerHeader from '../../../../../components/form/page/PageContainerHeader'
import ApplicationTable from '../../../../../components/ApplicationTable'
import { isDraft } from '../../../../../common/isDraft'
import { actionRouter } from '../../../../../common/ListCommon/listFunctionCommon'
import { SearchMakerParams } from '../../../../../common/ListCommon/listCommonUtils'
import { amountGrantApplyTypeRender, amountGrantApplyTypeSelectOptions } from '../../../../../common/bizApplyType/amount'
import moneyFormatter from '../../../../../components/columnRenders/moneyFormatter'
import makeTitle from '../../../../../utils/makeTitle'

import { AMOUNT_GRANT_UPDATE_OTHER_APPLICATION_LIST } from '../../common/tabAction'

class CreditApplyList extends Component {
  constructor(props) {
    super(props)
    this.bizKeyUrl = this.bizKeyUrl.bind(this)
    this.onModify = this.onModify.bind(this)
    this.onDelete = this.onDelete.bind(this)
    this.columns = [
      {
        title: '借款人',
        dataIndex: 'borrowerName',
        key: 'borrowerName',
      },
      {
        title: '项目名称',
        dataIndex: 'projectName',
        key: 'projectName',
      },
      {
        title: '进件编号',
        dataIndex: 'orderNum',
        key: 'orderNum',
      },
      {
        title: '总额度(元)',
        dataIndex: 'totalCreditAmt',
        key: 'totalCreditAmt',
        render: moneyFormatter,
      },
      {
        title: '已发放额度',
        dataIndex: 'applyCreditAmt',
        key: 'applyCreditAmt',
        render: moneyFormatter,
      },
    ]

    this.fields = [
      { id: 'orderNum', label: '进件编号', component: 'Input', placeholder: '' },
      { id: 'projectName', label: '项目名称', component: 'Input', placeholder: '' },
      { id: 'borrowerName', label: '借款人', component: 'Input', placeholder: '' },
    ]


    this.actions = [
      {
        ...ACTIONS.MODIFY,
        action: this.onModify,
      },
      {
        ...ACTIONS.REMOVE,
        action: this.onDelete,
      },
    ]
    this.state = {
    }
  }
  componentDidMount() {
    const { tabhelper } = this.props
    this.unsubscribe = tabhelper.subscribe((type) => {
      if (type === AMOUNT_GRANT_UPDATE_OTHER_APPLICATION_LIST) {
        this.tableRef && this.tableRef.refresh()
      }
    })
  }

  componentWillUnmount() {
    this.unsubscribe && this.unsubscribe()
  }

  // 编辑
  onModify(selectedRowKeys, selectedRows) {
    const { history } = this.props
    const search = actionRouter(selectedRows[0], selectedRows[0].orderNum, selectedRows[0].busiApplyType, SearchMakerParams.paramsEdit)
    history.push(`/dashboard/amount/creditLegalQuotaForm${search}`)
  }
  // 删除
  onDelete(selectedRowKeys, selectedRows) {
    this.props.deleteAmountGrantDraft([{
      businessKey: selectedRows[0].businessKey,
    }]).then(() => this.table.refresh())
  }
  bizKeyUrl(value, record) {
    let search = null
    let path = null
    if (record.isDraft === isDraft.YES) {
      search = actionRouter(record, record.orderNum, record.busiApplyType, SearchMakerParams.DraftDetail)
      path = `/dashboard/amount/grant/info${search}`
    } else {
      search = actionRouter(record, record.orderNum, record.busiApplyType, SearchMakerParams.FlowDetail)
      path = `/dashboard/amount/grant/${record.uiName}${search}`
    }
    return path
  }
  render() {
    return (
      <div>
        <PageContainerHeader title={makeTitle('额度发放申请列表')} />
        <ApplicationTable
          ref={r => (this.tableRef = r)}
          columns={this.columns}
          fields={this.fields}
          actions={this.actions}
          query={this.props.queryAmountGrantApplyList}
          rowKey="businessKey"
          bizKeyUrl={this.bizKeyUrl}
          applyTypeRender={amountGrantApplyTypeRender}
          SelectOptions={amountGrantApplyTypeSelectOptions}
          listName="qryCreditTransList"
        />
      </div>

    )
  }
}

CreditApplyList.propTypes = {
  queryAmountGrantApplyList: PropTypes.func,
  deleteAmountGrantDraft: PropTypes.func,
  history: PropTypes.shape({
    push: PropTypes.func,
  }),
  tabhelper: PropTypes.shape({
    subscribe: PropTypes.func,
  }),
}

export default CreditApplyList
