import { createFetchAction } from 'modules/common'

const AMOUNT_GRANT_APPLY_LIST_INFO = 'AMOUNT_GRANT_APPLY_LIST_INFO' // 授信 - 法人信息额度
export const queryAmountGrantApplyList = createFetchAction(AMOUNT_GRANT_APPLY_LIST_INFO, 'vfc-intf-ent-contract.creditDistributionSubmitList')

const AMOUNT_GRANT_APPLY_LIST_INFO_DELETE = 'AMOUNT_GRANT_APPLY_LIST_INFO_DELETE' // 删除
export const deleteAmountGrantDraft = createFetchAction(AMOUNT_GRANT_APPLY_LIST_INFO_DELETE, 'vfc-intf-ent-credit.deleteLegalPersonCreditRecord')
