import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'

import CreditListApplyInfo from '../components/ApplyList'

import {
  queryAmountGrantApplyList,
  deleteAmountGrantDraft,
} from '../modules/applyListInfo'

const mapActionCreators = {
  queryAmountGrantApplyList,
  deleteAmountGrantDraft,
}

const mapStateToProps = () => ({})

export default withRouter(connect(mapStateToProps, mapActionCreators)(CreditListApplyInfo))
