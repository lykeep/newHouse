import loadable from '../../../../utils/loadable'

export default () =>
  loadable(() => import(/* webpackChunkName1111: "amount.grant.application.list" */ './containers/applyListContainer'))
