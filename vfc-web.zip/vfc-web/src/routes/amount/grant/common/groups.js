import tabIds, { tabTitleMap } from './tabIds'

import ChangeInfo from '../info/components/ChangeInfoForm/ChangeInfoForm'
import ApprovalInfo from '../info/components/ApprovalForm/ApprovalForm'
import CirculationInfo from '../info/components/CirculationRecordTable/CirculationRecordTable'
import FlowChartInfo from '../info/components/FlowChartInfo/FlowChartInfo'

import { PERMISSIONS } from '../../../../components/form/utils/calPermission'

const GrantGroups = [
  {
    groupId: tabIds.changeInfo,
    title: tabTitleMap[tabIds.changeInfo],
    forceRender: true,
    path: 'ChangeInfoForm/ChangeInfoForm',
    component: () => ChangeInfo,
  },
]

export const approvalGroup = {
  groupId: tabIds.approvalInfo,
  title: tabTitleMap[tabIds.approvalInfo],
  forceRender: true,
  path: 'ApprovalInfoForm/ApprovalForm',
  authority: PERMISSIONS.MODIFY,
  component: () => ApprovalInfo,
}

export const circulationGroup = {
  groupId: tabIds.circulationRecordInfo,
  title: tabTitleMap[tabIds.circulationRecordInfo],
  forceRender: false,
  path: 'BankAccountForm/BankAccountTable',
  authority: PERMISSIONS.READ,
  component: () => CirculationInfo,
}

export const flowChartGroup = {
  groupId: tabIds.flowChartInfo,
  title: tabTitleMap[tabIds.flowChartInfo],
  forceRender: false,
  path: 'BankAccountForm/BankAccountTable',
  component: () => FlowChartInfo,
}

export default GrantGroups
