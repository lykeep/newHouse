const formIds = {
  changeInfo: 'AMOUNT_RELEASE_CHANGE_INFO',
  approvalInfo: 'GRANT_APPROVALPAGE_INFO',
  circulationRecordInfo: 'GRANT_CIRCULATION_INFO',
  flowChartInfo: 'GRANT_FLOW_CHART_INFO',
}

export const formTitleMap = {
  [formIds.changeInfo]: '变更信息',
  [formIds.approvalInfo]: '审批信息',
  [formIds.circulationRecordInfo]: '流转记录',
  [formIds.flowChartInfo]: '流程图',
}

export default formIds
