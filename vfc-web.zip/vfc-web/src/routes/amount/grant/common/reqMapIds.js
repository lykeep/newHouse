import formIds from './formIds'

export const detailDataMap = {
  [formIds.changeInfo]: 'changeInfo',
  [formIds.approvalInfo]: 'approvalInfo',
}

/*
 * 提交数据时，formId和request中的Map的Key的对应关系
 */
export default {
  [formIds.changeInfo]: 'changeInfo',
  [formIds.approvalInfo]: 'approvalInfo',
}
