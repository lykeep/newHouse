import formIds from './formIds'

export const tabTitleMap = {
  [formIds.changeInfo]: '变更信息',
  [formIds.approvalInfo]: '审批信息',
  [formIds.circulationRecordInfo]: '流转记录',
  [formIds.flowChartInfo]: '流程图',
}

export default formIds
