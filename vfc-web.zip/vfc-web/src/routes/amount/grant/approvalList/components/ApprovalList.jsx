import React, { Component } from 'react'
import PropTypes from 'prop-types'
import ACTIONS from '../../../../../components/queryTable/consts'
import PageContainerHeader from '../../../../../components/form/page/PageContainerHeader'
import { actionRouter } from '../../../../../common/ListCommon/listFunctionCommon'
import { SearchMakerParams } from '../../../../../common/ListCommon/listCommonUtils'
import ApprovalTable from '../../../../../components/ApprovalTable'
import { amountGrantApplyTypeLabels } from '../../../../../common/bizApplyType/amount'
import moneyFormatter from '../../../../../components/columnRenders/moneyFormatter'
import makeTitle from '../../../../../utils/makeTitle'

import { AMOUNT_GRANT_UPDATE_OTHER_APPROVE_LIST } from '../../common/tabAction'

class GrantApprovalList extends Component {
  constructor(props) {
    super(props)
    this.bizKeyUrl = this.bizKeyUrl.bind(this)
    this.onApprove = this.onApprove.bind(this)

    this.columns = [
      {
        title: '借款人',
        dataIndex: 'borrowerName',
        key: 'borrowerName',
      },
      {
        title: '项目名称',
        dataIndex: 'projectName',
        key: 'projectName',
      },
      {
        title: '进件编号',
        dataIndex: 'orderNum',
        key: 'orderNum',
      },
      {
        title: '总额度(元)',
        dataIndex: 'totalCreditAmt',
        key: 'totalCreditAmt',
        render: moneyFormatter,
      },
      {
        title: '已发放额度',
        dataIndex: 'applyCreditAmt',
        key: 'applyCreditAmt',
        render: moneyFormatter,
      },
    ]

    this.actions = [
      {
        ...ACTIONS.APPROVAL,
        action: this.onApprove,
      },
    ]
  }
  componentDidMount() {
    const { tabhelper } = this.props
    this.unsubscribe = tabhelper.subscribe((type) => {
      if (type === AMOUNT_GRANT_UPDATE_OTHER_APPROVE_LIST) {
        this.table && this.table.refresh()
      }
    })
  }

  componentWillUnmount() {
    this.unsubscribe && this.unsubscribe()
  }

  // 审批按钮
  onApprove(selectedRowKeys, selectedRows) {
    const { history } = this.props
    history.push(this.bizKeyUrl('', selectedRows[0]))
  }
  bizKeyUrl(value, record) {
    let search = null
    search = actionRouter(record, record.orderNum, record.busiApplyType, SearchMakerParams.APPROVALDetail)
    return `/dashboard/amount/grant/${record.uiName}${search}`
  }
  render() {
    return (
      <div>
        <PageContainerHeader title={makeTitle('额度发放审批列表')} />
        <ApprovalTable
          ref={r => (this.table = r)}
          columns={this.columns}
          actions={this.actions}
          query={this.props.queryGrantApprovalList}
          rowKey="taskInstanceId"
          listKey="qryCreditTransList"
          bizKeyUrl={this.bizKeyUrl}
          bizApplyTypeLabels={amountGrantApplyTypeLabels}
          tabhelper={this.props.tabhelper}
        />
      </div>

    )
  }
}

GrantApprovalList.propTypes = {
  queryGrantApprovalList: PropTypes.func,
  tabhelper: PropTypes.shape({
    subscribe: PropTypes.func,
  }),
  history: PropTypes.shape({
    push: PropTypes.func,
  }),
}

export default GrantApprovalList
