import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'

import ApprovalList from '../components/ApprovalList'

import {
  queryGrantApprovalList,
} from '../modules/CreditApprovalTable'

const mapActionCreators = {
  queryGrantApprovalList,
}

const mapStateToProps = () => ({})

export default withRouter(connect(mapStateToProps, mapActionCreators)(ApprovalList))
