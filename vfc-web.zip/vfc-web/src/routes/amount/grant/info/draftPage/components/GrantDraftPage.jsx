import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import _debug from 'lb-debug'
import message from 'lbc-wrapper/lib/message'
import Spin from 'lbc-wrapper/lib/spin'

import pageContainerWrapper from '../../../../../../components/form/page/PageContainerWrapper'
import PageContainerHeader from '../../../../../../components/form/page/PageContainerHeader'

import PageLoader from '../../../../../../components/form/page/PageLoader'
import SubmitFlow, { shouldOpenSubmitModal } from '../../../../../../components/workflow/submitFlow/SubmitFlow'

import pageMode from '../../../../../../common/pageMode'
import { PERMISSIONS } from '../../../../../../components/form/utils/calPermission'
import reqMapIds, { detailDataMap } from '../../../common/reqMapIds'
import { tabTitleMap } from '../../../common/tabIds'
import formIds from '../../../common/formIds'
import groups from '../../../common/groups'
import { flowActions } from '../../../../../../common/workflow'

import { AMOUNT_GRANT_UPDATE_OTHER_APPLICATION_LIST, AMOUNT_GRANT_UPDATE_OTHER_APPROVE_LIST } from '../../../common/tabAction'
import bizTypeCode from '../../../../../../common/bizTypeCode'
import { amountGrantApplyTypeLabels } from '../../../../../../common/bizApplyType/amount'
import makeTitle from '../../../../../../utils/makeTitle'

const debug = _debug('GrantDraftPage')

const PAGE_ID = 'amount_grant_draft_page'

class GrantDraftPage extends PureComponent {
  constructor(props) {
    super(props)

    this.onSubmit = this.onSubmit.bind(this)
    this.updateApplyList = this.updateApplyList.bind(this)
    this.updateApproveList = this.updateApproveList.bind(this)
    this.doSubmit = this.doSubmit.bind(this)
    this.submitDone = this.submitDone.bind(this)

    /*
     * 每个页面都要通过search传几个参数：
     * m: 页面的模式：新增／编辑／只读
     * t: 页面的类型：草稿／变更／审批
     */
    const parsed = props.tabhelper.getsearch() // queryString.parse(props.location.search)

    /*
     * 如果是新增
     */
    const authority = parsed.m === pageMode.VIEW ? PERMISSIONS.READ : PERMISSIONS.MODIFY

    /*
     * 定义了这个页面有哪些tab
     * {
     *   groupId, 对应后台配置的groupId，不能为空，必须唯一
     *   title, 页面显示的tab标题
     *   forceRender, 在页面展示时，是否强制渲染tab中的内容。如果这个tab中包含了form，则必须为true
     *   path, tab内容组件的路径，在动态加载的时候会用
     *   authority, 权限，查看／编辑／隐藏
     *   component, tab内容的组件，必须是一个返回组件的方法
     * }
     *
     * 创建草稿和变更信息页面，group信息是前台写死的。流程的是从后台取的
     */
    this.tabItem = groups

    this.state = {
      loading: false,
      submiting: false,
      businessKey: '',
      bizKey: '',
      groups: this.tabItem.map(t => ({ group_id: t.groupId, authority })),
      data: {
      },
      applyType: parsed.at,
    }

    this.actions = parsed.m === pageMode.VIEW ? [] : [
      {
        comp_id: 'submit',
        label: '提交',
        type: 'primary',
        onClick: this.onSubmit,
        key: 'submit',
      },
    ]
  }

  componentDidMount() {
    /*
     * 页面开始后，需要去后台取相关信息：
     * 1，新增草稿时，需要去后台取业务系统的ID，附件树
     * 2，新增变更时，需要去后台取原数据（包含新的业务id），附件树
     * 3，审批时，需要去后台取原数据，附件树，group信息，审批信息
     * 4，编辑／查看时，需要去后台取原数据，附件树
     * 不同操作调用不同接口，但一个接口会返回所有需要的数据
     */
    const { queryAmountGrantDetailChange, tabhelper, getBidAndBpid } = this.props
    tabhelper.closeothersamepathtab()
    const parsed = tabhelper.getsearch()

    // 创建
    if (parsed.m === pageMode.CREATE) {
      /*
       * 这里要调用2个接口：
       * 1，获取流程id接口
       * 2，获取记录详情接口
       */
      getBidAndBpid({
        busiApplyType: this.state.applyType,
        busiType: bizTypeCode.AMOUNT_GRANT,
        businessNo: parsed.bid,
      }).then((ids) => {
        queryAmountGrantDetailChange({
          appFormId: ids.businessKey,
        }).then((data) => {
          this.setState({
            data: {
              [detailDataMap[formIds.changeInfo]]: { applyType: this.state.applyType, ...data },
            },
            businessKey: ids.businessKey,
            bizKey: parsed.bid,
            loading: false,
          })
        })
      })
    } else if (parsed.m === pageMode.MODIFY || parsed.m === pageMode.VIEW) {
      // 编辑或查看
      queryAmountGrantDetailChange({
        appFormId: parsed.bpid,
      }).then((data) => {
        this.setState({
          data: {
            [detailDataMap[formIds.changeInfo]]: { applyType: this.state.applyType, ...data },
          },
          businessKey: parsed.bpid,
          bizKey: parsed.bid,
          loading: false,
        })
      })
    }
  }


  onSubmit() {
    const { activeForms } = this.props

    this.setState({
      submiting: true,
    })

    const promises = Object.keys(this.props.activeForms).map((key) => {
      return new Promise((resolve, reject) => {
        activeForms[key]().validateFields((errors, values) => {
          if (errors) {
            debug('error')
            reject(key)
          } else {
            resolve({
              [reqMapIds[key]]: values,
            })
          }
        })
      })
    })
    Promise.all(promises).then(this.doSubmit, (key) => {
      this.setState({
        submiting: false,
      })
      this.pageLoader.displayMe(key)
      message.error(`${tabTitleMap[key]}中的字段有错误，请检查`)
    }).catch((e) => { debug(e) })
  }

  doSubmit(values) {
    const { processDefStart, bigSaveChange } = this.props

    let reqValue = {}
    values.forEach((v) => {
      reqValue = Object.assign(reqValue, v)
    })

    debug(reqValue)

    const bigSave = bigSaveChange

    /*
     * 先调用大保存，
     * 然后调用发起流程接口，返回后续节点的分配策略
     * 如果后续节点数量大于1
     * 或者后续节点的分配策略是收工选择或会签
     * 则弹出流程选择对话框
     * 否则直接关闭页面
     */
    bigSave({
      appFormId: this.state.businessKey,
      changeType: this.state.applyType,
    }).then(() => processDefStart({
      businessKey: this.state.businessKey,
      busiApplyType: this.state.applyType,
      busiType: bizTypeCode.AMOUNT_GRANT,
      completeFirstTaskFlag: true,
      firstComments: '额度发放',
    })).then((data) => {
      if (shouldOpenSubmitModal(data, flowActions.submit)) {
        this.submitModal.open({
          backNodeList: [], // 提交，没有回退节点
          assignStrategy: data.assignStrategy,
          nextNodeList: data.nodeList,
          userList: data.userList,
          actionTypeAllowed: flowActions.submit, // 固定提交操作
          taskInstId: data.taskInstId,
          successCallback: this.submitDone,
          failCallback: () => this.setState({ submiting: false }),
        })
      } else {
        this.submitDone()
      }
    }, () => {
      this.setState({
        submiting: false,
      })
    })
  }

  submitDone(reqValue) {
    /*
     * 提交成功，
     * 则更新申请列表
     * 更新审批列表
     * 弹出提交成功提示
     * 关闭当前tab页
     */
    this.setState({
      submiting: false,
    })
    this.updateApplyList(reqValue)
    this.updateApproveList(reqValue)
    message.success('提交成功')
    this.props.tabhelper.closetab()
  }

  /*
   * 在保存／提交／删除／修改的时候，都要更新申请列表
   */
  updateApplyList() {
    const { tabhelper } = this.props

    tabhelper.dispatch(AMOUNT_GRANT_UPDATE_OTHER_APPLICATION_LIST)
  }


  /*
   * 在提交的时候，要刷新审批列表
   */
  updateApproveList() {
    const { tabhelper } = this.props

    tabhelper.dispatch(AMOUNT_GRANT_UPDATE_OTHER_APPROVE_LIST)
  }

  render() {
    debug('render')
    return (
      <div>
        <Spin spinning={this.state.submiting} delay={20}>
          <PageContainerHeader title={makeTitle('额度', amountGrantApplyTypeLabels[this.state.applyType], true, this.state.businessKey, this.state.bizKey)} actions={this.actions} loading={this.state.loading} submiting={this.state.submiting} />
          <PageLoader
            ref={r => (this.pageLoader = r)}
            tabs={this.tabItem}
            groups={this.state.groups}
            data={this.state.data}
            loading={this.state.loading}
            bizKey={this.state.bizKey}
            businessKey={this.state.businessKey}
            updateApplyList={this.updateApplyList}
            groupIdToDataMap={detailDataMap}
            applyType={this.state.applyType}
          />
          <SubmitFlow
            ref={r => (this.submitModal = r)}
            loading={this.state.loading}
            successCallback={this.submitDone}
            failCallback={this.submitDone}
            taskCompleteAction={this.props.completeTask}
          />
        </Spin>
      </div>
    )
  }
}

GrantDraftPage.propTypes = {
  processDefStart: PropTypes.func,
  bigSaveChange: PropTypes.func,
  queryAmountGrantDetailChange: PropTypes.func,
  getBidAndBpid: PropTypes.func,
  completeTask: PropTypes.func,
  tabhelper: PropTypes.shape({
    closetab: PropTypes.func,
    subscribe: PropTypes.func,
    dispatch: PropTypes.func,
    getsearch: PropTypes.func,
  }),
  activeForms: PropTypes.object,
}

export default pageContainerWrapper({ name: PAGE_ID })(GrantDraftPage)
