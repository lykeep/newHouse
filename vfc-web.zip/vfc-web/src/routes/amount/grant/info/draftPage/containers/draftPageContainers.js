import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'

import pageActions from '../modules/draftPageModules'

import GrantInfoComp from '../components/GrantDraftPage'

import {
  processDefStart,
  getBidAndBpid,
} from '../../../../../../modules/workflow'

const mapActionCreators = {
  ...pageActions,
  processDefStart,
  getBidAndBpid,
}

const mapStateToProps = () => ({})

export default withRouter(connect(mapStateToProps, mapActionCreators)(GrantInfoComp))
