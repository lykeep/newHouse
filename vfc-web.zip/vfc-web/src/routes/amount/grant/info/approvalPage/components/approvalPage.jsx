import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import _debug from 'lb-debug'
import message from 'lbc-wrapper/lib/message'
import Spin from 'lbc-wrapper/lib/spin'

import pageContainerWrapper from '../../../../../../components/form/page/PageContainerWrapper'
import PageContainerHeader from '../../../../../../components/form/page/PageContainerHeader'

import PageLoader from '../../../../../../components/form/page/PageLoader'

import pageMode from '../../../../../../common/pageMode'
import { PERMISSIONS } from '../../../../../../components/form/utils/calPermission'
import groups, { approvalGroup, circulationGroup, flowChartGroup } from '../../../common/groups'
import calculateGroups from '../../../../../../components/form/groups/calculateGroups'
import SubmitFlow, { shouldOpenSubmitModal } from '../../../../../../components/workflow/submitFlow/SubmitFlow'
import groupIds, { tabTitleMap as idTitleMap } from '../../../common/tabIds'
import formIds from '../../../common/formIds'
import reqMapIds, { detailDataMap } from '../../../common/reqMapIds'
import { handleStatus } from '../../../../../../common/workflow'

import emptyFunc from '../../../../../../utils/emptyFunc'

import { AMOUNT_GRANT_UPDATE_OTHER_APPROVE_LIST, AMOUNT_GRANT_UPDATE_OTHER_QUERY_LIST } from '../../../common/tabAction'
import { PID_AMOUNT_GRANT_APPROVAL } from '../../../../../../common/pageIds'

import { amountGrantApplyTypeLabels } from '../../../../../../common/bizApplyType/amount'
import makeTitle from '../../../../../../utils/makeTitle'

const debug = _debug('AmountGrantApprovalPage')

class AmountGrantApprovalPage extends PureComponent {
  constructor(props) {
    super(props)

    this.onSubmit = this.onSubmit.bind(this)
    this.updateApproveList = this.updateApproveList.bind(this)
    this.doSubmit = this.doSubmit.bind(this)
    this.submitDone = this.submitDone.bind(this)
    this.nextStepOK = this.nextStepOK.bind(this)

    /*
     * 每个页面都要通过search传几个参数：
     * m: 页面的模式：新增／编辑／只读
     * t: 页面的类型：草稿／变更／审批
     */
    const parsed = props.tabhelper.getsearch()

    /*
     * 定义了这个页面有哪些tab
     * {
     *   groupId, 对应后台配置的groupId，不能为空，必须唯一
     *   title, 页面显示的tab标题
     *   forceRender, 在页面展示时，是否强制渲染tab中的内容。如果这个tab中包含了form，则必须为true
     *   path, tab内容组件的路径，在动态加载的时候会用
     *   authority, 权限，查看／编辑／隐藏
     *   component, tab内容的组件，必须是一个返回组件的方法
     * }
     *
     * 创建草稿和变更信息页面，group信息是前台写死的。流程的是从后台取的
     */
    this.tabItem = groups

    if (parsed.m !== pageMode.VIEW) {
      this.tabItem = this.tabItem.concat(approvalGroup)
    }

    this.tabItem = this.tabItem.concat(circulationGroup, flowChartGroup)

    this.state = {
      loading: true,
      submiting: false,
      groups: [], // 页面tab信息
      data: {}, // 业务数据
      workflowActions: [], // 流程可进行操作
      backNodeList: [], // 可退回节点
      businessKey: '',
      // isVote: false, // 当前节点是否投票
      // lastNode: false, // 当前节点是否为最后一个节点
      nextActivity: {
        assignStrategy: '',
        nodeList: [],
        userList: [],
      }, // 下一节点处理策略
      // actionType: '',
      applyType: parsed.at,
      // callBigSave: false, // 默认不调用大保存
    }

    this.actions = parsed.m === pageMode.VIEW ? [] : [
      {
        comp_id: 'submit',
        label: '提交',
        type: 'primary',
        onClick: this.onSubmit,
        key: 'submit',
      },
    ]
  }

  componentDidMount() {
    /*
     * 页面开始后，需要去后台取相关信息：
     * 1，group 信息
     * 2，业务数据
     * 3，流程流转信息
     */
    const { queryWorkflowDetail, tabhelper, queryGrantDetailChange } = this.props
    tabhelper.closeothersamepathtab()
    const parsed = tabhelper.getsearch()

    const queryFunc = queryGrantDetailChange

    /*
     * 如果pageMode是view，则从申请列表进入
     * 否则是从审核列表进入
     */
    if (parsed.m === pageMode.VIEW) {
      // 从申请列表进入，调用查询草稿接口查详情
      queryFunc({
        appFormId: parsed.bpid,
      }).then((data) => {
        this.setState({
          data: {
            [detailDataMap[formIds.changeInfo]]: { applyType: this.state.applyType, ...data },
          },
          businessKey: parsed.bpid,
          bizKey: parsed.bid,
          loading: false,
          procInstanceId: parsed.pid,
          groups: this.tabItem.map(t => ({ group_id: t.groupId, authority: PERMISSIONS.READ })),
        })
      })
    } else {
      // 从审核列表进入
      // 调用2个接口：
      // 1，草稿详情
      // 2，流程详情
      const queryDetailPro = queryFunc({
        appFormId: parsed.bpid,
      })
      const queryFlowPro = queryWorkflowDetail({
        taskInstanceId: parsed.tid,
      })

      Promise.all([queryDetailPro, queryFlowPro]).then((result) => {
        const [bizObj, data] = result

        // 根据流程状态处理决定是否展示审批信息和操作按钮
        const commonGroups = data.statusType === handleStatus.NOT_DONE ? [approvalGroup, circulationGroup, flowChartGroup] : [circulationGroup, flowChartGroup]
        this.actions = handleStatus.NOT_DONE === data.statusType ? this.actions : []

        this.setState({
          loading: false,
          procInstanceId: parsed.pid,
          taskInstanceId: parsed.tid,
          groups: calculateGroups(this.tabItem, data.formControl.inputElementList).concat(commonGroups),
          data: {
            [detailDataMap[formIds.changeInfo]]: { applyType: this.state.applyType, ...bizObj },
          },
          workflowActions: data.actionTypeAllowed, // 流程可进行操作
          backNodeList: data.backNodeList, // 可退回节点
          businessKey: parsed.bpid,
          bizKey: parsed.bid,
          // isVote: data.isVote, // 当前节点是否投票
          // lastNode: data.lastNode, // 当前节点是否为最后一个节点
          nextActivity: data.nextActivityVO, // 下一节点处理策略
          // callBigSave: shouldCallBigSive(data.formControl.inputElementList),
        })
      }).catch(() => {
      })
    }
  }


  onSubmit() {
    const { activeForms } = this.props

    this.setState({
      submiting: true,
    })

    const promises = Object.keys(this.props.activeForms).map((key) => {
      return new Promise((resolve, reject) => {
        activeForms[key]().validateFields((errors, values) => {
          if (errors) {
            debug('error')


            reject(key)
          } else {
            resolve({
              [reqMapIds[key]]: values,
            })
          }
        })
      })
    })

    Promise.all(promises).then(this.doSubmit, (key) => {
      this.setState({
        submiting: false,
      })
      this.pageLoader.displayMe(key)
      message.error(`${idTitleMap[key]}中的字段有错误，请检查`)
    }).catch((e) => { debug(e) })
  }

  doSubmit(values) {
    const { nextActivity } = this.state

    const parsed = this.props.tabhelper.getsearch()

    let reqValue = {}
    values.forEach((v) => {
      reqValue = Object.assign(reqValue, v)
    })

    this.reqData = reqValue


    /*
     * 不再调用大保存
     * 然后再提交流程
     */
    const savePromise = Promise.resolve()

    savePromise.then(() => {
      const approvalData = reqValue[reqMapIds[groupIds.approvalInfo]]
      /*
       * 如果后续分配策略是自动分配或收工领取，则直接可以结束了
       * 否则，就显示人工选择的弹框
       */
      if (!shouldOpenSubmitModal(nextActivity, approvalData.actionType)) {
        this.props.taskCompleted({
          actionType: approvalData.actionType,
          assignStrategy: this.state.nextActivity.assignStrategy,
          comment: approvalData.comment,
          taskInstanceId: this.state.taskInstanceId,
          // 之前少了这个字段
          targetTaskDefKey: approvalData.targetTaskDefKey,
          orgPath: approvalData.orgPath, // 2018-09-17, 标识是否退回提交后原路返回
        }).then(() => {
          this.submitDone()
        }).catch(() => {
          this.setState({
            submiting: false,
          })
        })
      } else {
        this.submitModal.open({
          backNodeList: this.state.backNodeList,
          assignStrategy: this.state.nextActivity.assignStrategy,
          nextNodeList: this.state.nextActivity.nodeList,
          userList: this.state.nextActivity.userList,
          actionTypeAllowed: approvalData.actionType,
          comment: approvalData.comment,
          successCallback: this.submitDone,
          failCallback: () => this.setState({ submiting: false }),
          taskInstId: parsed.tid,
        })
      }
    }).catch((e) => {
      console.error(e)
      this.setState({
        submiting: false,
      })
    })
  }

  nextStepOK(value) {
    this.submitDone(value)
  }

  submitDone(data) {
    this.setState({
      submiting: false,
    }, () => {
      this.updateApproveList(data)
      message.success('提交成功')
      this.props.tabhelper.closetab()
    })
  }

  /*
   * 在提交的时候，要刷新审批列表
   */
  updateApproveList() {
    const { tabhelper } = this.props

    tabhelper.dispatch(AMOUNT_GRANT_UPDATE_OTHER_APPROVE_LIST)
    tabhelper.dispatch(AMOUNT_GRANT_UPDATE_OTHER_QUERY_LIST)
  }

  render() {
    debug('render')
    debug(this.state.businessKey)
    const { tabhelper } = this.props
    const parsed = tabhelper.getsearch()
    const { loading, backNodeList, workflowActions, procInstanceId } = this.state
    return (
      <div>
        <Spin spinning={this.state.submiting} delay={20}>
          <PageContainerHeader title={makeTitle('额度', amountGrantApplyTypeLabels[parsed.at], false, this.state.businessKey, this.state.bizKey)} actions={this.actions} loading={this.state.loading} submiting={this.state.submiting} />
          <PageLoader
            ref={r => (this.pageLoader = r)}
            tabs={this.tabItem}
            groups={this.state.groups}
            data={this.state.data}
            loading={loading}
            bizKey={this.state.bizKey}
            processKey={this.state.businessKey}
            updateApproveList={this.updateApproveList}
            updateApplyList={emptyFunc}
            workflowActions={workflowActions}
            procInstanceId={procInstanceId}
            backNodeList={backNodeList}
            groupIdToDataMap={detailDataMap}
            defaultSelectedKey={approvalGroup.groupId}
            applyType={this.state.applyType}
          />
          <SubmitFlow
            ref={r => (this.submitModal = r)}
            loading={loading}
            taskCompleteAction={this.props.submitApproval}
            successCallback={this.submitDone}
            failCallback={this.submitDone}
          />
        </Spin>
      </div>
    )
  }
}

AmountGrantApprovalPage.propTypes = {
  queryWorkflowDetail: PropTypes.func,
  queryGrantDetailChange: PropTypes.func,
  taskCompleted: PropTypes.func,
  submitApproval: PropTypes.func.isRequired,
  tabhelper: PropTypes.shape({
    closetab: PropTypes.func,
    subscribe: PropTypes.func,
    dispatch: PropTypes.func,
    getsearch: PropTypes.func,
  }),
  activeForms: PropTypes.object,
}

export default pageContainerWrapper({ name: PID_AMOUNT_GRANT_APPROVAL })(AmountGrantApprovalPage)
