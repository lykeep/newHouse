import { createFetchAction } from '../../../../../../modules/common'

// 从申请列表看变更详情，根据流程id查询
const AMOUNT_GRANT_APPROVAL_QUERY_LEGAL_DETAIL_CHANGE = 'AMOUNT_GRANT_APPROVAL_QUERY_LEGAL_DETAIL_CHANGE'

// 新增变更
const AMOUNT_GRANT_APPROVAL_BIG_SAVE_CHANGE = 'AMOUNT_GRANT_APPROVAL_BIG_SAVE_CHANGE'

export const queryGrantDetailChange = createFetchAction(AMOUNT_GRANT_APPROVAL_QUERY_LEGAL_DETAIL_CHANGE, 'vfc-intf-ent-contract.queryLimitGiveOutDetails')

export const bigSaveChange = createFetchAction(AMOUNT_GRANT_APPROVAL_BIG_SAVE_CHANGE, 'vfc-intf-ent-contract.saveCreditGiveOut')

export default {
  queryGrantDetailChange,
  bigSaveChange,
}
