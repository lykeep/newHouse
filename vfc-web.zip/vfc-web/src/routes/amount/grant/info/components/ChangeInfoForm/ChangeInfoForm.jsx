import React, { Component } from 'react'
import PropTypes from 'prop-types'
import message from 'lbc-wrapper/lib/message'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import formIds from '../../../common/formIds'
import InputField from '../../../../../../components/form/inputs/InputField'
import SelectField from '../../../../../../components/form/inputs/SelectField'
import MoneyField from '../../../../../../components/form/inputs/MoneyField'
import wrapFormContainer from '../../../../../../components/form/groups/wrapFormContainer'
import ChangeInfoAjaxActions from './ChangeInfoModule'

import { amountGrantApplyTypeSelectOptions } from '../../../../../../common/bizApplyType/amount'

class ChangeInfoForm extends Component {
  constructor(props) {
    super(props)

    this.onSave = this.onSave.bind(this)

    this.actions = [
      {
        comp_id: 'submit',
        label: '保存',
        type: 'primary',
        onClick: this.onSave,
        id: 'submit',
      },
    ]
  }

  onSave() {
    const { saveChangeInfo, businessKey, form } = this.props

    form.validateFields((errors, data) => {
      if (errors) {
        console.error(errors)
        return
      }
      saveChangeInfo({
        appFormId: businessKey,
        changeReason: data.changeReason,
      }).then(() => {
        message.success('保存成功')
      })
    })
  }

  render() {
    const { form, data, applyType, authority } = this.props

    return (
      <div>
        <Form>
          <Row gutter={16} type="flex" align="top">
            <SelectField
              form={form}
              authority={authority}
              name="applyType"
              key="applyType"
              formItemProps={{ label: '变更类型' }}
              fieldProps={{
                initialValue: applyType,
              }}
              inputProps={{
                options: amountGrantApplyTypeSelectOptions,
                disabled: true,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="borrowerName"
              key="borrowerName"
              formItemProps={{ label: '借款人' }}
              fieldProps={{
                initialValue: data.borrowerName,
              }}
              inputProps={{
                placeholder: '请输入',
                disabled: true,
              }}
            />
            <MoneyField
              form={form}
              authority={authority}
              name="totalCreditAmt"
              key="totalCreditAmt"
              formItemProps={{ label: '发放额度' }}
              fieldProps={{
                initialValue: data.totalCreditAmt,
              }}
              inputProps={{
                placeholder: '请输入',
                disabled: true,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="contractNum"
              key="contractNum"
              formItemProps={{ label: '合同编号' }}
              fieldProps={{
                initialValue: data.contractNum,
              }}
              inputProps={{
                placeholder: '请输入',
                disabled: true,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="projectName"
              key="projectName"
              formItemProps={{ label: '项目名称' }}
              fieldProps={{
                initialValue: data.projectName,
              }}
              inputProps={{
                placeholder: '请输入',
                disabled: true,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="orderNum"
              key="orderNum"
              formItemProps={{ label: '进件编号' }}
              fieldProps={{
                initialValue: data.orderNum,
              }}
              inputProps={{
                placeholder: '请输入',
                disabled: true,
              }}
            />
          </Row>
        </Form>
      </div>
    )
  }
}

ChangeInfoForm.propTypes = {
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  applyType: PropTypes.string.isRequired,
  businessKey: PropTypes.string.isRequired,
  data: PropTypes.object,
  saveChangeInfo: PropTypes.func,
}

export default wrapFormContainer(formIds.changeInfo, '变更信息', ChangeInfoAjaxActions)(ChangeInfoForm)
