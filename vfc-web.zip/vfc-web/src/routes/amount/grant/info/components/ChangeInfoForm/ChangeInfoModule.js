import { createFetchAction } from '../../../../../../modules/common'

const AMOUNT_GRANT_SAVE_CHANGE_INFO = 'AMOUNT_GRANT_SAVE_CHANGE_INFO'

export const saveChangeInfo = createFetchAction(AMOUNT_GRANT_SAVE_CHANGE_INFO, 'vfc-intf-ent-contract.saveCreditGiveOut')

export default {
  saveChangeInfo,
}
