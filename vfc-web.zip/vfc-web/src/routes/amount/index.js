// 额度变更
import AmountQueryList from './amount/queryList'
import AmountApplyList from './amount/applyList'
import AmountApprovalList from './amount/approvalList'

// 额度变更详情
import AmountDraftPage from './amount/info/draftPage'
import AmountApproval from './amount/info/approvalPage'

// 额度发放
import GrantQueryList from './grant/queryList'
import GrantApplyList from './grant/applyList'
import GrantApprovalList from './grant/approvalList'

// 额度发放详情
import GrantInfo from './grant/info/draftPage'
import GrantApproval from './grant/info/approvalPage'

import { PID_AMOUNT_GRANT_APPROVAL, PID_AMOUNT_ALTER_APPROVAL } from '../../common/pageIds'

// 担保
import GuaranteePage from '../order/addGuaranteeInfoLinkDraftPages/guaranteePage' // 担保信息新增-跳转保证页
import CarPage from '../order/addGuaranteeInfoLinkDraftPages/carPage' // 担保信息新增-跳转车辆页
import HousePropertyPage from '../order/addGuaranteeInfoLinkDraftPages/housePropertyPage' // 担保信息新增-跳转房产页
import OtherCollateralPage from '../order/addGuaranteeInfoLinkDraftPages/otherCollateralPage' // 担保信息新增-跳转其他抵质押页


export default (pUrl, store) => {
  const grant = `${pUrl}/amount/grant`
  const amount = `${pUrl}/amount/amount`
  return [
    {
      component: AmountQueryList(store),
      title: '额度查询列表',
      exact: true,
      path: `${amount}/queryList`,
    },
    {
      component: AmountDraftPage(store),
      title: '额度信息',
      exact: true,
      path: `${amount}/info`,
    },
    // 2018-09-23, 额度变更暂不上线
    // {
    //   component: AmountApplyList(store),
    //   title: '额度变更申请列表',
    //   exact: true,
    //   path: `${amount}/applyList`,
    // },
    // {
    //   component: AmountApprovalList(store),
    //   title: '额度变更审批列表',
    //   exact: true,
    //   path: `${amount}/approvalList`,
    // },
    {
      component: AmountApproval(store),
      title: '额度变更审核',
      exact: true,
      path: `${amount}/${PID_AMOUNT_ALTER_APPROVAL}`,
    },
    {
      component: GrantQueryList(store),
      title: '额度发放查询列表',
      exact: true,
      path: `${grant}/queryList`,
    },
    {
      component: GrantApplyList(store),
      title: '额度发放申请列表',
      exact: true,
      path: `${grant}/applyList`,
    },
    {
      component: GrantApprovalList(store),
      title: '额度发放审批列表',
      exact: true,
      path: `${grant}/approvalList`,
    },
    {
      component: GrantInfo(store),
      title: '额度发放详情',
      exact: true,
      path: `${grant}/info`,
    },
    {
      component: GrantApproval(store),
      title: '额度发放审核',
      exact: true,
      path: `${grant}/${PID_AMOUNT_GRANT_APPROVAL}`,
    },
    {
      component: GuaranteePage(store),
      title: '保证页',
      exact: true,
      path: `${amount}/addGuaranteeInfo/guaranteePage`,
    },
    {
      component: CarPage(store),
      title: '车辆页',
      exact: true,
      path: `${amount}/addGuaranteeInfo/carPage`,
    },
    {
      component: HousePropertyPage(store),
      title: '房产页',
      exact: true,
      path: `${amount}/addGuaranteeInfo/housePropertyPage`,
    },
    {
      component: OtherCollateralPage(store),
      title: '其他抵质押页',
      exact: true,
      path: `${amount}/addGuaranteeInfo/otherCollateralPage`,
    },
  ]
}
