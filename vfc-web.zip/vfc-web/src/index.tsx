
import * as React from "react";
import * as ReactDOM from "react-dom";
import { Provider } from "react-redux";
import { renderRoutes, RouteConfig } from "react-router-config";
import { HashRouter } from "react-router-dom";

import ErrorBoundaries from "./components/ErrorBoundaries";
import createStore from "./store/createStore";
import routesFunc from "./routes";


const store = createStore();
const routes: RouteConfig[] = routesFunc(store);

const APP = (
    <ErrorBoundaries>
      <Provider store={store}>
        <HashRouter>{renderRoutes(routes)}</HashRouter>
      </Provider>
    </ErrorBoundaries>
);

ReactDOM.render(APP, document.getElementById("root"))
