import { currencyTypeSelectOptions } from '../components/columnRenders/currencyType'
// 证件类型
export const idTypes = [
  { title: '身份证', value: '00', key: '00' },
  { title: '临时身份证', value: '01', key: '01' },
  { title: '军官证', value: '02', key: '02' },
  { title: '士兵证', value: '03', key: '03' },
  { title: '警官证', value: '04', key: '04' },
  { title: '普通护照', value: '05', key: '05' },
  { title: '台湾同胞来往大陆通行证', value: '06', key: '06' },
  { title: '港澳通报回乡证', value: '07', key: '07' },
  { title: '外国人居留证', value: '08', key: '08' },
  { title: '户口簿', value: '09', key: '09' },
  { title: '其他', value: '99', key: '99' },
]


export const custType = [
  { title: '领薪人士', value: '00', key: '00' },
  { title: '一般受薪人士', value: '01', key: '01' },
  { title: '优良职业', value: '02', key: '02' },
  { title: '公务员', value: '03', key: '03' },
  { title: '事业单位员工', value: '04', key: '04' },
  { title: '金融机构员工', value: '05', key: '05' },
  { title: '部队中高级干部', value: '06', key: '06' },
  { title: '自雇人士', value: '07', key: '07' },
  { title: '个体工商户', value: '08', key: '08' },
  { title: '私营企业主', value: '09', key: '09' },
  { title: '自由职业', value: '10', key: '10' },
  { title: '小企业实际控制人', value: '11', key: '11' },
  { title: '农户', value: '12', key: '12' },
  { title: '学生', value: '13', key: '13' },
  { title: '其他', value: '14', key: '14' },
  { title: '未知', value: '15', key: '15' },
]

// 与申请人关系
export const relationOps = [
  { key: '00', title: '父母', value: '00' },
  { key: '01', title: '子女', value: '01' },
  { key: '02', title: '祖父母', value: '02' },
  { key: '03', title: '亲属', value: '03' },
  { key: '04', title: '朋友', value: '04' },
  { key: '05', title: '同事', value: '05' },
  { key: '06', title: '同学', value: '06' },
  { key: '07', title: '其他', value: '07' },
]

// 联系人职务
export const contactJob = [
  { key: '00', title: '工人', value: '00' },
  { key: '01', title: '科（办）员', value: '01' },
  { key: '02', title: '科级', value: '02' },
  { key: '03', title: '处级', value: '03' },
  { key: '04', title: '副局级', value: '04' },
  { key: '05', title: '局级', value: '05' },
  { key: '06', title: '副部级', value: '06' },
  { key: '07', title: '部级', value: '07' },
  { key: '08', title: '其他', value: '08' },
]

// 性别
export const sexType = [
  { key: 'M', label: '男', value: 'M' },
  { key: 'F', label: '女', value: 'F' },
]

// 账户类别
export const acType = [
  { title: '一般账户', value: '00', key: '00' },
  { title: '其他账户', value: '01', key: '01' },
  { title: '借记卡账户', value: '02', key: '02' },
  { title: '贷记卡账户', value: '03', key: '03' },
  { title: '基本户', value: '04', key: '04' },
]


// 与借款人关系
export const withBorRela = [
  { title: '本人', value: '01', key: '01' },
  { title: '父母', value: '02', key: '02' },
  { title: '子女', value: '03', key: '03' },
  { title: '配偶', value: '04', key: '04' },
  { title: '兄弟姐妹', value: '05', key: '05' },
  { title: '孙子女', value: '06', key: '06' },
  { title: '外孙子女', value: '07', key: '07' },
  { title: '其他', value: '99', key: '99' },
]

// 其他联系人
export const contactRelation = [
  { key: '00', title: '父母', value: '00' },
  { key: '01', title: '子女', value: '01' },
  { key: '02', title: '祖父母', value: '02' },
  { key: '03', title: '亲属', value: '03' },
  { key: '04', title: '朋友', value: '04' },
  { key: '05', title: '同事', value: '05' },
  { key: '06', title: '同学', value: '06' },
  { key: '07', title: '其他', value: '07' },

]

export const corType = [
  { key: '01', title: '车辆登记证', value: '01' },
  { key: '02', title: '行驶证', value: '02' },
  { key: '03', title: '购置税证', value: '03' },
  { key: '04', title: '购车发票', value: '04' },
  { key: '05', title: '保险证明', value: '05' },
  { key: '06', title: '养路费缴纳证明', value: '06' },
  { key: '07', title: '车船税使用证明', value: '07' },
  { key: '08', title: '营运证', value: '08' },
  { key: '99', title: '其他', value: '99' },
]

// 产权归属
export const proAttr = [
  { title: '本人', value: '01', key: '01' },
  { title: '家人', value: '02', key: '02' },
  { title: '他人', value: '03', key: '03' },
]

// 房屋类型
export const houseType = [
  { title: '普通住宅', value: '01', key: '01' },
  { title: '公寓', value: '02', key: '02' },
  { title: '别墅', value: '03', key: '03' },
  { title: '商住两用房', value: '04', key: '04' },
  { title: '经济适用房', value: '05', key: '05' },
  { title: '写字楼', value: '06', key: '06' },
  { title: '仓库', value: '07', key: '07' },
  { title: '厂房', value: '08', key: '08' },
  { title: '产权车位/车库', value: '09', key: '09' },
  { title: '高铺', value: '11', key: '11' },
  { title: '其他', value: '10', key: '10' },
]

// 房屋装修情况
export const houseDecoration = [
  { title: '简装', value: '01', key: '01' },
  { title: '豪装', value: '02', key: '02' },
  { title: '毛坯', value: '03', key: '03' },
]

// 房屋结构
export const structure = [
  { title: '框架', value: '01', key: '01' },
  { title: '砖混', value: '02', key: '02' },
  { title: '钢混', value: '03', key: '03' },
]

// 户型
export const buildingsType = [
  { title: '1室0厅', value: '01', key: '01' },
  { title: '1室1厅', value: '02', key: '02' },
  { title: '2室0厅', value: '03', key: '03' },
  { title: '2室1厅', value: '04', key: '04' },
  { title: '2室2厅', value: '05', key: '05' },
  { title: '3室0厅', value: '06', key: '06' },
  { title: '3室1厅', value: '07', key: '07' },
  { title: '3室2厅', value: '08', key: '08' },
  { title: '3室3厅', value: '09', key: '09' },
  { title: '其它', value: '99', key: '99' },
]

// 土地用途
export const landPurpose = [
  { title: '工业', value: '01', key: '00' },
  { title: '农业', value: '02', key: '01' },
  { title: '商业', value: '03', key: '02' },
  { title: '住宅', value: '04', key: '04' },
  { title: '综合', value: '05', key: '05' },
  { title: '其他', value: '99', key: '99' },
]

export const landNature = [
  { title: '出让', value: '01', key: '01' },
  { title: '划拨', value: '02', key: '02' },
  { title: '其他', value: '99', key: '99' },
]

// 抵质押物凭证类型
export const insAccountCreateName = [
  { key: '00', title: '一般户', value: '00' },
  { key: '04', title: '基本户', value: '04' },
  { key: '02', title: '借记卡账户', value: '02' },
  { key: '03', title: '贷记卡账户', value: '03' },
  { key: '01', title: '其他', value: '01' },
]

// 交付物类型
export const priority = [
  { label: '原件', value: '00', key: '00' },
  { label: '复印件', value: '01', key: '01' },
]

// 币种
export const currency = currencyTypeSelectOptions
// [
//   { title: '人民币', value: '00', key: '00' },
//   { title: '美元', value: '01', key: '01' },
//   { title: '日元', value: '02', key: '02' },
//   { title: '欧元', value: '03', key: '03' },
//   { title: '英镑', value: '04', key: '04' },
//   { title: '港币', value: '05', key: '05' },
//   { title: '其他', value: '99', key: '99' },
// ]

export const grnteeVorType = [
  { title: '房产证/土地证/不动产证/其他权利证', value: '01', key: '01' },
  { title: '机动车登记证', value: '02', key: '02' },
  { title: '存单', value: '03', key: '03' },
  { title: '票据', value: '04', key: '04' },
  { title: '保单', value: '05', key: '05' },
  { title: '国债', value: '06', key: '06' },
  { title: '股票/股票', value: '07', key: '07' },
  { title: '其他权利', value: '08', key: '08' },
]

// 时间单位
export const dateUnit = [
  { title: '天', value: '01', key: '01' },
  { title: '月', value: '02', key: '02' },
  { title: '年', value: '03', key: '03' },
]



// 还款日
const arr = []
for (let i = 1; i <= 28; i += 1) {
  arr.push({ title: i, value: i, key: i })
}
export const repaymentDay = arr
