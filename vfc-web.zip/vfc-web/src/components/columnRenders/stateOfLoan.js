export default (value, record) => {
  let label
  switch (value) {
    case '000000':
      label = '等待签署'
      break
    case '000001':
      label = '签署中'
      break
    case '000002':
      label = '已作废'
      break
    case '000003':
      label = '已签署'
      break
    case '000004':
      label = '已放款'
      break
    case '000005':
      label = '已起租'
      break
    case '000006':
      label = '已结束'
      break
    case '001000':
      label = '待生效'
      break
    case '001001':
      label = '正常'
      break
    case '001002':
      label = '逾期'
      break
    case '001003':
      label = '结清'
      break
    case '002000':
      label = '待发放'
      break
    case '002001':
      label = '正常'
      break
    case '002002':
      label = '冻结'
      break
    case '002002':
      label = '已失效'
      break
    default:
  }
  return label
}
