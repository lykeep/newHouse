
const ascriptionType = {
  legal: '0000',
  natural: '0001',
}

export default ascriptionType
