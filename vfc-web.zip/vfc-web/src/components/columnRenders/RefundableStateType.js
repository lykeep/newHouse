export default (value, record) => {
  let label
  switch (value) {
    case '1':
      label = '已退款'
      break;
    default:
  }
  return label
}
