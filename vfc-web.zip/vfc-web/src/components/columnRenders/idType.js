import { idTypes } from '../../config/types'
import { buildColumnRender, buildSelectOptions } from '../../common/utils'

const idTypesLabels = {}
idTypes.forEach(id => (idTypesLabels[id.value] = id.title))

export const idTypesSelectOptions = buildSelectOptions(idTypesLabels)

export const idTypesRender = buildColumnRender(idTypesLabels)
