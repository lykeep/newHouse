import { currencyTypeRender } from './currencyType'

export default currencyTypeRender
// export default (value, record) => {
//   let label
//   switch (value) {
//     case '00':
//       label = '人民币'
//       break;
//     case '01':
//       label = '美元'
//       break;
//     case '02':
//       label = '日元'
//       break;
//     case '03':
//       label = '英镑'
//       break;
//     case '04':
//       label = '欧元'
//       break;
//     default:
//   }
//   return label
// }
