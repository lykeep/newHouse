export default (value, record) => (value === '00' ? '自然人' : '法人')
