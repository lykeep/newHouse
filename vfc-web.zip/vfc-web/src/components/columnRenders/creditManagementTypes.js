export const creditManagementTypes = {
  '01': '正常',
  '02': '关闭',
  '03': '过期',
}

export default (value = '') => creditManagementTypes[value] || ''
