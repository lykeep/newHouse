/*
 * 分期租金条款
 */
import { bpmRecordType } from '../../common/workflow'

export const bpmRecordTypeLabels = {
  [bpmRecordType.NEW]: '新增',
  [bpmRecordType.ALTER]: '变更',
}

export default (value = '', record) => {
  return bpmRecordTypeLabels[value] || ''
}
