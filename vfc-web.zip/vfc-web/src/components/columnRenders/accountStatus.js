export default (value, record) => {
  if (value === '00') {
    value = '冻结'
  } else if (value === '01') {
    value = '正常'
  } else if (value === '02') {
    value = '销户'
  }
  return value
}
