import { buildColumnRender, buildSelectOptions } from '../../common/utils';

// 合同状态
export const contractStatus = {
  CRT_WAIT_SIGN: 'CRT_WAIT_SIGN', // 等待签署
  CRT_SIGNING: 'CRT_SIGNING', // 签署中
  CRT_INVALID: 'CRT_INVALID', // 已作废
  CRT_SIGNED: 'CRT_SIGNED', // 已签署
  CRT_GRANTED: 'CRT_GRANTED', // 已放款
  CRT_RENT_START: 'CRT_RENT_START', // 已起租
  CRT_FINISH: 'CRT_FINISH', // 已结束
  CRT_GIVE_OUT: 'CRT_GIVE_OUT', // 已发放
  // LOAN_WAIT_EFF: 'LOAN_WAIT_EFF', // 待生效
  // LOAN_NORMAL: 'LOAN_NORMAL', // 正常
  // LOAN_OVER_DUE: 'LOAN_OVER_DUE', // 逾期
  // LOAN_SETTLEMENT: 'LOAN_SETTLEMENT', // 结清
  // CREDIT_WAIT_EFF: 'CREDIT_WAIT_EFF', // 待发放
  // CREDIT_NORMAL: 'CREDIT_NORMAL', // 正常
  // CREDIT_FROZEN: 'CREDIT_FROZEN', // 冻结
  // CREDIT_EXPIRE: 'CREDIT_EXPIRE', // 已失效
}

export const contractStatusLabels = {
  [contractStatus.CRT_WAIT_SIGN]: '等待签署',
  [contractStatus.CRT_SIGNING]: '签署中',
  [contractStatus.CRT_INVALID]: '已作废',
  [contractStatus.CRT_SIGNED]: '已签署',
  [contractStatus.CRT_GRANTED]: '已放款',
  [contractStatus.CRT_RENT_START]: '已起租',
  [contractStatus.CRT_FINISH]: '已结束',
  [contractStatus.CRT_GIVE_OUT]: '已发放',
  // [contractStatus.LOAN_WAIT_EFF]: '待生效',
  // [contractStatus.LOAN_NORMAL]: '正常',
  // [contractStatus.LOAN_OVER_DUE]: '逾期',
  // [contractStatus.LOAN_SETTLEMENT]: '结清',
  // [contractStatus.CREDIT_WAIT_EFF]: '待发放',
  // [contractStatus.CREDIT_NORMAL]: '正常',
  // [contractStatus.CREDIT_FROZEN]: '冻结',
  // [contractStatus.CREDIT_EXPIRE]: '已失效',
}

export const contractStatusSelectOptions = buildSelectOptions(contractStatusLabels)

export const contractStatusRender = buildColumnRender(contractStatusLabels)
