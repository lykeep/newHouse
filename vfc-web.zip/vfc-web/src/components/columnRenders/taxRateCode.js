export default (value, record) => {
  if (value === '0') {
    value = '6'
  } else if (value === '01') {
    value = '9'
  } else if (value === '02') {
    value = '7'
  } else if (value === '03') {
    value = '10'
  } else if (value === '04') {
    value = '12'
  }
  return value
}
