export default (value, record) => {
  if (value === '01') {
    value = '线上划扣'
  } else if (value === '02') {
    value = '线下汇款'
  }
  return value
}
