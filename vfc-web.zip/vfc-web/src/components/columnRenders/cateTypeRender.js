
import { idTypes } from '../../config/types'

export default (value, record) => {
  const idType = idTypes.filter(item => item.value === value)
  return idType.length === 0 ? '' : idType[0].title
}
