export default (value, record) => {
  let type
  switch (value) {
    case '000000':
      type = '租金本金'
      break;
    case '000001':
      type = '租金利息'
      break;
    case '000002':
      type = '残值'
      break;
    case '001000':
      type = '手续费'
      break;
    case '001001':
      type = '咨询服务费'
      break;
    case '001002':
      type = '资产管理费'
      break;
    case '001004':
      type = '罚息'
      break;
    case '001005':
      type = '罚款'
      break;
    case '002000':
      type = '租赁保证金'
      break;
    case '002001':
      type = '回购保证金'
      break;
    case '002002':
      type = '合作保证金'
      break;
    case '003000':
      type = '首付款'
      break;
    case '004000':
      type = '租前息'
      break;
    case '005000':
      type = '期供本金'
      break;
    case '005001':
      type = '期供利息'
      break;
    case '006001':
      type = '提前结清费用'
      break;
    case '001006':
      type = '价外残值'
      break;
    case '001007':
      type = '其他费用'
      break;
    default: type = ''
  }
  return type
}
