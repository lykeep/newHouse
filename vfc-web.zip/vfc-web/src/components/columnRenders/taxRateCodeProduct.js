export default (value, record) => {
  let type
  switch (value) {
    case 'TX001':
      type = '16'
      break;
    case 'TX002':
      type = '10'
      break;
    case 'TX003':
      type = '6'
      break;
    case 'TX004':
      type = '5'
      break;
    case 'TX005':
      type = '3'
      break;
    case 'TX006':
      type = '0'
      break;
    default: type = ''
  }
  return type
}
