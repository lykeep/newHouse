import padEnd from 'lodash/padEnd'

export default (value, precision = 2) => {
  if (value || value === 0) {
    if (`${value}`.indexOf('.') === -1) {
      return `${value}.${padEnd('', precision, '0')}`
    }
    const valArr = `${value}`.split('.')
    return `${valArr[0]}.${padEnd(`${valArr[1]}`, precision, '0')}`
  }
}
