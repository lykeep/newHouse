// 借据状态
import { buildColumnRender, buildSelectOptions } from '../../common/utils'

export const loanStatus = {
  NOT_SIGNED: '01', // 待签署
  SIGNING: '04', // 签署中
  SIGNED: '02', // 已签署
  DISCARDED: '03', // 已作废
}

export const loanStatusLabels = {
  [loanStatus.NOT_SIGNED]: '待签署',
  [loanStatus.SIGNING]: '签署中',
  [loanStatus.SIGNED]: '已签署',
  [loanStatus.DISCARDED]: '已作废',
}

export const loanStatusOptions = buildSelectOptions(loanStatusLabels)

export const loanStatusRender = buildColumnRender(loanStatusLabels)
