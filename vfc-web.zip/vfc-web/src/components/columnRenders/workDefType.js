import { buildColumnRender, buildSelectOptions } from '../../common/utils';

export const workDefStatus = {
  DRAFT: 'DRAFT', // 编辑中
  DEPLOYED: 'DEPLOYED', // 发布
  EXPIRED: 'EXPIRED', // 失效
  SUSPENDED: 'SUSPENDED', // 挂起
}

export const workDefStatusLabels = {
  [workDefStatus.DRAFT]: '编辑中',
  [workDefStatus.DEPLOYED]: '发布',
  [workDefStatus.EXPIRED]: '失效',
  [workDefStatus.SUSPENDED]: '挂起',
}

export const workDefStatusSelectOptions = buildSelectOptions(workDefStatusLabels)

export const workDefStatusRender = buildColumnRender(workDefStatusLabels)
