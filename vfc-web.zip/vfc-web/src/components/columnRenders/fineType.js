export default (value, record) => {
  let type
  switch (value) {
    case '01':
      type = '(本金+利息)罚息'
      break;
    case '02':
      type = '费用罚息'
      break;
    case '03':
      type = '保证金罚息'
      break;
    case '04':
      type = '租前息罚息'
      break;
    default: type = ''
  }
  return type
}
