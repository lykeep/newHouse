export default (value, record) => {
  let type
  switch (value) {
    case '01':
      type = '关键字 '
      break;
    case '02':
      type = '坐标'
      break;
    default: type = ''
  }
  return type
}
