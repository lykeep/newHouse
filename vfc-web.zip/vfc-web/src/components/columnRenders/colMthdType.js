export default (value, record) => {
  let type
  switch (value) {
    case '01':
      type = '第一次放款前一次收取'
      break;
    case '07':
      type = '提前还款时收取'
      break;
    default: type = ''
  }
  return type
}
