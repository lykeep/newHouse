import { buildColumnRender, buildSelectOptions, buildRadioOptions } from '../../common/utils'

export const sex = {
  MALE: 'M', // 男
  FAMALE: 'F', // 女
}

export const sexLabels = {
  [sex.MALE]: '男',
  [sex.FAMALE]: '女',
}

export const sexSelectOptions = buildSelectOptions(sexLabels)

export const sexRender = buildColumnRender(sexLabels)

export const sexRadioOptions = buildRadioOptions(sexLabels)
