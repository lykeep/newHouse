export default (value, record) => {
  if (value === '01') {
    value = '成功'
  } else if (value === '02') {
    value = '失败'
  }
  return value
}
