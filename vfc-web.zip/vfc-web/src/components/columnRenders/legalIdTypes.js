/*
 * 法人证件类型
 */

export const legalIdTypes = {
    '01': '营业执照',
    '00': '社会信用代码',
}

export default (value = '') => legalIdTypes[value] || ''
