export default (value, record) => {
  if (value === '1') {
    value = '划扣中'
  } else if (value === '2') {
    value = '划扣成功'
  } else if (value === '3') {
    value = '划扣失败'
  }
  return value
}
