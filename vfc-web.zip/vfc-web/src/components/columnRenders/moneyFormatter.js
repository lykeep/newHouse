export default (value = '', record) => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
