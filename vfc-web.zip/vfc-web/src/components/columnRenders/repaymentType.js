
export default (value, record) => {
  let label
  switch (value) {
    case 'NONE':
      label = '未收取'
      break;
    case 'PART_COLL':
      label = '部分收取'
      break;
    case 'ALL_RCVD':
      label = '全部收取'
      break;
    case 'NO_NEED':
      label = '无需收取'
      break;
    default:
  }
  return label
}
