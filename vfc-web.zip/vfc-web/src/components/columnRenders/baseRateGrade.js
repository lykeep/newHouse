/*
 * 分期租金条款
 */

export const baseRateGradeType = {
  month: '6个月以下',
  doubleMonth: '6个月-1年',
  quarter: '1-3年',
  halfYear: '3-5年',
  year: '5年以上',
}

export const baseRateGradeInNumber = {
  month: 1,
  doubleMonth: 2,
  quarter: 3,
  halfYear: 6,
  year: 12,
}

export const baseRateGradeTypeOptions = Object.keys(baseRateGradeType).map(g => ({
  title: baseRateGradeType[g],
  value: g,
  key: g,
}))

export default (value = '', record) => {
  return baseRateGradeType[value.toLowerCase()] || ''
}
