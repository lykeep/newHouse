export default (value, record) => {
  let type
  switch (value) {
    case '101600000010':
      type = '提交'
      break;
    case '101600000020':
      type = '批准'
      break;
    case '101600000030':
      type = '退回'
      break;
    case '101600000040':
      type = '撤回'
      break;
    case '101600000050':
      type = '否决'
      break;
    case '101600000060':
      type = '加签'
      break;
    case '101600000070':
      type = '撤销'
      break;
    case '101600000080':
      type = '传阅'
      break;
    case '101600000090':
      type = '任务转发'
      break;
    case '101600000100':
      type = '附条件同意'
      break;
    default:
  }
  return type
}
