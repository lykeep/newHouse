import { buildColumnRender, buildSelectOptions } from '../../common/utils'

export const YES = '1'
export const NO = '0'

export const yesOrNo = {
  YES,
  NO,
}

export const yesOrNoLabels = {
  [yesOrNo.YES]: '有',
  [yesOrNo.NO]: '无',
}

export const yesOrNoOptions = [
  {
    label: yesOrNoLabels[YES],
    value: YES,
    key: YES,
  },
  {
    label: yesOrNoLabels[NO],
    value: NO,
    key: NO,
  },
]

export const yOrN = {
  YES,
  NO,
}

export const yOrNLabels = {
  [yOrN.YES]: '是',
  [yOrN.NO]: '否',
}

export const yOrNSelectOptions = [
  {
    title: yOrNLabels[YES],
    value: YES,
    key: YES,
  },
  {
    title: yOrNLabels[NO],
    value: NO,
    key: NO,
  },
]

export const yOrNOptions = [
  {
    label: yOrNLabels[YES],
    value: YES,
    key: YES,
  },
  {
    label: yOrNLabels[NO],
    value: NO,
    key: NO,
  },
]

export const yesOrNoRender = buildColumnRender(yesOrNoLabels)
export const yOrNRender = buildColumnRender(yOrNLabels)


export default (value, record) => (value === YES ? '是' : '否')

