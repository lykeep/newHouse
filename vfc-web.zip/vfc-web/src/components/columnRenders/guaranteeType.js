/*
 * 保证人类型
 */

export const guaranteeType = {
  legal: '法人',
  natural: '自然人',
}

export const guaranteeTypeOptions = Object.keys(guaranteeType).map(g => ({
  title: guaranteeType[g],
  value: g,
  key: g,
}))

export default (value = '', record) => {
  return guaranteeType[value.toLowerCase()] || ''
}
