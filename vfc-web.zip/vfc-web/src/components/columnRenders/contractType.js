import { buildColumnRender, buildSelectOptions } from '../../common/utils';

// 合同类型
export const contractType = {
  DIRECT_RENT: 'DIRECT_RENT', // 直租
  BACK_RENT: 'BACK_RENT', // 回租
  LOAN_CTR: 'LOAN_CTR', // 贷款
  LOAN_CREDIT: 'LOAN_CREDIT', // 额度
  CRT_GRANTED: 'LOAN_CREDIT_USE', // 额度下支用
}

export const contractTypeLabels = {
  [contractType.DIRECT_RENT]: '直租',
  [contractType.BACK_RENT]: '回租',
  [contractType.LOAN_CTR]: '贷款',
  [contractType.LOAN_CREDIT]: '额度',
  [contractType.CRT_GRANTED]: '额度下支用',
}

export const contractTypeSelectOptions = buildSelectOptions(contractTypeLabels)

export const contractTypeRender = buildColumnRender(contractTypeLabels)
