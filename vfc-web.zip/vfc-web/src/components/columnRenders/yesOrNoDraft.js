export const YES = '02'
export const NO = '01'
export default (value, record) => (value === YES ? '是' : '否')
