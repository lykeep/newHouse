// 授信类别
import { buildColumnRender, buildSelectOptions } from '../../common/utils'


export const creditClass = {
  root: '00',
  creditUser: '30',
  supplier: '40',
}
export const creditClassLabels = {
  [creditClass.root]: '顶级授信',
  [creditClass.creditUser]: '领用人',
  [creditClass.supplier]: '供应商',
}

export const creditClassSelectOptions = buildSelectOptions(creditClassLabels)

export const creditClassRender = buildColumnRender(creditClassLabels)
