import { buildColumnRender, buildSelectOptions } from '../../common/utils';

// 借据状态
export const loanStatus = {
  LOAN_WAIT_EFF: 'LOAN_WAIT_EFF', // 待生效
  LOAN_NORMAL: 'LOAN_NORMAL', // 正常
  LOAN_OVER_DUE: 'LOAN_OVER_DUE', // 逾期
  LOAN_SETTLEMENT: 'LOAN_SETTLEMENT', // 结清
}

export const loanStatusLabels = {
  [loanStatus.LOAN_WAIT_EFF]: '待生效',
  [loanStatus.LOAN_NORMAL]: '正常',
  [loanStatus.LOAN_OVER_DUE]: '逾期',
  [loanStatus.LOAN_SETTLEMENT]: '结清',
}

export const loanStatusSelectOptions = buildSelectOptions(loanStatusLabels)

export const loanStatusRender = buildColumnRender(loanStatusLabels)
