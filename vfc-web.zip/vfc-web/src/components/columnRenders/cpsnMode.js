import { buildColumnRender, buildSelectOptions } from '../../common/utils'

export const cpsnMode = {
  AUTO: '0',
  MANPOWER: '1',
}

export const cpsnModeLabels = {
  [cpsnMode.AUTO]: '自动',
  [cpsnMode.MANPOWER]: '人工',
}

export const cpsnModeOptions = [
  {
    label: cpsnModeLabels[cpsnMode.AUTO],
    value: cpsnMode.AUTO,
    key: cpsnMode.AUTO,
  },
  {
    label: cpsnModeLabels[cpsnMode.MANPOWER],
    value: cpsnMode.MANPOWER,
    key: cpsnMode.MANPOWER,
  },
]

export const cpsnModeRender = buildColumnRender(cpsnMode)


export default (value, record) => (value === cpsnMode.AUTO ? '自动' : '人工')

