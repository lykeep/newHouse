/*
 * 出入库类型
 */

export const enterLibraryTypes = {
  '01': '待入库',
  '02': '已入库',
  '03': '待出库',
  '04': '已出库',
}

export default (value = '') => enterLibraryTypes[value] || ''
