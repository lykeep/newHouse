export const YES = 'Y'
export const NO = 'N'
export default (value, record) => (value === YES ? '是' : '否')
