export default (value, record) => {
  let type
  switch (value) {
    case '01':
      type = '按融资额百分比'
      break;
    case '02':
      type = '按合同金额百分比'
      break;
    case '03':
      type = '按放款金额百分比'
      break;
    case '04':
      type = '按未偿还本金百分比'
      break;
    case '05':
      type = '固定金额'
      break;
    default:
  }
  return type
}
