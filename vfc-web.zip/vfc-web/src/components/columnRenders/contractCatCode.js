import { buildColumnRender, buildSelectOptions } from '../../common/utils';

// 合同类别
export const contractCatCode = {
  LOAN: 'LOAN', // 贷款
  LEASE: 'LEASE', // 租赁

}

export const contractCatCodeLabels = {
  [contractCatCode.LOAN]: '贷款',
  [contractCatCode.LEASE]: '租赁',
}

export const contractCatCodeSelectOptions = buildSelectOptions(contractCatCodeLabels)

export const contractCatCodeRender = buildColumnRender(contractCatCodeLabels)
