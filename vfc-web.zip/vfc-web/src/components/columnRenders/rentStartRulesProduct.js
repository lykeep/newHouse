
export const Rent = '起租日规则'
export const Interest = '起息日规则'

export const rentStartRulesType = {
  Rent,
  Interest,
}

export const RentOptions = [
  { title: '放款日起租 ', value: '01', key: '01' },
  { title: '固定日起租', value: '02', key: '02' },
]

export const InterestOptions = [
  { title: '放款日起息 ', value: '01', key: '01' },
]

