export default (value, record) => {
  let type
  switch (value) {
    case '00':
      type = '一般户'
      break;
    case '04':
      type = '基本户'
      break;
    case '02':
      type = '借记卡账户'
      break;
    case '03':
      type = '贷记卡账户'
      break;
    case '01':
      type = '其他'
      break;
    default: type = ''
  }
  return type
}
