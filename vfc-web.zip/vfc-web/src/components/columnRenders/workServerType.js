import { buildColumnRender, buildSelectOptions } from '../../common/utils';

export const workServerStatus = {
  101200000020: '101200000020', // 岗位服务
  101200000030: '101200000030', // 岗位服务
}

export const workServerStatusLabels = {
  [workServerStatus[101200000020]]: '业务服务',
  [workServerStatus[101200000030]]: '岗位服务',
}

export const workServerStatusSelectOptions = buildSelectOptions(workServerStatusLabels)

export const workServerStatusRender = buildColumnRender(workServerStatusLabels)
