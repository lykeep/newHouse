export default (value, record) => {
  let label
  switch (value) {
    case '00':
      label = '首选'
      break;
    case '01':
      label = '常用'
      break;
    case '02':
      label = '备用'
      break;
    case '03':
      label = '紧急时使用'
      break;
    default:
  }
  return label
}
