import { buildColumnRender } from '../../common/utils'

// 货币以此为准
export const currencyType = {
  RMB: '00',
  USD: '01',
  JPY: '02',
  EUR: '03',
  GBP: '04',
  HKD: '05',
  OTH: '99',
}
export const currencyTypeLabels = {
  [currencyType.RMB]: '人民币',
  [currencyType.USD]: '美元',
  [currencyType.JPY]: '日元',
  [currencyType.EUR]: '欧元',
  [currencyType.GBP]: '英镑',
  [currencyType.HKD]: '港币',
  [currencyType.OTH]: '其他',
}

export const currencyTypeSelectOptions = [
  { key: currencyType.RMB, value: currencyType.RMB, title: currencyTypeLabels[currencyType.RMB] },
  { key: currencyType.USD, value: currencyType.USD, title: currencyTypeLabels[currencyType.USD] },
  { key: currencyType.JPY, value: currencyType.JPY, title: currencyTypeLabels[currencyType.JPY] },
  { key: currencyType.EUR, value: currencyType.EUR, title: currencyTypeLabels[currencyType.EUR] },
  { key: currencyType.GBP, value: currencyType.GBP, title: currencyTypeLabels[currencyType.GBP] },
  { key: currencyType.HKD, value: currencyType.HKD, title: currencyTypeLabels[currencyType.HKD] },
  { key: currencyType.OTH, value: currencyType.OTH, title: currencyTypeLabels[currencyType.OTH] },
]

export const currencyTypeRender = buildColumnRender(currencyTypeLabels)

export default (value, record) => {
  let type
  switch (value) {
    case '00':
      type = '人民币'
      break;
    case '01':
      type = '美元'
      break;
    case '02':
      type = '日元'
      break;
    case '03':
      type = '欧元'
      break;
    case '04':
      type = '英镑'
      break;
    case '05':
      type = '港币'
      break;
    case '99':
      type = '其他'
      break;
    default: type = ''
  }
  return type
}
