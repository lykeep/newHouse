/*
申请列表-申请类型
 */
export const AssetLeaseApplyType = {
  ChangeCarNo: '01',
  ChangeHypothecate: '02',
  ChangePledge: '03',
}
export const AssetLeaseApplyTypeLabels = {
  [AssetLeaseApplyType.ChangeCarNo]: '变更车架号',
  [AssetLeaseApplyType.ChangeHypothecate]: '抵押变更',
  [AssetLeaseApplyType.ChangePledge]: '解押变更',

}

export default (value = '', record) => AssetLeaseApplyTypeLabels[value] || ''
