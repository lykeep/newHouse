import { buildColumnRender, buildSelectOptions } from '../../common/utils';

// 合同业务类型编号
export const contractBizType = {
  DIRECT_RENT_CTR: 'DIRECT_RENT_CTR', // 直租合同
  DIRECT_RENT_LOAN: 'DIRECT_RENT_LOAN', // 直租借据
  BACK_RENT_CTR: 'BACK_RENT_CTR', // 回租合同
  BACK_RENT_LOAN: 'BACK_RENT_LOAN', // 回租借据
  LOAN_CTR_CTR: 'LOAN_CTR_CTR', // 贷款合同
  LOAN_CTR_LOAN: 'LOAN_CTR_LOAN', // 贷款借据
  LOAN_CREDIT_CTR: 'LOAN_CREDIT_CTR', // 额度合同
  LOAN_CREDIT_CREDIT: 'LOAN_CREDIT_CREDIT', // 额度
  LOAN_CREDIT_USE_CTR: 'LOAN_CREDIT_USE_CTR', // 额度下支用合同
  LOAN_CREDIT_USE_LOAN: 'LOAN_CREDIT_USE_LOAN', // 额度下支用借据
}

export const contractBizTypeLabels = {
  [contractBizType.DIRECT_RENT_CTR]: '直租合同',
  [contractBizType.DIRECT_RENT_LOAN]: '直租借据',
  [contractBizType.BACK_RENT_CTR]: '回租合同',
  [contractBizType.BACK_RENT_LOAN]: '回租借据',
  [contractBizType.LOAN_CTR_CTR]: '贷款合同',
  [contractBizType.LOAN_CTR_LOAN]: '贷款借据',
  [contractBizType.LOAN_CREDIT_CTR]: '额度合同',
  [contractBizType.LOAN_CREDIT_CREDIT]: '额度',
  [contractBizType.LOAN_CREDIT_USE_CTR]: '额度下支用合同',
  [contractBizType.LOAN_CREDIT_USE_LOAN]: '额度下支用借据',
}

export const contractBizTypeSelectOptions = buildSelectOptions(contractBizTypeLabels)

export const contractBizTypeRender = buildColumnRender(contractBizTypeLabels)
