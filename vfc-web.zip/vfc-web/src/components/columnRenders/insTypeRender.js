export default (value, record) => {
  let type
  switch (value) {
    case '01':
      type = '汽车商业保险'
      break;
    case '02':
      type = '交强险'
      break;
    case '03':
      type = '履约保证保险'
      break;
    case '04':
      type = '财产保险'
      break;
    case '05':
      type = '个贷综合险'
      break;
    case '06':
      type = '盗抢险、车损险、第三者责任险'
      break;
    case '07':
      type = '盗抢险、车损险'
      break;
    case '08':
      type = '第三者责任险'
      break;
    default: type = ''
  }
  return type
}
