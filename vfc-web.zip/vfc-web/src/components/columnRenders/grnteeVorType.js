export default (value, record) => {
  let type
  switch (value) {
    case '00':
      type = '房产证/土地证/不动产证/他项权利证'
      break;
    case '01':
      type = '保单'
      break;
    case '02':
      type = '存单'
      break;
    case '03':
      type = '票据'
      break;
    case '04':
      type = '机动车登记证'
      break;
    case '05':
      type = '国债'
      break;
    case '06':
      type = '股权/股票'
      break;
    case '07':
      type = '其它权利'
      break;
    default: type = ''
  }
  return type
}
