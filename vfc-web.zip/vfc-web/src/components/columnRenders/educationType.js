export default (value, record) => {
  let label
  switch (value) {
    case '00':
      label = '研究生及以上'
      break;
    case '01':
      label = '大学本科'
      break;
    case '02':
      label = '大学专业学校或中等技术学校'
      break;
    case '03':
      label = '高中'
      break;
    default:
  }
  return label
}
