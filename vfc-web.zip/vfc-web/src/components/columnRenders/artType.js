export default (value, record) => {
  if (value === '00') {
    value = '原件'
  } else if (value === '01') {
    value = '复印件'
  }
  return value
}
