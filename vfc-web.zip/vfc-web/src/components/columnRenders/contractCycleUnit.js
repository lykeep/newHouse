// 合同期限单位
import { buildColumnRender, buildSelectOptions } from '../../common/utils'

export const contractCycleUnit = {
  NOT_SIGNED: '01', // 待签署
  SIGNING: '04', // 签署中
  SIGNED: '02', // 已签署
  DISCARDED: '03', // 已作废
}

export const contractCycleUnitLabels = {
  [contractCycleUnit.NOT_SIGNED]: '待签署',
  [contractCycleUnit.SIGNING]: '签署中',
  [contractCycleUnit.SIGNED]: '已签署',
  [contractCycleUnit.DISCARDED]: '已作废',
}

export const contractCycleUnitOptions = buildSelectOptions(contractCycleUnitLabels)

export const contractCycleUnitRender = buildColumnRender(contractCycleUnitLabels)
