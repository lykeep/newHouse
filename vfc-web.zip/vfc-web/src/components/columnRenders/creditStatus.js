import { buildColumnRender, buildSelectOptions } from '../../common/utils'

export const creditStatus = {
  normal: '01',
  stop: '02',
  expired: '03',
}

const creditStatusLabels = {
  [creditStatus.normal]: '正常',
  [creditStatus.stop]: '关闭',
  [creditStatus.expired]: '过期',
}

export const creditStatusOptions = buildSelectOptions(creditStatusLabels)

export const creditStatusRender = buildColumnRender(creditStatusLabels)
