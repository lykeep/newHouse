export default (value, record) => {
  let type
  switch (value) {
    case '00':
      type = '身份证'
      break;
    case '01':
      type = '临时身份证'
      break;
    case '02':
      type = '军官证'
      break;
    case '03':
      type = '士兵证'
      break;
    case '04':
      type = '警官证'
      break;
    case '05':
      type = '普通护照'
      break;
    case '06':
      type = '台湾同胞来往大陆通行证'
      break;
    case '07':
      type = '港澳同胞回乡证'
      break;
    case '08':
      type = '外国人居留证'
      break;
    case '09':
      type = '户口簿'
      break;
    case '99':
      type = '其他'
      break;
    default: type = ''
  }
  return type
}
