export default (value, record) => (value === '00' ? '所管辖的子公司' : '隶属的母公司')
