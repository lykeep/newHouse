import { buildColumnRender, buildSelectOptions } from '../../common/utils'

export const secDepProTypeCode = {
  NORMAL: '01',
  NONORMAL: '02',
}

export const secDepProTypeLabels = {
  [secDepProTypeCode.NORMAL]: '标准',
  [secDepProTypeCode.NONORMAL]: '非标准',
}

export const secDepProTypeOptions = [
  {
    label: secDepProTypeLabels[secDepProTypeCode.NORMAL],
    value: secDepProTypeCode.NORMAL,
    key: secDepProTypeCode.NORMAL,
  },
  {
    label: secDepProTypeLabels[secDepProTypeCode.NONORMAL],
    value: secDepProTypeCode.NONORMAL,
    key: secDepProTypeCode.NONORMAL,
  },
]

export const secDepProTypeRender = buildColumnRender(secDepProTypeCode)


export default (value, record) => (value === secDepProTypeCode.NORMAL ? '标准' : '非标准')

