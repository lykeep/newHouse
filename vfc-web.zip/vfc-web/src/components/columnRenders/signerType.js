export default (value, record) => { // 产品分类
  let type
  switch (value) {
    case '01':
      type = '借款人'
      break;
    case '02':
      type = '出资人'
      break;
    default: type = ''
  }
  return type
}
