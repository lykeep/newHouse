export default (value, record) => {
  let label
  switch (value) {
    case '01':
      label = '系统自动'
      break;
    case '02':
      label = '还款单核销'
      break;
    default:
  }
  return label
}
