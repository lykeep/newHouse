import { buildColumnRender, buildSelectOptions } from '../../common/utils'

const receivableTypeLabels = {
  RENTAL: '租金',
  CHARGE: '费用',
  SECURITY_DEPOSIT: '保证金',
  DOWN_PAYMENT: '首付款',
  INTERIM: '租前息',
  INSTALLMENT: '期供',
  EARLY_SETTLEMENT: '提前结清',
  RENTAL_RESIDUAL: '残值',
  CHARGE_COMMISSION: '手续费',
  CHARGE_CONSULT: '咨询服务费',
  CHARGE_ASSET_MANAGE: '资产管理费',
  CHARGE_EARLY_SETTLEMENT: '提前结清费用',
  CHARGE_PENALTY_INTEREST: '罚息',
  CHARGE_FINE: '罚款',
  CHARGE_RS_VALUE: '价外残值',
  CHARGE_OTHER_CHARGE: '其他费用',
}

export const receivableTypeRender = buildColumnRender(receivableTypeLabels)

export const receivableTypeSelectOptions = buildSelectOptions(receivableTypeLabels)
