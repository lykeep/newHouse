// 模型决策结果
import { buildColumnRender, buildSelectOptions } from '../../common/utils'

export const riskResult = {
  SUCCESS: '0', // 通过
  FAIL: '1', // 拒绝
  MANUAL: '2', // 人工审核
}

export const riskResultLabels = {
  [riskResult.SUCCESS]: '通过',
  [riskResult.FAIL]: '拒绝',
  [riskResult.MANUAL]: '人工审核',
}

export const riskResultOptions = buildSelectOptions(riskResultLabels)

export const riskResultRender = buildColumnRender(riskResultLabels)
