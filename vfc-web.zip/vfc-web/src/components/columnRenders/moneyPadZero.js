import padEnd from './panEndFormatter'

export default (value = '', record) => {
  return padEnd(value, 2)
}
