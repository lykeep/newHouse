export default (value, record) => {
  let label
  switch (value) {
    case '0':
      label = '未核销'
      break;
    case '1':
      label = '部分核销'
      break;
    case '2':
      label = '已核销'
      break;
    default:
  }
  return label
}
