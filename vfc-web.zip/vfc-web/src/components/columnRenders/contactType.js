export default (value, record) => {
  let label
  switch (value) {
    case '00':
      label = '办公地址'
      break;
    case '01':
      label = '注册地址'
      break;
    case '02':
      label = '通讯地址'
      break;
    case '03':
      label = '单位固定电话'
      break;
    case '04':
      label = '住宅固定电话'
      break;
    default:
  }
  return label
}
