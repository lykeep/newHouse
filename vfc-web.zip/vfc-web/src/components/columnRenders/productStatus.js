export default (value, record) => { // 产品状态
  let type
  switch (value) {
    case '01':
      type = '上架'
      break;
    case '02':
      type = '下架'
      break;
    default: type = ''
  }
  return type
}
