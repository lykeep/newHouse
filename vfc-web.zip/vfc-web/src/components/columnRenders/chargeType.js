export default (value, record) => {
  let type
  switch (value) {
    case '01':
      type = '手续费'
      break;
    case '02':
      type = '其它费用'
      break;
    case '03':
      type = '咨询服务费'
      break;
    case '04':
      type = '资产管理费'
      break;
    case '05':
      type = '提前还款违约金'
      break;
    default:
  }
  return type
}
