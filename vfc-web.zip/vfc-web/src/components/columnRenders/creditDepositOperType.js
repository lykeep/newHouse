export default (value, record) => {
  let type
  switch (value) {
    case '3':
      type = '收取'
      break;
    case '4':
      type = '支出'
      break;
    default:
  }
  return type
}
