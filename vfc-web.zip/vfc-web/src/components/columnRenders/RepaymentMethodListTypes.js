export default (value, record) => {
  let label
  switch (value) {
    case '1':
      label = '系统划扣'
      break;
    case '2':
      label = '银行转账'
      break;
    default:
  }
  return label
}

