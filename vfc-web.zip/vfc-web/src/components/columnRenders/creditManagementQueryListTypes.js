

export const creditManagementQueryListTypes = {
  1: '正常',
  0: '停止',
}

export default (value = '') => creditManagementQueryListTypes[value] || ''
