export default (value, record) => {
  if (value === '10') {
    value = '合同'
  } else if (value === '20') {
    value = '借据'
  } else {
    value = ''
  }
  return value
}
