export default (value, record) => {
  let label
  switch (value) {
    case 'Jan':
      label = '1月'
      break;
    case 'Feb':
      label = '2月'
      break;
    case 'Mar':
      label = '3月'
      break;
    case 'Apr':
      label = '4月'
      break;
    case 'May':
      label = '5月'
      break;
    case 'Jun':
      label = '6月'
      break;
    case 'Jul':
      label = '7月'
      break;
    case 'Aug':
      label = '8月'
      break;
    case 'Sep':
      label = '9月'
      break;
    case 'Oct':
      label = '10月'
      break;
    case 'Nov':
      label = '11月'
      break;
    case 'Dec':
      label = '12月'
      break;
    case '1stQuarter':
      label = '第一季度'
      break;
    case '2ndQuarter':
      label = '第二季度'
      break;
    case '3rdQuarter':
      label = '第三季度'
      break;
    case '4thQuarter':
      label = '第四季度'
      break;
    case 'firstHalf':
      label = '上半年'
      break;
    case 'secondHalf':
      label = '下半年'
      break;
    default:
  }
  return label
}
