export default (value, record) => {
  let type
  switch (value) {
    case '01':
      type = '租赁合同'
      break;
    case '02':
      type = '抵押合同'
      break;
    case '03':
      type = '担保合同'
      break;
    case '04':
      type = '征信查询授权书'
      break;
    default: type = ''
  }
  return type
}
