export default (value, record) => {
  let label
  switch (value) {
    case '1':
      label = '已核销'
      break
    case '9':
      label = '已冲正'
      break
    default:
  }
  return label
}
