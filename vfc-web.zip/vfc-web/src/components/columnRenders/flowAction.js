import { flowActions } from '../../common/workflow'

const actionLabels = {
  [flowActions.submit]: '提交',
  [flowActions.approve]: '批准',
  [flowActions.back]: '退回',
  [flowActions.recall]: '撤回',
  [flowActions.reject]: '否决',
  [flowActions.counter]: '加签',
  [flowActions.revoke]: '撤销',
  [flowActions.circulation]: '传阅',
}

const buildOptions = (actionTypeAllowed = []) => actionTypeAllowed.map(a => ({
  title: actionLabels[a],
  value: a,
  key: a,
}))

export const flowActionOptions = buildOptions(Object.keys(actionLabels))

export default (value = '', record) => {
  return actionLabels[value] || ''
}
