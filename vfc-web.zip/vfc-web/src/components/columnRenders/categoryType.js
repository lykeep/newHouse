export default (value, record) => {
  let label
  switch (value) {
    case '00':
      label = '董事长'
      break;
    case '01':
      label = '董事'
      break;
    case '02':
      label = '法定代表人'
      break;
    case '03':
      label = '总经理'
      break;
    case '04':
      label = '财务负责人'
      break;
    case '05':
      label = '其他'
      break;
    default:
  }
  return label
}
