import { buildColumnRender, buildSelectOptions } from '../../common/utils';

/*
  产品-项目-保证金-计算方式
*/

export const sdCalcMethodCode = {
  CONTRACTPERCENT: '02', // 按合同金额百分比
  FINANCEPERCENT: '03', // 按融资额百分比
  FIXED: '04', // 固定金额
}

export const sdCalcMethodLabels = {
  [sdCalcMethodCode.CONTRACTPERCENT]: '按合同金额百分比',
  [sdCalcMethodCode.FINANCEPERCENT]: '按融资额百分比',
  [sdCalcMethodCode.FIXED]: '固定金额',
}

export const sdCalcMethodOptions = buildSelectOptions(sdCalcMethodLabels)

export const sdCalcMethodRender = buildColumnRender(sdCalcMethodLabels)


export const creditMethodCode = {
  // CONTRACTPERCENT: '02', // 按合同金额百分比
  FINANCEPERCENT: '03', // 按融资额百分比
}

export const creditMethodCodeLabels = {
  // [creditMethodCode.CONTRACTPERCENT]: '按合同金额百分比',
  [creditMethodCode.FINANCEPERCENT]: '按融资额百分比',
}

export const creditMethodCodeOptions = buildSelectOptions(creditMethodCodeLabels)
