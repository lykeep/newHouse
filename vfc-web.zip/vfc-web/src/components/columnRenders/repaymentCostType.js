export default (value, record) => {
  let label
  switch (value) {
    case '000':
      label = '租金'
      break
    case '001':
      label = '费用'
      break
    case '002':
      label = '保证金'
      break
    case '003':
      label = '首付款'
      break
    case '004':
      label = '租前息'
      break
    case '005':
      label = '期供'
      break
    case '006':
      label = '提前结清'
      break
    default:
  }
  return label
}
