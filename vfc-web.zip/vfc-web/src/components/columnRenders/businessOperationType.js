export default (value, record) => {
  let type
  switch (value) {
    case '0':
      type = '占用'
      break;
    case '1':
      type = '释放'
      break;
    case '2':
      type = '扣减'
      break;
    case '3':
      type = '归还'
      break;
    case '4':
      type = '冲正'
      break;
    default: type = ''
  }
  return type
}
