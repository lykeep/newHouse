export default (value, record) => {
  let label
  switch (value) {
    case 'China':
      label = '中国'
      break;
    case 'America':
      label = '美国'
      break;
    case 'Korea':
      label = '韩国'
      break;
    case 'France':
      label = '法国'
      break;
    case 'Ireland':
      label = '爱尔兰'
      break;
    case 'Indonesia':
      label = '印度尼西亚'
      break;
    default:
  }
  return label
}
