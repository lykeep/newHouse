// 法人企业类型
import { buildColumnRender, buildSelectOptions } from '../../common/utils'

const regType = [
  { title: '内资企业', value: '00', key: '00' },
  { title: '国有企业', value: '01', key: '01' },
  { title: '集体企业', value: '02', key: '02' },
  { title: '股份合作企业', value: '03', key: '03' },
  { title: '联营企业', value: '04', key: '04' },
  { title: '有限责任公司', value: '05', key: '05' },
  { title: '股份有限公司', value: '06', key: '06' },
  { title: '私营企业', value: '07', key: '07' },
  { title: '三资企业（港、澳、台投资企业）', value: '08', key: '08' },
  { title: '外商投资企业', value: '09', key: '09' },
  { title: '个体经营', value: '10', key: '10' },
  { title: '其他', value: '11', key: '11' },
]

export const legalPersonTypes = {
  limitedComp: '有限责任公司',
  gufenyouxian: '股份有限责任公司',
  geren: '个人独资企业',
  hehuo: '合伙企业',
  jiti: '集体企业',
}

const regTypeLabels = {}

regType.forEach(r => (regTypeLabels[r.key] = r.title))

export const regTypeRender = buildColumnRender(regTypeLabels)
