/*
 * module： 资产管理
 */

import { buildColumnRender, buildSelectOptions } from '../../common/utils';

/*
 * key : grnteeType  担保类型
 */
export const assetGrnteeTypeType = {
  Grntee: '01', // 保证
  MORTGAGE: '02', // 抵押
  RELEASE: '03', // 质押
}

export const assetGrnteeTypeTypeLabels = {
  [assetGrnteeTypeType.Grntee]: '保证',
  [assetGrnteeTypeType.MORTGAGE]: '抵押',
  [assetGrnteeTypeType.RELEASE]: '质押',
}

export const assetGrnteeTypeSelectOptions = buildSelectOptions(assetGrnteeTypeTypeLabels)

export const assetGrnteeTypeRender = buildColumnRender(assetGrnteeTypeTypeLabels)


/*
key ：grnteeObjType  押品类型
 */
export const assetGrnteeObjTypeType = {
  CarInfo: '01',
  HousePropertyInfo: '02',
  OtherHypothecation: '99',
}

export const assetGrnteeObjTypeTypeLabels = {
  [assetGrnteeObjTypeType.CarInfo]: '车辆',
  [assetGrnteeObjTypeType.HousePropertyInfo]: '房产',
  [assetGrnteeObjTypeType.OtherHypothecation]: '其他',
}

export const assetGrnteeObjTypeSelectOptions = buildSelectOptions(assetGrnteeObjTypeTypeLabels)

export const assetGrnteeObjTypeRender = buildColumnRender(assetGrnteeObjTypeTypeLabels)


/*
* key :grnteeStatus 担保管理 查询列表里的状态
 */
export const assetGrnteeStatusType = {
  TOBEENTER: '01', // 待入库
  ENTERED: '02', // 已入库
  TOBEOUT: '03', // 待出库
  OUTED: '04', // 已出库
  ENTERING: '05', // 入库中
  OUTING: '06', // 出库中
}
export const assetGrnteeStatusTypeLabels = {
  [assetGrnteeStatusType.TOBEENTER]: '待入库',
  [assetGrnteeStatusType.ENTERED]: '已入库',
  [assetGrnteeStatusType.TOBEOUT]: '待出库',
  [assetGrnteeStatusType.OUTED]: '已出库',
  [assetGrnteeStatusType.ENTERING]: '入库中',
  [assetGrnteeStatusType.OUTING]: '出库中',
}

export const assetGrnteeStatusTypeRender = buildColumnRender(assetGrnteeStatusTypeLabels)
