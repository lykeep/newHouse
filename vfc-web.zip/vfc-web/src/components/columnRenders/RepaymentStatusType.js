export default (value, record) => {
  let label
  switch (value) {
    case '1':
      label = '已确认'
      break;
    case '0':
      label = '未确认'
      break;
    default:
  }
  return label
}
