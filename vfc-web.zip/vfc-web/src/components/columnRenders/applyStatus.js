export default (value, record) => {
  let type
  switch (value) {
    case 'draftStatus':
      type = '草稿'
      break;
    case 'submittedStatus':
      type = '已提交'
      break;
    case 'approvalStatus':
      type = '审批中'
      break;
    case 'approvalPassStatus':
      type = '审批通过'
      break;
    case 'undoStatus':
      type = '撤销'
      break
    default: type = '草稿'
  }
  return type
}
