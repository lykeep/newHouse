export default (value, record) => {
  let label
  switch (value) {
    case '01':
      label = '本金+利息罚息'
      break;
    case '02':
      label = '费用罚息'
      break;
    case '03':
      label = '保证金罚息'
      break;
    case '04':
      label = '租前息罚息'
      break;
    default:
  }
  return label
}
