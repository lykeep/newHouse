export default (value, record) => {
  let type
  switch (value) {
    case 'normallevel1':
      type = '正常一级'
      break;
    case 'normallevel2':
      type = '正常二级'
      break;
    case 'concernLevel1':
      type = '关注一级'
      break;
    case 'concernLevel2':
      type = '关注二级'
      break;
    case 'secondaryLevel1':
      type = '次级一级'
      break;
    case 'secondaryLevel2':
      type = '次级二级'
      break;
    case 'suspiciousLevel1':
      type = '可疑一级'
      break;
    case 'lossLevel':
      type = '损失'
      break;
    default: type = '正常一级'
  }
  return type
}
