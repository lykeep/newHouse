/*
 * 分期租金条款收取频率
 */

export const installmentFrequency = {
  month: '月',
  doubleMonth: '双月',
  quarter: '季',
  halfYear: '半年',
  year: '年',
}

export const installmentFrequencyOptions = Object.keys(installmentFrequency).map(g => ({
  title: installmentFrequency[g],
  value: g,
  key: g,
}))

export default (value = '', record) => {
  return installmentFrequency[value.toLowerCase()] || ''
}
