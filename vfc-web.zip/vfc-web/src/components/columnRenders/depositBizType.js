import { buildColumnRender, buildSelectOptions } from '../../common/utils'

export const bizTypeCode = {
  DEDUCTION: '0',
  RETURN: '1',
  REVERSAL: '2',
  RECHARGE: '3',
  SPEND: '4',
}

export const bizTypeCodeLabels = {
  [bizTypeCode.DEDUCTION]: '扣减',
  [bizTypeCode.RETURN]: '归还',
  [bizTypeCode.REVERSAL]: '冲正',
  [bizTypeCode.RECHARGE]: '充值',
  [bizTypeCode.SPEND]: '支出',
}

export const bizTypeCodeOptions = buildSelectOptions(bizTypeCodeLabels)

export const bizTypeCodeRender = buildColumnRender(bizTypeCodeLabels)

export const transStatusCode = {
  SUCCESS: '01',
  FAILE: '02',
}

export const transStatusLabels = {
  [transStatusCode.SUCCESS]: '成功',
  [transStatusCode.FAILE]: '失败',
}

export const transStatusOptions = buildSelectOptions(transStatusLabels)

export const transStatusRender = buildColumnRender(transStatusLabels)
