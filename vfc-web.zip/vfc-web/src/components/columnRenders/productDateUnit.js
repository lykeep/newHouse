export default (value, record) => {
  let type
  switch (value) {
    case '01':
      type = '天'
      break;
    case '02':
      type = '月'
      break;
    case '03':
      type = '年'
      break;
    default:
  }
  return type
}
