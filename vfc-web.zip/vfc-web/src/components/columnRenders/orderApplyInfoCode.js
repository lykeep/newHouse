// 进件
import { buildColumnRender, buildSelectOptions } from '../../common/utils'

/*
  申请信息-基本信息-借款期限单位
*/

export const productDeadlineUnit = {
  DAY: '01', // 天
  MONTH: '02', // 月
  YEAR: '03', // 年
}

export const productDeadlineUnitLabels = {
  [productDeadlineUnit.DAY]: '天',
  [productDeadlineUnit.MONTH]: '月',
  [productDeadlineUnit.YEAR]: '年',
}

export const productDeadlineUnitOptions = buildSelectOptions(productDeadlineUnitLabels)

export const productDeadlineUnitRender = buildColumnRender(productDeadlineUnitLabels)


/*
  申请信息-基本信息-是否浮动利率
*/

export const ifRateFloatCode = {
  YES: '1', // 是
  NO: '0', // 否
}

export const ifRateFloatLabels = {
  [ifRateFloatCode.YES]: '是',
  [ifRateFloatCode.NO]: '否',
}

export const ifRateFloatOptions = buildSelectOptions(ifRateFloatLabels)

export const ifRateFloatRender = buildColumnRender(ifRateFloatLabels)

/*
  申请信息-基本信息-浮动方式
*/

export const rateFloatTypeCode = {
  RATEFLOAT: '01', // 浮动比例
  INTFLOAT: '02', // 浮动值
  FIXED: '03', // 固定值
}

export const rateFloatTypeLabels = {
  [rateFloatTypeCode.RATEFLOAT]: '浮动比例',
  [rateFloatTypeCode.INTFLOAT]: '浮动值',
  [rateFloatTypeCode.FIXED]: '固定值',
}

export const rateFloatTypeOptions = buildSelectOptions(rateFloatTypeLabels)

export const rateFloatTypeRender = buildColumnRender(rateFloatTypeLabels)

/*
  申请信息-基本信息-基本利率类型
*/

export const rateBaseTypeCode = {
  LOANRATE: '01', // 央行贷款利率
  FIXED: '02', // 固定利率
  SHIBOR: '03', // SHIBOR
  LIBOR: '03', // LIBOR
}

export const rateBaseTypeLabels = {
  [rateBaseTypeCode.LOANRATE]: '央行贷款利率',
  [rateBaseTypeCode.FIXED]: '固定利率',
  [rateBaseTypeCode.SHIBOR]: 'SHIBOR',
  [rateBaseTypeCode.LIBOR]: 'LIBOR',
}

export const rateBaseTypeOptions = buildSelectOptions(rateBaseTypeLabels)

export const rateBaseTypeRender = buildColumnRender(rateBaseTypeLabels)

/*
  申请信息-基本信息-付款方式
*/

export const payModeCode = {
  BDFORE: '01', // 先付
  AFTER: '02', // 后付
}

export const payModeLabels = {
  [payModeCode.BDFORE]: '先付',
  [payModeCode.AFTER]: '后付',
}

export const payModeOptions = buildSelectOptions(payModeLabels)

export const payModeRender = buildColumnRender(payModeLabels)

/*
  申请信息-基本信息-计息/起租日规则
*/

export const rentStartRulesCode = {
  AFTERLEND: '01', // 放款后起租
  FIXEDDARE: '02', // 固定日起租
}

export const rentStartRulesLabels = {
  [rentStartRulesCode.AFTERLEND]: '放款后起租',
  [rentStartRulesCode.FIXEDDARE]: '固定日起租',
}

export const rentStartRulesOptions = buildSelectOptions(rentStartRulesLabels)

export const rentStartRulesRender = buildColumnRender(rentStartRulesLabels)

/*
  申请信息-基本信息-还款方式
*/

export const intCalModeCode = {
  MODEONT: '01', // 等额本息
  MODETWO: '02', // 等额本金
  MODETHREE: '03', // 利随本清
  MODEFORE: '04', // 按期付息到期还本
  MODEFIVE: '05', // 等本等息
}

export const intCalModeLabels = {
  [intCalModeCode.MODEONT]: '等额本息',
  [intCalModeCode.MODETWO]: '等额本金',
  [intCalModeCode.MODETHREE]: '利随本清',
  [intCalModeCode.MODEFORE]: '按期付息到期还本',
  [intCalModeCode.MODEFIVE]: '等本等息',
}

export const intCalModeOptions = buildSelectOptions(intCalModeLabels)

export const intCalModeRender = buildColumnRender(intCalModeLabels)

/*
  申请信息-基本信息-还款日规则
*/

export const rentPayModCdCode = {
  PAYLENDDATE: '01', // 放款日对日
  PAYFIXEDDATE: '02', // 固定日还款
}

export const rentPayModCdLabels = {
  [rentPayModCdCode.PAYLENDDATE]: '放款日对日',
  [rentPayModCdCode.PAYFIXEDDATE]: '固定日还款',
}

export const rentPayModCdOptions = buildSelectOptions(rentPayModCdLabels)

export const rentPayModCdRender = buildColumnRender(rentPayModCdLabels)

/*
  申请信息-基本信息-罚息计算方式
*/

export const pnlCalcMethCdCode = {
  FIXEDRATIO: '01', // 固定利率值
  RATIOPERCENT: '02', // 执行利率的百分比
}

export const pnlCalcMethCdLabels = {
  [pnlCalcMethCdCode.FIXEDRATIO]: '固定利率值',
  [pnlCalcMethCdCode.RATIOPERCENT]: '执行利率的百分比',
}


/*
  申请信息-基本信息-担保方式
*/

export const guaTypeCode = {
  CREDIT: '04', // 信用
  PLEDGE: '03', // 质押
  MORTGAGE: '02', // 抵押
  ENSURE: '01', // 保证
}

export const guaTypeLabels = {
  [guaTypeCode.CREDIT]: '信用',
  [guaTypeCode.PLEDGE]: '质押',
  [guaTypeCode.MORTGAGE]: '抵押',
  [guaTypeCode.ENSURE]: '保证',
}

export const guaTypeOptions = buildSelectOptions(guaTypeLabels)

export const guaTypeRender = buildColumnRender(guaTypeLabels)


/*
  申请信息-费用信息-收取方式
*/

export const colMthdTypeCode = {
  TAKEBEFORELEND: '01', // 第一次放款前一次收取
  TAKEONCERATIO: '02', // 起息日一次性收取
  TAKEAFTERLEND: '03', // 每次放款后收取
  TAKEFIXEDDATE: '04', // 固定日期收取
  TAKEGRADA: '05', // 在合同执行期间分次收取
  TAKEONCERENT: '06', // 起租日一次性收
  TAKEEARLYPAY: '07', // 提前还款时收取
}

export const colMthdTypeLabels = {
  [colMthdTypeCode.TAKEBEFORELEND]: '第一次放款前一次收取',
  [colMthdTypeCode.TAKEONCERATIO]: '起息日一次性收取',
  [colMthdTypeCode.TAKEAFTERLEND]: '每次放款后收取',
  [colMthdTypeCode.TAKEFIXEDDATE]: '固定日期收取',
  [colMthdTypeCode.TAKEGRADA]: '在合同执行期间分次收取',
  [colMthdTypeCode.TAKEONCERENT]: '起租日一次性收',
  [colMthdTypeCode.TAKEEARLYPAY]: '提前还款时收取',
}

export const colMthdTypeOptions = buildSelectOptions(colMthdTypeLabels)

export const colMthdTypeRender = buildColumnRender(colMthdTypeLabels)

/*
  申请信息-费用信息-计算方式
*/

export const calcMthdTypeCode = {
  // FINANCEPERCENT: '01', // 按融资额百分比
  CONTRACTPERCENT: '02', // 按合同金额百分比
  // LENDPERCENT: '03', // 按放款金额百分比
  UNPAYPERCENT: '04', // 按未偿还本金百分比
  FIXED: '05', // 固定金额
}

export const calcMthdTypeLabels = {
  // [calcMthdTypeCode.FINANCEPERCENT]: '按融资额百分比',
  [calcMthdTypeCode.CONTRACTPERCENT]: '按合同金额百分比',
  // [calcMthdTypeCode.LENDPERCENT]: '按放款金额百分比',
  [calcMthdTypeCode.UNPAYPERCENT]: '按未偿还本金百分比',
  [calcMthdTypeCode.FIXED]: '固定金额',
}

export const calcMthdTypeOptions = buildSelectOptions(calcMthdTypeLabels)

export const calcMthdTypeRender = buildColumnRender(calcMthdTypeLabels)

/*
  申请信息-首付款信息-计算方式
*/

export const dpayCalcMethCdCode = {
  FINANCEPERCENT: '01', // 按融资额百分比
  FIXED: '02', // 固定金额
}

export const dpayCalcMethCdLabels = {
  [dpayCalcMethCdCode.FINANCEPERCENT]: '按融资额百分比',
  [dpayCalcMethCdCode.FIXED]: '固定金额',
}

export const dpayCalcMethCdOptions = buildSelectOptions(dpayCalcMethCdLabels)

export const dpayCalcMethCdRender = buildColumnRender(dpayCalcMethCdLabels)

/*
  申请信息-保证金信息-保证金类型
*/

export const secDepProTypeCode = {
  CONTRACT: '1', // 合同保证金
  CREDIT: '2', // 授信保证金
}

export const secDepProTypeLabels = {
  [secDepProTypeCode.CONTRACT]: '合同保证金',
  [secDepProTypeCode.CREDIT]: '授信保证金',
}

export const secDepProTypeOptions = buildSelectOptions(secDepProTypeLabels)

export const secDepProTypeRender = buildColumnRender(secDepProTypeLabels)

/*
  申请信息-保证金信息-计算方式
*/

export const sdCalcMethodCode = {
  LENDPERCENT: '01', // 按放款金额百分比
  CONTRACTPERCENT: '02', // 按合同金额百分比
  FINANCEPERCENT: '03', // 按融资额百分比
  FIXED: '04', // 固定金额
}

export const sdCalcMethodLabels = {
  [sdCalcMethodCode.LENDPERCENT]: '按放款金额百分比',
  [sdCalcMethodCode.CONTRACTPERCENT]: '按合同金额百分比',
  [sdCalcMethodCode.FINANCEPERCENT]: '按融资额百分比',
  [sdCalcMethodCode.FIXED]: '固定金额',
}

export const sdCalcMethodOptions = buildSelectOptions(sdCalcMethodLabels)

export const sdCalcMethodRender = buildColumnRender(sdCalcMethodLabels)

/*
  申请信息-保证金信息-处理方式
*/

export const sdDealMethodCode = { // 保证金类型为合同保证金时的处理方式
  DEDUCTION: '01', // 冲抵最后一期租金
  LASTRETURN: '02', // 最后一期租金日退还
  CONTRACTEND: '03', // 合同结束时退还
}

export const sdDealMethodCreditCode = { // 保证金类型为授信保证金时的处理方式
  AFTERREPAY: '01', // 还款后释放保证金
}

export const sdDealMethodLabels = {
  [sdDealMethodCode.DEDUCTION]: '冲抵最后一期租金',
  [sdDealMethodCode.LASTRETURN]: '最后一期租金日退还',
  [sdDealMethodCode.CONTRACTEND]: '合同结束时退还',
}

export const sdDealMethodCreditLabels = {
  [sdDealMethodCreditCode.AFTERREPAY]: '还款后释放保证金',
}

export const sdDealMethodOptions = buildSelectOptions(sdDealMethodLabels)
export const sdDealMethodCreditOptions = buildSelectOptions(sdDealMethodCreditLabels)

export const sdDealMethodRender = buildColumnRender(sdDealMethodLabels)
export const sdDealMethodCreditRender = buildColumnRender(sdDealMethodCreditLabels)

/*
  申请信息-保证金信息-收取方式
*/

export const sdColMethodCode = {
  FIXEDDATE: '01', // 固定日期收取
  FIESTLEND: '02', // 第一次放款前一次性收取
  EACHLEND: '03', // 每次放款前收取
  RENTDATE: '04', // 起租日一次性收取
  LENDDATE: '05', // 放款时收取
}

export const sdColMethodLabels = {
  [sdColMethodCode.FIXEDDATE]: '固定日期收取',
  [sdColMethodCode.FIESTLEND]: '第一次放款前一次性收取',
  [sdColMethodCode.EACHLEND]: '每次放款前收取',
  [sdColMethodCode.RENTDATE]: '起租日一次性收取',
  [sdColMethodCode.LENDDATE]: '放款时收取',
}

export const sdColMethodOptions = buildSelectOptions(sdColMethodLabels)

export const sdColMethodRender = buildColumnRender(sdColMethodLabels)

/*
  申请信息-租前息信息-收取方式
*/

export const interimColMethodCode = {
  COLLONCE: '01', // 起租日一次性收取
  FIXEDCOLL: '02', // 按固定频率收取
}

export const interimColMethodLabels = {
  [interimColMethodCode.COLLONCE]: '起租日一次性收取',
  [interimColMethodCode.FIXEDCOLL]: '按固定频率收取',
}

export const interimColMethodOptions = buildSelectOptions(interimColMethodLabels)

export const interimColMethodRender = buildColumnRender(interimColMethodLabels)
