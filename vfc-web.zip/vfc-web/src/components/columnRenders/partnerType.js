export default (value, record) => (value === '304100000001' ? '自然人客户' : '法人客户')

const bpType = [{
  title: '有限责任公司',
  value: '00',
  key: '00',
}, {
  title: '股份有限责任公司',
  value: '01',
  key: '01',
}, {
  title: '个人独资企业',
  value: '02',
  key: '02',
}, {
  title: '合伙企业',
  value: '03',
  key: '03',
}, {
  title: '集体企业',
  value: '04',
  key: '04',
}]

export const bpTypeRender = (value) => {
  for (let i = 0; i < bpType.length; i += 1) {
    if (bpType[i].value === value) {
      return bpType[i].title
    }
  }

  return ''
}
