export default (value, record) => { // 其他联系人类别
  let label
  switch (value) {
    case '00':
      label = '第一联系人'
      break;
    case '01':
      label = '第二联系人'
      break;
    default:
  }
  return label
}
