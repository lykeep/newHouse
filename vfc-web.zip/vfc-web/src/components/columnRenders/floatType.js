/*
 * 浮动方式
 */

export const floatType = {
  floatValue: '浮动值',
  floatPersent: '浮动比例',
  noFloat: '不浮动',
}

export const floatTypeOptions = Object.keys(floatType).map(g => ({
  title: floatType[g],
  value: g,
  key: g,
}))

export default (value = '', record) => {
  return floatType[value.toLowerCase()] || ''
}
