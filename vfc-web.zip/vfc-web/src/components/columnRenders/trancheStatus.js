export default (value, record) => {
  let type
  switch (value) {
    case '0':
      type = '未申请'
      break
    case '1':
      type = '审批中'
      break
    case '2':
      type = '待财务处理'
      break
    case '3':
      type = '放款完成'
      break
    default:
      type = value
  }
  return type
}

export const detailTrancheStatus = (value, record) => {
  let type
  switch (value) {
    case '0':
      type = '待放款'
      break
    case '1':
      type = '放款中'
      break
    case '2':
      type = '放款成功'
      break
    case '9':
      type = '放款失败'
      break
    default:
      type = value
  }
  return type
}