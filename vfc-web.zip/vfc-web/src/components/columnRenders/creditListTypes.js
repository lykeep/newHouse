

export const creditManagementQueryListTypes = {
  1: '正常',
  0: '停止',
}

// export const cxxxreditManagementQueryListTypes = {
//   1: '正常',
//   0: '停止',
// }

export const fun1 = (value = '') => {
  creditManagementQueryListTypes[value] || ''
}
