export default (value, record) => {
  if (value === '0') {
    value = '占用'
  } else if (value === '1') {
    value = '释放'
  }
  return value
}
