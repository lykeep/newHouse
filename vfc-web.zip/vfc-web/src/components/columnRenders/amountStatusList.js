import { buildColumnRender, buildSelectOptions } from '../../common/utils';

// 合同状态
export const amountStatus = {

  // LOAN_WAIT_EFF: 'LOAN_WAIT_EFF', // 待生效
  // LOAN_NORMAL: 'LOAN_NORMAL', // 正常
  // LOAN_OVER_DUE: 'LOAN_OVER_DUE', // 逾期
  // LOAN_SETTLEMENT: 'LOAN_SETTLEMENT', // 结清
  CREDIT_WAIT_EFF: 'CREDIT_WAIT_EFF', // 待发放
  CREDIT_NORMAL: 'CREDIT_NORMAL', // 正常
  CREDIT_FROZEN: 'CREDIT_FROZEN', // 冻结
  CREDIT_EXPIRE: 'CREDIT_EXPIRE', // 已失效
}

export const amountStatusLabels = {
  // [amountStatus.LOAN_WAIT_EFF]: '待发放',
  // [amountStatus.LOAN_NORMAL]: '正常',
  // [amountStatus.LOAN_OVER_DUE]: '逾期',
  // [amountStatus.LOAN_SETTLEMENT]: '结清',
  [amountStatus.CREDIT_WAIT_EFF]: '待发放',
  [amountStatus.CREDIT_NORMAL]: '正常',
  [amountStatus.CREDIT_FROZEN]: '冻结',
  [amountStatus.CREDIT_EXPIRE]: '已失效',
}

export const amountStatusSelectOptions = buildSelectOptions(amountStatusLabels)

export const amountStatusRender = buildColumnRender(amountStatusLabels)
