export default (value, record) => {
  let label
  switch (value) {
    case '01':
      label = '固定利率值'
      break;
    case '02':
      label = '执行利率的百分比'
      break;
    default:
  }
  return label
}
