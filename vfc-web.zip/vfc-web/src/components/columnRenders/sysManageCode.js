import { buildColumnRender, buildSelectOptions } from '../../common/utils'

export const orgType = [
  { title: '公司', value: '1', key: '1' },
  { title: '部门', value: '2', key: '2' },
  { title: '团队', value: '3', key: '3' },
]

// export const dataPmsnType = [
//   { title: '所有', value: '1', key: '1' },
//   { title: '本人', value: '2', key: '2' },
//   { title: '部门', value: '3', key: '3' },
//   { title: '部门及以下', value: '4', key: '4' },
//   { title: '公司', value: '5', key: '5' },
//   { title: '公司及以下', value: '6', key: '6' },
//   { title: '机构', value: '7', key: '7' },
//   { title: '集团', value: '8', key: '8' },
// ]
// ，00:个人 01：部门 02：部门及部门下 03：公司 04：公司及公司以下 05：机构 06. 集团 99：全部
export const dataPmsnType = {
  INDIVIDUAL: '00',
  DEP: '01',
  DEPBLOW: '02',
  OFFICE: '03',
  OFFICEBLOW: '04',
  ENT: '05',
  GROUP: '06',
  ALL: '99',

}
export const dataPmsnTypeLabels = {
  [dataPmsnType.INDIVIDUAL]: '个人',
  [dataPmsnType.DEP]: '部门',
  [dataPmsnType.DEPBLOW]: '部门及部门下',
  [dataPmsnType.OFFICE]: '公司',
  [dataPmsnType.OFFICEBLOW]: '公司及公司以下',
  [dataPmsnType.ENT]: '机构',
  [dataPmsnType.GROUP]: '集团',
  [dataPmsnType.ALL]: '全部',
}
export const dataPmsnTypeSelectOptions = buildSelectOptions(dataPmsnTypeLabels)
export const dataPmsnTypeRender = buildColumnRender(dataPmsnTypeLabels)

export const officeType = {
  COMPANY: '00',
  BUSINESS: '01',
  SALES: '02',
  OPERATE: '03',
}

export const officeTypeLabels = {
  [officeType.COMPANY]: '集团机构',
  [officeType.BUSINESS]: '营业机构',
  [officeType.SALES]: '销售机构',
  [officeType.OPERATE]: '操作机构',
}

export const officeTypeSelectOptions = buildSelectOptions(officeTypeLabels)

export const officeTypeRender = buildColumnRender(officeTypeLabels)


export const subOfficeType = {
  COMPANY: '00',
  DEPARTMENT: '01',
  TEAM: '02',
}

export const subOfficeTypeLabels = {
  [subOfficeType.COMPANY]: '公司',
  [subOfficeType.DEPARTMENT]: '部门',
  [subOfficeType.TEAM]: '团队/小组',
}

export const subOfficeTypeSelectOptions = buildSelectOptions(subOfficeTypeLabels)

export const subOfficeTypeRender = buildColumnRender(subOfficeTypeLabels)
