// 合同状态
import { buildColumnRender, buildSelectOptions } from '../../common/utils'
export const contractStatus = {
  NOT_SIGNED: '01', // 待签署
  SIGNING: '04', // 签署中
  SIGNED: '02', // 已签署
  DISCARDED: '03', // 已作废
}

export const contractStatusLabels = {
  [contractStatus.NOT_SIGNED]: '待签署',
  [contractStatus.SIGNING]: '签署中',
  [contractStatus.SIGNED]: '已签署',
  [contractStatus.DISCARDED]: '已作废',
}

export const contractStatusOptions = buildSelectOptions(contractStatusLabels)

export const contractStatusRender = buildColumnRender(contractStatusLabels)
