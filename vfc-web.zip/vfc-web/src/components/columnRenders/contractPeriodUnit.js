import { buildColumnRender, buildSelectOptions } from '../../common/utils';

// 合同期限单位
export const contractPeriodUnit = {
  DAY: '01', // 天
  MONTH: '02', // 月
  YEAR: '03', // 年

}

export const contractPeriodUnitLabels = {
  [contractPeriodUnit.DAY]: '天',
  [contractPeriodUnit.MONTH]: '月',
  [contractPeriodUnit.YEAR]: '年',
}

export const contractPeriodUnitSelectOptions = buildSelectOptions(contractPeriodUnitLabels)

export const contractPeriodUnitRender = buildColumnRender(contractPeriodUnitLabels)
