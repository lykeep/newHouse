export default (value, record) => {
  let label
  switch (value) {
    case '00':
      label = '已成功联系过'
      break;
    case '01':
      label = '未联系过'
      break;
    case '02':
      label = '联系无效'
      break;
    case '03':
      label = '曾经成功联系，现已失效'
      break;
    case '04':
      label = '已删除'
      break;
    default:
  }
  return label
}
