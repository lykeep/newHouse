/*
* 租赁物类型
 */
import {buildColumnRender, buildSelectOptions} from "../../common/utils";


export const assetLeaseType = {
  plane: '01',
  officialHousing: '02',
  officialLand: '03',
  ships: '04',
  electronics: '05',
  electrical: '06',
  residenceHousing: '07',
  flexibleItem: '08', // 通用设备
  commercialLand: '09',
  commercialHousing: '10',
  industrialLand: '11',
  residentialLand: '12',
  cars: '13',
  dedicatedDevice: '14',
  instruments: '15',
  others: '16',
  industrialHousing: '17',
}
export const assetLeaseTypeLabels = {
  [assetLeaseType.plane]: '飞机',
  [assetLeaseType.officialHousing]: '办公用房',
  [assetLeaseType.officialLand]: '办公用地',
  [assetLeaseType.ships]: '船舶',
  [assetLeaseType.electronics]: '电子产品及通用设备',
  [assetLeaseType.electrical]: '电气设备',
  [assetLeaseType.residenceHousing]: '居住用房',
  [assetLeaseType.flexibleItem]: '通用设备',
  [assetLeaseType.commercialLand]: '商业用地',
  [assetLeaseType.commercialHousing]: '商业用房',
  [assetLeaseType.industrialLand]: '工业用地',
  [assetLeaseType.residentialLand]: '居住用地',
  [assetLeaseType.cars]: '车辆',
  [assetLeaseType.dedicatedDevice]: '专用设备',
  [assetLeaseType.instruments]: '仪器仪表、计量标准器具及量具、衡器',
  [assetLeaseType.others]: '其他',
  [assetLeaseType.industrialHousing]: '工业用房',
}

export const assetLeaseTypeSelectOptions = buildSelectOptions(assetLeaseTypeLabels)

export const assetLeaseTypeRender = buildColumnRender(assetLeaseTypeLabels)

