import { buildColumnRender, buildSelectOptions } from '../../common/utils'

export const depositAcctType = {
  STANDARD: '1',
  UNSTANDARD: '0',
}

export const depositAcctTypeLabels = {
  [depositAcctType.STANDARD]: '标准保证金',
  [depositAcctType.UNSTANDARD]: '非标准保证金',
}

export const depositAcctTypeOptions = buildSelectOptions(depositAcctTypeLabels)

export const depositAcctTypeRender = buildColumnRender(depositAcctTypeLabels)
