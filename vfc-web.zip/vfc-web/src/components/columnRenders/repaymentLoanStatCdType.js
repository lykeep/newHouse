export default (value, record) => {
  let label
  switch (value) {
    case '001':
      label = '正常'
      break
    case '002':
      label = '逾期'
      break
    default:
  }
  return label
}
