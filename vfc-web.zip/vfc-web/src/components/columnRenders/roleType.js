import { buildColumnRender, buildSelectOptions } from '../../common/utils';

// 合同业务类型编号
export const roleType = {
  BORROWER: 'BORROWER', // 借款人
  MANUFACTURER: 'MANUFACTURER', // 厂商
  DEALER: 'DEALER', // 经销商
  LESSEE: 'LESSEE', // 承租人
  GUARANTOR: 'GUARANTOR', // 担保人
  SALESPERSON: 'SALESPERSON', // 销售员
  MARKETING_OFFICER: 'MARKETING_OFFICER', // 市场经理
  INACTIVE_GUARANTOR: 'INACTIVE_GUARANTOR', // 未激活的担保人
  JOINT_LESSEE: 'JOINT_LESSEE', // 联合承租人
  JOINT_BORROWER: 'JOINT_BORROWER', // 联合借款人
}

export const roleTypeLabels = {
  [roleType.BORROWER]: '借款人',
  [roleType.MANUFACTURER]: '厂商',
  [roleType.DEALER]: '经销商',
  [roleType.LESSEE]: '承租人',
  [roleType.GUARANTOR]: '担保人',
  [roleType.SALESPERSON]: '销售员',
  [roleType.MARKETING_OFFICER]: '市场经理',
  [roleType.INACTIVE_GUARANTOR]: '未激活的担保人',
  [roleType.JOINT_LESSEE]: '联合承租人',
  [roleType.JOINT_BORROWER]: '联合借款人',
}

export const roleTypeSelectOptions = buildSelectOptions(roleTypeLabels)

export const roleTypeRender = buildColumnRender(roleTypeLabels)
