export default (value, record) => (value === 'income' ? '收入' : '支出')
