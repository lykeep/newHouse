
import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Card from 'lbc-wrapper/lib/card/'
import Row from 'lbc-wrapper/lib/row'
import Col from 'lbc-wrapper/lib/col'
import Icon from 'lbc-wrapper/lib/icon'
import Table from 'lbc-wrapper/lib/table'
import AssureData from './AssureData'
import './BusinessCreditCard.scss'


const assureType = ['保证', '质押', '抵押']
const bz = [{ name: '保证1' }, { name: '保证2' }]
const zy = [{ name: '质押1' }, { name: '质押2' }, { name: '质押3' }]
const dy = [{ name: '抵押1' }, { name: '抵押2' }, { name: '抵押3' }]

class AssureTypeCard extends Component {
  
  constructor(props) {
    super(props)
    this.state={
      visible: false
    }
  }

  show = () => {
    const { visible } = this.state
    this.setState({ visible: !visible })
  }

  render() {
    const { type } = this.props
    const { visible } = this.state
    console.log('type', type)
    let data = []
    if (type == 1) {
      data = bz
    } else if ( type == 2) {
      data = zy
    } else if (type == 3) {
      data = dy
    }
    return (
      <Row className="mg-t-10 pd-l-10" >
        <Row className="mg-t-10">
          <span className="assureType-title">{assureType[type - 1]}</span>
          {
            data.length > 2 &&
              <span onClick={this.show} className="showBtn">
                collapse
                <Icon type={visible ? 'up' : 'down'} />
              </span>
          }
        </Row>
        {
          data.map((item, index) => {
            if (visible) {
              return <AssureData key={index} type={type} data={item} index={index} />
            } else if (index < 2) {
              return <AssureData key={index} type={type} data={item} index={index} />
              }
          })
        }
      </Row>
    )
  }
}

export default AssureTypeCard
