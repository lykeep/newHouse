import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Card from 'lbc-wrapper/lib/card/'
import Row from 'lbc-wrapper/lib/row'
import Col from 'lbc-wrapper/lib/col'
import Input from 'lbc-wrapper/lib/input'
import Icon from 'lbc-wrapper/lib/icon'
import Form from 'lbc-wrapper/lib/form'
import Checkbox from 'lbc-wrapper/lib/simpleCheckbox';


const assureType = ['保证人', '质押人', '抵押人']
class AssureData extends Component {
  constructor(props) {
    super(props)

  }

  onChange = (checkedValue) => {
    console.log('checkedValue', checkedValue)
    eee
  }

  render() {
    const { type, data, index } = this.props
    return (
      <div style={{ marginBottom: 10 }}>
        <Checkbox onChange={this.onChange}>
          <span className="mg-l-10">{assureType[type-1]}{index}</span>
          <span className="mg-l-10 assureName">({data.name})</span>
          <span className="mg-l-10">担保金额：</span>
          <span><Input style={{ width: 200 }} /></span>
        </Checkbox>
      </div>
    )
  }
}
export default AssureData
