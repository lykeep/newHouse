
import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Card from 'lbc-wrapper/lib/card/'
import Row from 'lbc-wrapper/lib/row'
import Col from 'lbc-wrapper/lib/col'
import Input from 'lbc-wrapper/lib/input'
import Form from 'lbc-wrapper/lib/form'
import InputNumber from 'lbc-wrapper/lib/inputNumber'
import Button from 'lbc-wrapper/lib/button'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import InputField from '../../components/form/inputs/InputField'
import NameFilterModal from '../form/inputs/nameFilterModal/NameFilterModal'

class ReceiveCompany extends Component {
  constructor(props) {
    super(props)
    this.columns = [{
      title: '名称',
      dataIndex: 'name',
    }, {
      title: 'id',
      dataIndex: 'id',
    }, {
      title: '时间',
      dataIndex: 'date',
    }, {
      title: '天气',
      dataIndex: 'weather',
    }]
  }

  render() {
    const { form, authority } = this.props
    const { getFieldDecorator } = form
    return (
      <Row>
        <Form>
          <NameFilterModal
            colSpan={8}
            form={form}
            authority={authority}
            name={['legalName', 'legalId']}
            modalData={{
              columns: this.columns,
            }}
            receivekey={['name', 'id']}
            formItemProps={{ label: '法人名称' }}
            fieldProps={{
            // initialValue: { legalId: legal.legalId, legalName: legal.legalName },
              rules: [
                { required: true, message: '法人必输！' },
              ],
            }}
            inputProps={{
              placeholder: '请输入',
            }}
          />
          <Col span={8}>
            <SimpleFormItem label="分配授信额度">
              {getFieldDecorator('LineCredit', {
                onChange: this.inputChange,
                rules: [{
                  required: true,
                  message: '分配授信额度必填',
                }],
              })(
                <Input placeholder="请输入" />
              )}
            </SimpleFormItem>
          </Col>
        </Form>
      </Row>
    )
  }
}

export default Form.create()(ReceiveCompany)

