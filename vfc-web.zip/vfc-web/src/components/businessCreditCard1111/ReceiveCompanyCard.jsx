import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Card from 'lbc-wrapper/lib/card/'
import Row from 'lbc-wrapper/lib/row'
import Col from 'lbc-wrapper/lib/col'
import Icon from 'lbc-wrapper/lib/icon'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import InputNumber from 'lbc-wrapper/lib/inputNumber'
import Button from 'lbc-wrapper/lib/button'
import InputField from '../../components/form/inputs/InputField'
import NameFilterModal from '../../components/form/inputs/nameFilterModal/NameFilterModal'
import ReceiveCompany from './ReceiveCompany'
import { colSpan as defaultColSpan } from '../form/inputs/consts'

// import calPermission, { PERMISSIONS } from '../../utils/calPermission'
// import { colSpan as defaultColSpan } from '../consts'

let uid = 0
class ReceiveCompanyCard extends Component {
  constructor(props) {
    super(props)
  }

  remove = (k) => {
    const { form } = this.props;
    const b = form.getFieldValue('b');
    if (b.length === 1) {
      return;
    }

    // can use data-binding to set
    form.setFieldsValue({
      b: b.filter(key => key !== k),
    });
  }

  add = () => {
    const { form } = this.props;
    // can use data-binding to get
    const b = form.getFieldValue('b');
    const nextb = b.concat(uid);
    uid++;
    // can use data-binding to set
    // important! notify form to detect changes
    form.setFieldsValue({
      b: nextb,
    });
  }

  render() {
    const { form, authority, name, fieldProps={}, colSpan, formItemProps={} } = this.props
    const { getFieldDecorator, getFieldValue } = form
 
    getFieldDecorator('b', { initialValue: [] });
    const b = getFieldValue('b');
    const formItems = b.map((k, index) => {
      return (
        <SimpleFormItem key={index}>
          {getFieldDecorator(`names[${k}]`, {
              validateTrigger: ['onChange', 'onBlur'],
              rules: [{
                required: true,
                whitespace: true,
              }],
            })(
              <ReceiveCompany authority={authority} ref={ e => this.refDOM = e} />
            )}
        </SimpleFormItem>
      )
    })
    return (
      <Card style={{ background: '#FAFAFA', marginBottom: 20 }} bordered={false}>
        <Button
          className="reCompanyBtn_add"
          type="dashed"
          icon="plus"
          onClick={this.add}
        >
          增加下属领用供应商
        </Button>
        <Col span={24} className="lb-col-gutter">
          <ReceiveCompany
            // onChange={this.receiveCompany}
            authority={authority}
            ref={e=>this.refDOM=e}
          />
        </Col>
        <Row>
          {formItems}
        </Row>
      </Card>
    )
  }
}

ReceiveCompanyCard.defaultProps = {
  colSpan: defaultColSpan,
}

export default ReceiveCompanyCard
