import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Card from 'lbc-wrapper/lib/card/'
import Row from 'lbc-wrapper/lib/row'
import Icon from 'lbc-wrapper/lib/icon'
import Table from 'lbc-wrapper/lib/table'

const nameList = ['保证', '抵押', '质押']
const dataList = [{
  name: '张三',
  number: '',
}, {
  name: '李四',
  number: '',
}]

class CheckedInfoList extends Component {
  constructor(props) {
    super(props)
    this.state = {
      showHeader: false,
    }
    this.columns = [
      {
        title: 'name',
        dataIndex: 'name',
        key: '1',
        render: (text) => {
          return (
            <span>保证人1{text}</span>
          )
        },
      }, {
        title: 'name',
        dataIndex: 'name',
        key: '1',
        render: (text) => {
          return (
            <span></span>
          )
        },
      },
    ]
  }

    reGroup = (data) => {

    }

  render() {

    const { name } = this.props
   // const { dataSource = [] } = this.reGroup(dataList)
    return(
      <div>
        <div>{name}</div>
           <Table {...this.state} columns={this.columns} dataSource={[]} />
      </div>
    )
  }
}

export default CheckedInfoList

