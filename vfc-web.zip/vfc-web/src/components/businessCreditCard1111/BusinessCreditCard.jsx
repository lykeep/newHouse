import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Card from 'lbc-wrapper/lib/card/'
import Row from 'lbc-wrapper/lib/row'
import Form from 'lbc-wrapper/lib/form'
import Icon from 'lbc-wrapper/lib/icon'
import InputNumber from 'lbc-wrapper/lib/inputNumber'
import Button from 'lbc-wrapper/lib/button'
import { effectiveObject } from '../../utils/dataType'
import RadioField from '../../components/form/inputs/RadioField'
import InputField from '../../components/form/inputs/InputField'
import CheckboxField from '../../components/form/inputs/CheckboxField'
import InputNumberField from '../../components/form/inputs/InputNumberField'
import SelectField from '../../components/form/inputs/SelectField'
import CheckedInfoList from './CheckedInfoList'
import ReceiveCompanyCard from './ReceiveCompanyCard'
import AssureTypeCard from './AssureTypeCard'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import wrapFormContainer from '../../components/form/groups/wrapFormContainer'
import './BusinessCreditCard.scss'

let uuid = 0;
class BusinessCreditCard extends Component {
  constructor(props) {
    super(props)
    this.state = {
      reCompany: '0',
      assureTypeArr: [],
      titleList: ['保理业务', '租赁业务', '借款业务'],
      businessType: {
        1: [{
          title: '反向保理',
          value: '1',
          key: '1',
        }, {
          title: '正向保理',
          key: 2,
          value: 2,
        }, {
          title: '项目',
          key: 3,
          value: 3,
        }],
        2: [{
          title: '直租',
          key: 4,
          value: 4,
        }, {
          title: '售后回租',
          key: 5,
          value: 5,
        }, {
          title: '项目',
          key: 6,
          value: 6,
        }],
      },
      factoringType: [
        {
          title: '明保理',
          value: 1,
          key: 1,
        },
        {
          title: '暗保理',
          value: 2,
          key: 2,
        },
      ],
      recourseType: [
        {
          title: '有追索权',
          value: 1,
          key: 1,
        },
        {
          title: '无追索权',
          value: 2,
          key: 2,
        },
      ],
      financingType: [
        {
          title: '保理池融资',
          value: 1,
          key: 1,
        },
        {
          title: '非保理池融资',
          value: 2,
          key: 2,
        },
      ],
      assureType: [
        {
          label: '保证',
          value: 1,
        }, {
          label: '质押',
          value: 2,
        }, {
          label: '抵押',
          value: 3,
        },
      ],
      company: [
        {
          label: '是',
          value: '0',
          key: '0',
        },
        {
          label: '否',
          value: '1',
          key: '1',
        },
      ],
      guaranteeType: [
        {
          name: '保证',
          key: '0',
        }, {
          name: '质押',
          key: '1',
        }, {
          name: '抵押',
          key: '2',
        },
      ],
    }
  }

  checkboxChange = (e) => {
    // console.log('e', e)
    this.setState({ assureTypeArr: e })
  }

  remove = (k) => {
    const { form } = this.props;
    // can use data-binding to get
    const keys = form.getFieldValue('keys');
    // We need at least one passenger
    if (keys.length === 1) {
      return;
    }

    // can use data-binding to set
    form.setFieldsValue({
      keys: keys.filter(key => key !== k),
    });
  }

  

  add = () => {
    const { form } = this.props;
    // can use data-binding to get
    const keys = form.getFieldValue('keys');
    const nextKeys = keys.concat(uuid);
    uuid++;
    // can use data-binding to set
    // important! notify form to detect changes
    form.setFieldsValue({
      keys: nextKeys,
    });
  }

  onChange = (e) => {
    this.setState({
      reCompany: e.target.value
    })
  }

  render() {
    const { form, authority, title = 0 } = this.props
    const { businessType, factoringType, financingType, recourseType, titleList, assureTypeArr, assureType, company, reCompany } = this.state
    //  console.log('authority', form)
    const { getFieldDecorator } = form
    getFieldDecorator('keys', { initialValue: [] });
    const keys = form.getFieldValue('keys');

    // 领用企业
    const mapReCompany = keys.map((k, index) => {
      return (
        <SimpleFormItem key={index}>
          {getFieldDecorator(`names-[${k}]`, {
            validateTrigger: ['onChange', 'onBlur'],
            rules: [{
              required: true,
              whitespace: true,
              message: "Pleace",
              type: "object"
            }],
          })(
            <ReceiveCompanyCard
              key={index}
              form={form}
              name={k}
              authority={authority}
              showBtn
            />
          )}
        </SimpleFormItem>
      )
    })

    return (
      <Card className="business-Credit" bordered={false} title={titleList[title]} extra={<Icon type="close" />}>
        <Form>
          <Row>
            <SelectField
              form={form}
              authority={authority}
              name="businessType"
              key="businessType"
              formItemProps={{ label: '业务类型' }}
              fieldProps={{
                initialValue: '1',
                rules: [{ required: true, message: '请选择' }],
              }}
              inputProps={{
                  options: businessType[1],
                  placeholder: '请选择',
              }}
            />
            {
                title == 0 &&
                <div>
                  <SelectField
                    form={form}
                    authority={authority}
                    name="factoringType"
                    key="factoringType"
                    formItemProps={{ label: '明暗保理' }}
                    fieldProps={{
                      // initialValue: data.scc,
                      rules: [{ required: true, message: '请选择' }],
                    }}
                    inputProps={{
                      options: factoringType,
                      placeholder: '请选择',
                    }}
                  />
                  <SelectField
                    form={form}
                    authority={authority}
                    name="recourseType"
                    key="recourseType"
                    formItemProps={{ label: '有无追索权' }}
                    fieldProps={{
                    // initialValue: data.scc,
                    rules: [
                        { required: true, message: '请选择' },
                        ],
                      }}
                    inputProps={{
                        options: recourseType,
                        placeholder: '请选择',
                    }}
                  />
                  <SelectField
                    form={form}
                    authority={authority}
                    name="financingType"
                    key="financingType"
                    formItemProps={{ label: '是否保理池融资' }}
                    fieldProps={{
                      // initialValue: ,
                      rules: [{ required: true, message: '请选择' }],
                    }}
                    inputProps={{
                      options: financingType,
                      placeholder: '请选择',
                    }}
                  />
                </div>
            }
            <InputNumberField
              form={form}
              authority={authority}
              name="timeLimit"
              formItemProps={{ label: '期限（月）' }}
              fieldProps={{
                  // initialValue: ,
                  rules: [
                      { required: true, message: '请输入期限' },
                  ],
              }}
              inputProps={{
                  placeholder: '请输入',
              }}
            />
            <InputNumberField
              form={form}
              authority={authority}
              name="cashDeposit"
              formItemProps={{ label: '保证金百分比' }}
              fieldProps={{
                // initialValue: "",
                rules: [
                    { required: true, message: '请输入保证金百分比' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
          </Row>
          <Row>
            <CheckboxField
              form={form}
              authority={authority}
              name="assureType"
              formItemProps={{ label: '担保类型' }}
              fieldProps={{
                onChange: this.checkboxChange,
                initialValue: assureTypeArr,
                rules: [{ required: false }],
              }}
              inputProps={{ options: assureType }}
            />
          </Row>
          {
              assureTypeArr.indexOf(1) > -1 && <AssureTypeCard type="1" />
          }
          {
            assureTypeArr.indexOf(2) > -1  && <AssureTypeCard type="2" />
          }
          {
            assureTypeArr.indexOf(3) > -1  && <AssureTypeCard type="3" />
          }
          <Row>
            <RadioField
              form={form}
              authority={authority}
              name="reCompany"
              key="reCompany"
              formItemProps={{ label: '是否有领用企业' }}
              fieldProps={{
                  initialValue: reCompany,
                  onChange: this.onChange,
              }}
              inputProps={{ options: company }}
            />
            {
                reCompany == '0' &&
                <Button
                  className="reCompanyBtn"
                  type="dashed"
                  size="small"
                  icon="search"
                  onClick={this.add}
                >
                  增加领用企业
                </Button>
            }
          </Row>
          {
              reCompany == '1' &&
              <InputField
                form={form}
                authority={authority}
                name="LineCredit"
                formItemProps={{ label: '分配授信额度' }}
                fieldProps={{
                  rules: [
                  ],
                }}
                inputProps={{
                  placeholder: '请输入',
                }}
              />
          }
          {
              reCompany == '0' && mapReCompany
          }
        </Form>
      </Card>
      
    )
  }
}

export default wrapFormContainer('businessCreditCard', '', { })(BusinessCreditCard)

