import React, { Component } from 'react'
import classNames from 'classnames'
import Animate from 'rc-animate'
import Icon from 'lbc-wrapper/lib/icon'
import Tooltip from 'lbc-wrapper/lib/tooltip'
import Progress from 'lbc-wrapper/lib/progress'
import Button from 'lbc-wrapper/lib/button'
import Checkbox from 'lbc-wrapper/lib/simpleCheckbox'
import { APP_HOST_NAME } from 'utils/consts'
import calPermission, { PERMISSIONS } from '../utils/calPermission'
import axios from 'axios'
import {buildData} from 'middleware/ajax'
import './UploadList.scss'
import thumb_doc from './images/ico_attachment_doc.png'
import thumb_jpg from './images/ico_attachment_jpg.png'
import thumb_pdf from './images/ico_attachment_pdf.png'
import thumb_png from './images/ico_attachment_png.png'
import thumb_txt from './images/ico_attachment_txt.png'
import thumb_xls from './images/ico_attachment_doc.png'

// https://developer.mozilla.org/en-US/docs/Web/API/FileReader/readAsDataURL
const previewFile = (file, callback) => {
  const reader = new FileReader()
  reader.onloadend = () => callback(reader.result)
  reader.readAsDataURL(file)
}

const extname = (url) => {
  if (!url) {
    return ''
  }
  const temp = url.split('/')
  const filename = temp[temp.length - 1]
  const filenameWithoutSuffix = filename.split(/\#|\?/)[0]
  return (/\.[^./\\]*$/.exec(filenameWithoutSuffix) || [''])[0]
}

const isImageUrl = (url) => {
  const extension = extname(url)
  if (/^data:image\//.test(url) || /(webp|svg|png|gif|jpg|jpeg|bmp)$/.test(extension)) {
    return true
  } else if (/^data:/.test(url)) {
    // other file types of base64
    return false
  } else if (extension) {
    // other file types which have extension
    return false
  }
  return true
}

class UploadList extends Component {
  constructor(props) {
    super(props)

    this.handleCheckFile = this.handleCheckFile.bind(this)
    this.saveDownNode = this.saveDownNode.bind(this)
    this.downloadFiles = this.downloadFiles.bind(this)
    this.removeFiles = this.removeFiles.bind(this)
    this.downloadNodes = {}
    this.state = {
      checkfiles: {},
    }
  }
  downloadFiles(e) {
    const { checkfiles } = this.state
    for (const k in checkfiles) {
      this.downloadFile(checkfiles[k])
    }
  }
  removeFiles(e) {
    const { checkfiles } = this.state
    for (const k in checkfiles) {
      this.handleRemove(checkfiles[k])
    }
  }
  handleRemove(file) {
    const { onRemove } = this.props
    const { checkfiles } = this.state
    if (onRemove) {
      onRemove(file)
      if (checkfiles.hasOwnProperty(file.uid)) {
        delete checkfiles[file.uid]
        this.setState({ checkfiles })
      }
    }
  }

  handlePreview(file, e) {
    const { onPreview } = this.props
    if (!onPreview) {
      return
    }
    e.preventDefault()
    return onPreview(file)
  }

  handleCheckFile(file, e) {
    const { checked } = e.target
    let { checkfiles } = this.state
    if (checked) {
      checkfiles = Object.assign(checkfiles, { [file.uid]: file })
    } else {
      delete checkfiles[file.uid]
    }
    this.setState({ checkfiles })
  }

  componentDidUpdate() {
    if (this.props.listType !== 'picture' && this.props.listType !== 'picture-card') {
      return
    }
    (this.props.items || []).forEach((file) => {
      if (
        typeof document === 'undefined' ||
        typeof window === 'undefined' ||
        !window.FileReader ||
        !window.File ||
        !(file.originFileObj instanceof File) ||
        file.thumbUrl !== undefined
      ) {
        return
      }
      /*eslint-disable */
      file.thumbUrl = ''
      /* eslint-enable */
      previewFile(file.originFileObj, (previewDataUrl) => {
        /*eslint-disable */
        file.thumbUrl = previewDataUrl
        /* eslint-enable */
        this.forceUpdate()
      })
    })
  }

  saveDownNode(node, file) {
    this.downloadNodes[file.uid] = node
  }

  downloadFile(file) {
    if (!file.response) return

    const downloadurl = `${APP_HOST_NAME}/los/vfc-intf-ent-doccenter.downloadDoc`
    const { docName, fssReadKey, docFormat } = file.response.model

    axios({
      method: 'post',
      url: downloadurl,
      data: buildData({ fileName: docName, fssReadKey, format: docFormat }, sessionStorage._k, true),
      responseType: 'blob',
    }).then((response) => {
      const eleLink = document.createElement('a')
      eleLink.style.display = 'none'
      eleLink.download = decodeURIComponent(docName)
      eleLink.href = URL.createObjectURL(response.data)
      document.body.appendChild(eleLink)
      eleLink.click()
      document.body.removeChild(eleLink)
    })
  }

  render() {
    const {
      authority,
      prefixCls,
      items = [],
      listType,
      showPreviewIcon,
      showRemoveIcon,
      showDowloadIcon,
      showCheckBoxIcon,
      locale,
      uploadButton,
    } = this.props

    const permis = calPermission(authority)

    const list = items.map((file) => {
      let progress
      let icon = <Icon type={file.status === 'uploading' ? 'loading' : 'paper-clip'} />

      if (listType === 'picture' || listType === 'picture-card') {
        if (listType === 'picture-card' && file.status === 'uploading') {
          icon = <div className={`${prefixCls}-list-item-uploading-text`}>上传中...</div>
        } else {
          const $extname = extname(file.name)
          icon = <Icon type="file" className={`${prefixCls}-list-item-icon`} />
          console.log(this.props)
          const {reqData} = buildData({fssReadKey: file.response.model.fssReadKey, fomat: file.response.model.docFormat}, sessionStorage._k, true)
          const getDownloadurl = () => (`${APP_HOST_NAME}/los/vfc-intf-ent-doccenter.downloadDoc?reqData=${
            encodeURIComponent(reqData)
          }`)
          const getIcon = thumb_icon => (<img className={`${prefixCls}-list-item-thumbnail`} src={thumb_icon} alt={file.name} />)
          if (['.doc', '.docx'].some(i => i === $extname)) {
            icon = getIcon(thumb_doc)
          }
          if (['.xls', '.xlsx'].some(i => i === $extname)) {
            icon = getIcon(thumb_xls)
          }
          if (['.jpg', '.jpeg'].some(i => i === $extname)) {
            icon = getIcon(file.response ? getDownloadurl() : thumb_jpg)
          }
          if ($extname === '.png') {
            icon = getIcon(file.response ? getDownloadurl() : thumb_png)
          }
          if ($extname === '.pdf') {
            icon = getIcon(thumb_pdf)
          }
          if ($extname === '.txt') {
            icon = getIcon(thumb_txt)
          }
        }
      }

      // if (listType === 'picture' || listType === 'picture-card') {
      //   if (listType === 'picture-card' && file.status === 'uploading') {
      //     icon = <div className={`${prefixCls}-list-item-uploading-text`}>{locale.uploading}</div>
      //   } else if (!file.thumbUrl && !file.url) {
      //     icon = <Icon className={`${prefixCls}-list-item-thumbnail`} type="picture" />
      //   } else {
      //     const thumbnail = isImageUrl(file.thumbUrl || file.url) ? (
      //       <img src={file.thumbUrl || file.url} alt={file.name} />
      //     ) : (
      //       <Icon type="file" className={`${prefixCls}-list-item-icon`} />
      //     )
      //     icon = (
      //       <a
      //         className={`${prefixCls}-list-item-thumbnail`}
      //         onClick={e => this.handlePreview(file, e)}
      //         href={file.url || file.thumbUrl}
      //         target="_blank"
      //         rel="noopener noreferrer"
      //       >
      //         {thumbnail}
      //       </a>
      //     )
      //   }
      // }

      if (file.status === 'uploading') {
        // show loading icon if upload progress listener is disabled
        const loadingProgress =
          'percent' in file ? <Progress type="line" {...this.props.progressAttr} percent={file.percent} /> : null

        progress = (
          <div className={`${prefixCls}-list-item-progress vfc-fileupload-progress`} key="progress">
            {loadingProgress}
          </div>
        )
      }
      const infoUploadingClass = classNames({
        [`${prefixCls}-list-item`]: true,
        [`${prefixCls}-list-item-${file.status}`]: true,
      })
      const preview = file.url ? (
        <a
          {...file.linkProps}
          href={file.url}
          target="_blank"
          rel="noopener noreferrer"
          className={`${prefixCls}-list-item-name`}
          onClick={e => this.handlePreview(file, e)}
          title={file.name}
        >
          {file.name}
        </a>
      ) : (
        <span className={`${prefixCls}-list-item-name`} onClick={e => this.handlePreview(file, e)} title={file.name}>
          {file.name}
        </span>
      )
      const style: React.CSSProperties = {
        pointerEvents: 'none',
        opacity: 0.5,
      }
      const previewIcon = showPreviewIcon ? (
        <a
          href={file.url || file.thumbUrl}
          target="_blank"
          rel="noopener noreferrer"
          style={file.url || file.thumbUrl ? undefined : style}
          onClick={e => this.handlePreview(file, e)}
          title={locale.previewFile}
          className="action-preview-eye"
        >
          <Icon type="eye-o" />
        </a>
      ) : null
      const removeIcon = showRemoveIcon ? (
        <Icon type="delete" title={locale.removeFile} onClick={() => this.handleRemove(file)} className="action-delete" />
      ) : null
      const removeIconCross = showRemoveIcon ? (
        <Icon type="cross" title={locale.removeFile} onClick={() => this.handleRemove(file)} />
      ) : null
      const downloadIcon = showDowloadIcon ? (
        <a onClick={this.downloadFile.bind(this, file)} ref={node => this.saveDownNode(node, file)}>
          <Icon type="download" title="Download file" className="action-download" />
        </a>
      ) : null
      const CheckBoxIcon = showCheckBoxIcon ? (
        <Checkbox onChange={e => this.handleCheckFile(file, e)} className="action-checkbox" />
      ) : null
      const actions =
        listType === 'picture-card' && file.status !== 'uploading' ? (
          <span className={`${prefixCls}-list-item-actions`}>
            {CheckBoxIcon}
            {permis === PERMISSIONS.MODIFY && removeIcon}
            {(file.type.indexOf('image/') === 0 || file.type === 'application/pdf') && previewIcon}
            {downloadIcon}
          </span>
        ) : (
          removeIconCross
        )
      let message
      if (file.response && typeof file.response === 'string') {
        message = file.response
      } else {
        message = (file.error && file.error.statusText) || locale.uploadError
      }
      const iconAndPreview =
        file.status === 'error' ? (
          <Tooltip title={message}>
            {icon}
            {preview}
          </Tooltip>
        ) : (
          <span>
            {icon}
            {preview}
          </span>
        )

      return (
        <div className={infoUploadingClass} key={file.uid}>
          <div className={`${prefixCls}-list-item-info`}>{iconAndPreview}</div>
          {actions}
          <span className="upload-alt">{file.response && decodeURIComponent(file.response.model.docName)}</span>
          <span className="upload-desc">{file.response && file.response.model.docUploaderName}</span>
          <span className="upload-desc">{file.response && file.response.model.docUploadTime}</span>
          <Animate transitionName="fade" component="">
            {progress}
          </Animate>
        </div>
      )
    })
    const listClassNames = classNames({
      [`${prefixCls}-list`]: true,
      [`${prefixCls}-list-${listType}`]: true,
    })
    const animationDirection = listType === 'picture-card' ? 'animate-inline' : 'animate'

    if (listType === 'picture-card') {
      return (
        <div>
          <div className="fileuploadcard-btn-group">
            <Button type="primary" size="small" ghost onClick={this.downloadFiles}>
              批量下载
            </Button>&nbsp;
            {permis === PERMISSIONS.MODIFY && (
              <Button type="primary" size="small" ghost onClick={this.removeFiles}>
                批量删除
              </Button>
            )}
          </div>
          <div className={listClassNames}>
            {permis === PERMISSIONS.MODIFY && uploadButton}
            {list}
          </div>
        </div>
      )
    }

    return (
      <Animate transitionName={`${prefixCls}-${animationDirection}`} component="div" className={listClassNames}>
        {list}
      </Animate>
    )
  }
}

UploadList.defaultProps = {
  listType: 'text',
  progressAttr: {
    strokeWidth: 2,
    showInfo: false,
  },
  prefixCls: 'ant-upload',
  showRemoveIcon: true,
  showPreviewIcon: true,
  showDowloadIcon: true,
  showCheckBoxIcon: true,
}

export default UploadList
