import React, { Component } from 'react'
import PropTypes from 'prop-types'
import classNames from 'classnames'
import RcUpload from 'rc-upload'
import uniqBy from 'lodash/uniqBy'
import {defaultLocale, LocaleReceiver} from 'lbc-wrapper/lib/localeProvider'
import {utils} from 'lbc-wrapper/lib/upload'
import UploadList from './UploadList'
import notification from 'lbc-wrapper/lib/notification'
import './Upload.scss'

const { T, fileToObject, genPercentAdd, getFileItem, removeFileItem } = utils

class Upload extends Component {
  constructor(props) {
    super(props)

    this.state = {
      fileList: props.fileList || props.defaultFileList || [],
      dragState: 'drop',
    }

    this.renderUploadList = this.renderUploadList.bind(this)
    this.saveUpload = this.saveUpload.bind(this)
    this.beforeUpload = this.beforeUpload.bind(this)
    this.onStart = this.onStart.bind(this)
    this.autoUpdateProgress = this.autoUpdateProgress.bind(this)
    this.onSuccess = this.onSuccess.bind(this)
    this.onProgress = this.onProgress.bind(this)
    this.onError = this.onError.bind(this)
    this.handleRemove = this.handleRemove.bind(this)
    this.handleManualRemove = this.handleManualRemove.bind(this)
    this.onChange = this.onChange.bind(this)
    this.onFileDrop = this.onFileDrop.bind(this)
    this.clearProgressTimer = this.clearProgressTimer.bind(this)
  }

  componentWillUnmount() {
    this.clearProgressTimer()
  }

  onStart(file) {
    let targetItem
    const nextFileList = this.state.fileList.concat()
    targetItem = fileToObject(file)
    targetItem.status = 'uploading'
    nextFileList.push(targetItem)
    this.onChange({
      file: targetItem,
      fileList: nextFileList,
    })
    // fix ie progress
    if (!window.FormData) {
      this.autoUpdateProgress(0, targetItem)
    }
  }

  autoUpdateProgress(_, file) {
    const getPercent = genPercentAdd()
    let curPercent = 0
    this.clearProgressTimer()
    this.progressTimer = setInterval(() => {
      curPercent = getPercent(curPercent)
      this.onProgress(
        {
          percent: curPercent * 100,
        },
        file,
      )
    }, 200)
  }

  onSuccess(response, file) {
    this.clearProgressTimer()
    try {
      if (typeof response === 'string') {
        response = JSON.parse(response)
      }
    } catch (e) {
      /* do nothing */
    }
    if (response.responseCode !== '000000') {
      this.onError(response.responseMsg, response, file)
      return
    }
    const fileList = this.state.fileList
    const targetItem = getFileItem(file, fileList)
    // removed
    if (!targetItem) {
      return
    }
    targetItem.status = 'done'
    targetItem.response = response
    this.onChange({
      file: { ...targetItem },
      fileList,
    })
  }

  onProgress(e, file) {
    const fileList = this.state.fileList
    const targetItem = getFileItem(file, fileList)
    // removed
    if (!targetItem) {
      return
    }
    targetItem.percent = e.percent
    this.onChange({
      event: e,
      file: { ...targetItem },
      fileList: this.state.fileList,
    })
  }

  onError(error, response, file) {
    this.clearProgressTimer()
    const fileList = this.state.fileList
    const targetItem = getFileItem(file, fileList)
    // removed
    if (!targetItem) {
      return
    }
    // targetItem.error = error
    // targetItem.response = response
    // targetItem.status = 'error'
    // this.onChange({
    //   file: { ...targetItem },
    //   fileList,
    // })
    this.handleManualRemove(file)
    notification.error({
      message: response.responseCode,
      description: response.responseMsg,
    })
  }

  handleRemove(file) {
    const { onRemove } = this.props

    Promise.resolve(typeof onRemove === 'function' ? onRemove(file) : onRemove).then((ret) => {
      // Prevent removing file
      if (ret === false) {
        return
      }

      const removedFileList = removeFileItem(file, this.state.fileList)
      if (removedFileList) {
        this.onChange({
          file,
          fileList: removedFileList,
        })
      }
    })
  }

  handleManualRemove(file) {
    this.upload.abort(file)
		file.status = 'removed' // eslint-disable-line
    this.handleRemove(file)
  }

  onChange(info) {
    if (!('fileList' in this.props)) {
      this.setState({ fileList: info.fileList })
    }

    const { onChange } = this.props
    if (onChange) {
      onChange(info)
    }
  }

  componentWillReceiveProps(nextProps) {
    if ('fileList' in nextProps) {
      this.setState({
        fileList: nextProps.fileList || [],
      })
    }
  }

  onFileDrop(e) {
    this.setState({
      dragState: e.type,
    })
  }

  beforeUpload(file, fileList) {
    if (!this.props.beforeUpload) {
      return true
    }
    const result = this.props.beforeUpload(file, fileList)
    if (result === false) {
      this.onChange({
        file,
        fileList: uniqBy(this.state.fileList.concat(fileList.map(fileToObject)), (item: UploadFile) => item.uid),
      })
      return false
    } else if (result && result.then) {
      return result
    }
    return true
  }

  clearProgressTimer() {
    clearInterval(this.progressTimer)
  }

  saveUpload(node) {
    this.upload = node
  }

  renderUploadList(locale) {
    const { showUploadList, listType, onPreview, authority } = this.props
    const { showRemoveIcon, showPreviewIcon } = showUploadList
    return (
      <UploadList
        uploadButton={this.uploadButton}
        listType={listType}
        authority={authority}
        items={this.state.fileList}
        onPreview={onPreview}
        onRemove={this.handleManualRemove}
        showRemoveIcon={showRemoveIcon}
        showPreviewIcon={showPreviewIcon}
        locale={{ ...locale, ...this.props.locale }}
      />
    )
  }

  render() {
    const { prefixCls = '', className, showUploadList, listType, type, disabled, children } = this.props

    const rcUploadProps = {
      onStart: this.onStart,
      onError: this.onError,
      onProgress: this.onProgress,
      onSuccess: this.onSuccess,
      ...this.props,
      beforeUpload: this.beforeUpload,
    }

    const uploadList = showUploadList ? (
      <LocaleReceiver componentName="Upload" defaultLocale={defaultLocale.Upload}>
        {this.renderUploadList}
      </LocaleReceiver>
    ) : null

    if (type === 'drag') {
      const dragCls = classNames(prefixCls, {
        [`${prefixCls}-drag`]: true,
        [`${prefixCls}-drag-uploading`]: this.state.fileList.some(file => file.status === 'uploading'),
        [`${prefixCls}-drag-hover`]: this.state.dragState === 'dragover',
        [`${prefixCls}-disabled`]: disabled,
      })
      return (
        <span className={className}>
          <div className={dragCls} onDrop={this.onFileDrop} onDragOver={this.onFileDrop} onDragLeave={this.onFileDrop}>
            <RcUpload {...rcUploadProps} ref={this.saveUpload} className={`${prefixCls}-btn`}>
              <div className={`${prefixCls}-drag-container`}>{children}</div>
            </RcUpload>
          </div>
          {uploadList}
        </span>
      )
    }

    let uploadButtonCls = classNames(prefixCls, {
      [`${prefixCls}-select`]: true,
      [`${prefixCls}-select-${listType}`]: true,
      [`${prefixCls}-disabled`]: disabled,
    })

    if (listType === 'picture-card') {
      uploadButtonCls = classNames(prefixCls, {
        [`${prefixCls}-select-${listType}`]: true,
        [`${prefixCls}-disabled`]: disabled,
      })
    }

    const uploadButton = (
      <div className={uploadButtonCls} style={{ display: children ? '' : 'none' }}>
        <RcUpload {...rcUploadProps} ref={this.saveUpload} />
      </div>
    )

    if (listType === 'picture-card') {
      this.uploadButton = (
        <div className={`${prefixCls}-list-item`}>
          <div className={uploadButtonCls} style={{ display: children ? '' : 'none' }}>
            <RcUpload {...rcUploadProps} ref={this.saveUpload} />
          </div>
          <span className="upload-alt">支持.jpg .png .txt .doc docx .xls .pdf</span>
        </div>
      )
      return (
        <span className={className}>
          {uploadList}
        </span>
      )
    }

    return (
      <span className={className}>
        {uploadButton}
        {uploadList}
      </span>
    )
  }
}

Upload.defaultProps = {
  prefixCls: 'ant-upload',
  type: 'select',
  multiple: false,
  action: '',
  data: {},
  accept: '',
  beforeUpload: T,
  showUploadList: true,
  listType: 'text',
  className: '',
  disabled: false,
  supportServerRender: true,
}

export default Upload
