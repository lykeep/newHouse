import React, { Component } from 'react'
import PropTypes from 'prop-types'
import FileUploadTree from './FileUploadTree'
import Button from 'lbc-wrapper/lib/button'
import Modal from 'lbc-wrapper/lib/modal'


class FileUploadModal extends Component {
  constructor(props) {
    super(props)
    this.showModal = this.showModal.bind(this)
    this.handleCancel = this.handleCancel.bind(this)

    this.state = {
      visible: false,
    }
  }
  showModal() {
    this.setState({
      visible: true,
    })
  }
  handleCancel() {
    this.setState({
      visible: false,
    })
  }
  render() {
    const { authority, bizKey, processKey, operType, btnLabel } = this.props
    return (
      <div>
        <Button type="primary" onClick={this.showModal}>
					{btnLabel}
        </Button>
        <Modal visible={this.state.visible} onOk={this.handleCancel} onCancel={this.handleCancel} footer={null} width={1000}>
          <FileUploadTree authority={authority} bizKey={bizKey} applyFormId={processKey} operType={operType} />
        </Modal>
      </div>
    )
  }
}

FileUploadModal.propTypes = {
  authority: PropTypes.string.isRequired,
  bizKey: PropTypes.string.isRequired,
  processKey: PropTypes.string,
  operType: PropTypes.string.isRequired,
}

FileUploadModal.defaultProps = {
  btnLabel: '附件上传',
}

export default FileUploadModal
