import React, { Component } from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import PropTypes from 'prop-types'
import Row from 'lbc-wrapper/lib/row'
import Col from 'lbc-wrapper/lib/col'
import Card from 'lbc-wrapper/lib/card'
import Badge from 'lbc-wrapper/lib/badge'
import Tree, { TreeNode, DirectoryTree } from 'lbc-wrapper/lib/tree'
import FileUploadCard from './FileUploadCard'
import { getFullContent, getDocTree } from './UploadModule'

class FileuploadTree extends Component {
  constructor(props) {
    super(props)

    this.state = {
      rootTreeNodes: [],
      uploadContents: [],
    }
  }

  onSelect(selectedKeys, info) {
    this.setState({
      uploadContents: this.state.uploadContents.map(child =>
        React.cloneElement(child, { isshow: selectedKeys[0] === child.props.typeid })),
    })
  }

  componentDidMount() {
    const { bizKey, applyFormId, operType, authority } = this.props
    const uploadContents = []
    this.props.getDocTree({ applyFormId, bizId: bizKey, operType }).then((res) => {
      res.docClassInfoList.forEach((i, ik) => {
        i.docSubClassInfoList.forEach((j, jk) => {
          uploadContents.push(React.createElement(FileUploadCard, {
            key: `${ik}-${jk}`,
            name: 'docFileMap',
            typeid: j.docRelId,
            bizKey,
            applyFormId,
            authority,
            operType,
            isshow: false,
            fileList: j.docPhyInfoList,
          }))
        })
      })
      this.setState({ rootTreeNodes: res.docClassInfoList, uploadContents })
    })
  }

  render() {
    const { rootTreeNodes, uploadContents } = this.state
    const { title } = this.props
    return (
      <Card title={title} style={{ marginBottom: '16px' }} bordered={false}>
        <Row gutter={16}>
          <Col span={6}>
            <DirectoryTree defaultExpandAll onSelect={this.onSelect.bind(this)}>
              {rootTreeNodes.map(node => (
                <TreeNode
                  title={
                    <Badge
                      dot={
                        node.docSubClassInfoList &&
                        node.docSubClassInfoList.some(s => s.docPhyInfoList && s.docPhyInfoList.length > 0)
                      }
                      style={{ backgroundColor: '#2C648E' }}
                    >
                      {node.docClassName}
                    </Badge>
                  }
                  key={node.docClassId}
                >
                  {node.docSubClassInfoList &&
                    node.docSubClassInfoList.map(subnode => (
                      <Tree.TreeNode
                        title={
                          <Badge
                            dot={subnode.docPhyInfoList && subnode.docPhyInfoList.length > 0}
                            style={{ backgroundColor: '#2C648E' }}
                          >
                            {subnode.docSubClassName}
                          </Badge>
                        }
                        key={subnode.docRelId}
                        isLeaf
                      />
                    ))}
                </TreeNode>
              ))}
            </DirectoryTree>
          </Col>
          <Col span={18}>{uploadContents}</Col>
        </Row>
      </Card>
    )
  }
}

FileuploadTree.defaultProps = {
  title: '附件文档',
}

FileuploadTree.propTypes = {
  getDocTree: PropTypes.func.isRequired,
  authority: PropTypes.string.isRequired,
  bizKey: PropTypes.string.isRequired,
  applyFormId: PropTypes.string,
  operType: PropTypes.string.isRequired,
  title: PropTypes.string,
}

export default withRouter(connect(state => ({ core: state.core }), {
  getFullContent,
  getDocTree,
})(FileuploadTree))
