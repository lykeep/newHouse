import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import Row from 'lbc-wrapper/lib/row'
import Col from 'lbc-wrapper/lib/col'
import Icon from 'lbc-wrapper/lib/icon'
import FileUploadField from './FileUploadField'
import './FileUploadCard.scss'

class FileUploadCard extends PureComponent {
  render() {
    const { name, ColSpan, typeid, bizKey, applyFormId, authority, operType, isshow, fileList } = this.props
    return (
      <Col span={ColSpan} style={{ paddingLeft: '8px', paddingRight: '8px', display: isshow ? '' : 'none' }}>
        <Row gutter={16} type="flex" align="top">
          <Col span={24} className="clearfix">
            <FileUploadField name={name} listType="picture-card" fileList={fileList} typeid={typeid} bizKey={bizKey} applyFormId={applyFormId} authority={authority} operType={operType}>
              <div>
                <Icon type="plus" />
                <div className="ant-upload-text">上传附件</div>
              </div>
            </FileUploadField>
          </Col>
        </Row>
      </Col>
    )
  }
}

FileUploadCard.defaultProps = {
  ColSpan: 24,
}

FileUploadCard.propTypes = {
  name: PropTypes.string.isRequired,
  isshow: PropTypes.bool,
  ColSpan: PropTypes.number,
  typeid: PropTypes.string.isRequired,
  bizKey: PropTypes.string.isRequired,
  applyFormId: PropTypes.string,
  authority: PropTypes.string.isRequired,
  operType: PropTypes.string.isRequired,
  fileList: PropTypes.array,
}

export default FileUploadCard
