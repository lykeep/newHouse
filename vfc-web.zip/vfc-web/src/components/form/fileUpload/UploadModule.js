import { createReducer, createFetchAction } from 'modules/common'

const VFC_DOCCENTER_GET_FULL_CONTENT = 'VFC_DOCCENTER_GET_FULL_CONTENT'
const VFC_DOCCENTER_GET_DOC_TREE = 'VFC_DOCCENTER_GET_DOC_TREE'

export const getFullContent = createFetchAction(VFC_DOCCENTER_GET_FULL_CONTENT, 'vfc-intf-ent-doccenter.getFullContent')
export const getDocTree = createFetchAction(VFC_DOCCENTER_GET_DOC_TREE, 'vfc-intf-ent-doccenter.getDocTree')

const intialState = {
}

export default createReducer(intialState, {})
