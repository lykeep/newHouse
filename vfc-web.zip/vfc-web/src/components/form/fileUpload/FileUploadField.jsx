import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Col from 'lbc-wrapper/lib/col'
import Upload from './Upload'
// import Upload from 'lbc-wrapper/lib/upload'
import Button from 'lbc-wrapper/lib/button'
import Icon from 'lbc-wrapper/lib/icon'
import message from 'lbc-wrapper/lib/message'
import Modal from 'lbc-wrapper/lib/modal'
import { colSpan } from '../inputs/consts'
import { APP_HOST_NAME } from 'utils/consts'
import axios from 'axios'
import { buildData } from 'middleware/ajax'
import './FileUploadField.scss'

const props = {
  multiple: true,
  onChange(info) {
    if (info.file.status === 'done') {
      message.success(`${info.file.name} 文件上传成功`)
    } else if (info.file.status === 'error') {
      message.error(`${info.file.name} 文件上传失败`)
    }
  },
}

class FileUploadField extends Component {
  constructor(props) {
    super(props)

    this.state = {
      previewVisible: false,
      previewImage: '',
      previewWidth: 520,
      previewRotate: 0,
    }
  }
  handlePreview(file) {
    if (!file.response) return

    const downloadurl = `${APP_HOST_NAME}/los/vfc-intf-ent-doccenter.downloadDoc`
    const { docName, fssReadKey, docFormat } = file.response.model

    const { reqData } = buildData({ fileName: docName, fssReadKey, format: docFormat }, sessionStorage._k, true)

    if (file.type === 'application/pdf') {
      window.open(`${downloadurl}?reqData=${encodeURIComponent(reqData)}&inline=true`)
    }
    if (file.type.indexOf('image/') === 0) {
      this.setState({
        previewImage: `${downloadurl}?reqData=${encodeURIComponent(reqData)}`,
        previewVisible: true,
      })
    }
  }
  handleCancel() {
    this.setState({ previewVisible: false })
  }
  handleRemove(file) {
    if (!file.response) return
    const { docPhyId, docName } = file.response.model
    const { bizKey, applyFormId, operType } = this.props
    axios({
      method: 'post',
      url: `${APP_HOST_NAME}/los/vfc-intf-ent-doccenter.deleteDoc`,
      data: buildData({ bizKey, applyFormId, operType, docPhyId }, sessionStorage._k, true),
    }).then(response => {
      const { data } = response
      if (data.responseCode === '000000') {
        message.success(`${docName} 文件删除成功`)
      }
    })
  }
  imgRotate() {
    this.setState({ previewRotate: this.state.previewRotate + 90 })
  }
  imgBigger() {
    this.setState({ previewWidth: this.state.previewWidth + 120 })
  }
  imgSmaller() {
    if ((this.state.previewWidth - 120) <= 48) {
      return
    }
    this.setState({ previewWidth: this.state.previewWidth - 120 })
  }
  previewReset() {
    this.setState({ previewWidth: 520, previewRotate: 0 })
  }
  render() {
    const { name, typeid, listType, action, bizKey, applyFormId, authority, operType, fileList } = this.props
    const { previewVisible, previewImage, previewRotate, previewWidth } = this.state
    const uploadButton = (
      <Button>
        <Icon type="upload" /> 上传
      </Button>
    )
    return (
      <div className="clearfix">
        <Upload
          name={name}
          authority={authority}
          action={action}
          listType={listType}
          defaultFileList={fileList.map(model => ({
            status: 'done',
            response: { model },
            type: model.docFormat,
            name: model.docName,
            uid: model.fssReadKey,
            thumbUrl: model.fssReadKey,
          }))}
          data={file => ({
            applyFormId,
            bizId: bizKey,
            operType,
            docFormat: file.type || 'application/octet-stream',
            docName: encodeURIComponent(file.name),
            docRelId: typeid,
          })}
          onPreview={this.handlePreview.bind(this)}
          onRemove={this.handleRemove.bind(this)}
          {...props}
        >
          {this.props.children || uploadButton}
        </Upload>
        <Modal
          visible={previewVisible}
          closable={false}
          className="lb-fileuploadfield_preview"
          width={previewWidth}
          afterClose={this.previewReset.bind(this)}
          onCancel={this.handleCancel.bind(this)}
          footer={null}
        >
          <img alt="preview" style={{ width: '100%', transform: `rotate(${previewRotate}deg)` }} src={previewImage} />
          <div className="lb-fileuploadfield_control">
            <Button size="small" onClick={this.imgRotate.bind(this)} icon="reload" ghost >
              旋转
            </Button>
            &nbsp;
            <Button size="small" onClick={this.imgBigger.bind(this)} icon="plus" ghost >
              放大
            </Button>
            &nbsp;
            <Button size="small" onClick={this.imgSmaller.bind(this)} icon="minus" ghost >
              缩小
            </Button>
            &nbsp;
            <Button size="small" onClick={this.previewReset.bind(this)} icon="retweet" ghost >
              复位
            </Button>
          </div>
        </Modal>
      </div>
    )
  }
}

FileUploadField.defaultProps = {
  ColSpan: colSpan,
  action: `${APP_HOST_NAME}/los/vfc-intf-ent-doccenter.uploadDoc`,
  fileList: [],
}

FileUploadField.propTypes = {
  action: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  fieldProps: PropTypes.object,
  inputProps: PropTypes.object,
  ColSpan: PropTypes.number,
  listType: PropTypes.string,
  typeid: PropTypes.string.isRequired,
  bizKey: PropTypes.string.isRequired,
  applyFormId: PropTypes.string,
  authority: PropTypes.string.isRequired,
  operType: PropTypes.string.isRequired,
  fileList: PropTypes.array,
}

export default FileUploadField
