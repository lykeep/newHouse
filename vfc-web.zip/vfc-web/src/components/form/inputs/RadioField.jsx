import PropTypes from 'prop-types'
import React, { Component } from 'react'
import Radio from 'lbc-wrapper/lib/radio'
import Col from 'lbc-wrapper/lib/col'
import _debug from 'lb-debug'

import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import calPermission, { PERMISSIONS } from '../utils/calPermission'
import { colSpan as defaultColSpan } from './consts'
import ReadOptionsValue from './readComp/ReadOptionsValue'

import './inputs.scss'

const debug = _debug('vfc:RadioField')

const RadioGroup = Radio.Group

class RadioField extends Component {
  constructor(props) {
    super(props)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
  }

  renderNormal() {
    const { form, name, formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan, authority, style } = this.props

    const { getFieldDecorator } = form

    return (
      <Col span={colSpan} style={style} className="lb-col-gutter">
        <SimpleFormItem {...formItemProps} authority={authority}>
          {
            getFieldDecorator(name, fieldProps)(<RadioGroup {...inputProps} />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  renderRead() {
    const { formItemProps = {}, inputProps = {}, colSpan, form, name, authority, fieldProps = {} } = this.props

    const { getFieldDecorator } = form

    return (
      <Col span={colSpan} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps} authority={authority}>
          {
            getFieldDecorator(name, { initialValue: fieldProps.initialValue })(<ReadOptionsValue options={inputProps.options} keyName="label" />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  render() {
    debug('render')
    const permis = calPermission(this.props.authority)

    if (!this.props.show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }
}

RadioField.defaultProps = {
  colSpan: defaultColSpan,
  show: true,
}

RadioField.propTypes = {
  form: PropTypes.shape({
    getFieldDecorator: PropTypes.func.isRequired,
  }).isRequired,
  name: PropTypes.string.isRequired,
  fieldProps: PropTypes.shape({
    // initialValue: PropTypes.string,
  }),
  formItemProps: PropTypes.object.isRequired,
  inputProps: PropTypes.shape({
    options: PropTypes.array.isRequired,
  }),
  colSpan: PropTypes.oneOfType([
    PropTypes.number.isRequired,
    PropTypes.object.isRequired,
  ]),
  authority: PropTypes.string.isRequired,
  style: PropTypes.object,
  show: PropTypes.bool,
}

export default RadioField
