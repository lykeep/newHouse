import * as React from 'react'
import Form, { SimpleFormItem } from 'lbc-wrapper/lib/form'
import DatePicker, { DatePickerProps } from 'lbc-wrapper/lib/datePicker'
import Input from 'lbc-wrapper/lib/input'
import Col from 'lbc-wrapper/lib/col'
import moment from 'moment'
import _debug from 'lb-debug'

import calPermission, { PERMISSIONS } from '../utils/calPermission'
import { colSpan as defaultColSpan } from './consts'
import ReadSimpleValue from './readComp/ReadSimpleValue'
import { BaseInputProps } from './BaseInputProps'

import './inputs.scss'

const debug = _debug('vfc:DatePickerField')

export interface DatePickerFieldProps extends BaseInputProps {
  inputProps: DatePickerProps
}

class DatePickerField extends React.Component<DatePickerFieldProps> {
  public static defaultProps = {
    colSpan: defaultColSpan,
    inputProps: {},
    show: true,
  }

  constructor(props: DatePickerFieldProps) {
    super(props)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
    this.onDateChange = this.onDateChange.bind(this)
  }

  public onDateChange(value: moment.Moment, dateString: string) {
    const { form, name, inputProps } = this.props
    const { setFieldsValue } = form

    const { onChange } = inputProps
    setFieldsValue({
      [name]: dateString,
    })

    if (onChange) {
      onChange(value, dateString)
    }
  }

  public renderNormal() {
    const { form, name, formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan } = this.props

    const { getFieldDecorator, getFieldValue } = form
    return (
      <Col span={colSpan} style={this.props.style} className="lb-col-gutter">
        <Form.Item {...formItemProps}>
          {
            getFieldDecorator(name, fieldProps)(<Input type="hidden" />)
          }
          <DatePicker
            placeholder="请选择"
            {...inputProps}
            onChange={this.onDateChange}
            disabled={inputProps.disabled}
            defaultValue={!fieldProps.initialValue ? fieldProps.initialValue : moment(fieldProps.initialValue)}
            value={!getFieldValue(name) ? getFieldValue(name) : moment(getFieldValue(name))}
          />
        </Form.Item>
      </Col>
    )
  }

  public renderRead() {
    const { formItemProps = {}, colSpan, form, name, fieldProps } = this.props
    const { getFieldDecorator } = form
    return (
      <Col span={colSpan} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps}>
          {
            getFieldDecorator(name, { initialValue: fieldProps.initialValue })(<ReadSimpleValue />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  public render() {
    debug('render')
    const permis = calPermission(this.props.authority)

    if (!this.props.show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }
}

export default DatePickerField
