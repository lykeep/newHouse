import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import Input from 'lbc-wrapper/lib/input'
import Form, { SimpleFormItem } from 'lbc-wrapper/lib/form'
import Col from 'lbc-wrapper/lib/col'
import Button from 'lbc-wrapper/lib/button'
import ReadSimpleValue from '../readComp/ReadSimpleValue'

import BankNameSelectorModal from './BankNameSelectorModal'

import calPermission, { PERMISSIONS } from '../../utils/calPermission'
import { colSpan as defaultColSpan } from '../consts'

import ajaxActions from './BankNameModule'

const FormItem = Form.Item

class BankNameSelector extends Component {
  static propTypes = {
    form: PropTypes.object.isRequired,
    formItemLayout: PropTypes.object,
    bankInfoCallback: PropTypes.func,
  }

  constructor() {
    super()

    this.state = {
      show: false,
    }
    this.onSearchHandler = this.onSearchHandler.bind(this)
    this.selectBankHandler = this.selectBankHandler.bind(this)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
    this.onClose = this.onClose.bind(this)
  }

  onSearchHandler() {
    this.setState({
      show: true,
    })
  }

  onClose() {
    this.setState({
      show: false,
    })
  }

  selectBankHandler(data) {
    this.props.form.setFieldsValue({
      [this.props.name[0]]: data.bankName,
      [this.props.name[1]]: data.bankNo,
      [this.props.name[2]]: data.innerBankNo,
    })
    this.setState({
      show: false,
    })
  }

  renderNormal() {
    const { form, name, formItemProps = {}, fieldProps = {}, colSpan, bankInfoCallback } = this.props
    const { getFieldDecorator } = form
    const { show } = this.state
    const inputAfter = (
      <Button type="primary" icon="search" size="small" onClick={this.onSearchHandler} />
    )

    return (
      <Col span={colSpan} style={this.props.style} className="lb-col-gutter">
        <FormItem {...formItemProps} >
          {
            getFieldDecorator(name[0], {
              ...fieldProps,
              initialValue: fieldProps.initialValue && fieldProps.initialValue[0],
            })(<Input readOnly addonAfter={inputAfter} />)
          }
        </FormItem>
        {
          name[1] ? getFieldDecorator(name[1], { initialValue: fieldProps.initialValue && fieldProps.initialValue[1] })(<Input type="hidden" />) : null
        }
        {
          name[2] ? getFieldDecorator(name[2], { initialValue: fieldProps.initialValue && fieldProps.initialValue[2] })(<Input type="hidden" />) : null
        }
        <BankNameSelectorModal
          onClose={this.onClose}
          bankSearchAction={bankInfoCallback}
          visible={show}
          onSelect={this.selectBankHandler}
        />
      </Col>
    )
  }

  renderRead() {
    const { formItemProps = {}, colSpan, form, name, authority, fieldProps } = this.props
    const { getFieldDecorator } = form

    return (
      <Col span={colSpan} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps} authority={authority}>
          {
            getFieldDecorator(name[0], { initialValue: fieldProps.initialValue && fieldProps.initialValue[0] })(<ReadSimpleValue />)
          }
        </SimpleFormItem>
        {
          name[1] ? getFieldDecorator(name[1], { initialValue: fieldProps.initialValue && fieldProps.initialValue[1] })(<Input type="hidden" />) : null
        }
        {
          name[2] ? getFieldDecorator(name[2], { initialValue: fieldProps.initialValue && fieldProps.initialValue[2] })(<Input type="hidden" />) : null
        }
      </Col>
    )
  }

  render() {
    const permis = calPermission(this.props.authority)

    if (!this.props.show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }
}

BankNameSelector.propTypes = {
  colSpan: PropTypes.number,
  show: PropTypes.bool,
}

BankNameSelector.defaultProps = {
  colSpan: defaultColSpan,
  show: true,
}


const mapStateToProps = () => ({})

export default connect(mapStateToProps, ajaxActions)(BankNameSelector)
