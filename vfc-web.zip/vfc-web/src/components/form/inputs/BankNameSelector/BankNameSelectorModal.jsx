import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Form, { SimpleFormItem } from 'lbc-wrapper/lib/form'
import Modal from 'lbc-wrapper/lib/modal'
import Button from 'lbc-wrapper/lib/button'
import Row from 'lbc-wrapper/lib/row'
import Col from 'lbc-wrapper/lib/col'
import Cascader from 'lbc-wrapper/lib/cascader'
import Input from 'lbc-wrapper/lib/input'

import { province } from './province'
import { banks } from './banks'

class BankNameSelectorModal extends Component {
  constructor(props) {
    super(props)

    this.onSearch = this.onSearch.bind(this)
    this.renderBankList = this.renderBankList.bind(this)

    this.state = {
      bankList: [],
    }
  }

  onSearch() {
    const { form, bankSearchAction } = this.props
    form.validateFields((error, values) => {
      if (error) {
        return
      }

      bankSearchAction({
        bankHQNo: values.bankInfo[1],
        currentPage: 1,
        keyword: values.keyWord,
        pageCount: 999,
        provinceCode: values.bankInfo[0],
      }).then((res) => {
        this.setState({
          bankList: res.bankInfoList,
        })
      })
    })
  }

  selectBankHandler(index) {
    this.props.onSelect(this.state.bankList[index])
  }

  renderBankList() {
    return (
      <div style={{ maxHeight: '500px', overflow: 'auto', margin: '5px' }}>
        {
          this.state.bankList.map((b, i) => {
            return (
              <p style={{ margin: '3px' }}>
                <a role="button" onClick={() => this.selectBankHandler(i)}>{`${b.bankNo}:${b.bankName}(${b.innerBankNo})`}</a>
              </p>
            )
          })
        }
      </div>
    )
  }

  render() {
    const { form, visible, onClose } = this.props
    const { getFieldDecorator } = form
    return (
      <Modal
        title="选择银行信息"
        closable={false}
        maskClosable={false}
        visible={visible}
        width={800}
        destroyOnClose

        footer={[<Button key="close" onClick={onClose}>关闭</Button>]}
      >
        <Form>
          <Row>
            <Col span={8}>
              <SimpleFormItem
                label="选择银行"
              >
                {
                  getFieldDecorator('bankInfo', {
                    rules: [
                      { required: true, message: '银行必须选择' },
                    ]
                  })(
                    <Cascader
                      style={{ width: '100%' }}
                      allowClear={false}
                      placeholder="请选择开户银行"
                      options={province.map((pro) => {
                        pro.children = banks
                        return pro
                      })}
                    />
                  )
                }
              </SimpleFormItem>
            </Col>
            <Col offset={1} span={8}>
              <SimpleFormItem label="关键字">
                {
                  getFieldDecorator('keyWord', {
                    rules: [
                      { required: true, message: '关键字必输' },
                    ]
                  })(<Input placeholder="关键字" onPressEnter={this.onSearch} />)
                }
              </SimpleFormItem>
            </Col>
            <Col offset={1} span={4}>
              <Button type="primary" onClick={this.onSearch} >查询</Button>
            </Col>
          </Row>
        </Form>
        {
          this.renderBankList()
        }

      </Modal>

    )
  }
}

BankNameSelectorModal.propTypes = {
  visible: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  onSelect: PropTypes.func.isRequired,
  bankSearchAction: PropTypes.func.isRequired,
  form: PropTypes.shape({
    getFieldDecorator: PropTypes.func,
  }),
}

export default Form.create()(BankNameSelectorModal)
