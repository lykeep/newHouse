import { createFetchAction } from '../../../../modules/common'

const COMMON_SELECT_BANK_NAME_QUERY_LIST = 'COMMON_SELECT_BANK_NAME_QUERY_LIST'
export const bankInfoCallback = createFetchAction(COMMON_SELECT_BANK_NAME_QUERY_LIST, 'vfc-intf-ent-base.bankInfoQry')

export default {
  bankInfoCallback,
}
