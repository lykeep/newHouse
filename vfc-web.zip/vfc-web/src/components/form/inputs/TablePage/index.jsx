import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Pagination from 'lbc-wrapper/lib/pagination'
import Table from 'lbc-wrapper/lib/table'
import './TablePage.scss'

class TablePage extends Component {
  constructor(props) {
    super(props)

    this.onChange = this.onChange.bind(this)
    this.onShowSizeChange = this.onShowSizeChange.bind(this)
    this.queryHandle = this.queryHandle.bind(this)

    this.state = {
      current: 1,
    }
  }
  componentDidMount() {
    const { pageSize = 10 } = this.props
    this.queryHandle(1, pageSize)
  }

  onChange(pageNumber, pageSize) {
    this.queryHandle(pageNumber, pageSize)
  }
  onShowSizeChange(current, pageSize) {
    this.queryHandle(current, pageSize)
  }

  queryHandle(current, pageSize) {
    const { query } = this.props
    this.setState({ current, selectedRowKeys: [] })
    if (query) {
      query({
        pageNo: current,
        recordsPerPage: pageSize,
      })
    }
  }
  render() {
    const { total, pageSizeOptions, pageSize, rowSelection, doPagination=true, className='', size='default',  ...props } = this.props
    const { current } = this.state
    return (
      <div>
        <Table
          className={className}
          size={size}
          position="left"
          rowKey="index"
          pagination={false}
          {...props}
        />
        {
          doPagination &&
          <div className="pagination-warp">
            <Pagination
              size="small"
              total={total}
              showTotal={total => `共 ${total} 条`}
              onChange={this.onChange}
              pageSize={pageSize || 10}
              current={current}
              onShowSizeChange={this.onShowSizeChange}
            />
          </div>
        }
      </div>
    )
  }
}

TablePage.propTypes = {
  query: PropTypes.func,
  total: PropTypes.number,
  pageSizeOptions: PropTypes.array,
}


export default TablePage
