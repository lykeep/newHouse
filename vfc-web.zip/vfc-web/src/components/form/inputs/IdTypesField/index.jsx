import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Col from 'lbc-wrapper/lib/col'
import Input from 'lbc-wrapper/lib/input'
import Select, { Option } from 'lbc-wrapper/lib/select'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import calPermission, { PERMISSIONS } from '../../utils/calPermission'
// import { validIdentityNum, passportValidator, jgzValidator, tbzValidator, hxzValidator } from '../../utils/validators'
import './IdTypesField.scss'
import { passportNum, passportMessage, validIdentityNum, validIdentityNumMessage, tbzNum, tbzMessage,
  hxzNum, hxzMessage, jgzMessage, jgzNum } from '../../../../validators/common'
import ReadIdTypesValue from './ReadIdTypesValue'

const idTypes = [
  {
    key: '00',
    name: '身份证',
    rule: validIdentityNum,
    message: validIdentityNumMessage,
  },
  {
    key: '01',
    name: '临时身份证',
    rule: validIdentityNum,
    message: validIdentityNumMessage,
  },
  {
    key: '02',
    name: '军官证',
  },
  {
    key: '03',
    name: '士兵证',
    rule: jgzNum,
    message: jgzMessage,
  },
  {
    key: '04',
    name: '警官证',
  },
  {
    key: '05',
    name: '普通护照',
    rule: passportNum,
    message: passportMessage,
  },
  {
    key: '06',
    name: '台湾同胞来往大陆通行证',
    rule: tbzNum,
    message: tbzMessage,

  },
  {
    key: '07',
    name: '港澳通报回乡证',
    rule: hxzNum,
    message: hxzMessage,
  },
  {
    key: '08',
    name: '外国人居留证',
  },
  {
    key: '09',
    name: '户口簿',
  },
  {
    key: '99',
    name: '其他',
  },
]


class IdTypeValidators extends Component {
  constructor(props) {
    super(props)
    this.state = {
    }
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
  }

  onChangeSelect = (e) => {
    const { form, name } = this.props
    // const idNumber = form.getFieldValue(name[1])
    this.setState({ idType: e }, () => {
      form.validateFields([name[1]], { force: true });
    })
  }

  // 根据不同证件类型验证 证件号
  validateCertificate = (rule, value, callback) => {
    // 如果idtypes没有对应的rule，则验证不为空
    const validate = () => {
      idTypes.forEach((item) => {
        if (!value) {
          return callback('请输入证件号码！')
        }
        if (item.key === idType) {
          if (item.rule) {
            const pattern = item.rule
            if (!pattern.test(value)) return callback(item.message)
          } else if (value.length < 2 || value.length > 32) {
            return callback('请输入长度2~32')
          }
        }
      })
    }
    // if (!(rule.required))
    const { form, name } = this.props
    const idType = form.getFieldValue(name[0])
    if (!(rule.required)) {
      if (this.state.idType && this.state.idType.length !== 0) {
        validate()
      } else {
        callback()
      }
    }
    if (!value) {
      return callback('请输入证件号码！')
    }
    validate()

    callback()
  }

  renderNormal = () => {
    const { form, name, colSpan, label, disabled, fieldProps = {}, show = true } = this.props
    const { getFieldDecorator } = form
    const initialValue = fieldProps.initialValue || {}
    const normal = (<Col span={colSpan} className="lb-col-gutter vfc-idTypes">
      <Col span={12}>
        <SimpleFormItem label={label[0]}>
          {
            getFieldDecorator(name[0], {
              initialValue: initialValue[name[0]],
              rules: [{
                required: this.props.required,
                message: '请选择证件类型！',
              }],
              onChange: e => this.onChangeSelect(e),
            })(<Select disabled={disabled} placeholder="请选择证件类型">
              {
                idTypes.map((item, index) => <Option key={index} value={item.key}>{item.name}</Option>)
              }
            </Select>)
          }
        </SimpleFormItem>
      </Col>
      <Col span={12} className="lb-col-gutter vfc-idTypes">
        <SimpleFormItem label={label[1]}>
          {
            getFieldDecorator(name[1], {
              initialValue: initialValue[name[1]],
              rules: [{
                required: this.props.required,
                validator: this.validateCertificate,
              },
            ],
              onChange: e => this.onChangeSelect(e),
            })(<Input disabled={disabled} placeholder="请输入证件号码" />)
          }
        </SimpleFormItem>
      </Col>
    </Col>
    )

    if (show) {
      return normal
    }
    return <div />
  }


  renderRead = () => {
    const { name, fieldProps = {}, colSpan, label, show = true, formItemProps, authority, form } = this.props
    const value = fieldProps.initialValue || {}
    const { getFieldDecorator } = form
    const read =
    (<Col span={colSpan}>
      <Col span={12} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps} label={label[0]} authority={authority}>
          {
            getFieldDecorator(name[0], { initialValue: value[name[0]] })(<ReadIdTypesValue type="idType" />)
          }
        </SimpleFormItem>
        {/* <SimpleFormItem label={label[0]}>
          <span>{idType.length != 0 ? idType[0].name : ''}</span>
        </SimpleFormItem> */}
      </Col>
      <Col span={12} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps} label={label[1]} authority={authority}>
          {
            getFieldDecorator(name[1], { initialValue: value[name[1]] })(<ReadIdTypesValue type="idNo" />)
          }
        </SimpleFormItem>
        {/* <SimpleFormItem label={label[1]}>
        <span>{value[name[1]]}</span>
      </SimpleFormItem> */}
      </Col>
    </Col>)

    if (show) return read
    return <div />
  }

  render() {
    const permis = calPermission(this.props.authority)
    if (!this.props.show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }
    // // HIDE
    return null
  }
}

IdTypeValidators.propTypes = {
  form: PropTypes.shape({
    getFieldDecorator: PropTypes.func.isRequired,
  }).isRequired,
  fieldProps: PropTypes.shape({
    initialValue: PropTypes.object,
    rules: PropTypes.array,
  }),
  name: PropTypes.array.isRequired,
  label: PropTypes.array.isRequired,
  colSpan: PropTypes.number.isRequired,
  authority: PropTypes.string.isRequired,
  disabled: PropTypes.bool,
  show: PropTypes.bool,
}

IdTypeValidators.defaultProps = {
  show: true,
}


export default IdTypeValidators
