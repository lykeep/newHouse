import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'

const idTypes = [
  {
    key: '00',
    name: '身份证',
  },
  {
    key: '01',
    name: '临时身份证',
  },
  {
    key: '02',
    name: '军官证',
  },
  {
    key: '03',
    name: '士兵证',
  },
  {
    key: '04',
    name: '警官证',
  },
  {
    key: '05',
    name: '普通护照',
  },
  {
    key: '06',
    name: '台湾同胞来往大陆通行证',
  },
  {
    key: '07',
    name: '港澳通报回乡证',
  },
  {
    key: '08',
    name: '外国人居留证',
  },
  {
    key: '09',
    name: '户口簿',
  },
  {
    key: '99',
    name: '其他',
  },
]

class ReadIdTypesValue extends PureComponent {
  render() {
    const { value = '', type } = this.props
    const idType = idTypes.filter(item => item.key === value)
    return (
      <span>
        { type === 'idType' && <span>{idType.length === 0 ? '' : idType[0].name}</span>}
        { type === 'idNo' && <span>{value}</span> }
      </span>
    )
  }
}

ReadIdTypesValue.propTypes = {
  value: PropTypes.string,
  type: PropTypes.string,
}

export default ReadIdTypesValue
