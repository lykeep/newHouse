import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Input from 'lbc-wrapper/lib/input'

class HiddenField extends Component {
  renderNormal() {
    return null
  }

  render() {
    const { form, name, fieldProps = {} } = this.props
    const { getFieldDecorator } = form

    return (
      getFieldDecorator(name, fieldProps)(<Input type="hidden" />)
    )
  }
}

HiddenField.propTypes = {
  form: PropTypes.shape({
    getFieldDecorator: PropTypes.func.isRequired,
  }).isRequired,
  name: PropTypes.string.isRequired,
  fieldProps: PropTypes.shape({
    initialValue: PropTypes.string,
    rules: PropTypes.array,
  }),
}

export default HiddenField
