import * as React from 'react'
import PropTypes from 'prop-types'
import Cascader, { CascaderPropsLB } from 'lbc-wrapper/lib/cascader'
import Input from 'lbc-wrapper/lib/input'
import Col from 'lbc-wrapper/lib/col'
import Form, { SimpleFormItem } from 'lbc-wrapper/lib/form'
import _debug from 'lb-debug'

import calPermission, { PERMISSIONS } from '../../utils/calPermission'
import { colSpan as defaultColSpan } from '../consts'
import ReadCascaderValue from '../readComp/ReadCascaderValue'
import { BaseInputProps } from '../BaseInputProps'
import { Omit, Partial } from '../../../../types/utils'
import '../inputs.scss'

const debug = _debug('vfc:CityField')

export interface CityFieldProps extends Omit<BaseInputProps, 'name'> {
  haveState?: boolean
  loader?: (params?: any) => Promise<any>
  inputProps: Partial<CascaderPropsLB>
  name: string[]
}

interface CityFieldState {
  options: any[]
}

class CityField extends React.Component<CityFieldProps, CityFieldState> {
  public static defaultProps = {
    colSpan: defaultColSpan,
    show: true,
  }

  public static propTypes = {
    form: PropTypes.shape({
      getFieldDecorator: PropTypes.func.isRequired,
    }).isRequired,
    name: PropTypes.array.isRequired,
    fieldProps: PropTypes.shape({
      initialValue: PropTypes.array,
      rules: PropTypes.array,
    }),
    formItemProps: PropTypes.shape({
      label: PropTypes.string,
    }),
    inputProps: PropTypes.object,
    colSpan: PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.object,
    ]),
    authority: PropTypes.string.isRequired,
    show: PropTypes.bool,
  }

  constructor(props: CityFieldProps) {
    super(props)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)

    this.onChange = this.onChange.bind(this)
    this.loadOptions = this.loadOptions.bind(this)

    this.state = {
      options: [],
    }
  }

  public componentDidMount() {
    this.loadOptions()
  }


  public onChange(value: string[]) {
    const { form, name } = this.props

    const { setFieldsValue } = form
    setFieldsValue({
      [name[0]]: value[0],
      [name[1]]: value[1],
      [name[2]]: value[2],
    })
  }

  public loader() {
    if (this.props.haveState) {
      return import('./cities')
    }

    return import('./cities.1')
  }

  public loadOptions() {
    const loader = this.props.loader || this.loader

    loader.call(this).then((options: any) => {
      debug(options)
      this.setState({
        options: options.default || options,
      })
    })
  }

  public renderNormal() {
    const { form, name, formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan } = this.props
    const { getFieldDecorator, getFieldValue } = form
    const initialValue = fieldProps.initialValue || []
    const rules = fieldProps.rules || []

    const values = name.map(n => getFieldValue(n))

    // values = values[0] ? values : initialValue


    return (
      <Col span={colSpan} style={this.props.style} className="lb-col-gutter">
        <Form.Item {...formItemProps}>
          <Cascader
            options={this.state.options}
            {...inputProps}
            onChange={this.onChange}
            // disabled={inputProps.disabled}
            value={values}
            defaultValue={initialValue}
            placeholder="请选择地区"
          />
        </Form.Item>
        {
          getFieldDecorator(name[0], { initialValue: initialValue[0], rules })(<Input type="hidden" />)
        }
        {
          getFieldDecorator(name[1], { initialValue: initialValue[1] })(<Input type="hidden" />)
        }
        {
          getFieldDecorator(name[2], { initialValue: initialValue[2] })(<Input type="hidden" />)
        }
      </Col>
    )
  }

  public renderRead() {
    const { formItemProps = {}, colSpan, form, name, fieldProps } = this.props
    const { getFieldValue } = form

    const { initialValue = [] } = fieldProps

    const values = name.map((n, i) => getFieldValue(n) || initialValue[i])

    return (
      <Col span={colSpan} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps}>
          {
            (<ReadCascaderValue options={this.state.options} value={values} />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  public render() {
    debug('render')
    const permis = calPermission(this.props.authority)

    if (!this.props.show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }
}

export default CityField
