import React, { Component } from 'react'
import PropTypes from 'prop-types'
import axios from 'axios'
import AutoComplete from 'lbc-wrapper/lib/autoComplete'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import Col from 'lbc-wrapper/lib/col'
import calPermission, { PERMISSIONS } from '../utils/calPermission'
import { buildData, buildCustomHeader, API_ROOT1 } from 'middleware/ajax_no_encry'
import { colSpan } from './consts'

// global composition state
let onComposition = false

class Autocomplete extends Component {
  constructor() {
    super()
    this.state = {
      dataSource: [],
    }
    this.handleSearch = this.handleSearch.bind(this)
    this.onSelect = this.onSelect.bind(this)
    this.renderNormal = this.renderNormal.bind(this)
    this.post = this.post.bind(this)
  }

  componentDidMount() {}

  onSelect() {}

  handleSearch(inputValue) {
    if (!this.props.sync && !onComposition) {
      this.post(inputValue)
    }
  }

  post(inputValue) {
    const { url } = this.props
    const fullUrl = url.indexOf(API_ROOT1) === -1 ? API_ROOT1 + url : url
    const sendData = buildData(inputValue)
    axios({
      method: 'post',
      url: fullUrl,
      data: Object.assign(
        {
          // _channel_id: '03',
          // encFlag: 0,
        },
        {
          search: inputValue,
        },
      ),
      headers: buildCustomHeader(sendData),
    }).then((response) => {
      const { data } = response
      if (data.responseCode === '000000') {
        this.setState({
          dataSource: data.response.bankList,
        })
      }
    })
  }

  handleComposition(event) {
    event.type === 'compositionend' ? (onComposition = false) : (onComposition = true)
  }

  renderNormal() {
    const { form, name, formItemProps = {}, fieldProps = {}, ColSpan, options, sync } = this.props
    const { getFieldDecorator } = form
    return (
      <Col span={ColSpan} className="lb-col-gutter">
        <SimpleFormItem {...formItemProps}>
          {getFieldDecorator(name, fieldProps)(<AutoComplete
            dataSource={sync ? options : this.state.dataSource}
            onSelect={this.onSelect}
            onSearch={this.handleSearch}
            filterOption={(inputValue, option) => option.props.children.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1}
          >
            <input
              type="text"
              onCompositionStart={this.handleComposition}
              onCompositionUpdate={this.handleComposition}
              onCompositionEnd={this.handleComposition}
            />
                                               </AutoComplete>)}
        </SimpleFormItem>
      </Col>
    )
  }

  renderRead() {
    const { formItemProps = {}, fieldProps = {}, inputProps = {}, ColSpan } = this.props
    return (
      <Col span={ColSpan} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps}>
          <span>{fieldProps.initialValue || inputProps.value}</span>
        </SimpleFormItem>
      </Col>
    )
  }

  render() {
    const permis = calPermission(this.props.authority)

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }
}

Autocomplete.defaultProps = {
  ColSpan: colSpan,
  sync: true,
}

Autocomplete.propTypes = {
  name: PropTypes.string.isRequired,
  form: PropTypes.object.isRequired,
  formItemProps: PropTypes.object,
  fieldProps: PropTypes.object,
  inputProps: PropTypes.object,
  sync: PropTypes.bool,
  options: PropTypes.array,
  url: PropTypes.string,
  ColSpan: PropTypes.number,
  authority: PropTypes.string.isRequired,
}

export default Autocomplete
