import * as React from 'react'
import * as PropTypes from 'prop-types'
import Select, { SelectPropsLB, SelectOptionLB } from 'lbc-wrapper/lib/select'
import Col from 'lbc-wrapper/lib/col'
import _debug from 'lb-debug'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import calPermission, { PERMISSIONS } from '../utils/calPermission'
import { colSpan as defaultColSpan } from './consts'
import ReadOptionsValue from './readComp/ReadOptionsValue'
import './inputs.scss'
import { BaseInputProps } from './BaseInputProps'

const debug = _debug('vfc:SelectField')

export interface SelectFieldProps extends BaseInputProps {
  inputProps: SelectPropsLB
  optionsLoader?: any
  optionFormatter?: any
  async?: boolean

}

export interface SelectFieldState {
  options: SelectOptionLB[]
}

class SelectField extends React.Component<SelectFieldProps, any> {
  public static propTypes = {
    form: PropTypes.shape({
      getFieldDecorator: PropTypes.func.isRequired,
    }).isRequired,
    name: PropTypes.string.isRequired,
    fieldProps: PropTypes.shape({
      initialValue: PropTypes.string,
      rules: PropTypes.array,
    }),
    formItemProps: PropTypes.shape({
      label: PropTypes.string,
    }),
    inputProps: PropTypes.shape({
      options: PropTypes.array,
      value: PropTypes.string,
    }),
    colSpan: PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.object,
    ]),
    async: PropTypes.bool,
    optionsLoader: PropTypes.func,
    optionFormatter: PropTypes.func,
    authority: PropTypes.string.isRequired,
    show: PropTypes.bool,
  }

  public static defaultProps = {
    colSpan: defaultColSpan,
    async: false,
    optionFormatter(res: any) { return res },
    show: true,
  }

  constructor(props: SelectFieldProps) {
    super(props)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
    this.getPopupContainer = this.getPopupContainer.bind(this)

    this.state = {
      options: [],
    }
  }

  public componentDidMount() {
    const { optionsLoader, optionFormatter, async } = this.props

    if (async && optionsLoader) {
      optionsLoader().then((res: any) => this.setState({
        options: optionFormatter(res),
      }))
    }
  }

  public renderNormal() {
    const { form, name, formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan, async } = this.props

    const options = async ? { options: this.state.options } : {}

    const { getFieldDecorator } = form
    return (
      <Col span={colSpan} style={this.props.style} className="lb-col-gutter">
        <SimpleFormItem {...formItemProps}>
          {
            getFieldDecorator(name, fieldProps)(<Select
              getPopupContainer={this.getPopupContainer}
              allowClear={true}
              placeholder="请选择"
              {...inputProps}
              {...options}
            />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  public renderRead() {
    const { formItemProps = {}, inputProps = {}, colSpan, async, form, name, fieldProps } = this.props
    const options = (async ? this.state.options : inputProps.options) || []
    const { getFieldDecorator } = form

    return (
      <Col span={colSpan} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps}>
          {
            getFieldDecorator(name, { initialValue: fieldProps.initialValue })(<ReadOptionsValue options={options} />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  public render() {
    debug('render')
    const permis = calPermission(this.props.authority)

    if (!this.props.show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }

  private getPopupContainer(triggerNode: Element) {
    debug(triggerNode.parentElement)
    return triggerNode.parentElement || document.body
  }
}

export default SelectField
