# AutoComplete 自动补全输入框

## 一、如何使用?

### 1. 数据异步ajax获取

``` js
// 在react组件中导入
import Autocomplete from 'components/form/inputs/AutocompleteField'


...

<Form>
  <Row gutter={16} type="flex" align="top">
    <Autocomplete 
      name="examp"
      form={this.props.form}
      formItemProps={{label: '行名', required: true}}
      sync={false}
      url="test.autocomplete" />
  </Row>
</Form>

...

```

### 2. 数据同步props传入

``` js
// 在react组件中导入
import Autocomplete from 'components/form/inputs/AutocompleteField'


...

<Form>
  <Row gutter={16} type="flex" align="top">
    <Autocomplete 
      name="examp"
      form={this.props.form}
      formItemProps={{label: '行名', required: true}}
      sync={true}
      options={datas} />
  </Row>
</Form>

...

```

## 二、props使用说明

|参数         |说明       |类型        |默认值     |是否必输     |
|-------------|----------|-----------|-----------|-----------|
|`name`|form表单数据项名称|string|无|是|
|`form`|经过 Form.create 包装的组件将会自带 this.props.form 属性|object|无|是|
|`sync`|true为同步、false为异步|bool|true|否|
|`options`|sync为同步时，需要传入自动补全的数据, 格式参见[数据格式](#三、数据格式)|array|无|否|
|`url`|sync为异步时，需要传入获取自动补全数据的接口名称, 格式参见[数据格式](#三、数据格式)|array|无|否|
|`formItemProps`|formItem 属性|object|无|否|
|`fieldProps`|fieldProps 属性|object|无|否|
|`inputProps`|inputProps 属性|object|无|否|

## 三、数据格式

``` js
// 在使用url获取数据，和options传入数据时，必须参照下列数据格式

[
  {
  	value: 'example-01', 
  	text: '中国银行'
  }, 
  {
  	value: 'example-02', 
  	text: '中国农业银行'
  }
]

...

```