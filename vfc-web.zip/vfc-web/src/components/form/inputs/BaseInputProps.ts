import { FormItemProps, GetFieldDecoratorOptions, WrappedFormUtils } from 'lbc-wrapper/lib/form'
import { PERMISSIONS } from '../utils/calPermission';

export interface BaseInputProps {
  form: WrappedFormUtils
  authority: PERMISSIONS
  name: string
  formItemProps?: FormItemProps
  colSpan: number
  style?: any
  fieldProps:GetFieldDecoratorOptions
  show?: boolean
}
