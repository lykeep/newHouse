import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Modal from 'lbc-wrapper/lib/modal'
import Input from 'lbc-wrapper/lib/input'
import Button from 'lbc-wrapper/lib/button'
import Table from 'lbc-wrapper/lib/table'
import { isFunc } from '../../../../utils/dataType'
import Fields from '../../../../components/queryTable/FieldsWrapper'

class FilterModel extends Component {
  constructor(props) {
    super(props)
    this.state = {
      inputValue: '',
      data: [],
      current: '',
    }
    this.onChange = this.onChange.bind(this)
    this.onClose = this.onClose.bind(this)
    this.query = this.query.bind(this)
    this.fieldsQueryRegister = this.fieldsQueryRegister.bind(this)
    this.onChangePagination = this.onChangePagination.bind(this)
  }

  componentDidMount() {
    // const { fields=[], visible } = this.props
    // console.log('FilterModel,componentDidMount')
    // if (visible) {
    //   this.query({})
    // }
  }

  onChange = (e) => {
    this.setState({ inputValue: e.target.value })
  }

  onChangePagination(current, pageSize) {
    this.setState({
      current,
    })
    this.pageInfo({ pageNo: current, recordsPerPage: pageSize })
  }


  onClick = (key, record) => {
    const { name, type = { type: 'input' }, onCreate, onSelect } = this.props
    this.setState({ inputValue: '' })
    if (type.type === 'button') {
      onCreate(record)
    } else if (type.type === 'input') {
      onCreate({ [name[0]]: record[key[0]], [name[1]]: record[key[1]] })
    }
    if (isFunc(onSelect)) {
      onSelect(record)
    }
  }

  onClose = () => {
    const { onCancel } = this.props
    this.setState({ inputValue: '' })
    onCancel()
  }

  regroup = (modalData, key) => {
    const { disabledFunc = () => false } = this.props
    const { columns = [] } = modalData
    const newColumns = [...columns, {
      key: 'opr',
      title: '操作',
      dataIndex: 'opr',
      width: 100,
      render: (text, record) => (<a disabled={disabledFunc(text, record)} role="button" onClick={() => this.onClick(key, record)} className="opr" >选择</a>),
    }]
    // columns.forEach((item) => {
    //   newColumns.push({
    //     key: item.dataIndex,
    //     title: item.title,
    //     dataIndex: item.dataIndex,
    //   })
    // })
    // newColumns.push({
    //   key: 'opr',
    //   title: '操作',
    //   dataIndex: 'opr',
    //   width: 100,
    //   render: (text, record) => {
    //     return (
    //       <span onClick={() => this.onClick(key, record)} className="opr" >
    //         选择
    //       </span>
    //     )
    //   },
    // })

    return {
      newColumns,
    }
  }


  query = (params) => {
    console.log('query')
    const { action, receivekey, modelKey, filterKey, fields = [], parameters = {} } = this.props
    const { inputValue } = this.state
    const key = filterKey || receivekey[0]
    const p = fields.length !== 0 ? params : {}
    if (action) {
      action({
        pageNo: 1,
        recordsPerPage: 5,
        [key]: inputValue,
        ...parameters,
        ...p,
      }).then((data) => {
        console.log('queryquery', data)
        this.setState({
          inputValue,
          current: 1,
          data: data[modelKey],
          total: data.total,
        })
      })
    } else {
      console.error('<NameFilterModal />缺少参数action')
    }
  }

  pageInfo = (params) => {
    const { action, receivekey, modelKey, parameters = {}, filterKey } = this.props
    const { inputValue } = this.state
    const key = filterKey || receivekey[0]
    if (action) {
      action({
        pageNo: params.pageNo,
        recordsPerPage: params.recordsPerPage,
        [key]: inputValue,
        ...parameters,
      }).then((data) => {
        this.setState({
          data: data[modelKey],
          total: data.total,
        })
      })
    } else {
      console.error('<NameFilterModal />缺少参数action')
    }
  }

  fieldsQueryRegister() {
    // console.log('func1', func)
    // this.queryCallback = func
  }

  resetCallback() {
    console.log('func2')
    // this.currentPageNo = 1
    // this.currentFilters = {}
  }


  render() {
    const { visible, modalData = {}, receivekey, fields, inputProps = {}, doPagination } = this.props
    const { inputValue, data, total, current } = this.state
    const { newColumns } = this.regroup(modalData, receivekey)
    // 分页
    const pagination = {
      total,
      showTotal: a => `共 ${a} 条`,
      onChange: this.onChangePagination,
      pageSize: 5,
      current,
      onShowSizeChange: this.onChangePagination,

      // showTotal={total => `共 ${total} 条`}
      // onChange={this.onChange}
      // pageSize={pageSize || 10}
      // current={current}
      // onShowSizeChange={this.onShowSizeChange}
    }
    return (
      <Modal
        closable={false}
        visible={visible}
        title="请选择"
        width={1000}
        footer={<Button onClick={this.onClose}>取消</Button>}
        className="filterModal"
        getContainer={this.props.getContainer}
        destroyOnClose
      >
        <div>
          {!fields || fields.length === 0 ? (
            <div>
              <Input
                style={{ width: 200, marginBottom: 20 }}
                onChange={this.onChange}
                value={inputValue}
                placeholder={inputProps.modalPlaceholder || '请输入'}
              />
              <Button onClick={this.query} style={{ marginLeft: 20 }}>查询</Button>
            </div>
          ) : (<Fields fields={fields} query={this.query} queryRegister={this.fieldsQueryRegister} loadOnMount resetCallback={this.resetCallback} />)}
        </div>
        <Table
          position="left"
          size="small"
          rowKey="index"
          columns={newColumns}
          dataSource={data}
          pagination={doPagination && pagination}
        />
        {/* <TablePage
          rowSelection={null}
          columns={newColumns}
          dataSource={this.state.data}
          query={this.pageInfo}
          pageSize={5}
          total={total}
          size="small"
          rowKey={rowKey}
          doPagination={doPagination}
        /> */}
      </Modal>
    )
  }
}

FilterModel.propTypes = {
  receivekey: PropTypes.array.isRequired,
  modelKey: PropTypes.string,
  filterKey: PropTypes.string,
  visible: PropTypes.bool,
  modalData: PropTypes.object,
  fields: PropTypes.array,
  parameters: PropTypes.object,
  inputProps: PropTypes.object,
  doPagination: PropTypes.bool,
  type: PropTypes.object,
  onSelect: PropTypes.func,
  // columns: PropTypes.object.isRequired,
  // visible: PropTypes.boolean.isRequired,
  onCancel: PropTypes.func.isRequired,
  onCreate: PropTypes.func.isRequired,
  name: PropTypes.array.isRequired,
  action: PropTypes.func.isRequired,
}

export default FilterModel
