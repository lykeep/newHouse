import React, { Component } from 'react'
import { findDOMNode } from 'react-dom'
import PropTypes from 'prop-types'
import Col from 'lbc-wrapper/lib/col'
import Icon from 'lbc-wrapper/lib/icon'
import Input from 'lbc-wrapper/lib/input'
import Button from 'lbc-wrapper/lib/button'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import HiddenField from '../HiddenField'
import calPermission, { PERMISSIONS } from '../../utils/calPermission'
import { colSpan as defaultColSpan } from '../consts'
import FilterModel from './FilterModel'
import ReadSimpleValue from '../readComp/ReadSimpleValue'
import './NameFilterModal.scss'

class NameFilterModal extends Component {
  constructor(props) {
    super(props)
    this.state = {
      visible: false,
      receiveArr: {},
      dataSource: [],
      madalData: {},
      me: null,
    }
    this.handleCancel = this.handleCancel.bind(this)
    this.handleCreate = this.handleCreate.bind(this)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
  }

  static getDerivedStateFromProps(props, state) {
    const { name, value = {}, useForm } = props
    if (!useForm) {
      return null
    }

    const { receiveArr = {} } = state
    if (value[name[0]] !== receiveArr[name[0]] || value[name[1]] !== receiveArr[name[1]]) {
      return {
        receiveArr: value,
      }
    }

    return null
  }

  componentDidMount() {
    const { value } = this.props
    this.setState({
      receiveArr: value || {},
      me: findDOMNode(this),
    });
  }

  inputOnFocus = () => {
    this.setState({ visible: true })
    const { fields = [] } = this.props
    if (fields.length === 0) {
      this.tableRef.query()
    }
    // console.log('432423', this.tableRef)
  }

  handleCancel = () => {
    this.setState({ visible: false })
  }

  handleCreate = (val) => {
    const { name, form, useForm=true, onChange, type={type: 'input' }, onSelect } = this.props

    // type -> button
    if (type.type === 'button' && onChange) {
      onChange(val)
    }
    // if (onSelect) {
    //   onSelect(val)
    // }
    // 弹窗 type->input 返回值为id、name
    if (type.type === 'input') {
      if (useForm) {
        if (onChange) onChange(val)
        form.setFieldsValue({ [name[0]]: val[name[0]], [name[1]]: val[name[1]] })
      } else {
        if (onChange) onChange(val)
        this.setState({ receiveArr: { [name[0]]: val[name[0]], [name[1]]: val[name[1]] } })
      }
    }

    this.setState({ visible: false, madalData: val })
  }

  // 点击查看
  clickShow = () => {
    const { madalData } = this.state
    const { onClickIcon } = this.props
    if (onClickIcon) {
      onClickIcon({ ...madalData })
    }
  //  this.props.history.push('/dashboard/partners/legal/querylist/')
  }

  renderNormal = () => {
    const { form = {}, name, modelKey, onSelect, receivekey, colSpan ,formItemProps = {}, fieldProps = {}, parameters = {},
      inputProps = {}, useForm = true, action, modalData, type = { type: 'input' }, showIcon = false, rowKey, validateStatus, help, modalProps = {}, doPagination = true,
      tips={}, disabledFunc } = this.props
    const { getFieldDecorator } = form
    const { visible, receiveArr, dataSource } = this.state
    const initialValue = fieldProps.initialValue || {}

    return (
      <Col span={colSpan} className="lb-col-gutter">
        {
          type.type === 'input' &&
          <div>
            {
            !useForm &&
            <div>
              {
                type.type === 'input' &&
                <SimpleFormItem validateStatus={validateStatus} help={help} {...formItemProps}>
                  { showIcon && <span role="button" onClick={() => this.clickShow()} className="eyeIcon"><Icon type="eye-o" /></span>}
                  <Input autoComplete="off" placeholder={inputProps.placeholder || '请输入'} value={receiveArr[name[0]] || ''} onClick={e => this.inputOnFocus(e)} />
                  <HiddenField value={receiveArr[name[1]] || ''} />
                </SimpleFormItem>
              }
            </div>
            }
            {
            useForm &&
            <div>
              <SimpleFormItem {...formItemProps}>
                { showIcon && <span role="button" onClick={() => this.clickShow()} className="eyeIcon"><Icon type="eye-o" /></span>}
                {
                  getFieldDecorator(
                    name[0],
                    { ...fieldProps, initialValue: initialValue[name[0]] },
                  )(<Input autoComplete="off" onClick={e => this.inputOnFocus(e)} {...inputProps} />)
                }
              </SimpleFormItem>
              {
                getFieldDecorator(
                  name[1],
                  { ...fieldProps, initialValue: initialValue[name[1]] },
                )(<HiddenField />)
              }
            </div>
          }
          </div>
        }
        {
          type.type === 'button' &&
          <SimpleFormItem {...formItemProps} required={type.required}>
            <Button disabled={tips.disabled} onClick={this.inputOnFocus}>{type.name}</Button>
            {
              tips.disabled &&
              <span className="mg-l-20">
                <Icon className="red" type="exclamation-circle-o" theme="outlined" />
                <span className="red mg-l-10">{tips.text}</span>
              </span>
            }
          </SimpleFormItem>
        }
        <FilterModel
          ref={r => (this.tableRef = r)}
          visible={visible}
          modalData={{
            columns: modalData.columns,
            dataSource,
          }}
          parameters={parameters}
          onSelect={onSelect}
          receivekey={receivekey}
          type={type}
          name={name}
          modelKey={modelKey}
          action={action}
          disabledFunc={disabledFunc}
          onCancel={this.handleCancel}
          onCreate={this.handleCreate}
          getContainer={() => this.state.me}
          rowKey={rowKey}
          doPagination={doPagination}
          {...inputProps}
          {...this.props}
          {...modalProps}
        />
      </Col>
    )
  }

  renderRead() {
    const { formItemProps = {}, fieldProps = {}, colSpan, name, useForm = true, type = { type: 'input' }, showIcon = false, form = {} } = this.props
    const initialValue = fieldProps.initialValue || {}
    const { receiveArr } = this.state
    const { getFieldDecorator } = form

    const content = useForm ? getFieldDecorator(name[0], { initialValue: initialValue[name[0]] })(<ReadSimpleValue />) : (<span>{receiveArr[name[0]] || ''}</span>)

    return (
      <Col span={colSpan} className="lb-col-gutter  ant-form-inline">
        {
          type.type === 'input' &&
          <SimpleFormItem {...formItemProps} >
            { showIcon && <span role="button" onClick={() => this.clickShow()} className="eyeIcon"><Icon type="eye-o" /></span>}
            {
              content
            }
          </SimpleFormItem>
        }
      </Col>
    )
  }

  render() {
    const permis = calPermission(this.props.authority)

    if (!this.props.show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }
}

NameFilterModal.prototypes = {
  modelKey: PropTypes.string,
  action: PropTypes.func,
  fields: PropTypes.array,
  form: PropTypes.shape({
    getFieldDecorator: PropTypes.func,
  }).isRequired,
  name: PropTypes.array.isRequired,
  fieldProps: PropTypes.shape({
    initialValue: PropTypes.string,
    rules: PropTypes.array,
  }),
  formItemProps: PropTypes.shape({
    label: PropTypes.string,
  }),
  inputProps: PropTypes.object,
  colSpan: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.object,
  ]),
  receivekey: PropTypes.array.isRequired,
  authority: PropTypes.string.isRequired,
  onClickIcon: PropTypes.func,
  show: PropTypes.bool,
}

NameFilterModal.defaultProps = {
  colSpan: defaultColSpan,
  show: true,
}

export default NameFilterModal
