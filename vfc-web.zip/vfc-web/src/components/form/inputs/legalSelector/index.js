import { connect } from 'react-redux'
import LegalSelector from './LegalSelector'
import { queryLegalList } from './LegalSelectorModule'

const mapActionCreators = {
  queryLegalList,
}

const mapStateToProps = () => ({ })

export default connect(mapStateToProps, mapActionCreators)(LegalSelector)
