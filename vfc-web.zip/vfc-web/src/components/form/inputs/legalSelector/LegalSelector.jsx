import React, { Component } from 'react'
import NameFilterModal from '../nameFilterModal/NameFilterModal'
import legalIdTypesRender from '../../../columnRenders/legalIdTypes'

class LegalSelector extends Component {
  constructor(props) {
    super(props)

    this.columns = [{
      title: '名称',
      dataIndex: 'lpName',
    }, {
      title: '证件类型',
      dataIndex: 'entIdType',
      key: 'entIdType',
      render: legalIdTypesRender,
    }, {
      title: '证件号码',
      dataIndex: 'entIdNo',
      key: 'entIdNo',
    }]
  }

  render() {
    const { queryLegalList, ...props } = this.props

    return (
      <NameFilterModal
        modalData={{
            columns: this.columns,
        }}
        action={queryLegalList}
        modelKey="lpQueryListVos"
        receivekey={['lpName', 'lpNo']}
        formItemProps={{ label: '法人名称' }}
        inputProps={{
            placeholder: '点击选择',
            style: { width: '100%' },
            readOnly: true,
        }}
        rowKey="lpNo"
        modalProps={{
          placeholder: '请输入法人名称',
        }}
        {...props}
      />
    )
  }
}

export default LegalSelector
