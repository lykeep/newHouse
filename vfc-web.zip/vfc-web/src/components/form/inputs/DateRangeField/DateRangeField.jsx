import React, { Component } from 'react'
import moment from 'moment'
import PropTypes from 'prop-types'
import Col from 'lbc-wrapper/lib/col'
import { RangePicker } from 'lbc-wrapper/lib/datePicker'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import HiddenField from '../HiddenField'
import { effectiveString, effectiveObject } from '../../../../utils/dataType'
import calPermission, { PERMISSIONS } from '../../utils/calPermission'
import { colSpan as defaultColSpan } from '../consts'
import './DateRange.scss'

class DateRangeField extends Component {
  constructor(props) {
    super(props)
    this.state = {
      start: null,
      end: null,
    }
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
  }

  componentDidMount() {
    const { fieldProps, inputProps = {} } = this.props
    const { initialValue = {} } = fieldProps
    const { dateKey = {} } = inputProps
    if (effectiveObject(initialValue)) {
      this.setState({
        start: initialValue[dateKey.start] || null,
        end: initialValue[dateKey.end] || null,
      })
    }
  }

  onChange = (values, dateStrings) => {
    const { inputProps, form } = this.props
    const { dateKey } = inputProps

    this.setState({
      start: values[0],
      end: values[1],
    })

    form.setFieldsValue({
      [dateKey.start]: dateStrings[0],
      [dateKey.end]: dateStrings[1],
    })
  }

  validatorDate = (rule, value, callback) => {
    if (value) {
      // effectiveString 判断是否为有效字符串
      if (effectiveString(value)) {
        return callback()
      }
    }
    callback('请填写完整日期！')
    return callback()
  }

  // required为true, 加入验证规则
  rules = (fieldProps) => {
    const fieldRule = Object.assign({}, fieldProps)
    if (fieldRule.rules) {
      if (fieldRule.rules[0].required) {
        Object.assign(fieldProps.rules[0], {
          validator: (rule, value, callback) => this.validatorDate(rule, value, callback, this.props),
        })
      }
    }
    return fieldRule
  }

  renderNormal = () => {
    const { form, formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan } = this.props
    const { getFieldDecorator } = form
    const { initialValue = {} } = fieldProps
    const { dateKey } = inputProps
    const newFieldProps = this.rules(fieldProps)
    const { rules } = formItemProps

    const start = initialValue[dateKey.start] || null
    const end = initialValue[dateKey.end] || null

    return (
      <Col span={colSpan} className="lb-col-gutter vfc-DataRange">
        <SimpleFormItem {...formItemProps} {...newFieldProps} >
          {/* {
            getFieldDecorator(name, {
              ...newFieldProps,
              onChange: e => this.onChange(e),
            })(<DateRange {...inputProps} />)
          } */}

          {
            getFieldDecorator(`${dateKey.start}`, { ...fieldProps,
              initialValue: start || '' })(<HiddenField />)
          }
          {
            getFieldDecorator(`${dateKey.end}`, { ...fieldProps,
              initialValue: end || '' })(<HiddenField />)
          }
          <RangePicker
            required={rules ? rules[0].required : false}
            onChange={this.onChange}
            placeholder={['开始时间', '结束时间']}
            defaultValue={[
              effectiveString(start) ? moment(start) : null,
              effectiveString(end) ? moment(end) : null,
              // start, end
            ]}
            style={{ width: '100%' }}
          />
        </SimpleFormItem>
      </Col>
    )
  }

  // 只读
  renderRead = () => {
    const { formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan } = this.props
    const { dateKey } = inputProps
    const value = fieldProps.initialValue || {}
    return (
      <Col span={colSpan} className="lb-col-gutter vfc-DataRange ant-form-inline">
        <SimpleFormItem {...formItemProps}>
          {
            (value[dateKey.start] || value[dateKey.end]) &&
            <span>{value[dateKey.start]} 至 {value[dateKey.end]}</span>
          }
        </SimpleFormItem>
      </Col>
    )
  }

  render() {
    const permis = calPermission(this.props.authority)

    if (!this.props.show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }
    // HIDE
    return null
  }
}

DateRangeField.propTypes = {
  form: PropTypes.shape({
    getFieldDecorator: PropTypes.func.isRequired,
  }).isRequired,
  fieldProps: PropTypes.shape({
    initialValue: PropTypes.object,
    rules: PropTypes.object,
  }),
  formItemProps: PropTypes.shape({
    label: PropTypes.string,
  }),
  inputProps: PropTypes.shape({
    dateKey: PropTypes.object.isRequired,
  }),
  colSpan: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.object,
  ]),
  authority: PropTypes.string.isRequired,
  show: PropTypes.bool,
}
DateRangeField.defaultProps = {
  colSpan: defaultColSpan,
  show: true,
}

export default DateRangeField
