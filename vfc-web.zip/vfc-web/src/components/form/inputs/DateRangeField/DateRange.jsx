import React, { Component } from 'react'
import PropTypes from 'prop-types'
import moment from 'moment'
import DatePickerWrapper from 'lbc-wrapper/lib/datePicker'
import { effectiveObject } from '../../../../utils/dataType'
import '../inputs.scss'

class DateRange extends Component {
  state = {
    startValue: null,
    endValue: null,
    endOpen: false,
  }

  componentDidMount() {
    const { value, dateKey } = this.props
    if (effectiveObject(value)) {
      this.setState({
        startValue: moment(value[dateKey.start]),
        endValue: moment(value[dateKey.end]),
      })
    }
  }

  componentWillReceiveProps(nextProps) {
    // Should be a controlled component.
    // 时间格式转换成 moment格式
    const { dateKey } = this.props
    if ('value' in nextProps) {
      const value = nextProps.value
      if (value) {
        const newVal = {}
        Object.keys(value).map((item) => {
          Object.assign(newVal, { [item]: value[item] ? moment(value[item]) : null })
        })
        this.setState({ startValue: newVal[dateKey.start], endValue: newVal[dateKey.end] });
        // this.setState({startValue: });
      }
    }
  }

  onChange = (field, value) => {
    this.setState({
      [field]: value,
    })
    this.triggerChange({ [field]: value })
  }

  onStartChange = (value) => {
    this.onChange('startValue', value);
  }

  onEndChange = (value) => {
    this.onChange('endValue', value);
  }

  // 不可选开始时间
  disabledStartDate = (startValue) => {
    const endValue = this.state.endValue;
    if (!startValue || !endValue) {
      return false;
    }
    return startValue.valueOf() > endValue.valueOf();
  }

  // 不可选结束时间
  disabledEndDate = (endValue) => {
    const startValue = this.state.startValue;
    if (!endValue || !startValue) {
      return false;
    }
    return endValue.valueOf() <= startValue.valueOf();
  }

  handleStartOpenChange = (open) => {
    if (!open) {
      this.setState({ endOpen: true });
    }
  }

  handleEndOpenChange = (open) => {
    this.setState({ endOpen: open });
  }

  triggerChange = (changedValue) => {
    // Should provide an event to pass value to Form.
    // 返回值 格式 “2018-01-01”
    const { onChange, dateKey } = this.props
    if (onChange) {
      const newObj = Object.assign({}, this.state, changedValue)
      delete newObj.endOpen
      Object.keys(newObj).map((item) => {
        Object.assign(newObj, { [item]: newObj[item] ? moment(newObj[item]).format('YYYY-MM-DD') : null })
      })
      onChange({ [dateKey.start]: newObj.startValue, [dateKey.end]: newObj.endValue });
    }
  }

  render() {
    const style = { width: '6%', display: 'inline-block', textAlign: 'center' }
    const { startValue, endValue, endOpen } = this.state;
    const { placeholder } = this.props

    return (
      <div className="DataRangeField">
        <DatePickerWrapper
          disabledDate={this.disabledStartDate}
          format="YYYY-MM-DD"
          value={startValue}
          placeholder={placeholder.start}
          onChange={this.onStartChange}
          onOpenChange={this.handleStartOpenChange}
        />
        <span style={style}> - </span>
        <DatePickerWrapper
          disabledDate={this.disabledEndDate}
          format="YYYY-MM-DD"
          value={endValue}
          placeholder={placeholder.end}
          onChange={this.onEndChange}
          open={endOpen}
          onOpenChange={this.handleEndOpenChange}
        />
      </div>
    )
  }
}

DateRange.propTypes = {
  value: PropTypes.object,
  dateKey: PropTypes.object,
  placeholder: PropTypes.object,
}

DateRange.defaultProps = {
  placeholder: { start: '开始时间', end: '结束时间' },
}
export default DateRange
