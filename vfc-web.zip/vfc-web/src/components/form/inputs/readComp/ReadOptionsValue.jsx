import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'

class ReadOptionsValue extends PureComponent {
  render() {
    const { value, options, formatter, keyName='title' } = this.props

    let title = ''
    for (let i = 0; i < options.length; i += 1) {
      if (value == options[i].value) {
        title = options[i][keyName] || options[i]['label']
        break
      }
    }

    title = formatter ? formatter(value, options) : title
    return (
      <span>{title}</span>
    )
  }
}

ReadOptionsValue.propTypes = {
  value: PropTypes.string,
  options: PropTypes.array,
  formatter: PropTypes.func,
  keyName: PropTypes.string,
}

export default ReadOptionsValue
