import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'

class ReadMultiLineValue extends PureComponent {
  render() {
    const { value = '' } = this.props
    const newLine = value.split('\n')
    return (
      <div>
        {
          newLine.map((t, i) => (<p key={i}>{t}</p>))
        }
      </div>
    )
  }
}

ReadMultiLineValue.propTypes = {
  value: PropTypes.string,
}

export default ReadMultiLineValue
