import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'

function findMe(value, options = []) {
  for (let i = 0; i < options.length; i += 1) {
    if (options[i].value === value) {
      return options[i]
    }
  }

  return null
}

class ReadCascaderValue extends PureComponent {
  render() {
    const { value = [], options = [] } = this.props

    if (value[0] === undefined) {
      return ''
    }

    const title = []
    let curr = null
    let opts = options
    for (let i = 0; i < value.length; i += 1) {
      curr = findMe(value[i], opts)
      title.push(curr ? curr.label : value[i])
      opts = curr ? curr.children : []
    }

    return (
      <span>{title.join('/')}</span>
    )
  }
}

ReadCascaderValue.propTypes = {
  value: PropTypes.array,
  options: PropTypes.array,
}

export default ReadCascaderValue
