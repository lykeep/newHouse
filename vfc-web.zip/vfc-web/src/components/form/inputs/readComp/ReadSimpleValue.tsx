import React from 'react'
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'

interface ReadSimpleValueProps {
  value?: string | number
  formatter?: (value: string | number | undefined) => string
  isLink?: boolean
  to?: string
}

class ReadSimpleValue extends React.PureComponent<ReadSimpleValueProps> {
  public static propTypes = {
    // value: PropTypes.string,
    formatter: PropTypes.func,
    isLink: PropTypes.bool,
    to: PropTypes.string,
  }

  public render() {
    const { value, formatter, isLink, to } = this.props
    let v: string = ''

    if (value !== undefined) {
      v = formatter ? formatter(value) : `${value}`
    }

    return (
      <span>{isLink ? (<Link to={to || ''}>{v}</Link>) : v}</span>
    )
  }
}

export default ReadSimpleValue
