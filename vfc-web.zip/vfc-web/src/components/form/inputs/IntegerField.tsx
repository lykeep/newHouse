import * as React from 'react'
import * as PropTypes from 'prop-types'
import InputNumber, { InputNumberPropsLB } from 'lbc-wrapper/lib/inputNumber'
import Col from 'lbc-wrapper/lib/col'
import { SimpleFormItem, GetFieldDecoratorOptions } from 'lbc-wrapper/lib/form'
import calPermission, { PERMISSIONS } from '../utils/calPermission'
import { colSpan as defaultColSpan } from './consts'
import ReadSimpleValue from './readComp/ReadSimpleValue'
import { BaseInputProps } from './BaseInputProps'
import { Omit } from '../../../types/utils'

import './inputs.scss'

function formatter(value: string | number) {
  return `${value}`
}

export interface IntegerFieldProps extends Omit<BaseInputProps, 'fieldProps'> {
  inputProps: InputNumberPropsLB
  canZero?: boolean
  fieldProps: GetFieldDecoratorOptions & {
    maxLength?: number
    minLength?: number
  }
}

class IntegerField extends React.Component<IntegerFieldProps> {
  public static propTypes = {
    form: PropTypes.shape({
      getFieldDecorator: PropTypes.func.isRequired,
    }).isRequired,
    name: PropTypes.string.isRequired,
    fieldProps: PropTypes.shape({
      minLength: PropTypes.number,
      maxLength: PropTypes.number,
    }),
    formItemProps: PropTypes.object.isRequired,
    inputProps: PropTypes.shape({
      min: PropTypes.number,
      precision: PropTypes.number,
    }),
    colSpan: PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.object,
    ]),
    authority: PropTypes.string.isRequired,
    show: PropTypes.bool,
  }

  public static defaultProps = {
    colSpan: defaultColSpan,
    inputProps: {
      precision: 0,
    },
    show: true,
    fieldProps: {
      minLength: 1,
      maxLength: 9,
    },
  }

  constructor(props: IntegerFieldProps) {
    super(props)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
  }

  public renderNormal() {
    const { form, name, formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan, canZero } = this.props

    const { initialValue, rules, maxLength = 16, minLength = 1, ...others } = fieldProps

    const { getFieldDecorator } = form

    const reg = canZero ? new RegExp(`^([1-9]\\d{${minLength - 1},${maxLength - 1}}$)|0`) : new RegExp(`^[1-9]\\d{${minLength - 1},${maxLength - 1}}$`)

    return (
      <Col span={colSpan} style={this.props.style} className="lb-col-gutter">
        <SimpleFormItem {...formItemProps} label={`${formItemProps.label}`}>
          {
            getFieldDecorator(name, {
              initialValue: fieldProps.initialValue,
              rules: [
                { pattern: reg, message: `请输入${minLength}-${maxLength}位正整数！` },
                ...fieldProps.rules || [],
              ],
              ...others,
            })(<InputNumber
              step={1}
              {...inputProps}
            />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  public renderRead() {
    const { formItemProps = {}, colSpan, form, name, fieldProps } = this.props
    const { getFieldDecorator } = form

    return (
      <Col span={colSpan} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps}>
          {
            getFieldDecorator(name, { initialValue: fieldProps.initialValue })(<ReadSimpleValue formatter={formatter} />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  public render() {
    const permis = calPermission(this.props.authority)

    if (!this.props.show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }
}

export default IntegerField
