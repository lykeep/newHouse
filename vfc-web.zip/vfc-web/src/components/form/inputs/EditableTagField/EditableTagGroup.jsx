import Icon from 'lbc-wrapper/lib/icon'
import Input from 'lbc-wrapper/lib/input'
import Tag from 'lbc-wrapper/lib/tag'
import React, { Component } from 'react'
import { colSpan as defaultColSpan } from '../consts'

class EditableTagGroup extends Component {
  constructor(props) {
    super(props)

    this.handleClose = this.handleClose.bind(this)
    this.showInput = this.showInput.bind(this)
    this.handleInputChange = this.handleInputChange.bind(this)
    this.handleInputConfirm = this.handleInputConfirm.bind(this)
    this.saveInputRef = this.saveInputRef.bind(this)

    this.state = {
      tags: [],
      inputVisible: false,
      inputValue: '',
    }
  }

  handleClose(removedTag) {
    const { value } = this.props
    const tags = value ? value.split(',') : []
    tags.map((item, i) => {
      if (item === removedTag) {
        this.setState({
          tags: tags.splice(i, 1),
        })
      }
      return tags
    })
    this.triggerChange(tags)
  }

  showInput() {
    this.setState({ inputVisible: true }, () => this.input.focus());
  }

  handleInputChange(e) {
    const teleReg = /(^[\d]{1,3}$)/
    if (e.target.value && !teleReg.test(e.target.value)) {
    } else {
      this.setState({ inputValue: e.target.value });
    }
  }

  triggerChange = (changedValue) => {
    const { onChange } = this.props
    if (onChange) {
      onChange(changedValue.join())
    }
  }

  handleInputConfirm(e) {
    const { value, onChange } = this.props
    const inputValue = this.state.inputValue;
    let tags = value ? value.split(',') : []
    if (inputValue && tags.indexOf(inputValue) === -1) {
      tags = [...tags, inputValue];
    }

    this.setState({
      tags,
      inputVisible: false,
      inputValue: '',
    })

    this.triggerChange(tags)
  }

  saveInputRef(input) {
    this.input = input
  }


  render() {
    const { value } = this.props
    const { inputVisible, inputValue } = this.state

    const arr = value ? value.split(',') : []
    return (
      <div>
        {arr.map((tag, index) => (
          <Tag closable key={tag} afterClose={() => this.handleClose(tag)}>
            {tag}
          </Tag>
          ))}
        {inputVisible && (
          <Input
            ref={this.saveInputRef}
            type="text"
            size="small"
            style={{ width: 78 }}
            value={inputValue}
            onChange={this.handleInputChange}
            onBlur={this.handleInputConfirm}
            onPressEnter={this.handleInputConfirm}
          />
          )}
        {!inputVisible && (
          <Tag
            onClick={this.showInput}
            style={{ background: '#fff', borderStyle: 'dashed' }}
          >
            <Icon type="plus" /> 新增
          </Tag>
          )}
      </div>
    )
  }
}

EditableTagGroup.defaultProps = {
  colSpan: defaultColSpan,
}

export default EditableTagGroup
