import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Col from 'lbc-wrapper/lib/col'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import EditableTagGroup from './EditableTagGroup'
import ReadSimpleValue from '../readComp/ReadSimpleValue'
import calPermission, { PERMISSIONS } from '../../utils/calPermission'
import { colSpan as defaultColSpan } from '../consts'

class DateRangeField extends Component {
  constructor(props) {
    super(props)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
  }


  renderNormal = () => {
    const { form, name, formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan } = this.props
    const { getFieldDecorator } = form

    return (
      <Col span={colSpan} className="lb-col-gutter">
        <SimpleFormItem {...formItemProps}>
          {
            getFieldDecorator(name, fieldProps)(<EditableTagGroup {...inputProps} />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  // 只读
  renderRead = () => {
    const { name, formItemProps = {}, fieldProps = {}, inputProps = {}, form, colSpan } = this.props
    const { getFieldDecorator } = form
    return (
      <Col span={colSpan} className="lb-col-gutter">
        <SimpleFormItem {...formItemProps}>
          {
            getFieldDecorator(name, { initialValue: fieldProps.initialValue })(<ReadSimpleValue />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  render() {
    const permis = calPermission(this.props.authority)
    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }
    // HIDE
    return null
  }
}

DateRangeField.propTypes = {
  form: PropTypes.shape({
    getFieldDecorator: PropTypes.func.isRequired,
  }).isRequired,
  fieldProps: PropTypes.shape({
    initialValue: PropTypes.string,
    rules: PropTypes.array,
  }),
  formItemProps: PropTypes.shape({
    label: PropTypes.string,
  }),
  colSpan: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.object,
  ]),
  authority: PropTypes.string.isRequired,
}
DateRangeField.defaultProps = {
  colSpan: defaultColSpan,
}

export default DateRangeField
