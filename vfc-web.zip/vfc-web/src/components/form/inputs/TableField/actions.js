const ACTIONS = {
  ADD: {
    label: '新增',
    icon: 'plus',
    key: 'add',
  },
  REMOVE: {
    label: '删除',
    minSelect: 1,
    maxSelect: 1,
    confirm: true,
    message: '确认要删除这些记录？',
    key: 'remove',
  },
}

export default ACTIONS
