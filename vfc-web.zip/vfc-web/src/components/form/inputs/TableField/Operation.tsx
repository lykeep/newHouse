import * as React from 'react'
import Icon from 'lbc-wrapper/lib/icon'
import Divider from 'lbc-wrapper/lib/divider'
import Popconfirm from 'lbc-wrapper/lib/popconfirm'

export enum OPERATIONS {
  VIEW = 'V',
  MODIFY = 'M',
  DELETE = 'D',
}

export interface Operation {
  key: string
  action: (param: any) => any
  render: () => any
}

export type OP_TYPE = OPERATIONS | Operation

interface OperationProps {
  viewHandler: (param: any) => void
  modifyHandler: (param: any) => void
  deleteHandler: (param: any) => void
  clickHandler: (param?: any) => void
  operations?: OP_TYPE[]
}

class OperationClass extends React.Component<OperationProps> {
  public static defaultProps = {
    operations: [
      OPERATIONS.VIEW,
      OPERATIONS.MODIFY,
      OPERATIONS.DELETE,
    ],
  }

  constructor(props: OperationProps) {
    super(props)

    this.renderView = this.renderView.bind(this)
    this.renderModify = this.renderModify.bind(this)
    this.renderDelete = this.renderDelete.bind(this)
    this.renderOthers = this.renderOthers.bind(this)
  }

  public renderView() {
    const { viewHandler } = this.props
    return (
      <span onClick={viewHandler} role="button" tabIndex={-1} key="view" style={{ cursor: 'pointer' }} ><Icon type="eye-o" /></span>
    )
  }

  public renderModify() {
    const { modifyHandler } = this.props
    return (
      <span onClick={modifyHandler} role="button" tabIndex={-1} key="modify" style={{ cursor: 'pointer' }} ><Icon type="edit" /></span>
    )
  }

  public renderDelete() {
    const { deleteHandler } = this.props
    return (
      <Popconfirm title="确认要删除这条数据吗？" onConfirm={deleteHandler} key="delete" okText="确定" cancelText="取消">
        <span role="button" tabIndex={-1} style={{ cursor: 'pointer' }} ><Icon type="delete" /></span>
      </Popconfirm>

    )
  }

  public renderOthers(opt: Operation, i: number) {
    const { clickHandler } = this.props
    return (
      <span onClick={() => { opt.action(clickHandler()) }} role="button" tabIndex={-1} key={opt.key || i} style={{ cursor: 'pointer' }} >
        {
          opt.render()
        }
      </span>
    )
  }

  public render() {
    const { operations } = this.props

    const realOps: any[] = []
    operations!.forEach((o, i) => {
      if (o === OPERATIONS.VIEW) {
        realOps.push(this.renderView())
      } else if (o === OPERATIONS.MODIFY) {
        realOps.push(this.renderModify())
      } else if (o === OPERATIONS.DELETE) {
        realOps.push(this.renderDelete())
      } else {
        realOps.push(this.renderOthers(o, i))
      }

      if (i < operations!.length - 1) {
        realOps.push(<Divider type="vertical" key={i} />)
      }
    })
    return (
      <div style={{minWidth: '5px', minHeight: '21px'}}>
        {realOps}
      </div>
    )
  }
}

export default OperationClass
