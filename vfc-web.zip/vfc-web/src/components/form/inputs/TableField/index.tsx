import * as React from 'react'
import Col from 'lbc-wrapper/lib/col'
import TableField, { TableFieldBodyProps } from './TableField'
import { BaseInputProps } from '../BaseInputProps'

import './TableField.less'

export { TableFieldBodyProps }

export interface TableFieldProps<T> extends BaseInputProps {
  inputProps: TableFieldBodyProps<T>
  form: any // 覆盖antd的form
}

class TableFieldWrapper<T> extends React.PureComponent<TableFieldProps<T>> {
  public static defaultProps = {
    fieldProps: {},
    inputProps: {},
    colSpan: 24,
  }

  public render() {
    const { form, name, fieldProps, inputProps, colSpan, authority } = this.props
    const { getFieldDecorator, value, onChange, initValue } = form
    // table的数据存储在form里
    if (getFieldDecorator) {
      return (
        <Col span={colSpan} className="lb-table-field">
          {
            getFieldDecorator(name, fieldProps)(<TableField<T> scroll={{ x: true }} {...inputProps} authority={authority} />)
          }
        </Col>
      )
    }

    // table的数据存储于上层组件
    if (initValue && fieldProps.initialValue) {
      initValue(fieldProps.initialValue)
    }
    return (
      <Col span={colSpan} className="lb-table-field">
        <TableField<T>
          scroll={{
            x: true,
          }}
          {...inputProps}
          value={value}
          onChange={onChange}
          authority={authority}
        />
      </Col>
    )
  }
}

// const TableFieldWrapper: React.SFC<TableFieldProps<T>> = <T extends {}>({ form, name, fieldProps, inputProps, colSpan, authority }) => {
//   const { getFieldDecorator, value, onChange, initValue } = form
//   // table的数据存储在form里
//   if (getFieldDecorator) {
//     return (
//       <Col span={colSpan} className="lb-table-field">
//         {
//           getFieldDecorator(name, fieldProps)(<TableField scroll={{ x: true }} {...inputProps} authority={authority} />)
//         }
//       </Col>
//     )
//   }

//   // table的数据存储于上层组件
//   if (initValue && fieldProps.initialValue) {
//     initValue(fieldProps.initialValue)
//   }
//   return (
//     <Col span={colSpan} className="lb-table-field">
//       <TableField
//         scroll={{
//           x: true,
//         }}
//         {...inputProps}
//         value={value}
//         onChange={onChange}
//         authority={authority}
//       />
//     </Col>
//   )
// }

// TableFieldWrapper.propTypes = {
//   form: PropTypes.shape({
//     getFieldDecorator: PropTypes.func,
//   }),
//   name: PropTypes.string.isRequired,
//   fieldProps: PropTypes.object,
//   inputProps: PropTypes.shape({
//     columns: PropTypes.array.isRequired,
//   }),
//   colSpan: PropTypes.oneOfType([
//     PropTypes.number,
//     PropTypes.object,
//   ]),
//   authority: PropTypes.string.isRequired,
// }

TableFieldWrapper.defaultProps = {
  fieldProps: {},
  inputProps: {},
  colSpan: 24,
}

export default TableFieldWrapper
