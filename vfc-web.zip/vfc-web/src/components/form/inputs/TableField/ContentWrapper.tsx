import * as React from 'react'

class ContentWrapper extends React.Component<any> {
  public componentDidMount() {
    const { mountCallback } = this.props

    mountCallback()
  }

  public render() {
    const { mountCallback, ...props } = this.props
    return (<div {...props} />)
  }
}

export default ContentWrapper
