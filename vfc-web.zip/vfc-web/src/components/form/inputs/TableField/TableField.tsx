import * as React from 'react'
import Table, { TableProps, TableAction } from 'lb-components/lib/table'
import { ColumnProps } from 'lbc-wrapper/lib/table'
import Modal from 'lbc-wrapper/lib/modal'
import Button from 'lbc-wrapper/lib/button'
import pick from 'lodash/pick'
import _debug from 'lb-debug'
import isArray from 'lodash/isArray'
import isFunction from 'lodash/isFunction'
import ContentWrapper from './ContentWrapper'

import calPermission, { PERMISSIONS } from '../../utils/calPermission'
import Operation, { OPERATIONS, OP_TYPE } from './Operation'
import ACTIONS from './actions'
import { Omit } from '../../../../types/utils'

const INDEX_KEY = 'id'

type WithID<T> = T & { id: string }

export interface TableFieldBodyProps<T> extends Omit<TableProps<T>, 'onChange' | 'title'> {
  createLabel?: string
  serverReturnId?: boolean
  rowKey: string // 覆盖Table本身的rowKey
  useAjax?: boolean
  noAction?: boolean
  onCreateBegin?: (param?: any) => any
  onModifyBegin?: (param?: any) => any
  onViewBegin?: (param?: any) => any
  createHandler?: (param: any) => Promise<any>
  modifyHandler?: (param: any) => Promise<any>
  deleteHandler?: (param: any) => Promise<any>
  propsToModalContent?: any
  operations?: OP_TYPE[]
  pickUpIdFromResponse?: (record: T, rowKey: string) => string
  component: React.ComponentType<any>
  title: string // 实际上是Modal title
}

interface PropsInjecedByWrapper<T> {
  authority: PERMISSIONS
  value?: T[]
  onChange?: (value: any) => void // 使用any替换table本身的onChange
}

type TFP<T> = TableFieldBodyProps<T> & PropsInjecedByWrapper<T>

interface TableFieldBodyState<T> {
  visible: boolean
  currMode: PERMISSIONS | null
  currSelectIndex: number
  valueWithIndex?: T[]
  columns: Array<ColumnProps<T>>
  currentRecord: T | null
  mountCallback: () => void
}

const debug = _debug('vfc:TableField')

const MODE_CREATE = PERMISSIONS.CREATE
const MODE_MODIFY = PERMISSIONS.MODIFY
const MODE_VIEW = PERMISSIONS.READ

function removeRowkey(obj: {[index: string]: any} = {}, rowKey: string) {
  const keys = Object.keys(obj).filter(k => k !== rowKey)
  return pick(obj, keys)
}

class TableField<T> extends React.Component<TFP<T>, TableFieldBodyState<T>> {
  public static defaultProps = {
    rowKey: INDEX_KEY,
    useAjax: true,
    serverReturnId: true,
    pickUpIdFromResponse: (record: any, rowKey: string) => record[rowKey],
    propsToModalContent: {},
    onCreateBegin: (form: any) => form.resetFields(),
    idLabel: 'ID',
  }

  public static getDerivedStateFromProps(props: TFP<any>, state: TableFieldBodyState<any>) {
    return props.serverReturnId ? { valueWithIndex: props.value } : { valueWithIndex: (Array.isArray(props.value) && props.value.map((v, i) => ({ ...v, [INDEX_KEY]: i + 1 }))) || [] }
  }
  private actions: TableAction[]
  private submitting: boolean
  private comp: any

  constructor(props: TFP<T>) {
    super(props)

    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
    this.renderTable = this.renderTable.bind(this)
    this.onCreate = this.onCreate.bind(this)
    this.onModify = this.onModify.bind(this)
    this.onView = this.onView.bind(this)
    this.onDelete = this.onDelete.bind(this)
    this.onCancel = this.onCancel.bind(this)
    this.onOK = this.onOK.bind(this)
    this.onDeleteAction = this.onDeleteAction.bind(this)

    this.actions = [
      {
        ...ACTIONS.ADD,
        action: this.onCreate,
        key: 'add',
        label: props.createLabel || ACTIONS.ADD.label,
      },
    ]

    let opsWidth = 110 // 40 + 20 * (props.operations.length)

    const permis = calPermission(this.props.authority)

    let operations: OP_TYPE[] = [
      OPERATIONS.VIEW,
      OPERATIONS.MODIFY,
      OPERATIONS.DELETE,
    ]

    if (permis === PERMISSIONS.MODIFY) {
      operations = props.operations || operations
    } else if (permis === PERMISSIONS.READ) {
      operations = [
        OPERATIONS.VIEW,
      ]
      opsWidth = 60
    }

    if (isArray(props.operations)) {
      operations = props.operations
    }

    const ops:Array<ColumnProps<any>> = [
      {
        title: '操作',
        dataIndex: 'operations',
        key: 'operations',
        fixed: 'right',
        width: `${opsWidth}px`,
        render: (text: any, record: WithID<T>) => {
          const opts = isFunction(props.operations) ? props.operations(record) : operations
          return (
            <Operation
              operations={opts}
              viewHandler={() => this.onView(record)} // () => props.viewHandler(record)}
              modifyHandler={() => this.onModify(record)} // () => props.modifyHandler(record)}
              deleteHandler={() => this.onDelete(record)} // () => props.deleteHandler(record)}
              clickHandler={() => record} // () => props.deleteHandler(record)}
            />
          )
        },
      },
    ]

    this.state = {
      visible: false,
      currMode: null, // 当前操作类型
      currSelectIndex: 0,
      valueWithIndex: !props.serverReturnId ? props.value && props.value.map((v: any, i) => ({ ...v, [INDEX_KEY]: i + 1 })) : props.value,
      // columns: [...props.columns, ...ops],
      columns: [/*
        title: props.idLabel,
        dataIndex: props.rowKey
        key: props.rowKey,
      }, */ ...props.columns!, ...ops],
      currentRecord: null,
      mountCallback: () => { /* nothing */ }
    }

    this.submitting = false // 防止连续提交
  }



  public onCreate() {
    const { onCreateBegin } = this.props
    this.setState({
      visible: true,
      currMode: MODE_CREATE,
      mountCallback: () => onCreateBegin && onCreateBegin(this.comp),
    }) // , () => setTimeout(() => onCreateBegin(this.comp), 1000))
  }

  public onModify(record: WithID<T>) {
    const { rowKey, onModifyBegin } = this.props

    this.setState({
      visible: true,
      currMode: MODE_MODIFY,
      currSelectIndex: record[rowKey],
      currentRecord: record,
      mountCallback: () => (onModifyBegin ? onModifyBegin() : this.comp.setFieldsValue(removeRowkey(record, rowKey))),
    }) // , () => setTimeout(() => (onModifyBegin ? onModifyBegin() : this.comp.setFieldsValue(removeRowkey(record, rowKey))), 1000))
  }

  // onModify(selectedRowKeys) {
  //   console.log(selectedRowKeys)
  //   const { value, rowKey } = this.props
  //   const { valueWithIndex } = this.state
  //   console.log(value)
  //   const selectedRow = find(valueWithIndex, o => o[rowKey] === selectedRowKeys[0])
  //   this.setState({
  //     visible: true,
  //     currMode: MODE_MODIFY,
  //     currSelectIndex: selectedRowKeys[0],
  //   }, () => setTimeout(() => this.comp.setFieldsValue(selectedRow), 1))
  // }

  public onView(record: WithID<T>) {
    const { rowKey, onViewBegin } = this.props
    this.setState({
      visible: true,
      currMode: MODE_VIEW,
      currSelectIndex: record[rowKey],
      currentRecord: record,
      mountCallback: () => (onViewBegin ? onViewBegin() : this.comp.setFieldsValue(removeRowkey(record, this.props.rowKey))),
    }) // , () => setTimeout(() => (onViewBegin ? onViewBegin() : this.comp.setFieldsValue(removeRowkey(record, this.props.rowKey))), 1000))

  //   setTimeout(() => {
  //     console.log(record)
  //     this.comp.setFieldsValue(record)}, 1000)
  }

  // onView(selectedRowKeys) {
  //   const { value, rowKey } = this.props
  //   const { valueWithIndex } = this.state
  //   const selectedRow = find(valueWithIndex, o => o[rowKey] === selectedRowKeys[0])
  //   this.setState({
  //     visible: true,
  //     currMode: MODE_VIEW,
  //   }, () => setTimeout(() => this.comp.setFieldsValue(selectedRow), 1))
  // }

  public onDelete(record: WithID<T>) {
    const { value = [], onChange, rowKey, useAjax, deleteHandler } = this.props
    const { valueWithIndex } = this.state
    const promise = useAjax && deleteHandler ? deleteHandler(record) : Promise.resolve()
    promise.then((res) => {
      let i = 0;
      for (; i < value.length; i += 1) {
        if (valueWithIndex![i][rowKey] === record[rowKey]) {
          break
        }
      }

      if (onChange) {
        onChange([...value.slice(0, i), ...value.slice(i + 1)])
      }
    })
  }

  public onDeleteAction(selectedKeys: string[], selectedRows: Array<WithID<T>>) {
    this.onDelete(selectedRows[0])
  }

  // onDelete(selectedRowKeys) {
  //   const { value = [], onChange, rowKey } = this.props
  //   const { valueWithIndex } = this.state
  //   const selectedRow = find(valueWithIndex, o => o[rowKey] === selectedRowKeys[0])
  //   let i = 0;
  //   for (; i < value.length; i += 1) {
  //     if (valueWithIndex[i][rowKey] === selectedRow[rowKey]) {
  //       break
  //     }
  //   }
  //
  //   onChange([...value.slice(0, i), ...value.slice(i + 1)])
  //
  // }

  public onOK() {
    if (this.state.currMode === MODE_VIEW) {
      this.setState({
        visible: false,
      })

      return
    }
    const { value = [], onChange, rowKey, createHandler, modifyHandler, useAjax, serverReturnId, pickUpIdFromResponse } = this.props
    const { valueWithIndex, currSelectIndex } = this.state

    if (this.submitting) {
      return
    }

    this.submitting = true // 开始提交

    this.comp.validateFields((err: any, values: any) => {
      if (err) {
        console.error(err)
        this.submitting = false
        return
      }

      if (this.state.currMode === MODE_CREATE) {
        const promise = useAjax && createHandler ? createHandler(values) : Promise.resolve()
        promise.then((res) => {
          /*
           * 如果id是server返回的，那么要从server返回的数据中获取id
           * 如果server不返回id，则自己生成index
           */
          const id = serverReturnId ? { [rowKey]: pickUpIdFromResponse!(res, rowKey) } : {}
          if (onChange) {
            onChange([...value, { ...values, ...id }])
          }


          this.setState({
            visible: false,
          }, () => setTimeout(() => (this.submitting = false), 500))
        }, () => (this.submitting = false))
      } else if (this.state.currMode === MODE_MODIFY) {
        /*
         * 因为在打开编辑页面的时候，当前记录的ID是不会传递给打开的modal的
         * 这个id会存放在this.state.currSelectIndex里
         * 所以在提交编辑的ajax时，要重新组织提交的数据，是否包含ID
         */
        const v = serverReturnId ? { [rowKey]: currSelectIndex, ...values } : values
        const promise = useAjax && modifyHandler ? modifyHandler(v) : Promise.resolve()
        promise.then((res) => {
          let i = 0;
          for (; i < value.length; i += 1) {
            if (valueWithIndex && valueWithIndex[i][rowKey] === currSelectIndex) {
              break
            }
          }

          if (onChange) {
            onChange([...value.slice(0, i), v, ...value.slice(i + 1)])
          }

          this.setState({
            visible: false,
          }, () => setTimeout(() => (this.submitting = false), 500))
        }, () => (this.submitting = false))
      } else {
        this.setState({
          visible: false,
        }, () => setTimeout(() => (this.submitting = false), 500))
      }
    })
  }

  public onCancel() {
    this.setState({
      visible: false,
    })
  }

  public renderNormal() {
    const { value, columns, onChange, title, rowSelection, noAction, ...props } = this.props
    return (
      <Table
        data={this.state.valueWithIndex}
        columns={this.state.columns}
        {...props}
        actions={noAction ? [] : this.actions}
        rowSelection={undefined}
        position="left"
        size="default"
        bordered={false}
        // pagination={false}
      />
    )
  }

  public renderRead() {
    const { value, actions, columns, onChange, title, rowSelection, ...props } = this.props

    return (
      <Table
        data={this.state.valueWithIndex}
        columns={this.state.columns}
        rowSelection={undefined}
        actions={[]}
        size="middle"
        // pagination={false}
        {...props} />
    )
  }

  public renderTable() {
    debug('render')
    const permis = calPermission(this.props.authority)

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }

  public render() {
    const { title, propsToModalContent, value } = this.props
    const { visible, currMode } = this.state
    const Comp = this.props.component
    const t = currMode === MODE_CREATE ? '新增' : (currMode === MODE_MODIFY ? '修改' : '查看')

    const buttons = currMode === MODE_VIEW ? [
      <Button key="back" onClick={this.onCancel}>关闭</Button>,
    ] : [
      <Button key="back" onClick={this.onCancel}>取消</Button>,
      <Button key="submit" type="primary" onClick={this.onOK}>确认</Button>,
    ]
    return (
      <div>
        {
          this.renderTable()
        }
        <Modal
          title={`${title} - ${t}`}
          visible={visible}
          // onOk={this.onOK}
          onCancel={this.onCancel}
          // closable={false} commented by VFC-4473
          maskClosable={false}
          // okText="确认"
          // cancelText="取消"
          width={1000}
          destroyOnClose
          footer={buttons}
        >
          <ContentWrapper mountCallback={this.state.mountCallback}>
            <Comp
              ref={(tt: any) => { this.comp = tt }}
              mode={currMode}
              authority={currMode === MODE_VIEW ? PERMISSIONS.READ : PERMISSIONS.MODIFY}
              {...propsToModalContent}
              tableData={value}
              // currentRecord={currMode === MODE_MODIFY ? this.state.currentRecord : {}}
              currentRecord={currMode !== MODE_CREATE ? this.state.currentRecord : {}}
            />
          </ContentWrapper>
        </Modal>
      </div>
    )
  }
}

// TableField.propTypes = {
//   value: PropTypes.array,
//   onChange: PropTypes.func,
//   rowKey: PropTypes.string,
//   title: PropTypes.string.isRequired,
//   component: PropTypes.func.isRequired,
//   createHandler: PropTypes.func,
//   // viewHandler: PropTypes.func,
//   modifyHandler: PropTypes.func,
//   deleteHandler: PropTypes.func,
//   useAjax: PropTypes.bool,
//   authority: PropTypes.string.isRequired,
//   serverReturnId: PropTypes.bool,
//   pickUpIdFromResponse: PropTypes.func,
//   actions: PropTypes.array,
//   propsToModalContent: PropTypes.object,
//   createLabel: PropTypes.string,
//   onCreateBegin: PropTypes.func,
//   idLabel: PropTypes.string,
// }

export default TableField
