import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { OriginalInput } from 'lbc-wrapper/lib/input'
import Select from 'lbc-wrapper/lib/select'
import Col from 'lbc-wrapper/lib/col'
import Form, { SimpleFormItem } from 'lbc-wrapper/lib/form'
import _debug from 'lb-debug'

import calPermission, { PERMISSIONS } from '../utils/calPermission'
import { colSpan as defaultColSpan } from './consts'
import ReadSimpleValue from './readComp/ReadSimpleValue'
import ReadOptionsValue from './readComp/ReadOptionsValue'

import './inputs.scss'

const debug = _debug('vfc:InputWithSelectField')

class InputField extends Component {
  constructor(props) {
    super(props)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
  }

  renderNormal() {
    const { form, name, formItemProps = {}, fieldProps = {}, inputProps = {}, selectProps = {}, colSpan, authority } = this.props

    const { initialValue = [] } = fieldProps
    const { options = [] } = selectProps

    const { getFieldDecorator } = form

    const selectComp = getFieldDecorator(name[1], {
      initialValue: initialValue[1] || (options[0] && options[0].value),
    })(<Select {...selectProps} />)
    return (
      <Col span={colSpan} className="lb-col-gutter">
        <Form.Item {...formItemProps} authority={authority}>
          {
            getFieldDecorator(name[0], {
              ...fieldProps,
              initialValue: initialValue[0],
            })(<OriginalInput autoComplete="off" {...inputProps} addonAfter={selectComp} />)
          }
        </Form.Item>
      </Col>
    )
  }

  renderRead() {
    const { formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan, form, name, authority, selectProps } = this.props
    const { getFieldDecorator } = form
    const { initialValue = [] } = fieldProps
    const { options = [] } = selectProps

    return (
      <Col span={colSpan} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps} authority={authority}>
          {
            getFieldDecorator(name[0], {
              initialValue: initialValue[0],
            })(<ReadSimpleValue />)
          }
          {
            getFieldDecorator(name[1], {
              initialValue: initialValue[1] || (options[0] && options[0].value),
            })(<ReadOptionsValue options={options} />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  render() {
    debug('render')
    const permis = calPermission(this.props.authority)

    if (!this.props.show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }
}

InputField.propTypes = {
  form: PropTypes.shape({
    getFieldDecorator: PropTypes.func.isRequired,
  }).isRequired,
  name: PropTypes.array.isRequired,
  fieldProps: PropTypes.shape({
    initialValue: PropTypes.array,
    rules: PropTypes.array,
  }),
  formItemProps: PropTypes.shape({
    label: PropTypes.string,
  }),
  inputProps: PropTypes.object,
  colSpan: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.object,
  ]),
  authority: PropTypes.string.isRequired,
  show: PropTypes.bool,
}

InputField.defaultProps = {
  colSpan: defaultColSpan,
  show: true,
}

export default InputField
