import * as React from 'react'
import * as PropTypes from 'prop-types'
import Input, { InputPropsLB } from 'lbc-wrapper/lib/input'
import Col from 'lbc-wrapper/lib/col'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import _debug from 'lb-debug'

import calPermission, { PERMISSIONS } from '../utils/calPermission'
import { colSpan as defaultColSpan } from './consts'
import ReadSimpleValue from './readComp/ReadSimpleValue'
import './inputs.scss'
import { BaseInputProps } from './BaseInputProps'

const debug = _debug('vfc:InputField')

export interface InputFieldProps extends BaseInputProps {
  inputProps: InputPropsLB
  isLink?: boolean
  to?: string
}

class InputField extends React.Component<InputFieldProps, any> {
  public static propTypes = {
    form: PropTypes.shape({
      getFieldDecorator: PropTypes.func.isRequired,
    }).isRequired,
    name: PropTypes.string.isRequired,
    fieldProps: PropTypes.shape({
      // initialValue: PropTypes.string,
      rules: PropTypes.array,
    }),
    formItemProps: PropTypes.shape({
      label: PropTypes.string,
    }),
    inputProps: PropTypes.object,
    colSpan: PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.object,
    ]),
    authority: PropTypes.string.isRequired,
    show: PropTypes.bool,
    isLink: PropTypes.bool,
    to: PropTypes.string,
  }

  public static defaultProps = {
    colSpan: defaultColSpan,
    show: true,
    isLink: false,
  }

  constructor(props: InputFieldProps) {
    super(props)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
  }

  public renderNormal() {
    const { form, name, formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan } = this.props

    const { getFieldDecorator } = form
    return (
      <Col span={colSpan} style={this.props.style} className="lb-col-gutter">
        <SimpleFormItem {...formItemProps}>
          {
            getFieldDecorator(name, fieldProps)(<Input autoComplete="off" {...inputProps} />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  public renderRead() {
    const { formItemProps = {}, colSpan, form, name, fieldProps, isLink, to } = this.props
    const { getFieldDecorator } = form

    return (
      <Col span={colSpan} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps}>
          {
            getFieldDecorator(name, { initialValue: fieldProps.initialValue })(<ReadSimpleValue isLink={isLink} to={to} />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  public render() {
    debug('render')
    const permis = calPermission(this.props.authority)

    if (!this.props.show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }
}

export default InputField
