import * as React from 'react'
import * as PropTypes from 'prop-types'
import InputNumber, { InputNumberPropsLB } from 'lbc-wrapper/lib/inputNumber'
import Col from 'lbc-wrapper/lib/col'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import _debug from 'lb-debug'
// import toNumber from 'lodash/toNumber'
import calPermission, { PERMISSIONS } from '../utils/calPermission'
import { colSpan as defaultColSpan } from './consts'
import ReadSimpleValue from './readComp/ReadSimpleValue'
import precisionSplit from '../utils/precision'
import { BaseInputProps } from './BaseInputProps'

import './inputs.scss'

const debug = _debug('vfc:MoneyField')

export interface MoneyFieldProps extends BaseInputProps {
  inputProps: InputNumberPropsLB
  minPrecision?: number
  min?: number
  max?: number
}

function formatter(value: any) {
  const f = Math.round(value * 100) / 100;
  let s = f.toString();
  let rs = s.indexOf('.');
  if (rs < 0) {
    rs = s.length;
    s += '.';
  }
  while (s.length <= rs + 2) {
    s += '0';
  }
  return `${`${s}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')} 元`
}

class MoneyField extends React.Component<MoneyFieldProps> {
  public static propTypes = {
    form: PropTypes.shape({
      getFieldDecorator: PropTypes.func.isRequired,
    }).isRequired,
    name: PropTypes.string.isRequired,
    fieldProps: PropTypes.object,
    formItemProps: PropTypes.object.isRequired,
    inputProps: PropTypes.shape({
      min: PropTypes.number,
      precision: PropTypes.number,
    }),
    colSpan: PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.object,
    ]),
    authority: PropTypes.string.isRequired,
    show: PropTypes.bool,
    min: PropTypes.number,
    max: PropTypes.number,
  }

  public static defaultProps = {
    colSpan: defaultColSpan,
    inputProps: {
      min: 0,
      precision: 2,
    },
    show: true,
    max: 99999999999999.99,
    min: 0,
  }

  constructor(props: MoneyFieldProps) {
    super(props)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
    this.validator = this.validator.bind(this)
  }

  public validator(rule: any, value: number | string | undefined, callback: any) {
    const { min, max } = this.props

    if (value === undefined) {
      return callback()
    }

    const v: number = typeof value === 'string' ? parseFloat(value) : value

    if (min! > v) {
      return callback(`最小值为${min}`)
    } else if (max! < v) {
      return callback(`最大值为${max}`)
    } else {
      return callback()
    }
  }

  public renderNormal() {
    const { form, name, formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan, minPrecision = 2, min } = this.props

    const { rules = [], ...otherFieldProps } = fieldProps

    const { getFieldDecorator } = form
    return (
      <Col span={colSpan} style={this.props.style} className="lb-col-gutter">
        <SimpleFormItem {...formItemProps} label={`${formItemProps.label}(元)`} >
          {
            getFieldDecorator(name, {
              rules: [
                { validator: this.validator },
                ...rules,
              ],
              ...otherFieldProps,
            })(<InputNumber
              formatter={(value) => {
                if (value === undefined) {
                  return ''
                }
                const newV = precisionSplit(value, minPrecision, 14)
                return `${newV}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
                }
              }
              parser={(value: any): any => {
                // TODO: 强制使用any来禁用inputNumber的强制返回number
                if (value === undefined) {
                  return ''
                }
                const newV = value.replace(/\$\s?|(,*)/g, '')
                return precisionSplit(newV, minPrecision, 14)
              }}
              step={0.01}
              precision={2}
              min={min}
              {...inputProps}
            />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  public renderRead() {
    const { formItemProps = {}, colSpan, form, name, fieldProps } = this.props
    const { getFieldDecorator } = form

    return (
      <Col span={colSpan} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps} >
          {
            getFieldDecorator(name, { initialValue: fieldProps.initialValue })(<ReadSimpleValue formatter={formatter} />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  public render() {
    debug('---render field Money---')
    const permis = calPermission(this.props.authority)

    if (!this.props.show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }
}

export default MoneyField
