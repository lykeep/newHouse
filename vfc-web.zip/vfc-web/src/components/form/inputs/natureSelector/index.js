import { connect } from 'react-redux'
import NatureSelector from './NatureSelector'
import { queryNatureList } from './NatureSelectorModule'

const mapActionCreators = {
  queryNatureList,
}

const mapStateToProps = state => ({ })

export default connect(mapStateToProps, mapActionCreators)(NatureSelector)
