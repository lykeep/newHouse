import React, { Component } from 'react'
import NameFilterModal from '../nameFilterModal/NameFilterModal'
import legalIdTypesRender from '../../../columnRenders/legalIdTypes'

class NatureSelector extends Component {
  constructor(props) {
    super(props)

    this.onChange = this.onChange.bind(this)

    this.columns = [{
      title: 'ID',
      dataIndex: 'lpNo',
    }, {
      title: '名称',
      dataIndex: 'lpName',
    }, {
      title: '证件类型',
      dataIndex: 'creditNo',
      key: 'creditNo',
      render: legalIdTypesRender,
    }, {
      title: '证件号码',
      dataIndex: 'type',
      key: 'type',
    }]
  }

  onChange(values) {
    // this.props.onChange(vlaues)
  }

  render() {
    const { queryNatureList, onChange, ...props } = this.props

    return (
      <NameFilterModal
        modalData={{
            columns: this.columns,
        }}
        action={queryNatureList}
        modalKey="lpNoNameVos"
        receivekey={['copartnerName', 'copartnerNo']}
        formItemProps={{ label: '法人名称' }}
        fieldProps={{}}
        inputProps={{
            placeholder: '请输入',
            style: { width: '100%' },
        }}
        {...props}
      />
    )
  }
}

export default NatureSelector
