import { createFetchAction } from 'modules/common'

const COMMON_WIDGETS_QUERY_LEGAL_LIST = 'COMMON_WIDGETS_QUERY_LEGAL_LIST'

export const queryNatureList = createFetchAction(COMMON_WIDGETS_QUERY_LEGAL_LIST, 'vfc-bp-all.queryLpNoNameForAccess')
