import * as React from 'react'
import * as PropTypes from 'prop-types'
import InputNumber, { InputNumberPropsLB } from 'lbc-wrapper/lib/inputNumber'
import Col from 'lbc-wrapper/lib/col'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import calPermission, { PERMISSIONS } from '../utils/calPermission'
import { colSpan as defaultColSpan } from './consts'
import ReadSimpleValue from './readComp/ReadSimpleValue'
import precisionSplit from '../utils/precision'
import { BaseInputProps } from './BaseInputProps'

import './inputs.scss'
interface RateFieldProps extends BaseInputProps {
  inputProps: InputNumberPropsLB
  minPrecision?: number
  min?: number
  max?: number
  frontLength?: number
}

function formatter(value: string | number | undefined) {
  if (value === undefined) {
    return ''
  }

  return `${value}%`
}

class RateField extends React.Component<RateFieldProps> {
  public static propTypes = {
    form: PropTypes.shape({
      getFieldDecorator: PropTypes.func.isRequired,
    }).isRequired,
    name: PropTypes.string.isRequired,
    fieldProps: PropTypes.object,
    formItemProps: PropTypes.object.isRequired,
    inputProps: PropTypes.shape({
      min: PropTypes.number,
      precision: PropTypes.number,
    }),
    colSpan: PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.object,
    ]),
    authority: PropTypes.string.isRequired,
    show: PropTypes.bool,
    minPrecision: PropTypes.number, // 小数点后几位
    frontLength: PropTypes.number, // 小数点前几位
    max: PropTypes.number, // 最大可输入值
  }

  public static defaultProps = {
    colSpan: defaultColSpan,
    inputProps: {
      precision: 4,
    },
    show: true,
    minPrecision: 4,
    frontLength: 3,
    max: 100,
    min: 0,
  }

  constructor(props: RateFieldProps) {
    super(props)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
    this.validator = this.validator.bind(this)
  }

  public validator(rule: any, value: number | string | undefined, callback: any) {
    const { min, max } = this.props

    if (value === undefined) {
      return callback()
    }

    const v = typeof value === 'string' ? parseFloat(value) : value

    if (min! > v) {
      return callback(`最小值为${min}`)
    } else if (max! < v) {
      return callback(`最大值为${max}`)
    } else {
      return callback()
    }
  }

  public renderNormal() {
    const { form, name, formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan, minPrecision, frontLength } = this.props

    const { getFieldDecorator } = form
    return (
      <Col span={colSpan} style={this.props.style} className="lb-col-gutter">
        <SimpleFormItem {...formItemProps} label={`${formItemProps.label}(%)`} >
          {
            getFieldDecorator(name, {
              initialValue: fieldProps.initialValue,
              rules: [
                ...(fieldProps.rules || []),
                { validator: this.validator },
              ],
            })(<InputNumber
              formatter={value => typeof value === undefined ? '' : `${value}`} // precisionSplit(value, minPrecision, frontLength)}
              parser={(value): any => precisionSplit(value, minPrecision!, frontLength)}
              step={0.0001}
              precision={4}
              {...inputProps}
            />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  public renderRead() {
    const { formItemProps = {}, colSpan, form, name, fieldProps } = this.props
    const { getFieldDecorator } = form

    return (
      <Col span={colSpan} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps} >
          {
            getFieldDecorator(name, { initialValue: fieldProps.initialValue })(<ReadSimpleValue formatter={formatter} />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  public render() {
    const permis = calPermission(this.props.authority)

    if (!this.props.show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }
}

export default RateField
