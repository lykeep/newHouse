import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Form from 'lbc-wrapper/lib/form'
import Col from 'lbc-wrapper/lib/col'
import Input from 'lbc-wrapper/lib/input'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import calPermission, { PERMISSIONS } from '../utils/calPermission'
import { colSpan as defaultColSpan } from './consts'

class InputGroup extends Component {
  constructor(props) {
    super(props)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
  }

  renderNormal() {
    const { form, name, formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan } = this.props
    const { getFieldDecorator } = form
    return (
      <Col span={colSpan} className="lb-col-gutter">
        <SimpleFormItem {...formItemProps}>
          {
            getFieldDecorator(name, fieldProps)(<Form>{this.props.children}</Form>)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  renderRead() {
    const { formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan } = this.props
    return (
      <Col span={colSpan} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps}>
          <span>{fieldProps.initialValue || inputProps.value}</span>
        </SimpleFormItem>
      </Col>
    )
  }

  render() {
    const permis = calPermission(this.props.authority)

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }
}

export default InputGroup
