import React, { Component } from 'react'
import Input from 'lbc-wrapper/lib/input'

class HiddenField extends Component {
  renderNormal() {
    return null
  }

  render() {
    return (
      <Input type="hidden" />
    )
  }
}

export default HiddenField
