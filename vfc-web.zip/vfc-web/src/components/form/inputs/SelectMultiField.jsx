import React, { Component } from 'react'
import SelectMulti from 'lbc-wrapper/lib/select'
import PropTypes from 'prop-types'
import Col from 'lbc-wrapper/lib/col'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import calPermission, { PERMISSIONS } from '../utils/calPermission'
import { colSpan as defaultColSpan } from './consts'
import './SelectMultiField.scss'
import './inputs.scss'

class SelectMultiField extends Component {
  constructor(props) {
    super(props)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)

    this.state = {
      options: [],
    }
  }

  componentDidMount() {
    const { optionsLoader, optionFormatter, async } = this.props

    if (async && optionsLoader) {
      optionsLoader().then(res => this.setState({
        options: optionFormatter(res),
      }))
    }
  }

  renderNormal() {
    const { form, name, formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan, async, authority } = this.props
    const { getFieldDecorator } = form
    const options = async ? { options: this.state.options } : {}
    return (
      <Col span={colSpan} className="lb-col-gutter">
        <SimpleFormItem {...formItemProps} authority={authority}>
          {
              getFieldDecorator(name, fieldProps)(<SelectMulti mode="multiple" allowClear {...inputProps} {...options} />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  renderRead() {
    const { formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan, async, authority } = this.props
    const options = async ? this.state.options : inputProps.options

    return (
      <Col span={colSpan} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps} authority={authority}>
          {
            fieldProps.initialValue.map((value) => {
              for (let i = 0; i < options.length; i += 1) {
                if (value === options[i].value) {
                  return <span key={options[i].key} className="ant-select-multi">{options[i].title}</span>
                }
              }
            })
          }
        </SimpleFormItem>
      </Col>
    )
  }

  render() {
    const permis = calPermission(this.props.authority)

    if (!this.props.show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }
    // HIDE
    return null
  }
}

SelectMultiField.defaultProps = {
  colSpan: defaultColSpan,
  async: false,
  optionFormatter(res) { return res },
  show: true,
}

SelectMultiField.propTypes = {
  form: PropTypes.shape({
    getFieldDecorator: PropTypes.func.isRequired,
  }).isRequired,
  name: PropTypes.string.isRequired,
  fieldProps: PropTypes.shape({
    initialValue: PropTypes.array,
  }),
  formItemProps: PropTypes.object.isRequired,
  inputProps: PropTypes.shape({
    options: PropTypes.array.isRequired,
  }),
  colSpan: PropTypes.oneOfType([
    PropTypes.number.isRequired,
    PropTypes.object.isRequired,
  ]),
  async: PropTypes.bool,
  optionsLoader: PropTypes.func,
  optionFormatter: PropTypes.func,
  authority: PropTypes.string.isRequired,
  show: PropTypes.bool,
}

export default SelectMultiField
