import * as React from 'react'
import InputNumber, { InputNumberPropsLB } from 'lbc-wrapper/lib/inputNumber'
import Col from 'lbc-wrapper/lib/col'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import * as PropTypes from 'prop-types'
import _debug from 'lb-debug'
import calPermission, { PERMISSIONS } from '../utils/calPermission'
import { colSpan as defaultColSpan } from './consts'
import ReadSimpleValue from './readComp/ReadSimpleValue'
import { BaseInputProps } from './BaseInputProps'

import './inputs.scss'

const debug = _debug('vfc:InputNumberField')

function formatter(value: string | number) {
  return `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
}

export interface InputNumberFieldProps extends BaseInputProps {
  inputProps: InputNumberPropsLB & { format?: boolean }
}

class InputNumberField extends React.Component<InputNumberFieldProps> {
  public static propTypes = {
    form: PropTypes.shape({
      getFieldDecorator: PropTypes.func.isRequired,
    }),
    name: PropTypes.string.isRequired,
    formItemProps: PropTypes.shape({
      label: PropTypes.string.isRequired,
    }),
    fieldProps: PropTypes.shape({
      initialValue: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.string,
      ]),
    }),
    inputProps: PropTypes.shape({
      format: PropTypes.bool,
      value: PropTypes.number,
    }),
    colSpan: PropTypes.oneOfType([
      PropTypes.number,
      PropTypes.object,
    ]),
    authority: PropTypes.string.isRequired,
    show: PropTypes.bool,
  }

  public static defaultProps = {
    colSpan: defaultColSpan,
    show: true,
  }

  constructor(props: InputNumberFieldProps) {
    super(props)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
  }

  public renderNormal() {
    const { form, name, formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan, style } = this.props

    const { getFieldDecorator } = form
    return (
      <Col span={colSpan} style={style} className="lb-col-gutter">
        <SimpleFormItem {...formItemProps}>
          {
            getFieldDecorator(name, fieldProps)(<InputNumber autoComplete="off" {...inputProps} />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  public renderRead() {
    const { formItemProps = {}, inputProps = {}, colSpan, form, name, fieldProps } = this.props
    const { getFieldDecorator } = form

    return (
      <Col span={colSpan} className="lb-col-gutter ant-form-inline">
        <SimpleFormItem {...formItemProps}>
          {
            getFieldDecorator(name, { initialValue: fieldProps.initialValue })(<ReadSimpleValue formatter={inputProps.format ? formatter : undefined} />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  public render() {
    debug('render')

    if (!this.props.show) {
      return null
    }

    const permis = calPermission(this.props.authority)
    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    return null
  }
}

export default InputNumberField
