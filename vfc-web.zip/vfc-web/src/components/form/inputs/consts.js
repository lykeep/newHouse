export const colSpan = 8

export const formItemLayout = {
  labelCol: {
    xs: { span: 24 },
    sm: { span: 5 },
    xl: { span: 9 },
    xxl: { span: 6 },
  },
  wrapperCol: {
    xs: { span: 24 },
    sm: { span: 18 },
    xl: { span: 15 },
    xxl: { span: 18 },
  },
}
