import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Textarea from 'lbc-wrapper/lib/textArea'
import Col from 'lbc-wrapper/lib/col'
import _debug from 'lb-debug'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import calPermission, { PERMISSIONS } from '../utils/calPermission'
import { colSpan as defaultColSpan } from './consts'
import './inputs.scss'

import ReadMultiLineValue from './readComp/ReadMultiLineValue'

const debug = _debug('vfc:SelectField')

class TextareaField extends Component {
  constructor(props) {
    super(props)
    this.renderNormal = this.renderNormal.bind(this)
    this.renderRead = this.renderRead.bind(this)
  }

  renderNormal() {
    const { form, name, formItemProps = {}, fieldProps = {}, inputProps = {}, colSpan, authority } = this.props
    const { getFieldDecorator } = form
    return (
      <Col span={colSpan} className="lb-col-gutter">
        <SimpleFormItem {...formItemProps} authority={authority}>
          {
            getFieldDecorator(name, fieldProps)(<Textarea {...inputProps} />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  renderRead() {
    const { formItemProps = {}, colSpan, authority, name, form, fieldProps = {} } = this.props
    const { getFieldDecorator } = form
    return (
      <Col span={colSpan} className="lb-col-gutter">
        <SimpleFormItem {...formItemProps} authority={authority}>
          {
            getFieldDecorator(name, { initialValue: fieldProps.initialValue })(<ReadMultiLineValue />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  render() {
    debug('render')
    const permis = calPermission(this.props.authority)

    if (!this.props.show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }
}

TextareaField.propTypes = {
  form: PropTypes.shape({
    getFieldDecorator: PropTypes.func.isRequired,
  }).isRequired,
  name: PropTypes.string.isRequired,
  fieldProps: PropTypes.shape({
    initialValue: PropTypes.string,
    rules: PropTypes.array,
  }),
  formItemProps: PropTypes.shape({
    label: PropTypes.string,
  }),
  inputProps: PropTypes.shape({
    options: PropTypes.array,
    value: PropTypes.string,
  }),
  colSpan: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.object,
  ]),
  authority: PropTypes.string.isRequired,
  show: PropTypes.bool,
}

TextareaField.defaultProps = {
  colSpan: defaultColSpan,
  show: true,
}

export default TextareaField
