export default function loadGroups(groups) {
  const pagePromises = groups.map(g => import(`../${g}`))
  return Promise.all(pagePromises)
}
