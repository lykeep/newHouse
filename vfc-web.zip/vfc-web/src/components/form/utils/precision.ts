export default (value: number | string | undefined, pre: number, front = 14): string => {
  const strValue = value === undefined ? '' : `${value}`

  const parts = strValue.split('.')
  if (parts.length < 2) {
    return strValue.substring(0, front)
  }

  if (pre === 0) {
    return parts[0]
  }

  return `${parts[0].substring(0, front)}.${parts[1].substring(0, pre)}`
}
