export enum PERMISSIONS {
  READ = '1',
  HIDE = '99',
  MODIFY = '2',
  CREATE = '0',
  CREATE_CHANGE = '98',
}

export default function calPermission(authority: PERMISSIONS) {
  return authority
}
