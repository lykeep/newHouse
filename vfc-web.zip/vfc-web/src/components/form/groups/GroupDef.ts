import { PERMISSIONS } from "../utils/calPermission"

// import * as React from 'react'
export interface GroupDef {
  groupId: string
  authority?: string
  title: string,
  forceRender?: boolean,
  path?: string,
  // component: () => React.ComponentType,
  component: () => any
}

export interface GroupToShow {
  groupId: string
  authority: PERMISSIONS
  group_id?: string
}

export interface GroupDefFromServer {
  fieldName: string
  // authority: string
  // groupId?: string
  inputElementType: 'Hidden' | 'ReadOnly' | 'Editable'
}

export interface MapActionCreators {
  [index: string]: any
}

export type MapStateToProps = (state: any) => {[index: string]: any}
