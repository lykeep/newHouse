import * as React from 'react'
import * as PropTypes from 'prop-types'
import Form from 'lbc-wrapper/lib/form'
import Card from 'lbc-wrapper/lib/card'
import _debug from 'lb-debug'
import { connect } from 'react-redux'
import get from 'lodash/get'
import { MapActionCreators, MapStateToProps } from './GroupDef'

import { getFormFiels, getFormsFromStore, updateActiveForm } from '../../../modules/forms'
// import { updateFormFields as uFF, getFormFiels, getFormsFromStore, updateActiveForm } from '../../../modules/forms'
import { PERMISSIONS } from '../utils/calPermission'
import './formWrapper.scss'
import { WrappedGroupBaseProps } from './wrappedGroupBaseProps'

const debug = _debug('vfc:wrapFormContainer')

const SPLITOR = '@@'

export interface GroupFormWrapperOptions {
  title?: string
  mapActionCreators?: MapActionCreators
  mapStateToProps?: MapStateToProps
  mustValidate?: boolean
  dataIsArray?: boolean
}

type HOC<PWrapped, PHOC> = React.ComponentClass<PWrapped & PHOC> | React.SFC<PWrapped & PHOC>

// TODO: 必须继承FormComponentProps，而不能写在HOC里，我怀疑是Antd的bug


export default function registerWrapper<P extends WrappedGroupBaseProps>(
  name: string,
  opts: GroupFormWrapperOptions | string = {},
  mapActionCreators: MapActionCreators = {},
  mapStateToProps: MapStateToProps = () => ({}),
  mustValidate = false,
  dataIsArray = false
) {
  if (!name) {
    console.error('form wrapper: name is undefined!')
    throw new Error('name is undefined!')
  }

  let title: string | undefined
  if (typeof opts !== 'string') {
    title = opts.title
    mapActionCreators = opts.mapActionCreators || mapActionCreators
    mapStateToProps = opts.mapStateToProps || mapStateToProps
    mustValidate = opts.mustValidate || mustValidate
    dataIsArray = opts.dataIsArray || dataIsArray
  } else {
    title = opts
  }


  if (name.toLowerCase().indexOf('change') > 0 && !mustValidate) {
    console.error('变更信息必须强制验证，mustValidate不能为false！')
    mustValidate = true
    // throw new Error('变更信息必须强制验证，mustValidate不能为false！')
  }

  if (name.toLowerCase().indexOf('approv') > 0 && !mustValidate) {
    console.error('审批信息必须强制验证，mustValidate不能为false！')
    mustValidate = true
    // throw new Error('变更信息必须强制验证，mustValidate不能为false！')
  }

  const newMapActionCreators = {
    // TODO: 后续再增加updateFormFields的实现
    // updateFormFields: data => uFF(name, data),
    updateActiveForm,
    ...mapActionCreators,
  }

  const newMapStateToProps = (state: any) => Object.assign(
    {},
    {
      formMetadata: getFormFiels(getFormsFromStore(state), name),
    },
    mapStateToProps(state),
  )


  return function formWrapper(WrappedComponent: HOC<P, any>) {
    const WrappedFormComp = Form.create({})(WrappedComponent)
    // TODO: change any to real type
    class Wrap extends React.PureComponent<any> {
      public static contextTypes = {
        pageName: PropTypes.string,
        tabName: PropTypes.string,
        inTabWrapper: PropTypes.bool,
      }

      public ref: any

      public componentDidMount() {
        const { authority } = this.props
        const { pageName, tabName } = this.context
        debug('componentDidMount', authority)
        if (PERMISSIONS.READ !== authority) {
          // 如果只读，就不记录form实例
          this.props.updateActiveForm({
            pageName,
            name: (tabName ? `${tabName}${SPLITOR}${name}` : name),
            data: this.ref,
            mustValidate,
          })
        }
      }

      // public updateFormMetadata = (data: any) => {
      //   this.props.updateFormFields(`${this.context.pageName}.${name}`, data)
      // }

      public render() {
        debug('render')
        const { updateFormFields, groupIdToDataMap = {}, data = {}, ...props } = this.props
        const { inTabWrapper } = this.context
        const initValue = dataIsArray ? [] : {}
        return (
          <Card title={title} style={{ marginBottom: '16px' }} bordered={!inTabWrapper} className="ant-card-wider-padding">
            {/* <WrappedFormComp {...props} data={get(data, groupIdToDataMap[name]) || initValue} updateFormMetadata={this.updateFormMetadata} ref={(t) => { this.ref = t }} /> */}
            <WrappedFormComp {...props} data={get(data, groupIdToDataMap[name]) || initValue} ref={(t) => { this.ref = t }} />
          </Card>
        )
      }
    }

    return connect(newMapStateToProps, newMapActionCreators)(Wrap)
  }
}
