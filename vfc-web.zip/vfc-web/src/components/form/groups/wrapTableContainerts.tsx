import * as React from 'react'
import * as PropTypes from 'prop-types'
import Card from 'lbc-wrapper/lib/card'
import { connect } from 'react-redux'
import _debug from 'lb-debug'
import get from 'lodash/get'
import { SimpleRow } from 'lbc-wrapper/lib/row'
import shallowDif from '../../utils/shallowDif'
import { MapActionCreators, MapStateToProps } from './GroupDef'

const debug = _debug('vfc:creditTableWrapper')

const removeActiveForms = (props: any) => {
  const { activeForms, ...thisProps } = props

  return thisProps
}

interface WrapperProps {
  onChange: any
  value: any[]
  data: any
  groupIdToDataMap: {
    [index: string]: string
  }
}

interface WrapperState {
  value: any[]
  inited: boolean
}

interface WrapperContext {
  inTabWrapper: boolean
}

export interface WrappedTableBaseProps {
  data: any[]
  form: any

}

export default function creditTableWrapper<P extends WrappedTableBaseProps>(
  name: string,
  title: string,
  mapActionCreators?: MapActionCreators,
  mapStateToProps?: MapStateToProps,
  useExternalStore?: boolean,
  noCard?: boolean
) {
  if (!name) {
    console.error('table wrapper: name is undefined!')
    throw new Error('name is undefined!')
  }

  if (useExternalStore) {
    if (!Object.keys(mapActionCreators || {}).some(k => k === 'onChange')) {
      console.error('table wrapper: must have onChange in mapActionCreators!')
      throw new Error('must have onChange in mapActionCreators!')
    }
  }

  const didConnect: boolean = mapActionCreators || mapStateToProps ? true : false

  return function formWrapper(WrappedComponent: React.ComponentType<P>) {
    class Wrap extends React.Component<WrapperProps, WrapperState, WrapperContext> {
      public static contextTypes = {
        inTabWrapper: PropTypes.bool,
      }

      constructor(props: WrapperProps) {
        super(props)

        this.onChange = this.onChange.bind(this)
        this.initValue = this.initValue.bind(this)

        this.state = {
          value: [],
          inited: false,
        }
      }

      public shouldComponentUpdate(nextProps: WrapperProps, nextState: WrapperState) {
        // activeForms是从上层组件（tab，page）传过来的，这样会导致不必要的刷新，所以不要比较activeForms
        return shallowDif(removeActiveForms(this.props), removeActiveForms(nextProps)) || shallowDif(this.state, nextState)
      }

      public onChange(value: any[]) {
        this.setState({
          value,
        })
      }

      public initValue(value: any[]) {
        if (!this.state.inited) {
          this.setState({
            value,
            inited: true,
          })
        }
      }

      public render() {
        debug('---------- render----------')
        const onChange = useExternalStore ? this.props.onChange : this.onChange
        const value = useExternalStore ? this.props.value : this.state.value
        const initValue = useExternalStore ? null : this.initValue

        const { inTabWrapper } = this.context
        const { groupIdToDataMap = {}, data = {}, ...props } = this.props

        debug(value)

        if (noCard) {
          return (
            <SimpleRow>
              <WrappedComponent {...this.props} form={{ value, onChange, initValue }} data={get(data, groupIdToDataMap[name]) || []} />
            </SimpleRow>
          )
        }

        return (
          <Card title={title} style={{ marginBottom: '16px' }} bordered={!inTabWrapper} className="ant-card-wider-padding">
            <SimpleRow>
              <WrappedComponent form={{ value, onChange, initValue }} {...props} data={get(data, groupIdToDataMap[name]) || []}/>
            </SimpleRow>
          </Card>
        )
      }
    }

    return didConnect ? connect(mapStateToProps, mapActionCreators)(Wrap) : Wrap
  }
}
