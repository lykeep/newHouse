import { PERMISSIONS } from '../utils/calPermission'
import { GroupDefFromServer, GroupDef, GroupToShow } from './GroupDef'

enum PerMap {
  ReadOnly = PERMISSIONS.READ,
  Editable = PERMISSIONS.MODIFY,
}

const HIDDEN = 'Hidden'
const READONLY = 'ReadOnly'

function calculateGroups(allGroups: GroupDef[], groupsToShow: GroupDefFromServer[] = [], isView?: boolean): GroupToShow[] {
  const gMap = {}
  allGroups.forEach(g => (gMap[g.groupId] = g))

  return groupsToShow.filter(g => g.inputElementType !== HIDDEN && gMap[g.fieldName]).map(gg => Object.assign({}, gMap[gg.fieldName], { authority: isView ? PERMISSIONS.READ : PerMap[gg.inputElementType] })).filter(g => g.groupId)
}

export function shouldCallBigSive(groupsToShow: GroupDefFromServer[] = []) {
  return groupsToShow.filter(g => g.inputElementType !== HIDDEN).every(g => g.inputElementType !== READONLY)
}

/**
 * 给产品的流程使用的计算group的方法
 * @param  {array}  allGroups                      所有可显示的group的集合
 * @param  {Array}   [groupsToShowFromWorkFlow=[]] 从工作流获得的待显示的group集合
 * @param  {Array}   [groupToShowFromProduct=[]]   从产品获得的待显示的group的集合
 * @param  {Boolean} isView                        是否只读
 * @return {Array}                                 所有group
 */
export function calculateGroupsForProduct(
  allGroups: GroupDef[],
  groupsToShowFromWorkFlow: GroupDefFromServer[] = [],
  groupToShowFromProduct: GroupDefFromServer[] = [],
  isView?: boolean
): GroupToShow[] {
  const groupsToShow: GroupDefFromServer[] = []
  const gtFromProd = {}
  groupToShowFromProduct.forEach(g => (gtFromProd[g.fieldName] = g))
  groupsToShowFromWorkFlow.forEach((g) => {
    // 在产品的里面找这个group
    const gInProd = gtFromProd[g.fieldName]
    if (!gInProd) {
      // 没找到，则使用流程定义返回的group
      groupsToShow.push(g)
    } else {
      // 找到了，则看产品返回的是不是隐藏
      if (gInProd.inputElementType === HIDDEN) {
        // 隐藏，则跳过这个group
      } else {
        // 不隐藏，则按流程里的展示
        groupsToShow.push(g)
      }
    }
  })

  return calculateGroups(allGroups, groupsToShow, isView)
}

export default calculateGroups
