import { PERMISSIONS } from '../utils/calPermission'
import { FormComponentProps } from 'lbc-wrapper/lib/form'

export interface WrappedGroupBaseProps extends FormComponentProps {
  authority: PERMISSIONS
  data: any
  bizKey: string // bid
  applyType: string
  businessKey: string // bpid
}
