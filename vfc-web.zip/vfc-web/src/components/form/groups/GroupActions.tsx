import * as React from 'react'
import calPermission, { PERMISSIONS } from '../utils/calPermission'
import './GroupActions.scss'
import renderButton from '../page/renderButton'
import { PermissionButton } from '../page/PermissionButton'

export interface GroupActionsProps {
  actions?: PermissionButton[]
  authority: PERMISSIONS
}

class GroupActions extends React.Component<GroupActionsProps> {
  public shouldComponentUpdate(nextProps: GroupActionsProps) {
    return this.props.actions !== nextProps.actions
  }

  public render() {
    const { actions = [], authority } = this.props
    const permis = calPermission(authority)

    let acts = actions

    if (permis === PERMISSIONS.READ) {
      acts = actions.filter(a => a.alwaysShow)

      if (acts.length === 0) {
        return null
      }
    }

    return (
      <div className="lb-group-actions">
        {
          acts.map(b => <div className="button-item" key={b.key || b.id}>{renderButton(b)}</div>)
        }
      </div>
    )
  }
}

export default GroupActions
