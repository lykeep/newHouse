export interface Tabhelper {
  getsearch: () => any
  closeothersamepathtab: () => void
  dispatch: (action: string, data?: any) => any
  subscribe: (callback: (type: string) => void) => () => void
  closetab: () => void
}
