import { ButtonPropsLB } from 'lbc-wrapper/lib/button'

export type PermissionButton = ButtonPropsLB & {
  label: string
  key: string // render用唯一索引
  comp_id: string // 权限返回的id
  alwaysShow?: boolean
}
