import * as React from 'react'
import * as PropTypes from 'prop-types'
import Tabs, { TabPane } from 'lbc-wrapper/lib/tabs'
import LoadingGrid from '../../loadingGrid'
import { GroupDef, GroupToShow } from '../groups/GroupDef'

import './PageLoader.scss'
import { PERMISSIONS } from '../utils/calPermission'
import PageMode from '../../../common/pageMode'

export interface PageLoaderProps {
  bizKey: string  // 业务编号，businessNo, bid
  applyType: string // 申请类型
  businessKey: string // 申请编号, bpid
  defaultSelectedKey: string // 默认选择的tab的key
  loading: boolean
  data: any
  groups: GroupToShow[]
  tabs: GroupDef[]
  authority?: PERMISSIONS
  pageMode?: PageMode
}

interface PageLoaderOptionsProps {
  [index: string]: any
}

export interface PageLoaderState {
  loading: boolean
  selectedKey: string
}

type PageLoaderAllProps = PageLoaderProps & PageLoaderOptionsProps

class PageLoader extends React.Component<PageLoaderAllProps, PageLoaderState> {
  public static propTypes = {
    tabs: PropTypes.array.isRequired,
    groups: PropTypes.array,
    data: PropTypes.object,
    loading: PropTypes.bool.isRequired,
    groupIdToDataMap: PropTypes.object.isRequired,
    defaultSelectedKey: PropTypes.string.isRequired,
  }

  public static defaultProps = {
    groups: [],
  }

  constructor(props: PageLoaderAllProps) {
    super(props)

    this.renderTabs = this.renderTabs.bind(this)
    this.renderLoading = this.renderLoading.bind(this)
    this.onChange = this.onChange.bind(this)
    this.displayMe = this.displayMe.bind(this)

    this.state = {
      loading: false,
      selectedKey: props.defaultSelectedKey || '',
    }
  }

  public onChange(selectedKey: string): void {
    this.setState({
      selectedKey,
    })
  }

  public displayMe(selectedKey: string): void {
    this.setState({
      selectedKey,
    })
  }

  public renderTabs(): JSX.Element {
    const { groups, data, tabs, ...props } = this.props

    const groupsMap = {}
    groups.forEach(g => (groupsMap[g.group_id || g.groupId] = g))

    let selectedKey = this.state.selectedKey || tabs[0].groupId
    let selectedKeyOK = false

    const toDisplay: GroupDef[] = []
    tabs.forEach((tab) => {
      if (groupsMap[tab.groupId]) {
        if (tab.groupId === selectedKey) {
          selectedKeyOK = true
        }
        toDisplay.push({ ...tab, authority: groupsMap[tab.groupId].authority })
      }
    })

    if (!selectedKeyOK) {
      selectedKey = tabs[0].groupId
    }

    return (
      <Tabs animated={false} activeKey={selectedKey || toDisplay[0].groupId} onChange={this.onChange}>
        {
          toDisplay.map((g) => {
            const Comp = g.component()
            return (
              <TabPane key={g.groupId} tab={g.title} forceRender={g.forceRender}>
                <div className="lb-tab-container">
                  <Comp data={data} {...props} authority={g.authority} displayMe={this.displayMe} />
                </div>
              </TabPane>
            )
          })
        }
      </Tabs>
    )
  }

  public renderLoading(): JSX.Element {
    return (
      <div className="lb-page-loading-container">
        <LoadingGrid count={4} />
      </div>
    )
  }

  public render(): JSX.Element {
    return (this.state.loading || this.props.loading) ? this.renderLoading() : this.renderTabs()
  }
}

export default PageLoader
