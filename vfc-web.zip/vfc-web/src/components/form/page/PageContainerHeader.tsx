import * as React from 'react'
import renderButton from './renderButton'
import { PermissionButton } from './PermissionButton'
import './PageContainer.scss'

export interface PageContainerHeaderProps {
  title: string
  loading: boolean
  actions?: PermissionButton[]
}

class PageContainerHeader extends React.Component<PageContainerHeaderProps> {
  public static defaultProps = {
    actions: [],
    loading: true,
  }

  public shouldComponentUpdate(nextProps: PageContainerHeaderProps) {
    return this.props.title !== nextProps.title ||
      this.props.actions !== nextProps.actions ||
      this.props.loading !== nextProps.loading
  }

  public render() {
    const { title, actions, loading } = this.props
    return (
      <div className="lb-page-container-header">
        <div className="title">{title}</div>
        <div className="buttons">
          {
            loading || !actions ? null : actions.map(a => renderButton(a))
          }
        </div>
      </div>
    )
  }
}

export default PageContainerHeader
