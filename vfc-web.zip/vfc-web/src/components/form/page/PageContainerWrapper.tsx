import * as React from 'react'
import * as PropTypes from 'prop-types'
import _debug from 'lb-debug'
import { RouteComponentProps } from 'react-router-dom'
import { connect } from 'react-redux'
import { SyncAction } from '../../../modules/common'
import { GroupToShow } from '../../form/groups/GroupDef'
import { Tabhelper } from './tabhelperDef'

import { initForm as initFormRenamed, destroyForm as desForm, getFormsFromStore, getActiveForms, getMustValidateForms } from '../../../modules/forms'
import './PageContainer.scss'

const SPLITOR = '@@'

const extractFromTabs = (names = '') => {
  const ns = names.split(SPLITOR)
  return ns[1] || ns[0]
}

export type RetrieveAllDataCombiner = (values: any, id?: string) => any

const retrieveAllData = (activeForms: any, mustValidateForms: any, reqMapIds: any, formTitleMap: {[index: string]: string}, combiner: RetrieveAllDataCombiner) => {
  const allFormKeys = Object.keys(activeForms)
  const toBeValidatedFormKeys = allFormKeys.filter((key) => {
    // 如果在mustValidateForms里，则必须验证
    if (mustValidateForms[key]) {
      return true
    }

    // 不在，则看这个form里是否填了东西
    const allDatas = activeForms[key]().getFieldsValue()
    return Object.keys(allDatas).some(k => allDatas[k])
  })

  return toBeValidatedFormKeys.map((key) => {
    return new Promise((resolve, reject) => {
      activeForms[key]().validateFields((errors: any, values: any) => {
        const type = extractFromTabs(key)

        if (errors) {
          reject({
            key: type,
            message: formTitleMap[type],
          })
        } else {
          resolve({
            [reqMapIds[type]]: combiner(values, type),
          })
        }
      })
    })
  })
}

const debug = _debug('vfc:pageContainerWrapper')

interface PageWrapperDispatchProps {
  destroyForm: (value: any) => SyncAction
  initForm: (value: any) => SyncAction
}

interface PageWrapperStateToProps {
  activeForms: any
  mustValidateForms: any
}

export interface WrappedPageBaseState {
  loading: boolean
  submiting: boolean
  bizKey: string // pid
  businessKey: string // bpid
  applyType: string
  groups: GroupToShow[]
  data: any
  processId?: string // PID
  taskId?: string // TID
}

// export interface WrappedApprovalPageBaseState extends WrappedPageBaseState{
//   workflowActions: ACTION_ALLOWED[]
//   backNodeList: any[]
//   nextActivity: any
// }

export interface WrappedPageBaseProps extends PageWrapperStateToProps {
  extractFromTabs: (name?: string) => string
  retrieveAllData: typeof retrieveAllData
  tabhelper: Tabhelper
}

export interface PageWrapperOption {
  name: string
}

export default function pageContainerWrapper<P extends WrappedPageBaseProps>(opts: PageWrapperOption) {
  const mapStateToProps = (state: any): PageWrapperStateToProps => ({
    activeForms: getActiveForms(getFormsFromStore(state), opts.name),
    mustValidateForms: getMustValidateForms(getFormsFromStore(state), opts.name),
  })

  const mapActionCreators:PageWrapperDispatchProps = {
    initForm: initFormRenamed,
    destroyForm: desForm,
  }

  return (Comp: React.ComponentType<P>) => {
    // TODO: change any to real type
    class WrapperComp extends React.PureComponent<PageWrapperDispatchProps & PageWrapperStateToProps> {
      // public static propTypes = {

      // }
      public static childContextTypes = {
        pageName: PropTypes.string,
      }

      constructor(props: PageWrapperDispatchProps & PageWrapperStateToProps) {
        super(props)

        props.initForm({
          name: opts.name,
        })
      }
      public getChildContext() {
        return { pageName: opts.name }
      }

      public componentWillUnmount() {
        this.props.destroyForm({
          name: opts.name,
        })
      }

      public render() {
        debug('render')
        const { initForm, destroyForm, ...props } = this.props as PageWrapperDispatchProps & WrappedPageBaseProps
        return (
          <div className="lb-page-container">
            <Comp extractFromTabs={extractFromTabs} retrieveAllData={retrieveAllData} {...props} />
          </div>
        )
      }
    }

    return connect<PageWrapperStateToProps, PageWrapperDispatchProps, RouteComponentProps<any>>(mapStateToProps, mapActionCreators)(WrapperComp)
  }
}
