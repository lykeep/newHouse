import * as React from 'react'
import Button from 'lbc-wrapper/lib/button'
import { PermissionButton } from './PermissionButton'

const RenderButton: React.SFC<PermissionButton> = (button) => (<Button {...button}>{button.label}</Button>)

export default RenderButton
