import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import pick from 'lodash/pick'

import { getActiveForms, updateActiveForm as upAF, getFormsFromStore } from '../../../modules/forms'
import './tabPageWrapper.scss'

const SPLITOR = '@@'

const extractFromTabs = (names = '') => {
  const ns = names.split(SPLITOR)
  return ns[1] || ns[0]
}

export default function tabPageWrapper(name, mapActionCreators = {}, mapStateToProps = () => ({})) {
  const newMapActionCreators = {
    updateActiveForm: upAF,
    ...mapActionCreators,
  }

  const newMapStateToProps = state => Object.assign(
    {},
    {
      activeForms: getActiveForms(getFormsFromStore(state)),
    },
    mapStateToProps(state),
  )

  return (Comp) => {
    class WrapperComp extends Component {
      getChildContext() {
        return { tabName: name, inTabWrapper: true }
      }

      shouldComponentUpdate(nextProps) {
        const { pageName } = this.context
        const keys = Object.keys(this.props)
        for (let i = 0; i < keys.length; i += 1) {
          if (keys[i] === 'activeForms') {
            if (this.props.activeForms[pageName] !== nextProps.activeForms[pageName]) {
              return true
            }
          }

          if (this.props[keys[i]] !== nextProps[keys[i]]) {
            return true
          }
        }
        return false
      }

      render() {
        const { activeForms, ...props } = this.props
        const { pageName } = this.context

        const myKeys = Object.keys(activeForms[pageName]).filter(k => (k.indexOf(`${name}${SPLITOR}`) > -1))
        return (
          <div className="lb-tab-wrapper">
            <Comp {...props} activeForms={pick(activeForms[pageName], myKeys)} extractFromTabs={extractFromTabs} />
          </div>
        )
      }
    }

    WrapperComp.propTypes = {
      activeForms: PropTypes.object,
      updateActiveForm: PropTypes.func,
    }

    WrapperComp.childContextTypes = {
      tabName: PropTypes.string,
      inTabWrapper: PropTypes.bool,
    }

    WrapperComp.contextTypes = {
      pageName: PropTypes.string,
    }

    return connect(newMapStateToProps, newMapActionCreators)(WrapperComp)
  }
}
