import * as React from 'react'
import * as PropTypes from 'prop-types'
// import ReactDOM from 'react-dom'

export interface WrapIFrameProps {
  src: string
}
class IFrameWrapper extends React.PureComponent<WrapIFrameProps> {
  public static propTypes = {
    src: PropTypes.string,
  }

  constructor(props: WrapIFrameProps) {
    super(props)

    this.state = {
      iFrameHeight: '100px',
    }
  }

  public render() {
    const { src } = this.props
    return (
      <iframe
        title="风 控"
        style={{ height: 'calc(100vh - 115px)' }}
        // onLoad={() => {
        //   const obj = ReactDOM.findDOMNode(this);
        //   this.setState({
        //       iFrameHeight:  obj.contentWindow.document.body.scrollHeight + 'px'
        //   })
        // }}
        // ref="iframe"
        src={src}
        width="100%"
        frameBorder="0"
      />
    )
  }
}

export default IFrameWrapper
