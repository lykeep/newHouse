import React from 'react'
import LoadingGrid from '../loadingGrid'

import './loadingPage.less'

const LoadingPage = () => (
  <div className="lb-loading-page">
    <LoadingGrid count={5} />
  </div>
)

export default LoadingPage
