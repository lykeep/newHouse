import * as React from 'react'
import Modal from 'lbc-wrapper/lib/modal'
import Button from 'lbc-wrapper/lib/button'
import { ColumnProps } from 'lbc-wrapper/lib/table'
import { connect } from 'react-redux'

import { buildSelectOptions } from '../../common/utils'

import takeTaskCallback from './GetCheckListModule'
import takenStatus from './const'

import QueryTable, { Field } from '../queryTable'

export interface GetCheckListProps<T> {
  columns: Array<ColumnProps<T>>
  query: (param: any) => Promise<any>
  listKey: string
  rowKey?: any
  visible: boolean
  onCancelCallback: () => void
  takeTask: (param: any) => Promise<any>
  onSelectCallback: (param: T) => void
  bizApplyTypeLabels: object
}

interface GetCheckListState<T> {
  data: T[]
  totalCount: number | string
}

interface GetCheckListData {
  taskInstanceId: string
}

class GetCheckList<T extends GetCheckListData> extends React.Component<GetCheckListProps<T>, GetCheckListState<T>> {
  private columns: Array<ColumnProps<T>>
  private fields: Field[][]

  constructor(props: GetCheckListProps<T>) {
    super(props)
    this.query = this.query.bind(this)
    this.onCancel = this.onCancel.bind(this)

    this.columns = props.columns.concat([
      {
        key: 'opr',
        title: '操作',
        dataIndex: 'opr',
        width: 60,
        render: (text: string, record: T) => (<a onClick={() => this.onClick(record)} role="button" >选择</a>),
      },
    ]).map((c) => {
      delete c.fixed
      return c
    })

    this.fields = [
      [
        { id: 'businessKey', label: '申请编号', component: 'Input' },
        { id: 'busiApplyType', label: '申请类型', type: 'Select', options: buildSelectOptions(props.bizApplyTypeLabels) },
      ],
    ]

    this.state = {
      data: [],
      totalCount: '0',
    }
  }

  public onCancel() {
    this.props.onCancelCallback()
  }

  public onClick(record: T) {
    const { takeTask, onSelectCallback } = this.props

    takeTask({
      taskInstanceId: record.taskInstanceId,
    }).then(() => {
      onSelectCallback(record)
    })
  }

  public query(params: any): Promise<any> {
    return this.props.query({
      ...params,
      claimType: takenStatus.UNTAKEN,
    }).then((data) => {
      this.setState({
        data: data[this.props.listKey],
        totalCount: data.total,
      })
    })
  }

  public render() {
    const { rowKey } = this.props
    return (
      <Modal
        visible={this.props.visible}
        title="领取任务"
        closable={false}
        maskClosable={false}
        footer={<Button onClick={this.onCancel}>取消</Button>}
        width={1200}
        destroyOnClose
      >
        <QueryTable<T>
          data={this.state.data}
          rowSelection={undefined}
          columns={this.columns}
          fields={this.fields}
          query={this.query}
          rowKey={rowKey}
          totalCount={this.state.totalCount}
          size="small"
          actions={[]}
          recordsPerPage={5}
        />
      </Modal>
    )
  }
}

export default connect(() => ({}), { takeTask: takeTaskCallback })(GetCheckList)
