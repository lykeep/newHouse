import { createFetchAction } from '../../modules/common'

const APPROVAL_TABLE_TAKE_TASK = 'APPROVAL_TABLE_TAKE_TASK'

const takeTask = createFetchAction(APPROVAL_TABLE_TAKE_TASK, 'vfc-intf-ent-base.taskClaim')

export default takeTask
