import * as React from 'react'
import * as PropTypes from 'prop-types'
import QueryTable, { QueryTableProps, TableAction, Field } from '../queryTable'
import { ColumnProps } from 'lbc-wrapper/lib/table'
import ACTIONS from '../queryTable/consts'

import Status, { HANDLING } from '../status'
import takenStatus from './const'
import GetCheckList from './GetCheckList'

import ApplyNoWrapper from '../ApplyNoWrapper/ApplyNoWrapper'
import { buildColumnRender, buildSelectOptions } from '../../common/utils'
import { handleStatusOptions, flowStatusOptions } from '../../common/workflow'
import { Tabhelper } from '../form/page/tabhelperDef'
import { Omit } from '../../types/utils'


export interface ApprovalTableData {
  businessKey: string
  busiApplyType: string
  taskNodeName: string
  procStarterName: string
  startTime: string
  actualCompleteTime: string
  procState: string
  taskState: string
  taskInstanceId: string
  procInstanceId: string
  statusType: string
  uiName: string
}
export interface ApprovalTableProps<T> extends QueryTableProps<T> {
  bizKeyUrl: (value: string, record: T) => string
  bizApplyTypeLabels: object
  listKey: string
  tabhelper: Tabhelper
}

interface ApprovalTableState<T> {
  data: T[]
  modalVisible: boolean
  totalCount: string|number
}

class ApprovalTable<T> extends React.Component<ApprovalTableProps<T & ApprovalTableData>, ApprovalTableState<T>> {
  public static defaultProps = {
    columns: [],
    actions: [],
    listKey: 'list',
  }

  public static propTypes = {
    actions: PropTypes.array,
    columns: PropTypes.array,
    fields: PropTypes.array,
    query: PropTypes.func.isRequired,
    bizKeyUrl: PropTypes.func.isRequired,
    bizApplyTypeLabels: PropTypes.object.isRequired,
    listKey: PropTypes.string,
  }

  private columns: Array<ColumnProps<T>>
  private selectModalColumns: Array<ColumnProps<Omit<T & ApprovalTableData, 'businessKey'|'startTime'|'actualCompleteTime'>>>
  private actions: TableAction[]
  private fields: Field[][]
  private tableRef: QueryTable<T> | null

  constructor(props: ApprovalTableProps<T & ApprovalTableData>) {
    super(props)

    this.onGetTask = this.onGetTask.bind(this)
    this.query = this.query.bind(this)
    this.refresh = this.refresh.bind(this)
    this.onSelectCallback = this.onSelectCallback.bind(this)
    this.onCancelCallback = this.onCancelCallback.bind(this)

    const columnsPart0 = [
      {
        title: '申请编号',
        dataIndex: 'businessKey',
        key: 'businessKey',
        render: (value: string, record: T & ApprovalTableData) => (<ApplyNoWrapper value={value} to={props.bizKeyUrl(value, record)} />),
      },
    ]
    const columnsPart1 = [
      {
        title: '申请类型',
        dataIndex: 'busiApplyType',
        key: 'busiApplyType',
        render: buildColumnRender(props.bizApplyTypeLabels),
      },
      {
        title: '流程节点',
        dataIndex: 'taskNodeName',
        key: 'taskNodeName',
      },
      {
        title: '流程创建人',
        dataIndex: 'procStarterName',
        key: 'procStarterName',
      },
    ]
    const columnsPart2 = [
      {
        title: '任务开始时间',
        dataIndex: 'startTime',
        key: 'startTime',
      },
      {
        title: '任务结束时间',
        dataIndex: 'actualCompleteTime',
        key: 'actualCompleteTime',
      },
    ]
    const columnsPart3: Array<ColumnProps<any>> = [
      {
        title: '流程状态',
        dataIndex: 'procState',
        key: 'procState',
        render: (value: string) => (<Status status={value} />),
      },
      {
        title: '处理状态',
        dataIndex: 'taskState',
        key: 'taskState',
        width: '75px',
        fixed: 'right',
        render: (value: string) => (<Status status={value} type={HANDLING} />),
      },
    ]

    this.columns = [...columnsPart0, ...props.columns!, ...columnsPart1, ...columnsPart2, ...columnsPart3]

    this.selectModalColumns = props.columns!.concat(columnsPart1, columnsPart3)

    const a: TableAction[] = [
      {
        ...ACTIONS.GET_APPROVETASK,
        action: this.onGetTask,
      },
    ]

    this.actions = a.concat(this.props.actions!)

    this.fields = [
      [
        { id: 'businessKey', label: '申请编号', component: 'Input' },
        { id: 'busiApplyType', label: '申请类型', type: 'Select', options: buildSelectOptions(props.bizApplyTypeLabels) },
      ],
      [
        { id: 'procStarterName', label: '创建人' },
        { id: 'taskState', label: '处理状态', type: 'Select', options: handleStatusOptions },
        { id: 'procState', label: '流程状态', type: 'Select', options: flowStatusOptions },
      ],
    ]


    this.state = {
      modalVisible: false,
      data: [],
      totalCount: '0'
    }
  }

  public onGetTask(selectedRowKeys: any[], selectedRows: object[]) {
    this.setState({
      modalVisible: true,
    })
  }

  public onSelectCallback() {
    this.setState({
      modalVisible: false,
    })
    if (this.tableRef) {
      this.tableRef.refresh()
    }
  }

  public onCancelCallback() {
    this.setState({
      modalVisible: false,
    })
  }

  public query(params: any): Promise<any> {
    return this.props.query({
      ...params,
      claimType: takenStatus.TAKEN,
    }).then((data) => {
      this.setState({
        data: data[this.props.listKey],
        totalCount: data.total,
      })
    })
  }

  public refresh() {
    if (this.tableRef) {
      this.tableRef.refresh()
    }
  }

  public render() {
    const { columns, actions, query, tabhelper, ...props } = this.props

    const parsed = tabhelper.getsearch()

    this.fields = [
      [
        { id: 'businessKey', label: '申请编号', component: 'Input' },
        { id: 'busiApplyType', label: '申请类型', type: 'Select', options: buildSelectOptions(props.bizApplyTypeLabels), defaultValue: parsed.bat },
      ],
      [
        { id: 'procStarterName', label: '创建人' },
        { id: 'taskState', label: '处理状态', type: 'Select', options: handleStatusOptions, defaultValue: parsed.whs },
        { id: 'procState', label: '流程状态', type: 'Select', options: flowStatusOptions },
      ],
    ]

    return (
      <div>
        <QueryTable<T>
          ref={r => (this.tableRef = r)}
          columns={this.columns}
          fields={this.fields}
          actions={this.actions}
          query={this.query}
          data={this.state.data}
          totalCount={this.state.totalCount}
          rowKey="taskInstanceId"
          {...props}
        />
        <GetCheckList
          columns={this.selectModalColumns}
          visible={this.state.modalVisible}
          query={query}
          onSelectCallback={this.onSelectCallback}
          onCancelCallback={this.onCancelCallback}
          {...props}
        />
      </div>
    )
  }
}

export default ApprovalTable
