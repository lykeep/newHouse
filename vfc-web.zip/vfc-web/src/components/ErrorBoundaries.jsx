import React, { Component } from 'react'

class ErrorBoundaries extends Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }

  componentDidCatch(error, info) {
  // Display fallback UI
    this.setState({
      hasError: true,
      error,
      info,
    });
  }

  render() {
    if (this.state.hasError) {
      // You can render any custom fallback UI
      return (
        <div style={{ padding: '32px', color: 'red' }}>
          <h2>Oops, Something went wrong! Show this page to development team for help.</h2>
          <h3>Build Time: {process.env.REACT_APP_BUILD_TIME}</h3>
          <details style={{ whiteSpace: 'pre-wrap' }}>
            {this.state.error && this.state.error.stack}
            <br />
            <br />
            ComponentStack:
            {this.state.info.componentStack}
          </details>
        </div>
      )
    }

    return this.props.children
  }
}

const inDev = ({ ...props }) => props.children

export default process.env.NODE_ENV === 'development' ? inDev : ErrorBoundaries
