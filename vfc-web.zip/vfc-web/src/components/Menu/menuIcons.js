import React from 'react'
import './menuIcon.scss'

const env = process.env.REACT_APP_DWY

export const MenuIcon = props => (
  <i className={`anticon vfc_menu_icon ${props.type} ${env&&'dwy'}`}></i>
)

export default MenuIcon