import React, { Component } from 'react'
import PropTypes from 'prop-types'
import MenuWrapper, { Item as MenuItem, SubMenu } from 'lbc-wrapper/lib/menu'
import PerfectScrollbar from 'perfect-scrollbar'
import './Menu.scss'
import MenuIcon from './menuIcons'


class Menu extends Component {
  constructor(props) {
    super(props)

    this.state = {
      currentMenuKey: null,
    }

    this.menuClick = this.menuClick.bind(this)

    this.scrollbar = null
    this.ps = null
  }
  componentDidMount() {
    this.ps = new PerfectScrollbar(this.scrollbar, {
      suppressScrollX: true,
    })
  }
  componentWillUnmount() {
    this.ps.destroy()
    this.ps = null
  }
  onOpenChange() {
    this.ps.update()
  }
  menuClick(e) {
    const { history, menuList } = this.props
    let childs = null
    const menusfilter = (menus) => {
      e.keyPath.reverse().some(menuId =>
        menus.some((menu) => {
          if (menu.menuUrl === menuId || menu.menuId === menuId) {
            childs = menu.subMenuList
            if (childs && childs.length > 0) {
              menusfilter(childs)
            } else {
              history.push(menu.menuUrl)
            }
            return true
          }
        }))
    }
    menusfilter(menuList)
    this.setState({ currentMenuKey: e.key })
  }
  render() {
    const { autoshow, forceGemini, onResize, minThumbSize, menuList, location, ...other } = this.props

    return (
      <div
        ref={(node) => {
          this.scrollbar = node
        }}
        style={{height: 'calc(100vh - 64px)', position: 'relative', overflow: 'hidden'}}
      >
        <MenuWrapper
          mode="inline"
          onClick={this.menuClick}
          selectedKeys={/*[this.state.currentMenuKey]*/[location.pathname]}
          forceSubMenuRender
          onOpenChange={this.onOpenChange.bind(this)}
        >
          {menuList.map(i =>
              (i.subMenuList ? (
                <SubMenu
                  key={i.menuUrl || i.menuId}
                  title={
                    <span>
                      <MenuIcon type={`icon_${i.menuId}`} />
                      <span>{i.menuName}</span>
                    </span>
                  }
                >
                  {i.subMenuList.map(j =>
                      (j.subMenuList ? (
                        <SubMenu
                          key={j.menuUrl || j.menuId}
                          title={
                            <span>
                              <span>{j.menuName}</span>
                            </span>
                          }
                        >
                          {j.subMenuList.map(k => (
                            <MenuItem key={k.menuUrl || k.menuId}>
                              <span>{k.menuName}</span>
                            </MenuItem>
                          ))}
                        </SubMenu>
                      ) : (
                        <MenuItem key={j.menuUrl || j.menuId}>
                          <span>{j.menuName}</span>
                        </MenuItem>
                      )))}
                </SubMenu>
              ) : (
                <MenuItem key={i.menuUrl || i.menuId}>
                  <MenuIcon type={`icon_${i.menuId}`} />
                  <span>{i.menuName}</span>
                </MenuItem>
              )))}
        </MenuWrapper>
      </div>
    )
  }
}

Menu.propTypes = {
  autoshow: PropTypes.bool,
  forceGemini: PropTypes.bool,
  onResize: PropTypes.func,
  minThumbSize: PropTypes.number,
  menuList: PropTypes.array,
  history: PropTypes.object,
}

Menu.defaultProps = {
  autoshow: false,
  forceGemini: false,
  minThumbSize: 20,
  menuList: [],
}

Menu.contextTypes = {
  scrollArea: PropTypes.object,
}

export default Menu
