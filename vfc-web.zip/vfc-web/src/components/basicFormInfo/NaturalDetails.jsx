import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import InputField from '../form/inputs/InputField'
import InputNumberField from '../form/inputs/InputNumberField'
import IntegerField from '../form/inputs/IntegerField'
import DatePickerField from '../form/inputs/DatePickerField'
import SelectField from '../form/inputs/SelectField'
import MoneyField from '../form/inputs/MoneyField'
import IdTypesField from '../form/inputs/IdTypesField'
import CityField from '../form/inputs/CityField/CityField'
import { emailPattern } from '../utils/validators'
import { validZipCode, validZipCodeMessage, validName, validNameMessage, validPhoneName, validPhoneNameMessage } from '../../validators/common'
import {
  validLicenceIssuing,
  validLicenceIssuingMessage,
  validGraduateInstitutions,
  validGraduateInstitutionsMessage,
  validWechatId,
  validWechatIdMessage,
  validEmail,
  validEmailMessage,
  validQqNum,
  validQqNumMessage,
  validPossitiveNumber,
  validPossitiveNumberMessage,
} from '../../validators/np'

class NaturalDetails extends Component {
  constructor(props) {
    super(props)
    const { data } = this.props
    this.state = {
      marriageStatus: data.marriageStatus,
    }

    this.verifyingMailbox = this.verifyingMailbox.bind(this)
    this.marriageChange = this.marriageChange.bind(this)

    this.trueOrFalse = [
      {
        label: '是',
        value: 'true',
        key: 'A0',
      },
      {
        label: '否',
        value: 'false',
        key: 'A1',
      },
    ]

    this.custCategory = [
      { title: '农村客户', value: '00', key: '00' },
      { title: '城市客户', value: '01', key: '01' },
    ]

    this.hukouType = [
      { title: '城镇户口', value: '00', key: '00' },
      { title: '农业户口', value: '01', key: '01' },
    ]

    this.liveStatus = [
      { title: '租房', value: '00', key: '00' },
      { title: '本地有住房（无贷款）', value: '01', key: '01' },
      { title: '本地有住房（有贷款）', value: '02', key: '02' },
      { title: '异地自有住房(无贷款) ', value: '03', key: '03' },
      { title: '异地自有住房(有贷款) ', value: '04', key: '04' },
      { title: '无自有住房', value: '05', key: '05' },
    ]

    this.custType = [
      { title: '领薪人士', value: '00', key: '00' },
      { title: '一般受薪人士', value: '01', key: '01' },
      { title: '优良职业', value: '02', key: '02' },
      { title: '公务员', value: '03', key: '03' },
      { title: '事业单位员工', value: '04', key: '04' },
      { title: '金融机构员工', value: '05', key: '05' },
      { title: '部队中高级干部', value: '06', key: '06' },
      { title: '自雇人士', value: '07', key: '07' },
      { title: '个体工商户', value: '08', key: '08' },
      { title: '私营企业主', value: '09', key: '09' },
      { title: '自由职业', value: '10', key: '10' },
      { title: '小企业实际控制人', value: '11', key: '11' },
      { title: '农户', value: '12', key: '12' },
      { title: '学生', value: '13', key: '13' },
      { title: '其他', value: '14', key: '14' },
      { title: '未知', value: '15', key: '15' },
    ]

    this.highestEducation = [
      { title: '博士及以上', value: '00', key: '00' },
      { title: '研究生', value: '01', key: '01' },
      { title: '大学本科', value: '02', key: '02' },
      { title: '大学专科', value: '03', key: '03' },
      { title: '中等职业教育', value: '04', key: '04' },
      { title: '普通高级中学教育', value: '05', key: '05' },
      { title: '初级中学教育', value: '06', key: '06' },
      { title: '小学教育', value: '07', key: '07' },
    ]

    this.highestDegree = [
      { title: '学士', value: '00', key: '00' },
      { title: '硕士', value: '01', key: '01' },
      { title: '名誉博士', value: '02', key: '02' },
      { title: '其他', value: '03', key: '03' },
    ]
    this.marriageStatus = [
      { title: '已婚', value: '00', key: '00' },
      { title: '未婚', value: '01', key: '01' },
      { title: '离异', value: '02', key: '02' },
      { title: '丧偶', value: '03', key: '03' },
    ]

    this.spouseIdType = [
      { title: '已婚', value: '00', key: '00' },
      { title: '未婚', value: '01', key: '01' },
    ]
    this.famliyStructure = [
      { title: '有未成年子女', value: '00', key: '00' },
      { title: '有子女都成年', value: '01', key: '01' },
      { title: '无子女', value: '02', key: '02' },
    ]
  }

  verifyingMailbox(rule, value, callback) {
    const reg = new RegExp(emailPattern)
    if (value && !(reg.test(value))) {
      callback('The input is not valid E-mail!')
    } else {
      callback();
    }
  }
  marriageChange(e) {
    this.setState({
      marriageStatus: e,
    })
  }
  /*
  *自然人详情信息
  *1.disabled 默认 false
  */
  render() {
    const { form, data, authority, disabled = false } = this.props
    return (
      <div>
        <Form>
          <Row gutter={16} type="flex" align="top">
            <SelectField
              form={form}
              authority={authority}
              name="custCategory"
              formItemProps={{ label: '客户类别' }}
              fieldProps={{
                initialValue: data.custCategory,
              }}
              inputProps={{
                disabled,
                options: this.custCategory,
                placeholder: '请选择',
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="custType"
              formItemProps={{ label: '客户类型' }}
              fieldProps={{
                initialValue: data.custType,
              }}
              inputProps={{
                disabled,
                options: this.custType,
                placeholder: '请选择',
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="issuingOrgan"
              formItemProps={{ label: '发证机关' }}
              fieldProps={{
                initialValue: data.issuingOrgan,
                rules: [
                  { pattern: validLicenceIssuing, message: validLicenceIssuingMessage },
                ],
              }}
              inputProps={{
                disabled,
                placeholder: '请输入',
              }}
            />
            <DatePickerField
              form={form}
              authority={authority}
              name="credentialsIssueDate"
              formItemProps={{ label: '证件签发日期' }}
              fieldProps={{
                initialValue: data.credentialsIssueDate,
              }}
              inputProps={{
                disabled,
                placeholder: '请选择',
              }}
            />
            <DatePickerField
              form={form}
              authority={authority}
              name="credentialsInvalidDate"
              formItemProps={{ label: '证件失效日期' }}
              fieldProps={{
                initialValue: data.credentialsInvalidDate,
              }}
              inputProps={{
                disabled,
                placeholder: '请选择',
              }}
            />
            <CityField
              form={form}
              authority={authority}
              name={['idProvince', 'idCity', 'idArea']}
              formItemProps={{ label: '身份证地址' }}
              fieldProps={{
                initialValue: [data.idProvince, data.idCity, data.idArea],
              }}
              inputProps={{
                placeholder: '省/市/地区',
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="idAddress"
              formItemProps={{ label: '身份证详细地址' }}
              fieldProps={{
                initialValue: data.idAddress,
                rules: [
                  { min: 2, max: 128, message: '长度为2-128' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="hukouType"
              formItemProps={{ label: '户口类型' }}
              fieldProps={{
                initialValue: data.hukouType,
              }}
              inputProps={{
                disabled,
                options: this.hukouType,
                placeholder: '请选择',
              }}
            />
            <CityField
              form={form}
              authority={authority}
              name={['communPro', 'communCity', 'communArea']}
              formItemProps={{ label: '通讯地址' }}
              fieldProps={{
                initialValue: [data.communPro, data.communCity, data.communArea],
              }}
              inputProps={{
                placeholder: '省/市/地区',
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="communAddress"
              formItemProps={{ label: '通讯详细地址' }}
              fieldProps={{
                initialValue: data.communAddress,
                rules: [
                  { min: 2, max: 128, message: '长度为2-128' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                maxLength: 128,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="communZip"
              formItemProps={{ label: '通讯地址邮编' }}
              fieldProps={{
                initialValue: data.communZip,
                rules: [
                  { pattern: validZipCode, message: validZipCodeMessage },
                ],
              }}
              inputProps={{
                disabled,
                placeholder: '请输入',
              }}
            />
            <CityField
              form={form}
              authority={authority}
              name={['liveProvince', 'liveCity', 'liveArea']}
              formItemProps={{ label: '居住地址' }}
              fieldProps={{
                initialValue: [data.liveProvince, data.liveCity, data.liveArea],
              }}
              inputProps={{
                placeholder: '省/市/地区',
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="liveAddress"
              formItemProps={{ label: '居住详细地址' }}
              fieldProps={{
                initialValue: data.liveAddress,
                rules: [
                  { min: 2, max: 128, message: '长度为2-128' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                maxLength: 128,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="liveAddressZip"
              formItemProps={{ label: '居住地址邮编' }}
              fieldProps={{
                initialValue: data.liveAddressZip,
                rules: [
                  { pattern: validZipCode, message: validZipCodeMessage },
                ],
              }}
              inputProps={{
                disabled,
                placeholder: '请输入',
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="liveStatus"
              formItemProps={{ label: '居住状况' }}
              fieldProps={{
                initialValue: data.liveStatus,
              }}
              inputProps={{
                disabled,
                options: this.liveStatus,
                placeholder: '请选择',
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="graduationSchool"
              formItemProps={{ label: '毕业院校' }}
              fieldProps={{
                initialValue: data.graduationSchool,
                rules: [
                  { pattern: validGraduateInstitutions, message: validGraduateInstitutionsMessage },
                ],
              }}
              inputProps={{
                disabled,
                placeholder: '请输入',
              }}
            />
            <DatePickerField
              form={form}
              authority={authority}
              name="graduationTime"
              formItemProps={{ label: '毕业时间' }}
              fieldProps={{
                initialValue: data.graduationTime,
              }}
              inputProps={{
                disabled,
                placeholder: '请选择',
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="highestEducation"
              formItemProps={{ label: '最高学历' }}
              fieldProps={{
                initialValue: data.highestEducation,
              }}
              inputProps={{
                disabled,
                options: this.highestEducation,
                placeholder: '请选择',
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="highestDegree"
              formItemProps={{ label: '最高学位' }}
              fieldProps={{
                initialValue: data.highestDegree,
              }}
              inputProps={{
                disabled,
                options: this.highestDegree,
                placeholder: '请选择',
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="marriageStatus"
              formItemProps={{ label: '婚姻状况' }}
              fieldProps={{
                initialValue: data.marriageStatus,
              }}
              inputProps={{
                onChange: this.marriageChange,
                disabled,
                options: this.marriageStatus,
                placeholder: '请选择',
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="famliyStructure"
              formItemProps={{ label: '家庭结构' }}
              fieldProps={{
                initialValue: data.famliyStructure,
              }}
              inputProps={{
                disabled,
                options: this.famliyStructure,
                placeholder: '请选择',
              }}
            />
            <IdTypesField
              form={form}
              authority={authority}
              name={['spouseIdType', 'spouseIdNo']}
              label={['配偶证件类型', '配偶证件号码']}
              colSpan={16}
              show={this.state.marriageStatus === '00'}
              fieldProps={{
                rules: [
                  { required: false },
                ],
                initialValue: { spouseIdType: data.spouseIdType, spouseIdNo: data.spouseIdNo },
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="spouseName"
              show={this.state.marriageStatus === '00'}
              formItemProps={{ label: '配偶姓名' }}
              fieldProps={{
                initialValue: data.spouseName,
                rules: [
                  { pattern: validName, message: validNameMessage },
                ],
              }}
              inputProps={{
                disabled,
                placeholder: '请输入',
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="phone"
              show={this.state.marriageStatus === '00'}
              formItemProps={{ label: '联系电话' }}
              fieldProps={{
                initialValue: data.phone,
                rules: [
                  { pattern: validPhoneName, message: validPhoneNameMessage },
                ],
              }}
              inputProps={{
                disabled,
                placeholder: '请输入',
              }}
            />
            <IntegerField
              form={form}
              authority={authority}
              name="childNum"
              formItemProps={{ label: '子女数' }}
              canZero
              fieldProps={{
                initialValue: data.childNum,
                rules: [{ pattern: validPossitiveNumber, message: validPossitiveNumberMessage }],
              }}
              inputProps={{
                disabled,
                placeholder: '请输入',
              }}
            />
            <MoneyField
              key="monthIncome"
              form={form}
              authority={authority}
              name="monthIncome"
              formItemProps={{ label: '月收入' }}
              fieldProps={{
                initialValue: data.monthIncome,
              }}
              inputProps={{
                disabled,
                placeholder: '请输入',
              }}
            />
            <MoneyField
              key="famliyMonthOutcome"
              form={form}
              authority={authority}
              name="famliyMonthOutcome"
              formItemProps={{ label: '每月家庭支出' }}
              fieldProps={{
                initialValue: data.famliyMonthOutcome,
              }}
              inputProps={{
                disabled,
                placeholder: '请输入',
              }}
            />
            <InputNumberField
              form={form}
              authority={authority}
              name="supportFamilyNum"
              canZero
              formItemProps={{ label: '供养亲属人数' }}
              fieldProps={{
                initialValue: data.supportFamilyNum,
                rules: [{ pattern: validPossitiveNumber, message: validPossitiveNumberMessage }],
              }}
              inputProps={{
                disabled,
                placeholder: '请输入',
              }}
            />
            <InputField
              key="wx"
              form={form}
              authority={authority}
              name="wx"
              formItemProps={{ label: '微信号' }}
              fieldProps={{
                initialValue: data.wx,
                rules: [
                  { pattern: validWechatId, message: validWechatIdMessage },
                ],
              }}
              inputProps={{
                disabled,
                placeholder: '请输入',
              }}
            />
            <InputField
              key="email"
              form={form}
              authority={authority}
              name="email"
              formItemProps={{ label: '电子邮箱' }}
              fieldProps={{
                initialValue: data.email,
                rules: [
                  { required: false, message: '电子邮箱必输！' },
                  { pattern: validEmail, message: validEmailMessage },
                ],
              }}
              inputProps={{
                disabled,
                placeholder: '请输入',
              }}
            />
            <InputNumberField
              key="qq"
              form={form}
              authority={authority}
              name="qq"
              formItemProps={{ label: 'QQ号' }}
              fieldProps={{
                initialValue: data.qq,
                rules: [
                  { pattern: validQqNum, message: validQqNumMessage },
                ],
              }}
              inputProps={{
                disabled,
                placeholder: '请输入',
              }}
            />
          </Row>
        </Form>
      </div>
    )
  }
}

NaturalDetails.propTypes = {
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  data: PropTypes.object,
  disabled: PropTypes.bool,
}

export default NaturalDetails
