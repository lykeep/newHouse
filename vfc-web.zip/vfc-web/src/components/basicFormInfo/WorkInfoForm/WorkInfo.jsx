import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import SelectField from '../../form/inputs/SelectField'
import PayInfoForm from './PayInfoForm'
import SelfEmployedInfoForm from './SelfEmployedInfoForm'
import dictType from '../../../../src/routes/partners/natural/common/dictType'

class WorkInfo extends Component {
  constructor(props) {
    super(props)

    this.situationChange = this.situationChange.bind(this)
    this.isShow = this.isShow.bind(this)
    this.state = {
      work_flag: [
        { title: '受薪', value: '00', key: '00' },
        { title: '自雇', value: '01', key: '01' },
        { title: '无业/失业', value: '02', key: '02' }],
    }
  }


  componentDidMount() {
    const { data } = this.props
    this.setState({
      isSituationShow: data.work_flag || 'undefined',
    })
  }
  situationChange(e) {
    this.props.form.resetFields()
    this.setState({
      isSituationShow: e,
    })
  }
  isShow() {
    if (this.state.isSituationShow === dictType.paySalary) {
      return <PayInfoForm {...this.props} />
    } else if (this.state.isSituationShow === dictType.selfEmployed) {
      return <SelfEmployedInfoForm {...this.props} />
    }
    return null
  }

  render() {
    const { form, data, authority, disabled = false } = this.props
    return (
      <div>
        <Form>
          <Row gutter={16} type="flex" align="top">
            <SelectField
              form={form}
              authority={authority}
              name="work_flag"
              formItemProps={{ label: '供职情况' }}
              fieldProps={{
                initialValue: data.work_flag,
                rules: [{ required: true, message: '供职情况为必选项！' }],
              }}
              inputProps={{
                options: this.state.work_flag,
                onChange: this.situationChange,
                placeholder: '请选择',
                disabled,
              }}
            />
          </Row>
          <Row>
            {this.isShow()}
          </Row>
        </Form>
      </div>
    )
  }
}
WorkInfo.propTypes = {
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  data: PropTypes.object.isRequired,
}
export default WorkInfo
