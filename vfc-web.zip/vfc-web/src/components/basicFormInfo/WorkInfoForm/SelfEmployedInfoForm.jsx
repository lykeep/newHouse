import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Row from 'lbc-wrapper/lib/row'
import InputField from '../../form/inputs/InputField'
import SelectField from '../../form/inputs/SelectField'
import MoneyField from '../../form/inputs/MoneyField'
import { validBusLicenseNo, validBusLicenseNoMessage } from '../../../validators/np'

class SelfEmployedInfoForm extends Component {
  constructor(props) {
    super(props)

    this.liabilitiesTotalChange = this.liabilitiesTotalChange.bind(this)
    this.assetsTotalChange = this.assetsTotalChange.bind(this)

    this.state = {
      companyMangerAge: [
        { title: '一年(含)以下', value: '00', key: '00' },
        { title: '1-2年(含) ', value: '01', key: '01' },
        { title: '2-3年(含)', value: '02', key: '02' },
        { title: '3-5年(含)', value: '03', key: '03' },
        { title: '5-8年(含)', value: '04', key: '04' },
        { title: '8-10年(含)', value: '05', key: '05' },
        { title: '10年以上', value: '06', key: '06' }],
      borrowerWorkAge: [
        { title: '一年(含)以下', value: '00', key: '00' },
        { title: '1-2年(含) ', value: '01', key: '01' },
        { title: '2-3年(含)', value: '02', key: '02' },
        { title: '3-5年(含)', value: '03', key: '03' },
        { title: '5-8年(含)', value: '04', key: '04' },
        { title: '8-10年(含)', value: '05', key: '05' },
        { title: '10年以上', value: '06', key: '06' }],
      workIndustry: [
        { title: '农、林、牧、渔', value: '00', key: '00' },
        { title: '采矿', value: '01', key: '01' },
        { title: '制造', value: '02', key: '02' },
        { title: '建筑', value: '03', key: '03' },
        { title: '交通运输、仓储和邮政', value: '04', key: '04' },
        { title: '计算机信息服务', value: '05', key: '05' },
        { title: '批发和零售', value: '06', key: '06' },
        { title: '住宿和餐饮', value: '07', key: '07' },
        { title: '金融', value: '08', key: '08' },
        { title: '房地产', value: '09', key: '09' },
        { title: '社会、商务服务', value: '10', key: '10' },
        { title: '卫生、社会保障和社会福利', value: '11', key: '11' },
        { title: '文化娱乐', value: '12', key: '12' },
        { title: '科学研究', value: '13', key: '13' },
        { title: '政府组织', value: '14', key: '14' },
        { title: '公共设施管理', value: '15', key: '15' },
        { title: '教育', value: '16', key: '16' }],
      occupation: [
        { title: '国家机关、党组织、企业、事业单位负责人', value: '000', key: '000' },
        { title: '专业技术人员', value: '001', key: '001' },
        { title: '办事人员和有关人员', value: '002', key: '002' },
        { title: '商业、服务人员', value: '003', key: '003' },
        { title: '农、林、牧、渔、水利业生产人员', value: '004', key: '004' },
        { title: '生产、运输设备操作人员及相关人员', value: '005', key: '005' },
        { title: '军人', value: '006', key: '006' },
        { title: '不便分类的其他从业人员', value: '007', key: '007' },
      ],
    }
  }

  liabilitiesTotalChange(value) {
    const { form } = this.props
    const { getFieldValue, setFieldsValue } = form
    const currentAssetsTotal = getFieldValue('currentAssetsTotal') || 0

    setFieldsValue({
      currentNetAssets: currentAssetsTotal - value,
    })
  }

  assetsTotalChange(value) {
    const { form } = this.props
    const { getFieldValue, setFieldsValue } = form
    const liabilitiesTotal = getFieldValue('currentLiabilitiesTotal') || 0

    setFieldsValue({
      currentNetAssets: value - liabilitiesTotal,
    })
  }

  render() {
    const { form, authority, data, disabled = false } = this.props
    const { npWorkSelfEmployed = {} } = data
    return (
      <div>
        <Row gutter={16} type="flex" align="top">
          <SelectField
            form={form}
            authority={authority}
            name="occupation"
            formItemProps={{ label: '职业' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.occupation,
              }}
            inputProps={{
                options: this.state.occupation,
                placeholder: '请选择',
                disabled,
              }}
          />
          <SelectField
            form={form}
            authority={authority}
            name="workIndustry"
            formItemProps={{ label: '工作行业' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.workIndustry,
              }}
            inputProps={{
                options: this.state.workIndustry,
                placeholder: '请选择',
                disabled,
              }}
          />
          <InputField
            form={form}
            authority={authority}
            name="workUnitName"
            formItemProps={{ label: '工作单位名称' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.workUnitName,
                rules: [
                    { min: 2, max: 64, message: '长度为2-64之间' },
                ],
              }}
            inputProps={{
                placeholder: '请输入',
                disabled,
              }}
          />
          <InputField
            form={form}
            authority={authority}
            name="workAddress"
            formItemProps={{ label: '工作单位地址' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.workAddress,
                rules: [
                    { min: 2, max: 128, message: '长度为2-128之间' },
                ],
              }}
            inputProps={{
                placeholder: '请输入',
                disabled,
              }}
          />
          <InputField
            form={form}
            authority={authority}
            name="busLicenseNo"
            formItemProps={{ label: '营业执照号' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.busLicenseNo,
                rules: [
                    { pattern: validBusLicenseNo, message: validBusLicenseNoMessage },
                ],
              }}
            inputProps={{
                placeholder: '请输入',
                disabled,
              }}
          />
          <InputField
            form={form}
            authority={authority}
            name="busLicenseLp"
            formItemProps={{ label: '营业执照法人' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.busLicenseLp,
              }}
            inputProps={{
                placeholder: '请输入',
                disabled,
              }}
          />
          <SelectField
            form={form}
            authority={authority}
            name="companyMangerAge"
            formItemProps={{ label: '单位经营年限' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.companyMangerAge,
              }}
            inputProps={{
                options: this.state.companyMangerAge,
                placeholder: '请选择',
                disabled,
              }}
          />
          <SelectField
            form={form}
            authority={authority}
            name="borrowerWorkAge"
            formItemProps={{ label: '借款人从业年限' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.borrowerWorkAge,
              }}
            inputProps={{
                options: this.state.borrowerWorkAge,
                placeholder: '请选择',
                disabled,
              }}
          />
          <MoneyField
            form={form}
            authority={authority}
            name="proYearSaleIncome"
            formItemProps={{ label: '上年销售收入' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.proYearSaleIncome,
              }}
            inputProps={{
                placeholder: '请输入',
                disabled,
              }}
          />
          <MoneyField
            form={form}
            authority={authority}
            name="proYearOperteProfit"
            formItemProps={{ label: '上年营业利润' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.proYearOperteProfit,
              }}
            inputProps={{
                placeholder: '请输入',
                disabled,
              }}
          />
          <MoneyField
            form={form}
            authority={authority}
            name="proYearNetProfit"
            formItemProps={{ label: '上年净利润' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.proYearNetProfit,
              }}
            inputProps={{
                placeholder: '请输入',
                disabled,
              }}
          />
          <MoneyField
            form={form}
            authority={authority}
            name="thisYearOperteProfit"
            formItemProps={{ label: '当年营业利润' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.thisYearOperteProfit,
              }}
            inputProps={{
                placeholder: '请输入',
                disabled,
              }}
          />
          <MoneyField
            form={form}
            authority={authority}
            name="thisYearNetProfit"
            formItemProps={{ label: '当年净利润' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.thisYearNetProfit,
              }}
            inputProps={{
                placeholder: '请输入',
                disabled,
              }}
          />
          <MoneyField
            form={form}
            authority={authority}
            name="currentAssetsTotal"
            formItemProps={{ label: '当前资产合计' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.currentAssetsTotal,
              }}
            inputProps={{
                placeholder: '请输入',
                disabled,
                onChange: this.assetsTotalChange,
              }}
          />
          <MoneyField
            form={form}
            authority={authority}
            name="currentLiabilitiesTotal"
            formItemProps={{ label: '当前负债合计' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.currentLiabilitiesTotal,
              }}
            inputProps={{
                placeholder: '请输入',
                disabled,
                onChange: this.liabilitiesTotalChange,
              }}
          />
          <MoneyField
            form={form}
            authority={authority}
            name="currentNetAssets"
            min="-Infinity"
            formItemProps={{ label: '当前净资产' }}
            fieldProps={{
                initialValue: npWorkSelfEmployed.currentNetAssets,
              }}
            inputProps={{
                placeholder: '请输入',
                readOnly: true,
              }}
          />
        </Row>
      </div>
    )
  }
}
SelfEmployedInfoForm.propTypes = {
  form: PropTypes.object.isRequired,
  data: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  disabled: PropTypes.bool,
}
export default SelfEmployedInfoForm
