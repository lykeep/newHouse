import React, { Component } from 'react'
import Row from 'lbc-wrapper/lib/row'
import PropTypes from 'prop-types'
import _debug from 'lb-debug'
import InputField from '../../form/inputs/InputField'
import MoneyField from '../../form/inputs/MoneyField'
import SelectField from '../../form/inputs/SelectField'
import SelectMultiExportStrField from '../../form/inputs/SelectMultiExportStrField'

const debug = _debug('vfc:PraviteOwnInfoForm')

class PayInfoForm extends Component {
  constructor(props) {
    super(props)

    this.familyTotalLiabilitiesChange = this.familyTotalLiabilitiesChange.bind(this)
    this.famailyTotalAssetChange = this.famailyTotalAssetChange.bind(this)

    this.state = {
      securityAble: [
        { title: '养老保险', value: '00', key: '00' },
        { title: '医疗保险', value: '01', key: '01' },
        { title: '住房公积金', value: '02', key: '02' },
        { title: '意外伤害险', value: '03', key: '03' }],
      workAge: [
        { title: '1-3年', value: '00', key: '00' },
        { title: '3-5年', value: '01', key: '01' },
        { title: '5-10年', value: '02', key: '02' },
        { title: '10-20年', value: '03', key: '03' },
        { title: '20年以上', value: '04', key: '04' }],
      post: [
        { title: '副科（含）以下或一般员工', value: '00', key: '00' },
        { title: '科-副处（含）或初级管理者', value: '01', key: '01' },
        { title: '处-副局（含）或中级管理者', value: '02', key: '02' },
        { title: '局以上或高级管理者', value: '03', key: '03' }],
      occupationStatus: [
        { title: '在职', value: '00', key: '00' },
        { title: '离职/退休', value: '01', key: '01' },
        { title: '其他', value: '02', key: '02' }],
      occupation: [
        { title: '公务员', value: '00', key: '00' },
        { title: '单位（部门）负责人', value: '01', key: '01' },
        { title: '小业主', value: '02', key: '02' },
        { title: '教师', value: '03', key: '03' },
        { title: '医师、护士', value: '04', key: '04' },
        { title: '会计师、律师、评估师、税务师、建筑设计师', value: '05', key: '05' },
        { title: '体育、文艺专业人员', value: '06', key: '06' },
        { title: '专业技术人员', value: '07', key: '07' },
        { title: '一般工作人员或服务人员', value: '08', key: '08' },
        { title: '军人', value: '09', key: '09' },
        { title: '其他', value: '10', key: '10' },
      ],
      unitIndustry: [
        { title: '农、林、牧、渔业', value: '00', key: '00' },
        { title: '采矿业', value: '01', key: '01' },
        { title: '制造业', value: '02', key: '02' },
        { title: '电力、燃气及水的生产和供应业', value: '03', key: '03' },
        { title: '建筑业', value: '04', key: '04' },
        { title: '交通运输、仓储和邮政业', value: '05', key: '05' },
        { title: '信息传输、计算机服务和软件业', value: '06', key: '06' },
        { title: '批发和零售业', value: '07', key: '07' },
        { title: '住宿和餐饮业', value: '08', key: '08' },
        { title: '金融业', value: '09', key: '09' },
        { title: '房地产业', value: '10', key: '10' },
        { title: '租赁和商务服务业', value: '11', key: '11' },
        { title: '科学研究、技术服务和地质勘探业', value: '12', key: '12' },
        { title: '水利、环境和公共设施管理业', value: '13', key: '13' },
        { title: '居民服务和其他服务业', value: '14', key: '14' },
        { title: '教育', value: '15', key: '15' },
        { title: '卫生、社会保障和社会福利业', value: '16', key: '16' },
        { title: '文化、体育、娱乐业', value: '17', key: '17' },
        { title: '公共管理与社会组织', value: '18', key: '18' },
        { title: '国际组织', value: '19', key: '19' },
        { title: '其他', value: '20', key: '20' },
      ],
      postNowAge: [
        { title: '1-3年', value: '00', key: '00' },
        { title: '3-5年', value: '01', key: '01' },
        { title: '5年以上', value: '02', key: '02' }],
    }
  }

  famailyTotalAssetChange(value) {
    const { form } = this.props
    const { getFieldValue, setFieldsValue } = form
    const familyTotalLiabilities = getFieldValue('familyTotalLiabilities') || 0

    setFieldsValue({
      familyNetAsset: value - familyTotalLiabilities,
    })
  }

  familyTotalLiabilitiesChange(value) {
    const { form } = this.props
    const { getFieldValue, setFieldsValue } = form
    const famailyTotalAsset = getFieldValue('famailyTotalAsset') || 0

    setFieldsValue({
      familyNetAsset: famailyTotalAsset - value,
    })
  }

  render() {
    const { form, data, authority, disabled = false } = this.props
    debug('****praviteOwnInfoForm****')
    const { npWorkPay = {} } = data
    return (
      <div>
        <Row gutter={16}>
          <SelectField
            form={form}
            authority={authority}
            name="occupationStatus"
            formItemProps={{ label: '职业状况' }}
            fieldProps={{
                initialValue: npWorkPay.occupationStatus,
              }}
            inputProps={{
                options: this.state.occupationStatus,
                placeholder: '请选择',
                disabled,
              }}
          />
          <SelectField
            form={form}
            authority={authority}
            name="workAge"
            formItemProps={{ label: '工作年限' }}
            fieldProps={{
                initialValue: npWorkPay.workAge,
              }}
            inputProps={{
                options: this.state.workAge,
                placeholder: '请选择',
                disabled,
              }}
          />
          <InputField
            form={form}
            authority={authority}
            name="workUnitName"
            formItemProps={{ label: '工作单位名称' }}
            fieldProps={{
                initialValue: npWorkPay.workUnitName,
                rules: [
                    { min: 2, max: 64, message: '长度为2-64之间' },
                ],
              }}
            inputProps={{
                placeholder: '请输入',
                disabled,
              }}
          />
          <InputField
            form={form}
            authority={authority}
            name="workAddress"
            formItemProps={{ label: '工作单位地址' }}
            fieldProps={{
                initialValue: npWorkPay.workAddress,
                rules: [
                    { min: 2, max: 128, message: '长度为2-128之间' },
                ],
              }}
            inputProps={{
                placeholder: '请输入',
                disabled,
              }}
          />
          <SelectField
            form={form}
            authority={authority}
            name="occupation"
            formItemProps={{ label: '职业' }}
            fieldProps={{
                initialValue: npWorkPay.occupation,
              }}
            inputProps={{
                options: this.state.occupation,
                placeholder: '请选择',
                disabled,
              }}
          />
          <SelectField
            form={form}
            authority={authority}
            name="unitIndustry"
            formItemProps={{ label: '单位所属行业' }}
            fieldProps={{
              initialValue: npWorkPay.unitIndustry,
            }}
            inputProps={{
              options: this.state.unitIndustry,
              placeholder: '请选择',
              disabled,
            }}
          />
          <SelectField
            form={form}
            authority={authority}
            name="post"
            formItemProps={{ label: '职务' }}
            fieldProps={{
                initialValue: npWorkPay.post,
              }}
            inputProps={{
                options: this.state.post,
                placeholder: '请选择',
                disabled,
              }}
          />
          <SelectField
            form={form}
            authority={authority}
            name="postNowAge"
            formItemProps={{ label: '服务现职年限' }}
            fieldProps={{
                initialValue: npWorkPay.postNowAge,
              }}
            inputProps={{
                options: this.state.postNowAge,
                placeholder: '请选择',
                disabled,
              }}
          />
          <MoneyField
            form={form}
            authority={authority}
            name="perYearIncome"
            formItemProps={{ label: '税前个人年收入' }}
            fieldProps={{
                initialValue: npWorkPay.perYearIncome,
              }}
            inputProps={{
                placeholder: '请输入',
                disabled,
              }}
          />
          <SelectMultiExportStrField
            form={form}
            authority={authority}
            name="securityAble"
            formItemProps={{ label: '保障能力' }}
            fieldProps={{
                initialValue: npWorkPay.securityAble,
              }}
            inputProps={{
                options: this.state.securityAble,
                placeholder: '请选择',
                disabled,
              }}
          />
          <MoneyField
            form={form}
            authority={authority}
            name="famailyTotalAsset"
            formItemProps={{ label: '家庭总资产' }}
            fieldProps={{
                initialValue: npWorkPay.famailyTotalAsset,
              }}
            inputProps={{
                placeholder: '请输入',
                onChange: this.famailyTotalAssetChange,
                disabled,
              }}
          />
          <MoneyField
            form={form}
            authority={authority}
            name="familyTotalLiabilities"
            formItemProps={{ label: '家庭总负债' }}
            fieldProps={{
                initialValue: npWorkPay.familyTotalLiabilities,
              }}
            inputProps={{
                placeholder: '请输入',
                onChange: this.familyTotalLiabilitiesChange,
                disabled,
              }}
          />
          <MoneyField
            key="familyNetAsset"
            form={form}
            authority={authority}
            name="familyNetAsset"
            min="-Infinity"
            formItemProps={{ label: '家庭净资产' }}
            fieldProps={{
                initialValue: npWorkPay.familyNetAsset,
              }}
            inputProps={{
                placeholder: '请输入',
                readOnly: true,
              }}
          />
        </Row>
      </div>
    )
  }
}

PayInfoForm.propTypes = {
  form: PropTypes.shape({
    getFieldDecorator: PropTypes.func.isRequired,
  }).isRequired,
  data: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  disabled: PropTypes.bool,
}

export default PayInfoForm
