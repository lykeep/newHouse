import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import InputField from '../form/inputs/InputField'
import SelectField from '../form/inputs/SelectField'
import DatePickerField from '../form/inputs/DatePickerField'
import IdTypesField from '../form/inputs/IdTypesField'
import NameFilterModal from '../form/inputs/nameFilterModal/NameFilterModal'
import { sexSelectOptions } from '../../components/columnRenders/sex'
import { validName, validNameMessage, validMobilePhone, validMobilePhoneMessage } from '../../validators/common'
import { natureApplyType } from '../../common/bizApplyType/natural'

class NaturalBasicInfo extends Component {
  constructor(props) {
    super(props)

    this.onChange = this.onChange.bind(this)
  }


  onChange(val) {
    if (this.props.changeName) {
      this.props.changeName({ name: val.target.value })
    }
  }

  render() {
    // mName -> order、natural
    const { form, data, authority, nameType = 'input', disabled = false, applyType, mName } = this.props

    return (
      <div>
        <Form>
          <Row gutter={16} type="flex" align="top">
            {
              nameType === 'input' &&
              <InputField
                form={form}
                authority={authority}
                name="custName"
                formItemProps={{ label: '客户姓名' }}
                fieldProps={{
                  onChange: this.onChange,
                  initialValue: data.custName,
                  rules: [
                    { required: true, message: '客户姓名必输！' },
                    { pattern: validName, message: validNameMessage },
                  ],
                }}
                inputProps={{
                  placeholder: '请输入',
                  // disabled: disabled || ,
                  disabled: disabled || (mName === 'natural' && applyType === natureApplyType.ALTER),
                }}
              />
            }
            {
              nameType === 'nameFilter' &&
              <NameFilterModal
                colSpan={8}
                form={form}
                showIcon
                onClickIcon={this.onClickIcon}
                authority={authority}
                name={['legalName', 'legalId']}
                modalData={{
                  columns: this.columns,
                }}
                receivekey={['name', 'id']}
                formItemProps={{ label: '客户名称' }}
                fieldProps={{
                  rules: [
                    { required: true, message: '请输入客户名称！' },
                  ],
                }}
                inputProps={{
                  placeholder: '请输入',
                  disabled,
                }}
              />
            }
            <SelectField
              form={form}
              authority={authority}
              name="gender"
              formItemProps={{ label: '性别' }}
              fieldProps={{
                initialValue: data.gender,
              }}
              inputProps={{
                options: sexSelectOptions,
                disabled,
              }}
            />
            <DatePickerField
              form={form}
              authority={authority}
              name="birth"
              formItemProps={{ label: '出生日期' }}
              fieldProps={{
                initialValue: data.birth,
              }}
              inputProps={{
                placeholder: '请选择',
                disabled,
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="phone"
              formItemProps={{ label: '手机号' }}
              fieldProps={{
                initialValue: data.phone,
                 rules: [
                  { required: true, message: '手机号必输！' },
                  { pattern: validMobilePhone, message: validMobilePhoneMessage },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                disabled,
              }}
            />
            <IdTypesField
              disabled={disabled/* || applyType === natureApplyType.ALTER*/}
              form={form}
              authority={authority}
              name={['idType', 'idNo']}
              label={['证件类型', '证件号码']}
              colSpan={16}
              required
              fieldProps={{
                  initialValue: { idType: data.idType, idNo: data.idNo },
              }}
            />
          </Row>
        </Form>
      </div>
    )
  }
}

NaturalBasicInfo.propTypes = {
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  data: PropTypes.object,
  changeName: PropTypes.func,
  nameType: PropTypes.string,
  disabled: PropTypes.bool,
}

export default NaturalBasicInfo
