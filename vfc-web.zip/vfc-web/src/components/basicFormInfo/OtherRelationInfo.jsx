import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import InputField from '../form/inputs/InputField'
import SelectField from '../form/inputs/SelectField'
import { contactRelation } from '../../config/types'
import { effectiveArray, range } from '../../utils/dataType'
import TableField from '../form/inputs/TableField'
import OtherReltionModal from './OtherReltionModal'

class OtherRelationInfo extends Component {
  constructor(props) {
    super(props)
    this.state = {

    }

    this.columns = [
      {
        key: 'relName',
        dataIndex: 'relName',
        title: '借款人姓名',
      },
      {
        key: 'contactRelation',
        dataIndex: 'contactRelation',
        title: '与借款人关系',
        render: (text) => {
          const type = contactRelation.filter(i => i.value === text)
          return <span>{type.length > 0 ? type[0].title : ''}</span>
        },
      },
      {
        key: 'phone',
        dataIndex: 'phone',
        title: '联系人电话',
      },
    ]
  }

  onCreateBegin = (comp) => {
    console.log('其他联系人comp', comp)
  }


  render() {
    const { form, data = [], authority, disabled } = this.props

    return (
      <div>
        <TableField
          form={form}
          name="npOtherInfoUnitList"
          key="npOtherInfoUnitList"
          title="npOtherInfoUnitList"
          authority={authority}
          fieldProps={{
            initialValue: data,
          }}
          inputProps={{
            useAjax: false,
            columns: this.columns,
            component: OtherReltionModal,
            onCreateBegin: this.onCreateBegin,
            title: '其他联系人',
            rowSelection: null,
            propsToModalContent: {
              useAjax: false,
              disabled,
            },
            serverReturnId: false,
          }}
        />
        {/* <Form>
          {
            list.map((item, index) => (
              <Row key={`${index + 1}`} span={24}>
                <InputField
                  form={form}
                  span={8}
                  // key={`${index + 1}`}
                  authority={authority}
                  name={`relName-${index}`}
                  formItemProps={{ label: '联系人姓名' }}
                  fieldProps={{
                      rules: [
                        { required: index === 0, message: '请输入联系人姓名' },
                        { pattern: validName, message: validNameMessage },
                      ],
                      initialValue: data && item.relName,
                    }}
                  inputProps={{
                      placeholder: '请输入',
                      disabled,
                    }}
                />
                <SelectField
                  // key={`${index + 1}`}
                  form={form}
                  authority={authority}
                  name={`contactRelation-${index}`}
                  formItemProps={{ label: '与借款人关系' }}
                  fieldProps={{
                      rules: [
                        { required: index === 0, message: '请选择与借款人关系！' },
                      ],
                      initialValue: data && item.contactRelation,
                    }}
                  inputProps={{
                      options: contactRelation,
                      placeholder: '请选择',
                      disabled,
                    }}
                />
                <InputField
                  // key={`${index + 1}`}
                  form={form}
                  authority={authority}
                  name={`phone-${index}`}
                  formItemProps={{ label: '联系人电话' }}
                  fieldProps={{
                      rules: [
                        { required: index === 0, message: '请输入联系人电话' },
                        { pattern: validPhoneName, message: validPhoneNameMessage },
                      ],
                      initialValue: data && item.phone,
                    }}
                  inputProps={{
                      placeholder: '请输入',
                      disabled,
                    }}
                />
              </Row>))
              }
        </Form>
      */}
      </div>
    )
  }
}

OtherRelationInfo.propTypes = {
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  data: PropTypes.array,
  disabled: PropTypes.bool,
}

export default OtherRelationInfo
