
import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import InputField from '../form/inputs/InputField'
import BankNameSelector from '../form/inputs/BankNameSelector/BankNameSelector'
import { validBankAccountNum, validBankAccountNumMessage, validBankAccountName, validBankAccountNameMessage, validMobilePhone, validMobilePhoneMessage } from '../../validators/common'

class PaymentInfo extends Component {
  constructor(props) {
    super(props)
    this.state = {

    }
  }

  inputPhoneNumber(rule, value, callback) {
    const phoneRegExp = /^1[0-9]{10}$/
    if (value && !phoneRegExp.test(value)) {
      callback('请输入手机号');
    } else {
      callback();
    }
  }
  render() {
    const { form, data, authority } = this.props
    return (
      <div>
        <Form>
          <Row gutter={16} type="flex" align="top">
            <InputField
              form={form}
              authority={authority}
              name="acName"
              formItemProps={{ label: '户名' }}
              fieldProps={{
                rules: [
                  { required: false, message: '请输入户名' },
                  { pattern: validBankAccountName, message: validBankAccountNameMessage },
                ],
               initialValue: data.acName,
              }}
              inputProps={{
                disabled: true,
                placeholder: '请输入',
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="acNo"
              formItemProps={{ label: '账号' }}
              fieldProps={{
                rules: [
                  { required: true, message: '请输入账号' },
                  { pattern: validBankAccountNum, message: validBankAccountNumMessage },
                ],
                initialValue: data.acNo,
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
            <BankNameSelector
              form={form}
              authority={authority}
              name={['openAccountBank', 'bankNo', 'innerBankNo']}
              formItemProps={{ label: '开户行' }}
              fieldProps={{
                rules: [
                  { required: true, message: '请选择开户行' },
                ],
                  initialValue: [data.openAccountBank, data.bankNo, data.innerBankNo],
              }}
              inputProps={{
                  placeholder: '请输入',
              }}
            />
            <InputField
              form={form}
              authority={authority}
              name="phoneno"
              formItemProps={{ label: '预留手机号' }}
              fieldProps={{
                rules: [
                  { required: true, message: '请输入手机号' },
                  { pattern: validMobilePhone, message: validMobilePhoneMessage },
                ],
                initialValue: data.phoneno,
              }}
              inputProps={{
                placeholder: '请输入',
              }}
            />
          </Row>
        </Form>
      </div>
    )
  }
}

PaymentInfo.propTypes = {
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  data: PropTypes.object,
}

export default PaymentInfo
