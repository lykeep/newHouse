import React, { Component } from 'react'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import PropTypes from 'prop-types'
import SelectField from '../form/inputs/SelectField'
import InputField from '../form/inputs/InputField'
import { contactRelation } from '../../config/types'
import { validName, validNameMessage, validPhoneName, validPhoneNameMessage } from '../../validators/common'

class OtherReltionModal extends Component {
  constructor(props) {
    super(props)
    this.state = {}
  }

  render() {
    const { form, authority, disabled } = this.props

    return (
      <div>
        <Form>
          <Row gutter={16} type="flex" align="top">
            <InputField
              form={form}
              span={8}
              authority={authority}
              name="relName"
              formItemProps={{ label: '联系人姓名' }}
              fieldProps={{
                  rules: [
                    { required: true, message: '请输入联系人姓名' },
                    { pattern: validName, message: validNameMessage },
                  ],
                  initialValue: '',
                }}
              inputProps={{
                  placeholder: '请输入',
                  disabled,
                }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="contactRelation"
              formItemProps={{ label: '与借款人关系' }}
              fieldProps={{
                  rules: [
                    { required: true, message: '请选择与借款人关系！' },
                  ],
                  initialValue: '',
                }}
              inputProps={{
                  options: contactRelation,
                  placeholder: '请选择',
                  disabled,
                }}
            />
            <InputField
              form={form}
              authority={authority}
              name="phone"
              formItemProps={{ label: '联系人电话' }}
              fieldProps={{
                  rules: [
                    { required: true, message: '请输入联系人电话' },
                    { pattern: validPhoneName, message: validPhoneNameMessage },
                  ],
                  initialValue: '',
                }}
              inputProps={{
                  placeholder: '请输入',
                  disabled,
                }}
            />
          </Row>
        </Form>
      </div>
    )
  }
}

OtherReltionModal.propTypes = {
  form: PropTypes.shape({
    getFieldDecorator: PropTypes.func.isRequired,
  }).isRequired,
  authority: PropTypes.string.isRequired,
  disabled: PropTypes.bool,
}

export default Form.create()(OtherReltionModal)
