/**
 * 身份证验证规则
 */
export const idValidator = (id) => {
  const idReg = /^[1-9]\d{5}(18|19|20)\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/

  if (!id) return ''

  if (id.length === 15) {
    return '请输入18位身份证号'
  }

  if (!idReg.test(id)) {
    return '身份证格式错误'
  }

  return ''
}

/*
 * 户口簿验证
 */
export const residenceValidator = (number) => {
  if (!/^[a-zA-Z0-9]{3,21}$/.test(number)) {
    return '证件号码格式错误'
  }

  return ''
}

/*
 * 护照验证
 */
export const passportValidator = (pp) => {
  if (!pp) return ''

  if (!/^[a-zA-Z0-9]{5,20}$/.test(pp)) {
    return '证件号码格式错误'
  }

  return ''
}

/*
 * 士兵证验证
 */
export const jgzValidator = (junguanzheng) => {
  if (!junguanzheng) return ''

  if (!/^[\u4e00-\u9fa5a-zA-Z\d]{6,50}$/.test(junguanzheng)) {
    return '证件号码格式错误'
  }

  return ''
}

/*
 * 士兵证验证
 */
export const sbzValidator = sbz => jgzValidator(sbz)

/*
 * 港澳通行证验证
 */
export const gatxzValidator = (g) => {
  if (!g) return ''

  if (!/^[A-Z\d]{5,50}$/.test(g)) {
    return '证件号码格式错误'
  }

  return ''
}

/*
 * 台胞证验证
 */
export const tbzValidator = (t) => {
  if (!t) return ''

  if (!/^[0-9]{8}$/.test(t)) {
    return '台胞证格式错误'
  }

  return ''
}

/*
 * 回乡证
 */
export const hxzValidator = (h) => {
  if (!h) return ''

  if (!/^[HhMm][0-9]{8}$/.test(h)) {
    return '港澳回乡证格式错误,正确格式H/M+8位数字，例如H12345678。'
  }

  return ''
}

/*
 * 营业执照
 */
export const yyzzValidator = function (y) {
  // if (!y) return ''
  //
  // if (!/^\d{15}$/.test(y)) {
  //   return '营业执照格式错误'
  // }

  return ''
}

/*
 * 电子邮件
 */
export const emailPattern = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/

/*
 * 区号验证表达式
 */
export const areaNoPatter = /^0[0-9]{1,3}$/

/*
 * 电话号
 */
export const phoneNoPatter = /^[0-9]{7,8}$/

/*
 * 手机号验证表达式
 */
export const mobilePatter = /^1[0-9]{10}$/

/*
 * 邮编验证码
 */
export const postCodePattern = /^[1-9][0-9]{5}$/

/*
 * 银行卡号
 */
export const bankAccNoPattern = /^[0-9]+$/


export const incomeRateValidator = function (v, isPercent) {
  console.log(v)
  if (typeof v === 'number') {
    v += ''
  }

  if (!v) return ''

  if (isNaN(Number(v))) {
    return '不是一个合法的数字'
  }

  const m = isPercent ? 2 : 4

  const n = v.split('.')
  if (n.length > 1 && n[1].length > m) {
    return `小数点最多为${m}位`
  }

  return ''
}
/*
 * 年份
 */
export const validateYear = (y) => {
  const date = new Date()
  const year = date.getFullYear()
  const idReg = /^\d{4}$/

  if (!y) return ''

  if (y > year) {
    return '不可大于当前年份'
  }

  if (!idReg.test(y)) {
    return '年份格式错误'
  }
}

export const limitTermPattern = /^0$|^[1-9]\d*$/

export const amountPattern = /^[1-9]\d+$|^[1-9]\d+\.\d+$|^0\.\d+|^0$/

export const intPattern = /^0|[1-9]\d*$/
