export const PERMISSIONS = {
  READ: '1',
  HIDE: '99',
  MODIFY: '2',
  CREATE: '0',
  CREATE_CHANGE: '98',
}

export default function calPermission(authority) {
  return authority
  // return '2'
}
