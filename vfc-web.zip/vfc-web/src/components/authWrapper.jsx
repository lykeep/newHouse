import React from 'react'
import PropTypes from 'prop-types'
import { Redirect } from 'react-router-dom'
import { connect } from 'react-redux'

const authWrapper = (Component, ...rest) => {
  const AuthComp = ({ authed, ...props }) => (authed ? (<Component {...props} />) : (<Redirect to={{ pathname: '/signin', state: { from: props.location } }} />))

  AuthComp.propTypes = {
    authed: PropTypes.bool.isRequired,
  }

  return connect(state => ({ authed: state.core.loggedIn }), {})(AuthComp)
}

export default authWrapper
