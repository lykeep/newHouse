import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import Popover from 'lbc-wrapper/lib/popover'
import Icon from 'lbc-wrapper/lib/icon'
import message from 'lbc-wrapper/lib/message'
import Clipboard from 'clipboard'

class ApplyNoWrapperNoLink extends PureComponent {
  componentDidMount() {
    const { noCopy, value } = this.props
    if (!value || noCopy) {
      return
    }

    this.registerClipboard()
  }


  componentDidUpdate() {
    if (this.props.value && !this.props.noCopy && this.button && !this.clipboard) {
      this.registerClipboard()
    }
  }

  componentWillUnmount() {
    if (this.clipboard) {
      this.clipboard.destroy()
    }
  }

  registerClipboard = () => {
    message.config({
      duration: 1,
    })

    this.clipboard = new Clipboard(this.button, {
      text: () => this.props.value,
    })

    this.clipboard.on('success', (e) => {
      message.success('copied')
      e.clearSelection()
    })

    this.clipboard.on('error', (e) => {
      console.error(e)
    })
  }

  render() {
    const { value, prefix, surfix, showAll, noCopy, noPopover } = this.props

    if (!value) {
      return <div />
    }

    const all = value.length <= (prefix + surfix) || showAll
    return (
      <div style={{ display: 'inline-block' }}>
        {
          all ? value : (
            noPopover ? `${value.substr(0, prefix)}...${surfix === 0 ? '' : value.substr(0 - surfix)}` : (
              <Popover content={value}>
                {`${value.substr(0, prefix)}...${surfix === 0 ? '' : value.substr(0 - surfix)}`}
              </Popover>
            )
          )
        }

        {
          noCopy ? null : (<span style={{ cursor: 'pointer' }} ref={(t) => { this.button = t }}><Icon type="copy" /></span>)
        }
      </div>
    )
  }
}

ApplyNoWrapperNoLink.propTypes = {
  value: PropTypes.string,
  prefix: PropTypes.number,
  surfix: PropTypes.number,
  showAll: PropTypes.bool,
  noCopy: PropTypes.bool,
  noPopover: PropTypes.bool,
}

ApplyNoWrapperNoLink.defaultProps = {
  prefix: 9,
  surfix: 9,
  showAll: false,
  noCopy: false,
  noPopover: false,
  value: '',
}

export default ApplyNoWrapperNoLink
