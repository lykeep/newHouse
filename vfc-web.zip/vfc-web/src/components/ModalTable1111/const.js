export default {
  ProjectQueryList: 'projectQueryList',
}
