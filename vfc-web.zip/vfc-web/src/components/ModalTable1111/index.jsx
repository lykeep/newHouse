import React, { Component } from 'react'
import PropTypes from 'prop-types'

import QueryTable from '../queryTable'
import ACTIONS from '../queryTable/consts'

import ApplyNoWrapper from '../ApplyNoWrapper/ApplyNoWrapper'
import { buildColumnRender, buildSelectOptions } from '../../common/utils'
import { handleStatusOptions, flowStatusOptions } from '../../common/workflow'
import Modal from 'lbc-wrapper/lib/modal/index';
import Button from 'lbc-wrapper/lib/button/index';


class ModalTable extends Component {
  constructor(props) {
    super(props)

    // this.onGetTask = this.onGetTask.bind(this)
    this.query = this.query.bind(this)
    this.refresh = this.refresh.bind(this)
    this.onCancel = this.onCancel.bind(this)
    // this.onSelectCallback = this.onSelectCallback.bind(this)
    // this.onCancelCallback = this.onCancelCallback.bind(this)

    this.columns = props.columns.concat([
      {
        key: 'opr',
        title: '操作',
        dataIndex: 'opr',
        width: 60,
        render: (text, record) => (
          <a onClick={() => props.onSelectCallback(props.pageKey, record)} role="button" >选择</a>
        ),
      },
    ])

    this.state = {
      // modalVisible: false,
      data: [],
    }
  }

  // onSelectCallback(record) {
  //   this.setState({
  //     modalVisible: false,
  //   })
  //   this.tableRef.refresh()
  // }
  //
  // onCancelCallback() {
  //   this.setState({
  //     modalVisible: false,
  //   })
  // }
  onCancel() {
    this.props.onCancelCallback()
  }

  query(params) {
    this.props.query(params).then((data) => {
      this.setState({
        data: data[this.props.listName],
        totalCount: data.total,
      })
    })
  }

  refresh() {
    this.tableRef.refresh()
  }

  render() {
    const { columns, actions, query, title, ...props } = this.props
    return (
      <div>
        <Modal
          visible={this.props.visible}
          title={title}
          closable={false}
          maskClosable={false}
          footer={<Button onClick={this.onCancel}>取消</Button>}
          width={1200}
          destroyOnClose
        >
          <QueryTable
            data={this.state.data}
            rowSelection={null}
            columns={this.columns}
            fields={this.props.fields}
            query={this.query}
            // rowKey={rowKey}
            totalCount={this.state.totalCount}
            size="small"
            recordsPerPage={5}
          />
        </Modal>
      </div>
    )
  }
}

ModalTable.propTypes = {
  actions: PropTypes.array,
  columns: PropTypes.array,
  fields: PropTypes.array,
  query: PropTypes.func.isRequired,
  onSelectCallback: PropTypes.func.isRequired,
  onCancelCallback: PropTypes.func.isRequired,
  pageKey: PropTypes.string.isRequired,
  title: PropTypes.string,
  // bizKeyUrl: PropTypes.func.isRequired,
  // bizApplyTypeLabels: PropTypes.object.isRequired,
}

ModalTable.defaultProps = {
  listKey: 'list',
  title: '领取任务',
}

export default ModalTable
