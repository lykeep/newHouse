import React, { Component } from 'react'
import Modal from 'lbc-wrapper/lib/modal'
import Button from 'lbc-wrapper/lib/button'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'

import { bpmRecordTypeLabels } from '../columnRenders/bpmRecordType'

import takeTaskCallback from './GetCheckListModule'
import takenStatus from './const'

import QueryTable from '../queryTable'


class GetCheckList extends Component {
  constructor(props) {
    super(props)
    this.query = this.query.bind(this)
    this.onCancel = this.onCancel.bind(this)

    this.columns = props.columns.concat([
      {
        key: 'opr',
        title: '操作',
        dataIndex: 'opr',
        width: 60,
        render: (text, record) => {
          return (
            <a onClick={() => this.onClick(record)} role="button" >选择</a>
          )
        },
      },
    ])

    this.fields = [
      [
        { id: 'businessKey', label: '申请编号', component: 'Input' },
        { id: 'applyType', label: '申请类型', type: 'Select', options: Object.keys(bpmRecordTypeLabels).map(k => ({ title: bpmRecordTypeLabels[k], value: k, key: k })) },
      ],
    ]

    this.state = {
      data: [],
    }
  }

  onCancel() {
    this.props.onCancelCallback()
  }

  onClick(record) {
    const { takeTask, onSelectCallback } = this.props

    takeTask({
      taskInstanceId: record.taskInstanceId,
    }).then(() => {
      onSelectCallback(record)
    })
  }

  query(params) {
    this.props.query({
      ...params,
      claimType: takenStatus.UNTAKEN,
    }).then((data) => {
      this.setState({
        data: data.list,
        totalCount: data.total,
      })
    })
  }

  render() {
    const { rowKey } = this.props
    return (
      <Modal
        visible={this.props.visible}
        title="领取任务"
        closable={false}
        maskClosable={false}
        footer={<Button onClick={this.onCancel}>取消</Button>}
        width={1200}
        destroyOnClose
      >
        <QueryTable
          data={this.state.data}
          rowSelection={null}
          columns={this.columns}
          fields={this.fields}
          query={this.query}
          rowKey={rowKey}
          totalCount={this.state.totalCount}
          size="small"
          recordsPerPage={5}
        />
      </Modal>
    )
  }
}

GetCheckList.propTypes = {
  query: PropTypes.func.isRequired,
  takeTask: PropTypes.func.isRequired,
  onSelectCallback: PropTypes.func.isRequired,
  onCancelCallback: PropTypes.func.isRequired,
  rowKey: PropTypes.string.isRequired,
  visible: PropTypes.bool,
  columns: PropTypes.array.isRequired,
}

export default connect(() => ({}), { takeTask: takeTaskCallback })(GetCheckList)
