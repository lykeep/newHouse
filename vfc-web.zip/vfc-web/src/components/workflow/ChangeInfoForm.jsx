import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import message from 'lbc-wrapper/lib/message'
import GroupActions from '../form/groups/GroupActions'
import SelectField from '../form/inputs/SelectField'
import TextareaField from '../form/inputs/TextareaField'

class ChangeInfoForm extends Component {
  constructor(props) {
    super(props)

    this.onSave = this.onSave.bind(this)

    this.applyTypes = [{
      value: '02',
      key: '02',
      title: '变更',
    }]

    this.actions = [
      {
        id: 'save',
        label: '保存',
        type: 'primary',
        onClick: this.onSave,
      },
    ]
  }

  onSave() {
    const { form, saveCallback } = this.props

    form.validateFields((errors, values) => {
      if (errors) {
        console.log(errors)
        return
      }


      saveCallback(values).then((res) => {
        message.success('保存成功')
      })
    })
  }

  render() {
    const { form, data, authority, applyTypeOptions } = this.props
    return (
      <div>
        <Form>
          <Row gutter={16} type="flex" align="top">
            <SelectField
              form={form}
              authority={authority}
              name="applyType"
              formItemProps={{ label: '申请类型' }}
              fieldProps={{
                initialValue: data.applyType,
                rules: [
                  { required: true, message: '申请类型为必选项！' },
                ],
              }}
              inputProps={{
                options: applyTypeOptions || this.applyTypes,
                placeholder: '请选择',
                defaultActiveFirstOption: true,
              }}
            />
            <TextareaField
              colSpan={24}
              form={form}
              authority={authority}
              name="remark"
              formItemProps={{ label: '备注' }}
              fieldProps={{
                initialValue: data.remark,
                rules: [
                  { required: true, message: '备注必输！' },
                ],
              }}
              inputProps={{
                placeholder: '请输入',
                rows: 8,
                maxLength: 512,
              }}
            />

          </Row>
          <GroupActions actions={this.actions} authority={authority} />
        </Form>
      </div>
    )
  }
}

ChangeInfoForm.propTypes = {
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  data: PropTypes.object,
  saveCallback: PropTypes.func,
  applyTypeOptions: PropTypes.array,
}

export default ChangeInfoForm
