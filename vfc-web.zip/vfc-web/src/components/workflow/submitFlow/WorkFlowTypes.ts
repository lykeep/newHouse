export type ApproveActionAllowed = string

export type ApproveAssignStrategyType = string

export interface ApproveAssignStrategyObj {
  assignStrategy: ApproveAssignStrategyType
  nodeList: ApproveNode[]
}

export interface ApproveNextNode {
  CNode: string
  CName: string
}
export interface ApproveNode {
  taskDefCd: string // 节点id
  taskNodeNm: string // 节点名称
}

export interface ApproveUser {
  userId: string
  userName: string
}


export interface SubmitOpenOptions {
  backNodeList: ApproveNode[]
  assignStrategy: ApproveAssignStrategyType | null
  nextNodeList: ApproveNextNode[]
  userList: ApproveUser[]
  actionTypeAllowed: ApproveActionAllowed | null
  nextStepOK?: (() => any) | null
  taskInstId: string
  comment: string
  successCallback: null | ((param?: any) => any)
  failCallback: null | (() => any)
}
