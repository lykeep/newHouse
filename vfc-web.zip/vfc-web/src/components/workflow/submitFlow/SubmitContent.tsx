import * as React from 'react'
import Row from 'lbc-wrapper/lib/row'
import Input from 'lbc-wrapper/lib/input'
import Form, { FormComponentProps } from 'lbc-wrapper/lib/form'

import SelectField from '../../form/inputs/SelectField'
import SelectMultiField from '../../form/inputs/SelectMultiField'
import { activityStrategies, flowActions } from '../../../common/workflow'
import { PERMISSIONS } from '../../form/utils/calPermission'
import HiddenInputField from '../../form/inputs/HiddenInputField'
import { SubmitFlowModuleInjectedProps } from './SubmitFlowModule'

import { SubmitOpenOptions, ApproveNextNode, ApproveUser } from './WorkFlowTypes'

interface SubmitFlowContentProps extends SubmitOpenOptions, FormComponentProps, SubmitFlowModuleInjectedProps {
  loading: (l: boolean) => void
  taskNextNodePart: (param: any) => Promise<any>
}

interface SubmitFlowContentState {
  nodeShow: boolean
  manualShow: boolean
  huiqianShow: boolean
  backNodeShow: boolean
  nextNodeList: ApproveNextNode[]
  userList: ApproveUser[]
}

class SubmitContent extends React.Component<SubmitFlowContentProps, SubmitFlowContentState> {
  public static defaultProps = {
    backNodeList: [],
    nextNodeList: [],
    userList: [],
    // actionTypeAllowed: '',
    assignStrategy: null,
  }

  constructor(props: SubmitFlowContentProps) {
    super(props)

    this.renderBack = this.renderBack.bind(this)
    this.onNodeChange = this.onNodeChange.bind(this)

    this.state = {
      nodeShow: props.nextNodeList.length > 1, // 节点选择
      manualShow: activityStrategies.manual === props.assignStrategy, // 收工分配
      huiqianShow: activityStrategies.countersign === props.assignStrategy, // 会签
      backNodeShow: flowActions.back === props.actionTypeAllowed, // 回退
      nextNodeList: props.nextNodeList,
      userList: props.userList,
    }
  }

  public onNodeChange(value: string) {
    const { taskInstId, taskNextNodePart, loading } = this.props
    loading(true)
    this.props.form.setFieldsValue({
      assignStrategy: '',
      userList: null,
      nextUser: '',
      nextUserList: [],
    })
    taskNextNodePart({
      nextNode: value,
      taskInstanceId: taskInstId,
    }).then(res => this.setState({
      manualShow: activityStrategies.manual === res.assignStrategy, // 收工分配
      huiqianShow: activityStrategies.countersign === res.assignStrategy, // 会签
      userList: res.userList,
    }, () => {
      this.props.form.setFieldsValue({
        assignStrategy: res.assignStrategy,
        userList: res.userList,
      })
      loading(false)
    }))
  }

  public renderBack(authority: PERMISSIONS) {
    const { form, backNodeList } = this.props
    return (
      <SelectField
        colSpan={24}
        form={form}
        authority={authority}
        name="nextBackNode"
        formItemProps={{ label: '选择退回节点' }}
        fieldProps={{
          rules: [
            { required: true, message: '法人名称必输！' },
          ],
        }}
        inputProps={{
          placeholder: '请选择',
          options: backNodeList.map(n => ({
            title: n.taskNodeNm,
            value: n.taskDefCd,
            key: n.taskDefCd,
          })),
        }}
      />
    )
  }

  public render() {
    const { nodeShow, manualShow, huiqianShow, backNodeShow, userList, nextNodeList } = this.state
    const { form } = this.props
    const authority = PERMISSIONS.MODIFY

    if (backNodeShow) {
      return this.renderBack(authority)
    }

    return (
      <Form>
        <Row>
          <HiddenInputField
            colSpan={24}
            form={form}
            authority={authority}
            name="assignStrategy"
            formItemProps={{ label: '选择下一个处理节点' }}
            fieldProps={{
              initialValue: this.props.assignStrategy,
            }}
            inputProps={{
            }}
          />
          {
            nodeShow ? (
              <SelectField
                colSpan={24}
                form={form}
                authority={authority}
                name="nextNode"
                formItemProps={{ label: '下一个处理节点' }}
                fieldProps={{
                  rules: [
                    { required: true, message: '选择节点必输！' },
                  ],
                }}
                inputProps={{
                  placeholder: '请选择',
                  onChange: this.onNodeChange,
                  options: nextNodeList.map(n => ({
                    title: n.CName,
                    value: n.CNode,
                    key: n.CNode,
                  })),
                }}
              />
            ) : null
          }
          {
            manualShow ? (
              <SelectField
                colSpan={24}
                form={form}
                authority={authority}
                name="nextUser"
                formItemProps={{ label: '下一个节点处理人' }}
                fieldProps={{
                  rules: [
                    { required: true, message: '下一个节点处理人必输！' },
                  ],
                }}
                inputProps={{
                  placeholder: '请选择',
                  options: userList.map(n => ({
                    title: `${n.userName}(${n.userId})`,
                    value: n.userId,
                    key: n.userId,
                  })),
                }}
              />
            ) : null
          }
          {
            huiqianShow ? (
              <SelectMultiField
                colSpan={24}
                form={form}
                authority={authority}
                name="nextUserList"
                formItemProps={{ label: '会签处理人' }}
                fieldProps={{
                  rules: [
                    { required: true, message: '处理人必输！' },
                  ],
                }}
                inputProps={{
                  placeholder: '请选择',
                  options: userList.map(n => ({
                    title: `${n.userName}(${n.userId})`,
                    value: n.userId,
                    key: n.userId,
                  })),
                }}
              />
            ) : null
          }
          <div style={{ display: 'none' }}>
            {
              form.getFieldDecorator('userList')(<Input />)
            }
          </div>
        </Row>
      </Form>
    )
  }
}

export default Form.create()(SubmitContent)
