import * as React from 'react'
// import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import Modal from 'lbc-wrapper/lib/modal'
import Button from 'lbc-wrapper/lib/button'
import SubmitContent from './SubmitContent'
import ajaxActions, { SubmitFlowModuleInjectedProps } from './SubmitFlowModule'
import { SubmitOpenOptions, ApproveUser } from './WorkFlowTypes'

interface SubmitFlowModalProps extends SubmitOpenOptions, SubmitFlowModuleInjectedProps {
  show: boolean
  taskCompleted: (param: any) => Promise<any>
  onClose: () => void
  onOK: () => void
}

interface SubmitFlowModalState {
  loading: boolean
}

class SubmitFlowModal extends React.PureComponent<SubmitFlowModalProps, SubmitFlowModalState> {
  private content: any | null
  constructor(props: SubmitFlowModalProps) {
    super(props)

    this.onOK = this.onOK.bind(this)
    this.close = this.close.bind(this)
    this.successCallback = this.successCallback.bind(this)
    this.loading = this.loading.bind(this)

    this.state = {
      loading: false,
    }
  }

  public onOK() {
    const { taskCompleted, actionTypeAllowed, taskInstId, comment, userList = [] } = this.props
    this.content.validateFields((errors: any, values: any) => {
      if (errors) {
        return
      }

      const users = values.nextUserList || [ values.nextUser ]
      const usersObj = {}
      users.forEach((u: string) => (usersObj[u] = true))

      const realUserList = values.userList || userList

      const userTo = realUserList.filter((u: ApproveUser) => usersObj[u.userId])

      taskCompleted({
        actionType: actionTypeAllowed,
        assignStrategy: values.assignStrategy,
        comment,
        orgPath: true,
        nextNode: values.nextNode,
        // targetTaskDefKey: values.nextBackNode,
        taskInstanceId: taskInstId,
        userList: userTo,
      }).then(this.successCallback, this.close)
    })
  }

  public close() {
    const { onClose, failCallback } = this.props

    onClose()
    if (failCallback) {
      failCallback()
    }
  }

  public loading(loading: boolean) {
    this.setState({
      loading,
    })
  }

  public successCallback(res: any) {
    const { onOK, successCallback } = this.props
    onOK()
    if (successCallback) {
      return successCallback(res)
    }
    return Promise.resolve(res)
  }

  public render() {
    // if (this.props.loading) {
    //   return null
    // }

    const { onOK, ...props } = this.props

    return (
      <div>
        <Modal
          visible={this.props.show}
          title="审批提示"
          closable
          onCancel={this.close}
          maskClosable={false}
          mask={false}
          destroyOnClose
          keyboard={false}
          confirmLoading={this.state.loading}
          width={800}
          footer={[<Button key="submit" loading={this.state.loading} type="primary" onClick={this.onOK}>确定</Button>]}
        >
          <SubmitContent
            ref={r => (this.content = r)}
            loading={this.loading}
            {...props}
          />
        </Modal>
      </div>
    )
  }
}

// SubmitFlowModal.propTypes = {
//   taskCompleted: PropTypes.func,
//   failCallback: PropTypes.func,
//   successCallback: PropTypes.func,
//   taskInstId: PropTypes.string,
//   onOK: PropTypes.func.isRequired,
// }

// SubmitFlowModal.defaultProps = {
//   failCallback: () => {},
//   successCallback: () => {},
//   taskInstId: '',
// }


export default connect(() => ({}), ajaxActions)(SubmitFlowModal)
