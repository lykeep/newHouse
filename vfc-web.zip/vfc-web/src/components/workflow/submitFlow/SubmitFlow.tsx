import * as React from 'react'
import SubmitFlowModal from './SubmitFlowModal'

import { activityStrategies, flowActions } from '../../../common/workflow'
import { SubmitOpenOptions, ApproveAssignStrategyObj, ApproveAssignStrategyType, ApproveActionAllowed, ApproveNode } from './WorkFlowTypes'

interface SubmitFlowProps {
  loading: boolean
}

interface SubmitFlowState extends SubmitOpenOptions {
  show: boolean
}

class SubmitFlow extends React.PureComponent<SubmitFlowProps, SubmitFlowState> {
  constructor(props: SubmitFlowProps) {
    super(props)

    this.onOK = this.onOK.bind(this)
    this.open = this.open.bind(this)
    this.close = this.close.bind(this)
    this.state = {
      show: false,
      backNodeList: [],
      assignStrategy: null,
      nextNodeList: [],
      userList: [],
      actionTypeAllowed: null,
      nextStepOK: null,
      successCallback: null,
      failCallback: null,
      taskInstId: '',
      comment: '',
    }
  }

  public onOK() {
    this.setState({
      show: false,
    })
  }

  public open(flowData: SubmitOpenOptions ) {
    this.setState({
      show: true,
      backNodeList: flowData.backNodeList,
      assignStrategy: flowData.assignStrategy,
      nextNodeList: flowData.nextNodeList,
      userList: flowData.userList,
      actionTypeAllowed: flowData.actionTypeAllowed,
      nextStepOK: flowData.nextStepOK,
      taskInstId: flowData.taskInstId,
      successCallback: flowData.successCallback,
      failCallback: flowData.failCallback,
      comment: flowData.comment,
    })
  }

  public close() {
    this.setState({
      show: false,
    })
  }

  public render() {
    if (this.props.loading) {
      return null
    }

    return (
      <SubmitFlowModal {...this.state} onOK={this.onOK} onClose={this.close} />
    )
  }
}
export const shouldOpenSubmitModal = (as: ApproveAssignStrategyObj | ApproveAssignStrategyType, actionType: ApproveActionAllowed) => {
  if (!actionType || typeof actionType !== 'string') {
    console.error('处理意见必须是第二个参数')
  }
  if (actionType !== flowActions.approve && actionType !== flowActions.submit) {
    return false
  }

  let assignStrategy = as
  let nodeList: ApproveNode[] = []

  if (typeof as !== 'string') {
    assignStrategy = as.assignStrategy
    nodeList = as.nodeList || []
  } else {
    console.error('分配策略应该传对象')
  }

  return nodeList.length > 1 || assignStrategy === activityStrategies.manual || assignStrategy === activityStrategies.countersign
}

export default SubmitFlow
