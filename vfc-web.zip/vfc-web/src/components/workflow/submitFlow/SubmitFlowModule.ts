import { taskCompleted, taskNextNodePart, processDefStart } from '../../../modules/workflow'

export interface SubmitFlowModuleInjectedProps {
  taskCompleted: (param: any) => Promise<any>
  taskNextNodePart: (param: any) => Promise<any>
  processDefStart: (param: any) => Promise<any>
}
export default {
  taskCompleted,
  taskNextNodePart,
  processDefStart,
}
