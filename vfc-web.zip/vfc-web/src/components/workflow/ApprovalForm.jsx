import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import SelectField from '../form/inputs/SelectField'
import TextareaField from '../form/inputs/TextareaField'

import { flowActions } from '../../common/workflow'

const actionLabels = {
  [flowActions.submit]: '提交',
  [flowActions.approve]: '批准',
  [flowActions.back]: '退回',
  [flowActions.recall]: '撤回',
  [flowActions.reject]: '否决',
  [flowActions.counter]: '加签',
  [flowActions.revoke]: '撤销',
  [flowActions.circulation]: '传阅',
}

const buildOptions = (actionTypeAllowed = []) => actionTypeAllowed.map(a => ({
  title: actionLabels[a],
  value: a,
  key: a,
}))

class ApprovalForm extends Component {
  constructor(props) {
    super(props)

    this.onSave = this.onSave.bind(this)

    this.applyTypes = []

    this.actions = [
      {
        id: 'save',
        label: '保存',
        type: 'primary',
        onClick: this.onSave,
      },
    ]
  }

  onSave() {
    const { form, saveCallback } = this.props

    form.validateFields((errors, values) => {
      if (errors) {
        console.log(errors)
        return
      }

      saveCallback(values)
    })
  }

  render() {
    const { form, data, authority, workflowActions, backNodeList = [] } = this.props
    return (
      <div>
        <Form>
          <Row gutter={16} type="flex" align="top">
            <SelectField
              form={form}
              authority={authority}
              name="actionType"
              formItemProps={{ label: '操作' }}
              fieldProps={{
                initialValue: data.actionType,
                rules: [
                  { required: true, message: '操作为必选项！' },
                ],
              }}
              inputProps={{
                options: buildOptions(workflowActions),
                placeholder: '请选择',
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="targetTaskDefKey"
              show={form.getFieldValue('actionType') === flowActions.back}
              formItemProps={{ label: '退回到' }}
              fieldProps={{
                initialValue: data.targetTaskDefKey,
                rules: [
                  { required: true, message: '退回节点为必选项！' },
                ],
              }}
              inputProps={{
                options: backNodeList.map(b => ({
                  title: b.taskNodeNm,
                  value: b.taskDefCd,
                  key: b.taskDefCd,
                })),
                placeholder: '请选择',
                allowClear: false,
              }}
            />
            <SelectField
              form={form}
              authority={authority}
              name="orgPath"
              show={form.getFieldValue('actionType') === flowActions.back}
              formItemProps={{ label: '是否原路径返回' }}
              fieldProps={{
                initialValue: true,
                rules: [
                  { required: true, message: '是否原路径返回为必选项！' },
                ],
              }}
              inputProps={{
                options: [
                  { label: '是', value: true, key: 'Y' },
                  { label: '否', value: false, key: 'N' },
                ],
                placeholder: '请选择',
                allowClear: false,
              }}
            />
            <TextareaField
              colSpan={24}
              form={form}
              authority={authority}
              name="comment"
              formItemProps={{ label: '意见' }}
              fieldProps={{
                initialValue: data.comment,
              }}
              inputProps={{
                placeholder: '请输入',
                rows: 8,
                maxLength: 500,
              }}
            />

          </Row>
        </Form>
      </div>
    )
  }
}

ApprovalForm.propTypes = {
  form: PropTypes.object.isRequired,
  authority: PropTypes.string.isRequired,
  data: PropTypes.object,
  workflowActions: PropTypes.array.isRequired,
  saveCallback: PropTypes.func.isRequired,
  backNodeList: PropTypes.array,
}

ApprovalForm.defaultProps = {
}

export default ApprovalForm
