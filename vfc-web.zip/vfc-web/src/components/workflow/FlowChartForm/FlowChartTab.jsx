import React, { Component } from 'react'
import { connect } from 'react-redux'
import PropTypes from 'prop-types'
import Row from 'lbc-wrapper/lib/row'
import Col from 'lbc-wrapper/lib/col'
import { processFlowChart } from '../../../modules/workflow'

const mapActionCreators = {
  queryFlowChart: processFlowChart,
}

class FlowChartTab extends Component {
  constructor(props) {
    super(props)

    this.state = {
      data: '',
    }
  }

  componentDidMount() {
    const { procInstanceId } = this.props
    this.props.queryFlowChart({ procInstId: procInstanceId }).then((data) => {
      this.setState({
        data: `data:image/png;base64,${data.flowChar}`,
      })
    })
  }

  render() {
    return (
      <div>
        <Row gutter={16} type="flex" align="top">
          <Col colSpan={24}>
            <img src={this.state.data} style={{ width: '100%' }} alt="流程图" />
          </Col>
        </Row>
      </div>
    )
  }
}

FlowChartTab.propTypes = {
  procInstanceId: PropTypes.string,
  queryFlowChart: PropTypes.func,
}


export default connect(() => ({}), mapActionCreators)(FlowChartTab)
