import { createFetchAction } from 'modules/common'

const WORK_FLOW_CHART_QUERY = 'WORK_FLOW_CHART_QUERY'

const queryFlowChart = createFetchAction(WORK_FLOW_CHART_QUERY, 'vfc-intf-ent-base.processFlowChart')

export default queryFlowChart

