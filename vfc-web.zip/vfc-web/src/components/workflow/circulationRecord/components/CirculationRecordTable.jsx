import React, { Component } from 'react'
import { connect } from 'react-redux'
import PropTypes from 'prop-types'
import Table from 'lbc-wrapper/lib/table'
import Icon from 'lbc-wrapper/lib/icon'
import CirculationRecordModal from './CirculationRecordModal'
import { taskFlowList } from '../../../../modules/workflow'
import flowActionRender from '../../../columnRenders/flowAction'

const mapActionCreators = {
  queryCirculationList: taskFlowList,
}

class CirculationRecordTable extends Component {
  constructor(props) {
    super(props)
    this.onClick = this.onClick.bind(this)

    this.state = {
      visible: false,
      record: {},
      circulationListData: [],
    }

    this.columns = [
      {
        title: '节点名称',
        dataIndex: 'taskNodeName',
        key: 'taskNodeName',
      }, {
        title: '计划操作人',
        dataIndex: 'planUserName',
        key: 'planUserName',
      }, {
        title: '实际操作人',
        dataIndex: 'actualUserName',
        key: 'actualUserName',
      }, {
        title: '开始时间',
        dataIndex: 'startTime',
        key: 'startTime',
      }, {
        title: '完成时间',
        dataIndex: 'actualCompleteTime',
        key: 'actualCompleteTime',
      }, {
        title: '操作类型',
        dataIndex: 'actionType',
        key: 'actionType',
        render: flowActionRender,
      },
      {
        title: '会签结果',
        dataIndex: 'availableAm',
        key: 'availableAm',
      },
      {
        title: '备注',
        dataIndex: 'votingResult',
        key: 'votingResult',
        width: '65px',
        render: (text, record) => (
          <span
            role="button"
            style={{ cursor: 'pointer' }}
            onClick={() => this.onClick(record)}
          >
            <Icon type="eye-o" />
          </span>
        ),
      },
    ]
  }
  componentDidMount() {
    const { procInstanceId } = this.props
    const params = {
      procInstanceId,
    }
    this.props.queryCirculationList(params).then((data) => {
      this.setState({
        circulationListData: data.taskFlowList.map((d, i) => ({ ...d, id: `${i}` })),
      })
    })
  }
  onClick = (record) => {
    this.setState({
      visible: true,
      record,
    })
  }

  handleCancel = () => {
    this.setState({ visible: false })
  }

  render() {
    const { visible } = this.state
    return (
      <div>
        <Table
          dataSource={this.state.circulationListData}
          columns={this.columns}
          position="left"
          rowKey="id"
          pagination={false}
          bordered
        />
        <CirculationRecordModal
          visible={visible}
          record={this.state.record}
          authority="2"
          onCancel={this.handleCancel}
        />
      </div>
    )
  }
}

CirculationRecordTable.propTypes = {
  queryCirculationList: PropTypes.func,
  procInstanceId: PropTypes.string,
}


export default connect(() => ({}), mapActionCreators)(CirculationRecordTable)
