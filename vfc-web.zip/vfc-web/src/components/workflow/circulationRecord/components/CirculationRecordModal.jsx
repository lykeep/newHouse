import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Modal from 'lbc-wrapper/lib/modal'
import Form from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import InputField from '../../../form/inputs/InputField'
import SelectField from '../../../form/inputs/SelectField'
import TextareaField from '../../../form/inputs/TextareaField'
import { PERMISSIONS } from '../../../form/utils/calPermission'
import { flowActionOptions } from '../../../columnRenders/flowAction'

class CirculationRecordModal extends Component {
  constructor(props) {
    super(props)
    this.state = {

    }
    this.actionType = [
      { title: '提交', value: '101600000010', key: '101600000010' },
      { title: '批准', value: '101600000020', key: '101600000020' },
      { title: '退回', value: '101600000030', key: '101600000030' },
      { title: '撤回', value: '101600000040', key: '101600000040' },
      { title: '否决', value: '101600000050', key: '101600000050' },
      { title: '加签', value: '101600000060', key: '101600000060' },
      { title: '撤销', value: '101600000070', key: '101600000070' },
      { title: '传阅', value: '101600000080', key: '101600000080' },
      { title: '任务转发', value: '101600000090', key: '101600000090' },
      { title: '附条件同意', value: '101600000100', key: '101600000100' },
    ]
  }

  handleCancel = () => {
    this.props.onCancel()
    this.props.form.resetFields();
  }

  render() {
    const { visible, form, record = {}, authority = PERMISSIONS.MODIFY} = this.props
    return (
      <Modal
        visible={visible}
        title="查看-流转记录"
        onCancel={this.handleCancel}
        footer={null}
        width={1000}
      >
        <Form>
          <Row gutter={16} type="flex" align="top">
            <SelectField
              colSpan={12}
              key="actionType"
              form={form}
              authority={authority}
              name="actionType"
              formItemProps={{ label: '操作类型' }}
              fieldProps={{
                initialValue: record.actionType,
              }}
              inputProps={{
                options: flowActionOptions,
                disabled: true,
              }}
            />
            <InputField
              colSpan={12}
              key="planUserName"
              form={form}
              authority={authority}
              name="planUserName"
              formItemProps={{ label: '计划操作人' }}
              fieldProps={{
                initialValue: record.planUserName,
              }}
              inputProps={{
                disabled: true,
              }}
            />
            <InputField
              colSpan={12}
              key="actualUserName"
              form={form}
              authority={authority}
              name="actualUserName"
              formItemProps={{ label: '实际操作人' }}
              fieldProps={{
                initialValue: record.actualUserName,
              }}
              inputProps={{
                disabled: true,
              }}
            />
            <InputField
              colSpan={12}
              key="startTime"
              form={form}
              authority={authority}
              name="startTime"
              formItemProps={{ label: '开始时间' }}
              fieldProps={{
                initialValue: record.startTime,
              }}
              inputProps={{
                disabled: true,
              }}
            />
            <InputField
              colSpan={12}
              key="actualCompleteTime"
              form={form}
              authority={authority}
              name="actualCompleteTime"
              formItemProps={{ label: '完成时间' }}
              fieldProps={{
                initialValue: record.actualCompleteTime,
              }}
              inputProps={{
                disabled: true,
              }}
            />
            <InputField
              colSpan={12}
              key="availableAm"
              form={form}
              authority={authority}
              name="availableAm"
              formItemProps={{ label: '会签结果' }}
              fieldProps={{
                initialValue: record.availableAm,
              }}
              inputProps={{
                disabled: true,
              }}
            />
            <TextareaField
              colSpan={24}
              form={form}
              authority={authority}
              name="comment"
              formItemProps={{ label: '意见' }}
              fieldProps={{
                initialValue: record.comment,
              }}
              inputProps={{
                rows: 8,
                disabled: true,
              }}
            />
          </Row>
        </Form>
      </Modal>
    )
  }
}
CirculationRecordModal.propTypes = {
  visible: PropTypes.bool,
  record: PropTypes.object,
  authority: PropTypes.string,
  onCancel: PropTypes.func,
  form: PropTypes.object,
}
export default Form.create()(CirculationRecordModal)
