import React, { Component } from 'react'
import PropTypes from 'prop-types'
import QueryTable from '../queryTable'

class QueryListTable extends Component {
  constructor(props) {
    super(props)
    this.query = this.query.bind(this)
    this.refresh = this.refresh.bind(this)

    this.state = {
      data: [],
    }
  }

  query(params) {
    const { listName } = this.props
    this.props.query({
      ...params,
    }).then((data) => {
      this.setState({
        data: data[listName],
        totalCount: data.total,
      })
    })
  }

  refresh() {
    this.tableRef.refresh()
  }
  render() {
    const { columns, fields, actions, query, ...props } = this.props
    return (
      <div>
        <QueryTable
          ref={r => (this.tableRef = r)}
          columns={columns}
          fields={fields}
          actions={actions}
          query={this.query}
          data={this.state.data}
          rowKey={this.props.rowkey}
          totalCount={this.state.totalCount}
          {...props}
        />
      </div>
    )
  }
}

QueryListTable.propTypes = {
  actions: PropTypes.array,
  columns: PropTypes.array,
  fields: PropTypes.array,
  query: PropTypes.func.isRequired,
  listName: PropTypes.string.isRequired,
}

export default QueryListTable
