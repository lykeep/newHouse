import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Table from 'lbc-wrapper/lib/table'
import Icon from 'lbc-wrapper/lib/icon'

class TableForm extends Component {
  constructor(props) {
    super(props)

    this.columns = (props.multiple && !props.inView) ? props.columns.concat({
      key: 'opr',
      title: '操作',
      dataIndex: 'opr',
      width: 100,
      render: (text, record) => (
        <span onClick={() => this.onDelete(record)} className="opr" role="button">
          <Icon type="delete" />
        </span>
      ),
    }) : props.columns
  }

  onDelete(record) {
    const { value, rowKey, onChange } = this.props
    let i = 0;
    for (; i < value.length; i += 1) {
      if (value[i][rowKey] === record[rowKey]) {
        break
      }
    }

    onChange([...value.slice(0, i), ...value.slice(i + 1)])
  }

  render() {
    const { value=[], onChange, columns, multiple, isShowNbr, ...props } = this.props
    return (
      <Table
        dataSource={isShowNbr ? value.map((v, i) => ({ ...v, index: i + 1 })) : value}
        columns={this.columns}
        bordered
        {...props}
      />
    )
  }
}

TableForm.propTypes = {
  multiple: PropTypes.bool,
  columns: PropTypes.array,
  value: PropTypes.array,
  rowKey: PropTypes.string.isRequired,
  onChange: PropTypes.func,
  inView: PropTypes.bool,
}

export default TableForm
