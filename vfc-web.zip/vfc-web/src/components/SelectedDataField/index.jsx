
import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Col from 'lbc-wrapper/lib/col'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import Icon from 'lbc-wrapper/lib/icon'
import NameFilterModal from '../../components/form/inputs/nameFilterModal/NameFilterModal'
import calPermission, { PERMISSIONS } from '../form/utils/calPermission'
import TableForm from './TableForm'
import { effectiveArray } from '../../utils/dataType'

import './index.scss'

class SelectedDataField extends Component {
  constructor(props) {
    super(props)
    this.state = {
      selectedData: [],

      state: false,
    }
  }

  componentDidMount() {
    const { fieldProps={} } = this.props
    this.setState({
      selectedData: fieldProps.initialValue || [],
    })
  }

  onChange = (val) => {
    const { selectedData } = this.state
    const { onChange, multiple = false, name, selectorProps, filterKey } = this.props
    const { mapping } = selectorProps
    const dataList = [val]
    const newData = {}
    const list = selectedData.slice(0)
    mapping.forEach((item) => {
      dataList.map((i) => {
        Object.assign(newData, { [item.name]: i[item.dataKey] })
      })
    })

    if (multiple) {
      const fList = list.filter(i => i[filterKey] === newData[filterKey])
      if (fList.length === 0) {
        list.push(newData)
      }
    }

    this.setState({
      selectedData: multiple ? list : [newData],
      state: dataList.length === 0,
    }, () => this.props.form.setFieldsValue({ [name]: multiple ? list : [newData] }))
    if (onChange) {
      onChange(newData)
    }
    selectorProps.onChange && selectorProps.onChange(val)
  }

  onDelete = (key, record) => {
    const { selectedData } = this.state

    const { name } = this.props
    const list = selectedData.filter(item => item[key] !== record[key])
    console.log('acctNo', list)
    this.setState({
      selectedData: list,
    }, () => this.props.form.setFieldsValue({ [name]: list }))
  }

  regroup = (tableColumns, key, multiple) => {
    const newColumns = []
    tableColumns.forEach((item) => {
      newColumns.push({
        key: item.dataIndex,
        title: item.title,
        dataIndex: item.dataIndex,
      })
    })

    if (multiple) {
      newColumns.push({
        key: 'opr',
        title: '操作',
        dataIndex: 'opr',
        width: 100,
        render: (text, record) => (
          <span role="button" onClick={() => this.onDelete(key, record)} className="opr" >
            <Icon type="delete" />
          </span>
        ),
      })
    }

    return newColumns
  }

  validator = (rule, value, callback) => {
    if (!effectiveArray(value)) {
      this.setState({ state: true })
      callback('');
    } else {
      this.setState({ state: false })
      callback();
    }
  }

  renderNormal() {
    const { form, name, fieldProps = {}, multiple = false, required = false, inputProps={}, authority, selectorProps, formItemProps, pagination = false, parameters = {}, filterKey } = this.props
    const { getFieldDecorator } = form
    let columns = []
    if (multiple) {
      columns = this.regroup(inputProps.columns, filterKey, multiple)
    }
    return (
      <Col span={24} className="lb-col-gutter selected-data" >
        <div style={{ zIndex: 99 }} className="btn">
          <NameFilterModal
            colSpan={12}
            authority={authority}
            modalData={{
                columns: selectorProps.columns,
            }}
            fieldProps={fieldProps}
            formItemProps={formItemProps}
            parameters={parameters}
            useForm={false}
            type={{
              disabled: true,
              type: 'button',
              name: selectorProps.buttonLabel,
              btnStyle: this.state.state,
              required,
            }}
            tips={selectorProps.tips}
            doPagination={selectorProps.doPagination}
            disabledFunc={selectorProps.disabledFunc}
            filterKey={filterKey}
            action={selectorProps.action}
            modelKey={selectorProps.modelKey}
            receivekey={selectorProps.receivekey}
            onChange={this.onChange}
            name={selectorProps.name}
          />
        </div>
        <SimpleFormItem className={this.state.state ? 'selected-table' : ''}>
          {
            getFieldDecorator(name, {
              ...fieldProps,
             rules: [
                { required: this.props.required, message: '请选择一条数据！' },
                { validator: this.validator },
              ],
            })(<TableForm {...inputProps} columns={multiple ? columns : inputProps.columns} pagination={pagination} />)
          }
        </SimpleFormItem>
      </Col>
    )
  }

  renderRead() {
    const { inputProps, form, name, fieldProps, formItemProps, pagination = false } = this.props
    const { getFieldDecorator } = form

    return (
      <Col span={24} className="lb-col-gutter">
        <SimpleFormItem {...formItemProps}>
          { getFieldDecorator(name, fieldProps)(<TableForm size="middle" pagination={pagination} {...inputProps} />)}
        </SimpleFormItem>
      </Col>
    )
  }

  render() {
    const permis = calPermission(this.props.authority)
    const { show = true } = this.props

    if (!show) {
      return null
    }

    if (permis === PERMISSIONS.MODIFY) {
      return this.renderNormal()
    } else if (permis === PERMISSIONS.READ) {
      return this.renderRead()
    }

    // HIDE
    return null
  }
}

SelectedDataField.propTypes = {
  authority: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  fieldProps: PropTypes.shape({
    initialValue: PropTypes.array,
  }),
  inputProps: PropTypes.shape({
    columns: PropTypes.array,
    rowKey: PropTypes.string.isRequired,
  }),
  selectorProps: PropTypes.shape({
    modelKey: PropTypes.string.isRequired,
    receivekey: PropTypes.array.isRequired,
    action: PropTypes.func.isRequired,
    columns: PropTypes.array.isRequired,
  }),

}

export default SelectedDataField
