import React from 'react'
import './logo.scss'

const suffix = !process.env.REACT_APP_DWY ? '' : '_dwy'

const Logo = props => props.boxwrap ? (
  <div className={`logo_box${suffix}`}>
  	{props.collapsed ? (
  	  'vfc'
  	) : (
  	  <img
  	  	className='logo_img'
  	  	src={require(`./LOGO${suffix}.png`)}
  	  	alt="蔷薇数字金融平台"
  	  />
  	)}
  </div>
) : (
  <img
  	className='logo_img'
  	src={require(`./LOGO${suffix}.png`)}
  	alt="蔷薇数字金融平台"
  />
)

export default Logo
