import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import Popover from 'lbc-wrapper/lib/popover'

import './longStringWrapper.scss'

class LongStringWrapper extends PureComponent {
  render() {
    const { value } = this.props

    if (!value) {
      return <span />
    }

    return (
      <div style={{ display: 'inline-block' }}>
        {
              <Popover content={value}>
                <span >{`${value.substr(0, prefix)}...${value.substr(0 - surfix)}`}</span>
              </Popover>
        }

        {
          !showCopy ? null : (<span style={{ cursor: 'pointer' }} ref={(t) => { this.button = t }}><Icon type="copy" /></span>)
        }
      </div>
    )
  }
}

LongStringWrapper.propTypes = {
  value: PropTypes.string,
  prefix: PropTypes.number,
  surfix: PropTypes.number,
  showAll: PropTypes.bool,
  showCopy: PropTypes.bool,
  showPropover: PropTypes.bool,
}

LongStringWrapper.defaultProps = {
  prefix: 20,
  surfix: 20,
  showAll: false,
  showCopy: true,
  showPropover: true,
  value: '',
}

export default LongStringWrapper
