import * as React from 'react'
import QueryTable, { QueryTableProps, Field } from '../queryTable'
import Status from '../status'

import ApplyNoWrapper from '../ApplyNoWrapper/ApplyNoWrapper'
import { isDraftSelectOptions, isDraftRender } from '../../common/isDraft'
import { flowStatusOptions } from '../../common/workflow'
import { ColumnProps } from 'lbc-wrapper/lib/table'
import { SelectOptionLB } from 'lbc-wrapper/lib/select'
import { Omit } from '../../types/utils'

export interface ApplicationTableData {
  businessKey: string
  busiApplyType: string
  startTime: string
  actualCompleteTime: string
  isDraft: string
  status: string
  procInstanceId?: string
  uiName?: string
}

export interface ApplicationTableProps<T> extends Omit<QueryTableProps<T>, 'fields'> {
  bizKeyUrl: (value: string, record: T) => string
  applyTypeRender: (value: string, record: T) => string
  SelectOptions: SelectOptionLB[]
  listName: string
  fields: Field[]
}

interface ApplicationTableState<T> {
  data: T[]
  totalCount: number|string
}

class ApplicationTable<T extends ApplicationTableData> extends React.Component<ApplicationTableProps<T>, ApplicationTableState<T>> {
  public static defaultProps = {
    columns: []
  }

  private columns: Array<ColumnProps<T>>
  private fields0: Field[]
  private fields: Field[][]
  private tableRef: QueryTable<T> | null



  constructor(props: ApplicationTableProps<T>) {
    super(props)
    this.query = this.query.bind(this)
    this.refresh = this.refresh.bind(this)

    const columnsPart0 = [
      {
        title: '申请编号',
        dataIndex: 'businessKey',
        key: 'businessKey',
        render: (value: string, record: T) => (<ApplyNoWrapper value={value} to={props.bizKeyUrl(value, record)} />),
      },
    ]
    const columnsPart1 = [
      {
        title: '申请类型',
        dataIndex: 'busiApplyType',
        key: 'busiApplyType',
        render: props.applyTypeRender,
      },
    ]
    const columnsPart2 = [
      {
        title: '流程开始时间',
        dataIndex: 'startTime',
        key: 'startTime',
        // sorter: true,
      },
      {
        title: '流程结束时间',
        dataIndex: 'actualCompleteTime',
        key: 'actualCompleteTime',
        // sorter: true,
      },
    ]
    const columnsPart3 = [
      {
        title: '是否草稿',
        dataIndex: 'isDraft',
        key: 'isDraft',
        render: isDraftRender,
        width: 100,
      },
      {
        title: '流程状态',
        dataIndex: 'status',
        key: 'status',
        render: (value: string) => (<Status status={value} />),
        width: 100,
      },
    ]

    this.columns = [...columnsPart0, ...props.columns!, ...columnsPart1, ...columnsPart2, ...columnsPart3]

    this.fields0 = [
      { id: 'businessKey', label: '申请编号', component: 'Input' },
      { id: 'isDraft', label: '是否草稿', type: 'Select', options: isDraftSelectOptions },
      { id: 'status', label: '流程状态', type: 'Select', options: flowStatusOptions },
    ]

    if (props.SelectOptions && props.SelectOptions.length > 1) {
      this.fields0.push({ id: 'busiApplyType', label: '申请类型', type: 'Select', options: props.SelectOptions })
    }
    this.fields = [props.fields, this.fields0]
    this.state = {
      data: [],
      totalCount: '0'
    }
  }

  public query(params: any): Promise<any> {
    const { listName } = this.props
    return this.props.query({
      ...params,
    }).then((data) => {
      this.setState({
        data: data[listName],
        totalCount: data.total,
      })
    })
  }

  public refresh(): void {
    if (this.tableRef) {
      this.tableRef.refresh()
    }
  }

  public render() {
    const { columns, fields, actions, query, ...props } = this.props
    return (
      <div>
        <QueryTable<T>
          ref={r => (this.tableRef = r)}
          columns={this.columns}
          fields={this.fields}
          actions={actions}
          query={this.query}
          data={this.state.data}
          totalCount={this.state.totalCount}
          rowKey="businessKey"
          {...props}
        />
      </div>
    )
  }
}

export default ApplicationTable
