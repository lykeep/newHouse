export default {
  TAKEN: 'claim',
  UNTAKEN: 'unClaim',
}
