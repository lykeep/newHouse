import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Tabs from 'lbc-wrapper/lib/tabs'
// import './TabMenus.scss'

const TabPane = Tabs.TabPane

class TabsField extends Component {
  constructor(props) {
    super(props)
    this.state = {
    }
    this.onChangeTabs = this.onChangeTabs.bind(this)
  }

  onChangeTabs = (e) => {
    // console.log('onChangeTabs', e)
    if (this.props.onChange) {
      this.props.onChange(e)
    }
  }

  render() {
    const { componentProps, defaultActiveKey } = this.props

    console.log('tabs', componentProps)
    return (
      <div>
        <Tabs onChange={this.onChangeTabs} defaultActiveKey={defaultActiveKey || '0'}>
          {
            componentProps.map((item, index) => {
              if (isFunc(item.type) && isObject(item.props)) {
                return <TabPane tab={item.name || "New Tab"} key={index}><item.type {...item.props} /></TabPane>
              }
              console.log('----tabs请输入正确格式！----')
            })
          }
        </Tabs>
      </div>
    )
  }
}

TabsField.propTypes = {
  componentProps: PropTypes.array.isRequired,
  defaultActiveKey: PropTypes.string,
  onChange: PropTypes.func,
}

const isFunc = (target) => {
  if (Object.prototype.toString.call(target) == '[object Function]') {
    return true
  }
  return false
}

const isObject = (target) => {
  if (Object.prototype.toString.call(target) == '[object Object]') {
    return true
  }
  return false
}


export default TabsField

