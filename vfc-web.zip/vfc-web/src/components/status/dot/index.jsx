import React from 'react'
import PropTypes from 'prop-types'
import './index.scss'

const Dot = ({ color }) => (
  <span className={`lo-status-dot lo-status-dot-${color}`} />
)
Dot.propTypes = {
  color: PropTypes.string.isRequired,
}

export default Dot
