import React from 'react'
import PropTypes from 'prop-types'
import Dot from './dot'
import { flowStatus, handleStatus } from '../../common/workflow'
import { riskResult, riskResultLabels } from '../columnRenders/riskResult'

export const FLOW = 'FLOW'
export const HANDLING = 'HANDLING'
export const CONTRACT = 'CONTRACT'
export const RISK = 'RISK'

const Status = ({ status = '', type = FLOW }) => {
  let color = ''
  let label = ''
  if (type === FLOW) {
    if (status === flowStatus.RUNNING) {
      color = 'yello'
      label = '审批中'
    } else if (status === flowStatus.COMPLETED) {
      color = 'green'
      label = '完成'
    } else if (status === flowStatus.DISCARDED) {
      color = 'grey'
      label = '撤销'
    } else {
      return null
    }
  } else if (type === HANDLING) {
    if (status === handleStatus.NOT_DONE) {
      color = 'red'
      label = '待处理'
    } else if (status === handleStatus.DONE) {
      color = 'green'
      label = '已处理'
    }
  } else if (type === CONTRACT) {

  } else if (type === RISK) {
    if (status === riskResult.SUCCESS) {
      color = 'risk-green'
      label = riskResultLabels[riskResult.SUCCESS]
    } else if (status === riskResult.FAIL) {
      color = 'risk-grey'
      label = riskResultLabels[riskResult.FAIL]
    } else if (status === riskResult.MANUAL) {
      color = 'risk-blue'
      label = riskResultLabels[riskResult.MANUAL]
    }
  }

  return (
    <span>
      <Dot color={color} />
      <span style={{ display: 'inline-block', marginLeft: '8px' }}>{label}</span>
    </span>
  )
}

Status.propTypes = {
  status: PropTypes.string,
}

export default Status
