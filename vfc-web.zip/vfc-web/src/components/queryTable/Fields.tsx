import * as React from 'react'
import Form, { SimpleFormItem, FormComponentProps } from 'lbc-wrapper/lib/form'
import Row from 'lbc-wrapper/lib/row'
import Col from 'lbc-wrapper/lib/col'
import Icon from 'lbc-wrapper/lib/icon'
import Button from 'lbc-wrapper/lib/button'
import Input from 'lbc-wrapper/lib/input'
import Select, { SelectOptionLB } from 'lbc-wrapper/lib/select'
import take from 'lodash/take'
import './style'

const COLUMNS = 3

const colSpan = {
  sm: { span: 24 },
  md: { span: 24 / COLUMNS },
}

export interface Field {
  id: string | string[]
  label: string
  component?: 'Select' | 'Input' | React.ComponentType<any>
  options?: SelectOptionLB[]
  placeholder?: string
  type?: string
  defaultValue?: any
  colSpan?: number
  required?: boolean
  onChange?: (value: any) => any
}

export interface FieldsProps {
  fields: Field[][]
  queryRegister: (register: any) => void
  loadOnMount?: boolean
  resetCallback: () => void
  query: (param: any) => Promise<any>
}

interface FieldsState {
  collapsed: boolean
  loading: boolean
  allFields: Field[]
  shortFields: Field[]
}

class Fields extends React.Component<FieldsProps & FormComponentProps, FieldsState> {
  public static defaultProps = {
    fields: [],
    loadOnMount: true,
  }

  public static getDerivedStateFromProps(props: FieldsProps) {
    const allFields = [...props.fields[0] || [], ...props.fields[1] || []]

    return {
      allFields,
      shortFields: take(allFields, 2),
    }
  }

  private queryCondition: any

  constructor(props: FieldsProps & FormComponentProps) {
    super(props)

    const allFields: Field[] = [...props.fields[0] || [], ...props.fields[1] || []]

    this.state = {
      collapsed: true,
      loading: false,
      allFields,
      shortFields: take(allFields, 2),
    }

    this.renderButtons = this.renderButtons.bind(this)
    this.renderFormItems = this.renderFormItems.bind(this)
    this.renderFormItem = this.renderFormItem.bind(this)
    this.renderFormItemByType = this.renderFormItemByType.bind(this)
    this.renderFormItemSelect = this.renderFormItemSelect.bind(this)
    this.renderFormItemInput = this.renderFormItemInput.bind(this)
    this.renderFormItemSpecific = this.renderFormItemSpecific.bind(this)
    this.query = this.query.bind(this)
    this.reset = this.reset.bind(this)
    this.toggleForm = this.toggleForm.bind(this)
    this.onQueryClick = this.onQueryClick.bind(this)
    this.pageChangeQuery = this.pageChangeQuery.bind(this)

    // this.allFields = [...props.fields[0] || [], ...props.fields[1] || []]
    // this.shortFields = take(this.allFields, 2)
  }

  public componentDidMount() {
    // this.props.queryRegister(this.query)
    this.props.queryRegister(this.pageChangeQuery)
    if (this.props.loadOnMount) {
      this.query()
    }
  }

  public onQueryClick() {
    if (this.props.resetCallback) {
      this.props.resetCallback()
    }
    this.query()
  }

  public pageChangeQuery() {
    this.props.query(this.queryCondition)
  }

  public query() {
    const { query, form } = this.props
    // const { collapsed } = this.state

    const fieldIDs: string[] = []
    const realFields = this.state.allFields
    // const realFields = collapsed ? this.shortFields : this.allFields
    // const realFields = collapsed ? fields[0] : [...this.props.fields[0], ...this.props.fields[1]]
    realFields.forEach((f) => {
      if (typeof f.id === 'string') {
        fieldIDs.push(f.id)
      } else if (Array.isArray(f.id)) {
        f.id.forEach(i => fieldIDs.push(i))
      }
    })
    form.validateFields(fieldIDs, {}, (errors, values) => {
      if (errors) {
        return
      }

      this.setState({
        loading: true,
      })

      const toBeSent = {}
      fieldIDs.forEach((f) => {
        toBeSent[f] = values[f]
      })

      // save query conditions
      this.queryCondition = toBeSent

      const retPromise = query(toBeSent)

      if (!retPromise) {
        this.setState({
          loading: false,
        })
        return
      }

      retPromise.then(() => {
        this.setState({
          loading: false,
        })
      }).catch(() => {
        this.setState({
          loading: false,
        })
      })
    })
  }

  public reset() {
    this.props.form.resetFields()
    // 2018-09-19，增加以下两个重置，因为resetFields无法清除从render里设置的值，只能显式重新设置
    this.props.form.setFieldsValue({
      taskState: '',
      busiApplyType: '',
    })
    if (this.props.resetCallback) {
      this.props.resetCallback()
    }
  }

  public toggleForm() {
    this.setState({
      collapsed: !this.state.collapsed,
    })
  }

  public renderButtons() {
    const { collapsed } = this.state
    // const noCollapse = fields.length === 1 // || fields[1].length === 1
    const noCollapse = this.state.allFields.length < 3 // || fields[1].length === 1
    const fieldsNum = collapsed ? this.state.shortFields.length : this.state.allFields.length
    // const fieldsNum = collapsed ? fields[0].length : (fields[0].length + (fields[1] ? fields[1].length : 0))
    const allLine = fieldsNum % COLUMNS === 0 // 独占一行

    const collapseButton = (
      <a style={{ marginLeft: 8 }} onClick={this.toggleForm} role="button">
        {
          collapsed ? (<span className="up-or-down">展开 <Icon type="down" /></span>) : (<span className="up-or-down">收起 <Icon type="up" /></span>)
        }
      </a>
    )

    const buttons = (
      <div className="lb-query-table-buttons">
        <span style={allLine ? { display: 'block', float: 'right' } : {}}>
          <Button htmlType="submit" type="primary" onClick={this.onQueryClick} loading={this.state.loading}>
            查询
          </Button>
          <span className="reset-btn">
            <Button style={{ marginLeft: 8 }} onClick={this.reset}>
              重置
            </Button>
          </span>

          {
            noCollapse ? null : collapseButton
          }
        </span>
      </div>
    )

    return (
      <Col {...colSpan} offset={allLine ? (24 - (24 / COLUMNS)) : 0}>
        {
          buttons
        }
      </Col>
    )
  }

  public renderFormItems() {
    const fields = this.state.allFields
    // const fields = this.state.collapsed ? this.shortFields : this.allFields

    return fields.map((f, i) => this.renderFormItem(f, this.state.collapsed ? (i > 1) : false))
  }

  public renderFormItem(field: Field, hidden: boolean) {
    const { form } = this.props
    const { getFieldDecorator } = form

    let fieldID = ''

    if (typeof field.id === 'string') {
      fieldID = field.id
    } else {
      fieldID = field.id[0]
    }

    if (field.component !== undefined && typeof field.component !== 'string') {
      return hidden ? null : this.renderFormItemSpecific(field.component, field)
    }

    const item = hidden ? (<Input type="hidden" key={fieldID} />) : this.renderFormItemByType(field)

    if (hidden) {
      return getFieldDecorator(fieldID, { initialValue: field.defaultValue })(item)
    }

    return (
      <Col {...(field.colSpan || colSpan)} key={fieldID}>
        <SimpleFormItem
          label={field.label}
          required={field.required}
        >
          {
            getFieldDecorator(fieldID, {
              initialValue: field.defaultValue,
              // onChange: field.onChange, // comment while to TS
              rules: [
                { required: field.required, message: `请选择${field.label}` },
              ],
            })(item)
          }
        </SimpleFormItem>
      </Col>

    )
  }

  public renderFormItemByType(field: Field) {
    if (field.component === 'Select' || field.type === 'Select') {
      return this.renderFormItemSelect(field)
    }

    return this.renderFormItemInput(field)
  }

  public renderFormItemSelect(field: Field) {

    const change = field.onChange ? { onChange: field.onChange } : {}
    const select = (
      <Select allowClear={!field.required} dropdownMatchSelectWidth style={{ width: '100%' }} options={field.options} {...change} />
    )

    return select
  }

  public renderFormItemInput(field: Field) {
    const change = field.onChange ? { onChange: field.onChange } : {}
    return (<Input placeholder={field.placeholder} type={field.type} autoComplete="off" {...change} />)
  }

  public renderFormItemSpecific(Comp: React.ComponentType<any>, field: Field) {
    const change = field.onChange ? { onChange: field.onChange } : {}
    let fieldID = ''
    if (typeof field.id === 'string') {
      fieldID = field.id
    } else {
      fieldID = field.id[0]
    }
    return (
      <Col {...(field.colSpan || colSpan)} key={fieldID}>
        <Comp form={this.props.form} field={field} {...change} />
      </Col>
    )
  }

  public render() {
    const { fields } = this.props
    if (!fields || fields.length === 0) {
      return null
    }

    return (
      <div className="lb-query-table-fields">
        <Form layout="inline">
          <Row gutter={{ md: 8, lg: 24, xl: 48 }} type="flex" >
            {
              this.renderFormItems()
            }
            {
              this.renderButtons()
            }
          </Row>
        </Form>
      </div>
    )
  }
}

export default Form.create()(Fields)
