import * as React from 'react'
import Icon from 'lbc-wrapper/lib/icon'
import Divider from 'lbc-wrapper/lib/divider'
import Popconfirm from 'lbc-wrapper/lib/popconfirm'

export enum OPERATIONS {
  VIEW = 'V',
  MODIFY = 'M',
  DELETE = 'D',
}

interface OperationProps {
  operations: OPERATIONS[]
  deleteHandler: (param: any) => void
  viewHandler: (param: any) => void
  modifyHandler: (param: any) => void
}

class Operation extends React.Component<OperationProps> {
  public static defaultProps = {
    operations: [
      OPERATIONS.VIEW,
      OPERATIONS.MODIFY,
      OPERATIONS.DELETE,
    ]
  }

  constructor(props: OperationProps) {
    super(props)

    this.renderView = this.renderView.bind(this)
    this.renderModify = this.renderModify.bind(this)
    this.renderDelete = this.renderDelete.bind(this)
  }
  public shouldComponentUpdate() {
    return false
  }

  public renderView() {
    const { viewHandler } = this.props
    return (
      <span onClick={viewHandler} role="button" tabIndex={-1} key="view" style={{ cursor: 'pointer' }} ><Icon type="eye-o" /></span>
    )
  }

  public renderModify() {
    const { modifyHandler } = this.props
    return (
      <span onClick={modifyHandler} role="button" tabIndex={-1} key="modify" style={{ cursor: 'pointer' }} ><Icon type="edit" /></span>
    )
  }

  public renderDelete() {
    const { deleteHandler } = this.props
    return (
      <Popconfirm title="确认要删除这条数据吗？" onConfirm={deleteHandler} key="delete">
        <span role="button" tabIndex={-1} style={{ cursor: 'pointer' }} ><Icon type="delete" /></span>
      </Popconfirm>

    )
  }

  public render() {
    const { operations } = this.props

    const realOps: any[] = []
    operations.forEach((o, i) => {
      if (o === OPERATIONS.VIEW) {
        realOps.push(this.renderView())
      } else if (o === OPERATIONS.MODIFY) {
        realOps.push(this.renderModify())
      } else if (o === OPERATIONS.DELETE) {
        realOps.push(this.renderDelete())
      }

      if (i < operations.length - 1) {
        realOps.push(<Divider type="vertical" key={i} />)
      }
    })
    return (
      <div>
        {realOps}
      </div>
    )
  }
}

export default Operation
