import { handleStatus } from '../../common/workflow'
import { YES } from '../columnRenders/yesOrNo'
import { assetGrnteeStatusType, assetGrnteeTypeType } from '../columnRenders/AssetCollateralType';

const ACTIONS = {
    ADD: {
        label: '新增',
        icon: 'plus',
        key: 'add',
    },
    MODIFY: {
        label: '编辑',
        minSelect: 1,
        maxSelect: 1,
        // icon: 'edit',
        key: 'modify',
        disableFunc: (selectedRowKeys: any, selectedRows: any, selectedRowChange: any) => {
            if (selectedRowKeys.length !== 1) {
                return true
            }

            if (selectedRows[0].isDraft === YES) {
                return false
            }

            return true
        },
    },
    REMOVE: {
        label: '删除',
        minSelect: 1,
        // icon: 'close',
        confirm: true,
        message: '确认要删除这些记录？',
        key: 'remove',
        disableFunc: (selectedRowKeys: any, selectedRows: any, selectedRowChange: any) => {
            if (selectedRowKeys.length !== 1) {
                return true
            }

            if (selectedRows[0].isDraft === YES) {
                return false
            }

            return true
        },
    },
    VIEW_DETAIL: {
        label: '查看',
        minSelect: 1,
        maxSelect: 1,
        // icon: 'info-circle-o',
        key: 'view',
    },
    EXPORT: {
        label: '导出',
        minSelect: 1,
        key: 'export',
    },
    IMPORT: {
        label: '导入',
        minSelect: 1,
        key: 'import',
    },
    ALTER: {
        label: '变更',
        minSelect: 1,
        maxSelect: 1,
        key: 'alter',
    },
    APPROVAL: {
        label: '审批',
        minSelect: 1,
        maxSelect: 1,
        key: 'approval',
        disableFunc: (selectedRowKeys: any, selectedRows: any, selectedRowChange: any) => {
            if (selectedRowKeys.length !== 1) {
                return true
            }

            if (selectedRows[0].taskState === handleStatus.NOT_DONE) {
                return false
            }

            return true
        },
    },
    MAINTENANCE: {
        label: '维护',
        minSelect: 1,
        maxSelect: 1,
        key: 'maintenance',
    },
    EXEMPTED_FINE: {
        label: '罚金豁免',
        // minSelect: 1,
        // maxSelect: 1,
        key: 'exempted',
    },
    REPAY_APPLN: {
        label: '还款申请',
        minSelect: 1,
        maxSelect: 1,
        key: 'repay',
    },
    GET_APPROVETASK: {
        label: '获取任务',
        // minSelect: 1,
        // maxSelect: 1,
        key: 'task', // TODO：key暂时不知道
    },
    PUTIN_STORAGE: {
        label: '入库',
        minSelect: 1,
        maxSelect: 1,
        key: 'task', // TODO：key暂时不知道
        disableFunc: (selectedRowKeys: any, selectedRows: any, selectedRowChange: any) => {
            if (selectedRowKeys.length !== 1) {
                return true
            }

            if ((selectedRows[0].grnteeType !== assetGrnteeTypeType.Grntee)
                && (selectedRows[0].grnteeStatus === assetGrnteeStatusType.TOBEENTER || selectedRows[0].grnteeStatus === assetGrnteeStatusType.ENTERED)) {
                return false
            }

            return true
        },
    },
    PUTOUT_STORAGE: {
        label: '出库',
        minSelect: 1,
        maxSelect: 1,
        key: 'task', // TODO：key暂时不知道
        disableFunc: (selectedRowKeys: any, selectedRows: any, selectedRowChange: any) => {
            if (selectedRowKeys.length !== 1) {
                return true
            }

            if (selectedRows[0].grnteeStatus === assetGrnteeStatusType.TOBEOUT) {
                return false
            }

            return true
        },
    },
    ADDITIONALINFO: {
        label: '补充信息',
        minSelect: 1,
        maxSelect: 1,
        key: 'task', // TODO：key暂时不知道
    },
    PAYDEPOSIT: {
        label: '收支明细',
        minSelect: 1,
        maxSelect: 1,
        key: 'payDeposit', // TODO：key暂时不知道
    },
    RELEASEDETAIL: {
        label: '占用释放明细',
        minSelect: 1,
        maxSelect: 1,
        key: 'release', // TODO：key暂时不知道
    },
    DEDUCTION: {
        label: '抵扣',
        minSelect: 1,
        maxSelect: 1,
        key: 'task', // TODO：key暂时不知道
    },
    HANDBACK: {
        label: '退还',
        minSelect: 1,
        maxSelect: 1,
        key: 'task', // TODO：key暂时不知道
    },
    SDVIEWDETAIL: {
        label: '查看详情',
        minSelect: 1,
        maxSelect: 1,
        key: 'task', // TODO：key暂时不知道
    },
    CONNECTOPER: {
        label: '关联操作员',
        minSelect: 1,
        maxSelect: 1,
        key: 'task', // TODO：key暂时不知道
    },
    DELIMIT: {
        label: '划扣',
        minSelect: 1,
        // maxSelect: 1,
        key: 'delimit',
    },
    OCCUPANCY_RELEASE_DETAILS: {
        label: '占用释放明细',
        minSelect: 1,
        maxSelect: 1,
        key: 'occupancy_release_details', // 授信
    },
}
export default ACTIONS
