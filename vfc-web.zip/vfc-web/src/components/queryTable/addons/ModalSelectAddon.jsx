import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Col from 'lbc-wrapper/lib/col'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import Input from 'lbc-wrapper/lib/input'
import Button from 'lbc-wrapper/lib/button'
import Modal from 'lbc-wrapper/lib/modal'
import QueryTable from '../index'

class ModalSelectAddon extends Component {
  constructor(props) {
    super(props)

    this.query = this.query.bind(this)
    this.onOk = this.onOk.bind(this)
    this.onCancel = this.onCancel.bind(this)
    this.onClick = this.onClick.bind(this)
    this.onSelect = this.onSelect.bind(this)

    this.state = {
      queryListData: [],
      visible: false,
    }

    this.opr = [
      {
        key: 'opr',
        title: '操作',
        dataIndex: 'opr',
        width: 60,
        render: (text, record) => (
          <a onClick={() => this.onSelect(record)} role="button" >选择</a>
        ),
      },
    ]
  }

  onOk() {
    this.setState({
      visible: true,
    })
  }

  onCancel() {
    this.setState({
      visible: false,
    })
  }

  onClick() {
    this.onOk()
  }

  onSelect(record) {
    const { form, field } = this.props
    const { setFieldsValue } = form

    setFieldsValue({
      [field.id]: record[field.id],
      [field.name]: record[field.name],
    })

    this.onCancel()
  }

  query(params) {
    const { field } = this.props
    const { dataName = 'subOfficeList' } = field
    this.props.field.queryList(params).then((data) => {
      this.setState({
        queryListData: data[dataName],
        totalCount: data.total,
      })
    })
  }

  render() {
    const { form, field } = this.props

    const { getFieldDecorator } = form
    return (
      <div>
        <SimpleFormItem
          label={field.label}
        >
          {
            getFieldDecorator(field.name, {})(<Input readOnly style={{ width: '100%' }} onClick={this.onClick} />)
          }
          {
            getFieldDecorator(field.id, {})(<Input type="hidden" />)
          }
        </SimpleFormItem>
        <Modal
          visible={this.state.visible}
          title={field.label}
          width={800}
          closable={false}
          footer={<Button onClick={this.onCancel}>取消</Button>}
          destroyOnClose
        >
          <QueryTable
            ref={r => (this.tableRef = r)}
            columns={[...field.columns, ...this.opr]}
            fields={field.fields}
            actions={this.actions || []}
            query={this.query}
            data={this.state.queryListData}
            totalCount={this.state.totalCount}
            rowKey={field.rowKey}
            rowSelection={null}
          />
        </Modal>
      </div>
    )
  }
}

ModalSelectAddon.propTypes = {
  form: PropTypes.object,
  field: PropTypes.shape({
    id: PropTypes.string.isRequired,
    queryList: PropTypes.func,
    columns: PropTypes.array,
  }),
}

export default ModalSelectAddon
