
import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import Input from 'lbc-wrapper/lib/input'
import InputDate from './InputDate'


class DateAddon extends Component {

  onChange = (val) => {
    const { form, field } = this.props
    const { setFieldsValue } = form
    this.setState({}, () => setFieldsValue({
      [field.id[0]]: val.start,
      [field.id[1]]: val.end,
    }))
  }

  render() {
    const { form, field } = this.props
    const { defaultValue = [] } = field

    const { getFieldDecorator, getFieldValue } = form

    return (
      <div style={{ width: '100%' }} className="dateAddon">
        {
          getFieldDecorator(field.id[0], {
            initialValue: defaultValue[0],
            rules: [
              { required: field.required, message: '请选择起始天数' },
            ],
          })(<Input type="hidden" />)
        }
        {
          getFieldDecorator(field.id[1], {
            initialValue: defaultValue[1],
            rules: [
              { required: field.required, message: '请选择结束天数' },
            ],
          })(<Input type="hidden" />)
        }
        <SimpleFormItem
          label={field.label}
          required={field.required}
        >
          <InputDate
            onChange={this.onChange}
            value={{ start: getFieldValue(field.id[0]), end: getFieldValue(field.id[1]) }}
          />
        </SimpleFormItem>
      </div>
    )
  }
}

DateAddon.propTypes = {
  form: PropTypes.object,
  field: PropTypes.shape({
    id: PropTypes.array.isRequired,
    defaultValue: PropTypes.array,
  }),
}

export default DateAddon
