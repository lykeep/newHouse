import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import { RangePicker } from 'lbc-wrapper/lib/datePicker'
import Input from 'lbc-wrapper/lib/input'
import moment from 'moment'

class DateRangeAddon extends Component {
  constructor(props) {
    super(props)
    this.onDateChange = this.onDateChange.bind(this)
  }

  onDateChange(values, dateStrings) {
    const { form, field } = this.props
    const { setFieldsValue } = form

    setFieldsValue({
      [field.id[0]]: dateStrings[0],
      [field.id[1]]: dateStrings[1],
    })
  }

  render() {
    const { form, field } = this.props

    const { defaultValue = [] } = field

    const { getFieldDecorator } = form
    return (
      <SimpleFormItem
        label={field.label}
        required={field.required}
      >
        {
          getFieldDecorator(field.id[0], {
            initialValue: defaultValue[0],
            rules: [
              { required: field.required, message: '请选择起始日期' },
            ],
          })(<Input type="hidden" />)
        }
        {
          getFieldDecorator(field.id[1], {
            initialValue: defaultValue[1],
            rules: [
              { required: field.required, message: '请选择结束日期' },
            ],
          })(<Input type="hidden" />)
        }
        <RangePicker
          onChange={this.onDateChange}
          placeholder={['开始日期', '结束日期']}
          defaultValue={[
            !defaultValue[0] ? defaultValue[0] : moment(defaultValue[0]),
            !defaultValue[1] ? defaultValue[1] : moment(defaultValue[1]),
          ]}
          style={{ width: '100%' }}
        />
      </SimpleFormItem>
    )
  }
}

DateRangeAddon.propTypes = {
  form: PropTypes.object,
  field: PropTypes.shape({
    id: PropTypes.array.isRequired,
    defaultValue: PropTypes.array,
  }),
}

export default DateRangeAddon
