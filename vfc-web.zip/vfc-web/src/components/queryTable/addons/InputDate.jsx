
import React, { Component } from 'react'
import PropTypes from 'prop-types'
import InputNumber from 'lbc-wrapper/lib/inputNumber'

class InputDate extends Component {
  constructor(props) {
    super(props)
    this.state = {
      start: '',
      end: '',
    }
  }

  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value
      this.setState(value);
    }
  }

  onChange = (e, type) => {
    this.setState({ [type]: e })
    this.triggerChange({ [type]: e });
  }

  triggerChange = (changedValue) => {
    const { onChange } = this.props
    if (onChange) {
      onChange(Object.assign({}, this.state, changedValue));
    }
  }

  render() {
    const { start, end } = this.state
    const span = {
      display: 'inline-block',
      width: '5%',
      margin: '0 1%',
      textAlign: 'center',
    }
    return (
      <div>
        <InputNumber
          onChange={(e)=>this.onChange(e, 'start')}
          value={start}
          placeholder="请输入"
        />
        <span style={span}>-</span>
        <InputNumber
          onChange={(e)=>this.onChange(e, 'end')}
          value={end}
          placeholder="请输入"
        />
      </div>
    )
  }
}

InputDate.propTypes = {
  onChange: PropTypes.func,
}

export default InputDate
