import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { SimpleFormItem } from 'lbc-wrapper/lib/form'
import DatePicker from 'lbc-wrapper/lib/datePicker'
import Input from 'lbc-wrapper/lib/input'
import moment from 'moment'

class DatePickerAddon extends Component {
  constructor(props) {
    super(props)
    this.onDateChange = this.onDateChange.bind(this)
  }

  onDateChange(value, dateString) {
    const { form, field } = this.props
    const { setFieldsValue } = form
    setFieldsValue({
      [field.id]: dateString,
    })
  }

  render() {
    const { form, field } = this.props

    const { getFieldDecorator, getFieldValue } = form
    return (
      <SimpleFormItem
        label={field.label}
        required={field.required}
      >
        {
          getFieldDecorator(field.id, {
            initialValue: field.defaultValue,
            onChange: field.onChange,
            rules: [
              { required: field.required, message: `请选择${field.label}` },
            ],
          })(<Input type="hidden" />)
        }
        <DatePicker
          onChange={this.onDateChange}
          defaultValue={!field.defaultValue ? field.defaultValue : moment(field.defaultValue)}
          value={!getFieldValue(field.id) ? getFieldValue(field.id) : moment(getFieldValue(field.id))}
          style={{ width: '100%' }}
        />
      </SimpleFormItem>
    )
  }
}

DatePickerAddon.propTypes = {
  form: PropTypes.object,
  field: PropTypes.shape({
    id: PropTypes.string.isRequired,
    defaultValue: PropTypes.string,
  }),
}

export default DatePickerAddon
