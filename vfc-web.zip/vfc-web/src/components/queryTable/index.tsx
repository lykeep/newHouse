import * as React from 'react'
// import PropTypes from 'prop-types'
import TableWrapper, { TableProps, TableAction } from 'lb-components/lib/table'
import Fields from './FieldsWrapper'
import Operation, { OPERATIONS } from './Operation'
import { Field } from './Fields'
import { ColumnProps, PaginationConfig } from 'lbc-wrapper/lib/table'

import removeEmptyString from '../../utils/removeEmptyString'

import './queryTable.scss'

export { TableAction, Field }

const COUNT_PER_PAGE = 10

export interface QueryTableProps<T> extends TableProps<T> {
  query: (params: any) => Promise<any>
  loadOnMount?: boolean
  fields?: Field[][]
  actions?: TableAction[]
  totalCount?: number | string
  operations?: OPERATIONS[]
  recordsPerPage?: number
  viewHandler?: (param: any) => void
  modifyHandler?: (param: any) => void
  deleteHandler?: (param: any) => void
  noSelection?: boolean
}

class QueryTable<T> extends React.Component<QueryTableProps<T>> {
  public static defaultProps = {
    rowSelectionType: 'checkbox', // 在TS版本的lb-components上，改为了rowSelectionType
    rowSelection: 'checkbox',
    loadOnMount: true,
    noPagination: false,
    data: [],
    operations: [],
    bordered: false,
  }

  private currentPageNo: number
  private currentFilters: any
  private recordsPerPage: number
  private columnsWithOperation: Array<ColumnProps<T>> = []
  private queryCallback: (param?: any) => any
  private tableRef: TableWrapper<T> | null

  constructor(props: QueryTableProps<T>) {
    super(props)

    this.fieldsQueryRegister = this.fieldsQueryRegister.bind(this)
    this.query = this.query.bind(this)
    this.refresh = this.refresh.bind(this)
    this.handleTableChange = this.handleTableChange.bind(this)
    this.resetCallback = this.resetCallback.bind(this)

    this.currentPageNo = 1
    this.currentFilters = {}

    const opsWidth = 40 + (20 * props.operations!.length)

    const ops = props.operations!.length === 0 ? [] : [
      {
        title: '操作',
        dataIndex: 'operations',
        key: 'operations',
        width: `${opsWidth}px`,
        render: (text: any, record: T) => (
          <Operation
            operations={props.operations}
            viewHandler={() => props.viewHandler && props.viewHandler(record)}
            modifyHandler={() => props.modifyHandler && props.modifyHandler(record)}
            deleteHandler={() => props.deleteHandler && props.deleteHandler(record)}
          />
        ),
      },
    ]

    this.recordsPerPage = props.recordsPerPage || COUNT_PER_PAGE

    this.columnsWithOperation = [
      ...(props.columns || []),
      ...ops,
    ]

    this.queryCallback = this.query
  }

  public componentDidMount() {
    const { loadOnMount, fields = [] } = this.props
    if (loadOnMount && fields.length === 0) {
      this.refresh()
    }
  }

  public refresh() {
    this.resetCallback()
    this.query({})
  }

  public query(dataToBeSent: any) {
    if (this.tableRef) {
      this.tableRef.clearSelections()
    }

    return this.props.query ? this.props.query(removeEmptyString({
      ...this.currentFilters,
      ...dataToBeSent,
      pageNo: this.currentPageNo,
      recordsPerPage: this.recordsPerPage,
    })) : Promise.resolve()
  }

  public fieldsQueryRegister(func: any) {
    this.queryCallback = func
  }

  public resetCallback() {
    this.currentPageNo = 1
    this.currentFilters = {}
    if (this.tableRef) {
      this.tableRef.clearSelections()
    }
  }

  public handleTableChange(pagination: PaginationConfig, filters: any) {
    this.currentPageNo = pagination.current || 1
    this.currentFilters = filters
    if (this.tableRef) {
      this.tableRef.clearSelections()
    }

    this.queryCallback()
  }

  public render() {
    const { fields, query, loadOnMount, pagination, data, bordered, columns, rowSelectionType, noSelection, ...props } = this.props

    const total = typeof this.props.totalCount === 'string' ? parseInt(this.props.totalCount, 10) : this.props.totalCount


    const pag = typeof this.props.pagination !== 'undefined' ? this.props.pagination : {
      total: total || data!.length || 0,
      size: 'small',
      showTotal: (t: any) => `共 ${this.props.totalCount || t || 0} 条`,
      showSizeChanger: false,
      showQuickJumper: false,
      defaultPageSize: this.recordsPerPage,
      pageSize: this.recordsPerPage,
      current: this.currentPageNo,
    }

    return (
      <div className="lb-query-table in-modal">
        {!fields || fields.length === 0 ? null : (<Fields fields={fields} query={this.query} queryRegister={this.fieldsQueryRegister} loadOnMount={loadOnMount} resetCallback={this.resetCallback} />)}
        <TableWrapper
          size="small"
          scroll={{
            x: true,
          }}
          columns={this.columnsWithOperation}
          {...props}
          rowSelectionType={noSelection ? undefined: rowSelectionType}
          pagination={pag}
          bordered={bordered}
          data={data}
          onChange={this.handleTableChange}
          position="left"
          ref={(r: TableWrapper<T> | null) => (this.tableRef = r)}
        />
      </div>
    )
  }
}

export default QueryTable
