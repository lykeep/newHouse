import * as React from 'react'
import Fields, { FieldsProps } from './Fields'

class FieldsWrapper extends React.Component<FieldsProps> {
  public shouldComponentUpdate(nextProps: FieldsProps) {
    return this.props.fields !== nextProps.fields
  }

  public render() {
    return (
      <Fields {...this.props} />
    )
  }
}

export default FieldsWrapper
