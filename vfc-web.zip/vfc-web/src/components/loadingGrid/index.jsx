import React from 'react'
import PropTypes from 'prop-types'
import Row from 'lbc-wrapper/lib/row'
import Col from 'lbc-wrapper/lib/col'
import range from 'lodash/range'
import './loadingGrid.scss'

const renderGrid = key => (
  <div className="lb-loading-content" key={key}>
    <Row gutter={8}>
      <Col span={22}>
        <div className="lb-loading-block" />
      </Col>
    </Row>
    <Row gutter={8}>
      <Col span={8}>
        <div className="lb-loading-block" />
      </Col>
      <Col span={15}>
        <div className="lb-loading-block" />
      </Col>
    </Row>
    <Row gutter={8}>
      <Col span={6}>
        <div className="lb-loading-block" />
      </Col>
      <Col span={18}>
        <div className="lb-loading-block" />
      </Col>
    </Row>
    <Row gutter={8}>
      <Col span={13}>
        <div className="lb-loading-block" />
      </Col>
      <Col span={9}>
        <div className="lb-loading-block" />
      </Col>
    </Row>
    <Row gutter={8}>
      <Col span={4}>
        <div className="lb-loading-block" />
      </Col>
      <Col span={3}>
        <div className="lb-loading-block" />
      </Col>
      <Col span={16}>
        <div className="lb-loading-block" />
      </Col>
    </Row>
    <Row gutter={8}>
      <Col span={8}>
        <div className="lb-loading-block" />
      </Col>
      <Col span={6}>
        <div className="lb-loading-block" />
      </Col>
      <Col span={8}>
        <div className="lb-loading-block" />
      </Col>
    </Row>
  </div>
)

const LoadingGrid = ({ count = 2 }) => (
  <div className="lb-loading-grid">
    {
      range(count).map((a, i) => renderGrid(i))
    }
  </div>
)

LoadingGrid.propTypes = {
  count: PropTypes.number,
}

export default LoadingGrid
