import React from 'react'
import { LocaleContext } from './i18nProvider'

export default function localed(i18n) {
  return function withLocale(Component) {
    return function localedComponent(props) {
      return (
        <LocaleContext.Consumer>
          {
            locale => <Component {...props} i18n={i18n[locale]} />
          }
        </LocaleContext.Consumer>
      )
    }
  }
}
