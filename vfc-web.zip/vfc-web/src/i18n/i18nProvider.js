import React from 'react'

export const LOCALE = {
  EN: 'en',
  ZH_CN: 'zh_CN',
}

export const LocaleContext = React.createContext(LOCALE.ZH_CN)
