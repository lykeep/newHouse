import { buildColumnRender, buildSelectOptions } from './utils'

export const isDraft = {
  YES: 'Y',
  NO: 'N',
}

export const isDraftLabels = {
  [isDraft.YES]: '是',
  [isDraft.NO]: '否',
}

export const isDraftSelectOptions = buildSelectOptions(isDraftLabels)

export const isDraftRender = buildColumnRender(isDraftLabels)
