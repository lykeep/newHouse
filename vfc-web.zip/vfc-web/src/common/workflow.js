import { buildSelectOptions } from './utils'

export const activityStrategies = {
  // direct: 'Direct', // 自动分配
  // manual: 'Manual', // 手动分配
  // claim: 'Claim', // 手工领取
  // countersign: 'Countersign', // 会签
  direct: 'Direct', // 自动分配
  manual: 'Manual', // 手动分配
  claim: 'Claim', // 手工领取
  countersign: 'Countersign', // 会签
}

export const flowActions = {
  submit: 'SUBMIT', // 提交
  approve: 'APPROVE', // 批准
  back: 'DIRECT_BACK', // 退回
  recall: 'RECALL', // 撤回
  reject: 'REJECT', // 否决
  counter: 'COUNTER', // 加签
  revoke: 'REVOKE', // 撤销
  circulation: 'Circulation', // 传阅
}

export const flowStatus = {
  // DRAFT: '0',
  // APPROVE_ING: '1',
  // APPROVE_SUCCESS: '2',
  // REJECT: '3',
  // RETURN: '4',
  // CANCEL: '5',
  RUNNING: '1',
  // SUSPENDED: 'SUSPENDED',
  COMPLETED: '2',
  // TIMEOUT_COMPLETED: 'TIMEOUT_COMPLETED',
  DISCARDED: '5',
  // TIMEOUT_DISCARDED: 'TIMEOUT_DISCARDED',
  // DELETED: 'DELETED',
}

export const flowStatusLabels = {
  [flowStatus.RUNNING]: '审批中',
  [flowStatus.COMPLETED]: '完成',
  [flowStatus.DISCARDED]: '撤销',
}

export const flowStatusOptions = buildSelectOptions(flowStatusLabels)

export const bpmRecordType = {
  NEW: '00',
  ALTER: '01',
}

export const handleStatus = {
  NOT_DONE: 'Unprocessed', // 未处理
  DONE: 'Processed', // 以处理
}

export const handleStatusLabels = {
  [handleStatus.NOT_DONE]: '待处理',
  [handleStatus.DONE]: '已处理',
}

export const handleStatusOptions = buildSelectOptions(handleStatusLabels)
