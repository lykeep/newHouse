import pageType from '../pageType'
import pageMode from '../pageMode'
/*
paramsCreate ：新增
paramDetail ：点击跳转详情
paramsAdditional ：补充信息
paramsChange ：变更
paramsModify ：编辑
 */
// 资产管理 - 租赁物 - 其他租赁物 - 查询列表   OK
export const pageAssetLeaseQueryList = {
  // 其它租赁物信息
  toOtherLeaseholdInfo: {
    path: 'otherLeaseholdInfo',
    paramDetail: [pageMode.VIEW, pageType.RECORD],
    paramsAdditional: [pageMode.MODIFY, pageType.RECORD],
  },
}
// 资产管理 - 租赁物 - 车辆 - 查询列表
export const pageAssetLeaseCarQueryList = {
  // 车辆信息
  toCarInfo: {
    path: 'carInfo',
    paramsCreate: [pageType.DRAFT],
    paramDetail: [pageMode.VIEW, pageType.DRAFT],
    paramsAdditional: [],
  },
}
// 资产管理 - 租赁物 - 申请列表 （只有车辆有流程）
export const pageAssetLeaseApplicationList = {
  // 车辆信息
  toCarInfo: {
    path: 'carInfo',
    paramsCreate: [pageType.DRAFT],
    // 草稿详情
    paramDraftDetail: [pageMode.MODIFY, pageType.DRAFT],
    // 流程详情
    paramFlowDetail: [pageMode.VIEW, pageType.APPROVAL],
    // 变更抵押信息
    paramsChangeMortInfo: [],
    // 变更车架号
    paramsChangeVinNbr: [],
    paramsAdditional: [],
  },
}
// 资产管理 - 租赁物 - 审批列表 （只有车辆有流程）
export const pageAssetLeaseApprovalList = {
  // 其它租赁物信息
  toOtherLeaseholdInfo: {
    path: 'otherLeaseholdInfo',
    paramsCreate: [pageType.DRAFT],
    paramDetail: [],
    paramsAdditional: [],
  },
}
/** *****************担保管理************************* */
export const pageAssetCollateralQueryList = {
  // 保证页
  toGuaranteePage: {
    path: 'guaranteePage',
    paramsCreate: [pageType.DRAFT],
    paramDetail: [],
    paramsAdditional: [],
  },
  // 车辆页
  toCarInfo: {
    path: 'carInfo',
    // 新增
    paramsCreate: [pageMode.CREATE, pageType.DRAFT],
    // 跳转查看详情
    paramsDetail: [pageMode.VIEW, pageType.RECORD],
    // 补充信息
    paramsAdditional: [pageMode.MODIFY, pageType.RECORD],
    // 变更 （出入库）
    paramsModify: [pageMode.CREATE, ''],
    // 编辑 （申请列表）
    paramsEdit: [pageMode.MODIFY, ''],
  },
  // 房产页
  toHousePropertyInfo: {
    path: 'housePropertyInfo',
    // 新增
    paramsCreate: [pageMode.CREATE, pageType.DRAFT],
    // 跳转查看详情
    paramsDetail: [pageMode.VIEW, pageType.RECORD],
    // 补充信息
    paramsAdditional: [pageMode.MODIFY, pageType.RECORD],
    // 变更 （出入库）
    paramsModify: [pageMode.CREATE, ''],
    // 编辑 （申请列表）
    paramsEdit: [pageMode.MODIFY, ''],
  },
  // 其他抵质押页
  toOtherHypothecation: {
    path: 'otherHypothecation',
    // 新增
    paramsCreate: [pageMode.CREATE, pageType.DRAFT],
    // 跳转查看详情
    paramsDetail: [pageMode.VIEW, pageType.RECORD],
    // 补充信息
    paramsAdditional: [pageMode.MODIFY, pageType.RECORD],
    // 变更 （出入库）
    paramsModify: [pageMode.CREATE, ''],
    // 编辑 （申请列表）
    paramsEdit: [pageMode.MODIFY, ''],
  },

}
export const pageAssetCollateralApplicationList = {
  // 车辆页
  toCarInfo: {
    path: 'carInfo',
    // 新增
    paramsCreate: [pageMode.CREATE, pageType.DRAFT],
    // 草稿详情
    paramDraftDetail: [pageMode.MODIFY, pageType.DRAFT],
    // 流程详情
    paramFlowDetail: [pageMode.VIEW, pageType.APPROVAL],
    // 补充信息
    paramsAdditional: [pageMode.MODIFY, pageType.RECORD],
    // 变更 （出入库）
    paramsModify: [pageMode.CREATE, ''],
    // 编辑 （申请列表）
    paramsEdit: [pageMode.MODIFY, ''],
  },
  // 房产页
  toHousePropertyInfo: {
    path: 'housePropertyInfo',
    // 新增
    paramsCreate: [pageMode.CREATE, pageType.DRAFT],
    // 草稿详情
    paramDraftDetail: [pageMode.MODIFY, pageType.DRAFT],
    // 流程详情
    paramFlowDetail: [pageMode.VIEW, pageType.APPROVAL],
    // 补充信息
    paramsAdditional: [pageMode.MODIFY, pageType.RECORD],
    // 变更 （出入库）
    paramsModify: [pageMode.CREATE, ''],
    // 编辑 （申请列表）
    paramsEdit: [pageMode.MODIFY, ''],
  },
  toOtherHypothecation: {
    path: 'otherHypothecation',
    // 新增
    paramsCreate: [pageMode.CREATE, pageType.DRAFT],
    // 草稿详情
    paramDraftDetail: [pageMode.MODIFY, pageType.DRAFT],
    // 流程详情
    paramFlowDetail: [pageMode.VIEW, pageType.APPROVAL],
    // 补充信息
    paramsAdditional: [pageMode.MODIFY, pageType.RECORD],
    // 变更 （出入库）
    paramsModify: [pageMode.CREATE, ''],
    // 编辑 （申请列表）
    paramsEdit: [pageMode.MODIFY, ''],
  },
}
// 资产管理 - 担保管理 - 审批列表
export const pageAssetCollateralApprovalList = {
  // 其它租赁物信息
  toOtherLeaseholdInfo: {
    path: 'otherLeaseholdInfo',
    paramsCreate: [pageType.DRAFT],
    paramDetail: [],
    paramsAdditional: [],
  },
}
// 授信 - 法人额度管理
export const pageCreditManagementQueryList = {
  // 其它租赁物信息
  toOtherLeaseholdInfo: {
    path: 'otherLeaseholdInfo',
    paramsCreate: [pageType.DRAFT],
    paramDetail: [],
    paramsAdditional: [],
  },
}
export const PageNameList = {
  // 资产管理 - 租赁物
  pageAssetLeaseQueryList,
  pageAssetLeaseCarQueryList,
  pageAssetLeaseApplicationList,
  pageAssetLeaseApprovalList,
  // 资产管理 - 担保管理
  pageAssetCollateralQueryList,
  pageAssetCollateralApplicationList,
  pageAssetCollateralApprovalList,
  pageCreditManagementQueryList,
}
