/*
* 主要解决某一函数大量调用的情况下
* 防止需求变更 导致开发人员需要多处查找更改
 */
/*-------------------------------------*/

/*-------------------------------------*/
/*
seachMaker组件
 */
import searchMaker from '../../utils/makeSearch'
import { dealObjectValue } from './listCommonUtils'

/*
* params：  data - 数据
* params：  dataBid   - Bid，业务ID
* params：  applyType         - busiApplyType，申请类型
* params：  SearchMakerParams      - pageMode和pageType
* params：  otherParams  - 其他所需的特定参数对象
 */
export const actionRouter = (data, dataBid, applyType, SearchMakerParams, otherParams) => {
  let ids = {}
  if (data !== null) {
    ids = dealObjectValue({
      bid: dataBid,
      bpid: data.businessKey,
      pid: data.procInstanceId,
      tid: data.taskInstanceId,
    })
  }
  const search = searchMaker(...SearchMakerParams, applyType || '', ids, otherParams)
  return search
}
/*
* params：  parsms - 具体所需参数
* params：  path   - 路径
* params：  data         - 所传数据
* params：  dataBid      - 业务ID
* params：  otherParams  - 其他所需的特定参数对象
 */
export const searchMakerDeal = (params, path, data, dataBid, otherParams) => {
  const ids = dealObjectValue({
    bid: dataBid, // data.grnteeNbr
    bpid: data.businessKey,
    pid: data.procInstanceId,
    tid: data.taskInstanceId,
  })
  const searchMakerParams = params.concat(data.busiApplyType || '').filter(node => (
    node !== undefined
  ))
  const search = searchMaker(...searchMakerParams, ids, otherParams)
  return `${path}${search}`
}
export const searchMakerDealForQueryList = (params, path, data, dataBid, applyType, otherParams) => {
  const ids = dealObjectValue({
    bid: dataBid, // data.grnteeNbr
    bpid: data.businessKey,
    pid: data.procInstanceId,
    tid: data.taskInstanceId,
  })
  const searchMakerParams = params.concat(applyType).filter(node => (
    node !== undefined
  ))
  const search = searchMaker(...searchMakerParams, ids, otherParams)
  return `${path}${search}`
}
