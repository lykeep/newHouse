import pageMode from '../pageMode'
import pageType from '../pageType'
/*
删除对象中的value为空的属性
 */
export const dealObjectValue = (obj) => {
  const param = {}
  if (obj === null || obj === undefined || obj === '') return param
  Object.keys(obj).forEach((key) => {
    if (typeof (obj[key]) === 'object') {
      param[key] = dealObjectValue(obj[key])
    } else if (obj[key] !== null && obj[key] !== undefined && obj[key] !== '') {
      param[key] = obj[key]
    }
  })
  return param
}
/*
针对不同情况给出的
m && t
pageMode &&  pageType
 */
export const SearchMakerParams = {
  Create: [pageMode.CREATE, pageType.DRAFT],
  // 跳转查看详情
  NormalDetail: [pageMode.VIEW, pageType.RECORD],
  // 申请列表 草稿 点击详情
  DraftDetail: [pageMode.MODIFY, pageType.DRAFT],
  // 申请列表 非草稿  点击详情
  FlowDetail: [pageMode.VIEW, pageType.APPROVAL],
  // 审批列表 点击详情
  APPROVALDetail: [pageMode.MODIFY, pageType.APPROVAL],
  // 补充信息
  Additional: [pageMode.MODIFY, pageType.RECORD],
  // 新增变更
  ALTER: [pageMode.CREATE, pageType.DRAFT],
  // 变更 （出入库）
  paramsChange: [pageMode.CREATE, ''],
  // 编辑 （申请列表）
  paramsEdit: [pageMode.MODIFY, ''],
}
