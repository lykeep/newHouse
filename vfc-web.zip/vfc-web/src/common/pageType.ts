enum PageType {
  DRAFT = '01', // 草稿
  // Deprecated
  // CHANGE: '02', // 变更
  APPROVAL = '03', // 审批
  RECORD = '04', // 真实记录
}

export default PageType
