export default {
  '000000': '/dashboard/partners/legal/approvalList', // 法人审批
  '000011': '/dashboard/partners/natural/approvalList', // 自然人审批
  '000021': '/dashboard/asset/leaseItem/leaseApprovalList', // 资产租赁物管理审批
  '000031': '/dashboard/asset/collateral/collateralApprovalList', // 资产担保管理房
  '000032': '/dashboard/asset/collateral/collateralApprovalList', // 资产担保管理房
  '000033': '/dashboard/asset/collateral/collateralApprovalList', // 资产担保管理其他
  '000041': '/dashboard/credit/creditApprovalList', // 授信法人额度管理审批
  '000051': '/dashboard/credit/approvalList', // 集团授信审批
  '000061': '/dashboard/product/productManage/checkList', // 产品小贷审批
  '000062': '/dashboard/product/productManage/checkList', // 产品租赁物审批
  '000071': '/dashboard/product/projectManage/checkList', // 产品项目管理审批
  '000081': '/dashboard/securityDeposit/creditSecurity/approvalList', // 授信保证金审批
  '000091': '/dashboard/order/checkList', // 进件审批 互金/零售进件新增
  '000092': '/dashboard/order/checkList', // 进件审批 小贷进件新增
  '000093': '/dashboard/order/checkList', // 进件审批 小贷额度申请进件新增
  '000094': '/dashboard/order/checkList', // 进件审批 小贷额度支取进件新增
  '001001': '/dashboard/contract/contractInformation/checkList', // 合同审批 合同签署
  '001002': '/dashboard/contract/contractInformation/checkList', // 合同审批 额度合同签署
  '001101': '/dashboard/tranche/approvalList', // 放款单笔审批
  '001102': '/dashboard/tranche/approvalList', // 放款合并审批
  '001201': '/dashboard/amount/grant/approvalList', // 额度发放审批
  '001301': '/dashboard/amount/amount/approvalList', // 额度变更审批
}
