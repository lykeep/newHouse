export const buildSelectOptions = labelObj => Object.keys(labelObj).map(k => ({
  title: labelObj[k],
  value: k,
  key: k,
}))
export const buildColumnRender = labelObj => (value, record) => labelObj[value]

export const buildRadioOptions = labelObj => Object.keys(labelObj).map(k => ({
  label: labelObj[k],
  value: k,
  key: k,
}))
