import { PERMISSIONS } from '../components/form/utils/calPermission'

enum PageMode {
  CREATE = PERMISSIONS.CREATE,
  MODIFY = PERMISSIONS.MODIFY,
  VIEW = PERMISSIONS.READ,
}

export default PageMode
