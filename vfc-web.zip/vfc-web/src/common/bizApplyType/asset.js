import { buildColumnRender, buildSelectOptions } from '../utils'

// 资产管理-租赁物
export const assetLeaseApplyType = {
  CHANGE_FRAME_NO: '01', // 变更车架号
  MORTGAGE: '02', // 抵押
  RELEASE: '03', // 解押
}

export const assetLeaseApplyTypeLabels = {
  [assetLeaseApplyType.CHANGE_FRAME_NO]: '变更车架号',
  [assetLeaseApplyType.MORTGAGE]: '抵押',
  [assetLeaseApplyType.RELEASE]: '解押',
}

export const assetLeaseATSelectOptions = buildSelectOptions(assetLeaseApplyTypeLabels)

export const assetLeaseATRender = buildColumnRender(assetLeaseApplyTypeLabels)

// 资产管理-担保物
export const assetCollateralApplyType = {
  IN: '02', // 入库
  OUT: '01', // 出库
}

export const assetCollateralApplyTypeLabels = {
  [assetCollateralApplyType.IN]: '入库',
  [assetCollateralApplyType.OUT]: '出库',
}

export const assetCollateralATSelectOptions = buildSelectOptions(assetCollateralApplyTypeLabels)

export const assetCollateralATTypeRender = buildColumnRender(assetCollateralApplyTypeLabels)
