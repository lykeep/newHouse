import { buildColumnRender, buildSelectOptions } from '../utils'
/*
进件模块
 */
// 资产管理-租赁物
export const orderApplyType = {
  NEW: '01', // 新增
}

export const orderApplyTypeLabels = {
  [orderApplyType.NEW]: '新增',
}

export const orderATSelectOptions = buildSelectOptions(orderApplyTypeLabels)

export const orderATRender = buildColumnRender(orderApplyTypeLabels)

export const orderType = {
  smallloan: '00',
  retail: '01',
  collection: '02',
  inventoryfinance: '03',
  tradition: '04',
  creditline: '05',
  drawcreditline: '06',
}

export const orderTypeLabels = {
  [orderType.smallloan]: '小贷',
  [orderType.retail]: '互金零售',
  [orderType.collection]: '集采',
  [orderType.inventoryfinance]: '库融',
  [orderType.tradition]: '传统',
  [orderType.creditline]: '额度申请',
  [orderType.drawcreditline]: '额度支取',
}
export const orderTypePath = {
  [orderType.smallloan]: 'pettyLoan', // 小贷
  [orderType.retail]: 'retail', // 互金零售
  [orderType.collection]: '集采', // 集采
  [orderType.inventoryfinance]: '库融', // 库融
  [orderType.tradition]: '传统', // 传统
  [orderType.creditline]: 'quotaApplication', // 额度申请
  [orderType.drawcreditline]: 'withdrawalInfo', // 额度支取
}
export const orderTypeSelectOptions = buildSelectOptions(orderTypeLabels)

export const orderTypeRender = buildColumnRender(orderTypeLabels)
