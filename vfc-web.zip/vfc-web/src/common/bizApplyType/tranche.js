import { buildColumnRender, buildSelectOptions } from '../utils'
// 放款
export const trancheLoanApplyType = {
  SINGLE_LOAN: '10', // 单笔
  MUTLI_LOAN: '20', // 合并
}

export const trancheLoanApplyTypeLabels = {
  [trancheLoanApplyType.SINGLE_LOAN]: '单笔',
  [trancheLoanApplyType.MUTLI_LOAN]: '合并',
}

export const trancheLoanApplyTypeSelectOptions = buildSelectOptions(trancheLoanApplyTypeLabels)

export const trancheLoanApplyTypeRender = buildColumnRender(trancheLoanApplyTypeLabels)
