import { buildColumnRender, buildSelectOptions } from '../utils'

// 自然人
export const natureApplyType = {
  NEW: '00', // 新增
  ALTER: '01', // 变更
}

export const natureApplyTypeLabels = {
  [natureApplyType.NEW]: '新增',
  [natureApplyType.ALTER]: '变更',
}

export const naturalApplyTypeSelectOptions = buildSelectOptions(natureApplyTypeLabels)

export const naturalApplyTypeRender = buildColumnRender(natureApplyTypeLabels)
