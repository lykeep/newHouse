import { buildColumnRender, buildSelectOptions } from '../utils'

// 额度
export const creditDepositApplyType = {
  NEW: '01', // 新增
}

export const creditDepositApplyTypeLabels = {
  [creditDepositApplyType.NEW]: '新增',
}

export const creditDepositApplyTypeSelectOptions = buildSelectOptions(creditDepositApplyTypeLabels)

export const creditDepositApplyTypeRender = buildColumnRender(creditDepositApplyTypeLabels)
