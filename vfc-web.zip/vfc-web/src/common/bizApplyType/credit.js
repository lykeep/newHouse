import { buildColumnRender, buildSelectOptions } from '../utils'

// 授信法人额度管理
export const legalQuotaApplyType = {
  NEW: '01', // 新增
  ALTER: '02', // 变更
}

export const legalQuotaApplyTypeLabels = {
  [legalQuotaApplyType.NEW]: '新增',
  [legalQuotaApplyType.ALTER]: '变更',
}

export const legalQuotaApplyTypeSelectOptions = buildSelectOptions(legalQuotaApplyTypeLabels)

export const legalQuotaApplyTypeRender = buildColumnRender(legalQuotaApplyTypeLabels)

// 集团授信
export const creditApplyType = {
  NEW: '01', // 新增
  ALTER: '02', // 变更
}

export const creditApplyTypeLabels = {
  [creditApplyType.NEW]: '新增',
  [creditApplyType.ALTER]: '变更',
}

export const creditApplyTypeSelectOptions = buildSelectOptions(creditApplyTypeLabels)

export const creditApplyTypeRender = buildColumnRender(creditApplyTypeLabels)
