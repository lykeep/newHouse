import { buildColumnRender, buildSelectOptions } from '../utils'
// 法人
export const contractApplyType = {
  SIGN: '01', // 签署
  CHANGE_ACCOUNT: '02', // 账户变更
}

export const contractApplyTypeLabels = {
  [contractApplyType.SIGN]: '签署',
  [contractApplyType.CHANGE_ACCOUNT]: '账户变更',
}

export const contractApplyTypeSelectOptions = buildSelectOptions(contractApplyTypeLabels)

export const contractApplyTypeRender = buildColumnRender(contractApplyTypeLabels)
