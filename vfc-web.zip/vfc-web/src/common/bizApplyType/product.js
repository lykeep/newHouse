import { buildColumnRender, buildSelectOptions } from '../utils'
// 产品管理
export const productApplyType = {
  NEW: '01', // 新增
  ALTER: '02', // 变更
}

export const productApplyTypeLabels = {
  [productApplyType.NEW]: '新增',
  [productApplyType.ALTER]: '变更',
}

export const productApplyTypeSelectOptions = buildSelectOptions(productApplyTypeLabels)

export const productApplyTypeRender = buildColumnRender(productApplyTypeLabels)

// 产品新增类型
export const productAddType = {
  ADDRENT: '02', // 新增租赁
  ADDSMALLLOAN: '01', // 新增小贷
}

export const productAddTypeLabels = {
  [productApplyType.ADDSMALLLOAN]: '小贷',
  [productApplyType.ADDRENT]: '租赁',
}

export const productAddTypeSelectOptions = buildSelectOptions(productAddTypeLabels)

export const productAddTypeRender = buildColumnRender(productAddTypeLabels)

// 项目管理
export const projectApplyType = {
  NEW: '01', // 新增
  ALTER: '02', // 变更
}

export const projectApplyTypeLabels = {
  [projectApplyType.NEW]: '新增',
  [projectApplyType.ALTER]: '变更',
}

export const projectApplyTypeSelectOptions = buildSelectOptions(projectApplyTypeLabels)

export const projectApplyTypeRender = buildColumnRender(projectApplyTypeLabels)
