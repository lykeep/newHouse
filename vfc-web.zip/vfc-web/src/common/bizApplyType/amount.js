import { buildColumnRender, buildSelectOptions } from '../utils'

// 额度变更
export const amountApplyType = {
  CHANGE_CUT: '01', // 调减
  FREEZE: '02', // 冻结
  UNFREEZE: '03', // 解冻
  LOSE_EFFICACY: '04', // 失效
}

export const amountApplyTypeLabels = {
  [amountApplyType.CHANGE_CUT]: '调减',
  [amountApplyType.FREEZE]: '冻结',
  [amountApplyType.UNFREEZE]: '解冻',
  [amountApplyType.LOSE_EFFICACY]: '失效',
}

export const amountApplyTypeSelectOptions = buildSelectOptions(amountApplyTypeLabels)

export const amountApplyTypeRender = buildColumnRender(amountApplyTypeLabels)

// 额度发放
export const amountGrantApplyType = {
  GRANT: '01', // 发放
}

export const amountGrantApplyTypeLabels = {
  [amountGrantApplyType.GRANT]: '额度发放',
}

export const amountGrantApplyTypeSelectOptions = buildSelectOptions(amountGrantApplyTypeLabels)

export const amountGrantApplyTypeRender = buildColumnRender(amountGrantApplyTypeLabels)
