import { buildColumnRender, buildSelectOptions } from '../utils'
// 法人
export const legalApplyType = {
  NEW: '00', // 新增
  ALTER: '01', // 变更
}

export const legalApplyTypeLabels = {
  [legalApplyType.NEW]: '新增',
  [legalApplyType.ALTER]: '变更',
}

export const legalApplyTypeSelectOptions = buildSelectOptions(legalApplyTypeLabels)

export const legalApplyTypeRender = buildColumnRender(legalApplyTypeLabels)
