// import { message, notification } from 'lbc-wrapper'
import message from 'lbc-wrapper/lib/message'
import notification from 'lbc-wrapper/lib/notification'
import createHashHistory from 'history/createHashHistory'
import axios from 'axios'
import { FETCH } from './index'
import convertPropToString from '../utils/convertPropToString'

import { APP_HOST_NAME } from '../utils/consts'
import { md5 } from '../utils/security'

const hashHistory = createHashHistory()

const API_ROOT1 = `${APP_HOST_NAME}/los/`

const buildCustomHeader = (data) => {
  if (data) {
    return {
      summary: md5(data),
      // headers: { summary: md5(data) },
    }
  }
  return {}
}

const buildData = (payload = {}, key, enc) => {
  if (typeof payload === 'object') {
    return JSON.stringify(payload)
  }
  return payload
}

export default ({ getState }) => next => (action) => {
  if (typeof action === 'undefined') {
    console.log('ajax', action)
  }
  if (typeof action === 'object') {
    const ajaxAPI = action[FETCH]
    if (typeof ajaxAPI === 'undefined') {
      return next(action)
    }

    let { url } = ajaxAPI
    const { options, type, payload } = ajaxAPI

    if (typeof url === 'function') {
      url = url(getState())
    }

    if (typeof url !== 'string') {
      throw new Error('Specify a string url URL.')
    }

    const showLoader = options ? !options.NO_LOADER : true
    if (showLoader) {
      // loader(true)
    }

    if (options && Object.prototype.hasOwnProperty.call(options, 'NO_LOADER')) {
      delete options.NO_LOADER
    }

    const requestType = `${type}_REQUEST`
    const successType = `${type}_SUCCESS`
    const failureType = `${type}_FAILURE`

    const actionWith = (data) => {
      const finalAction = Object.assign({}, action, data)
      delete finalAction[FETCH]
      return finalAction
    }
    next(actionWith({ type: requestType }))

    const sendData = buildData(payload)

    const fullUrl = url.indexOf(API_ROOT1) === -1 ? API_ROOT1 + url : url
    return axios({
      method: 'post',
      url: fullUrl,
      data: Object.assign(
        {
          _channel_id: '0101',
          // encFlag: 0,
        },
        convertPropToString(payload) || {},
      ),
      headers: buildCustomHeader(sendData),
    }).then((response) => {
      const { responseCode, responseMsg, model } = response.data

      const res = Object.assign({ responseCode, responseMsg }, model ? (typeof model === 'string' ? JSON.parse(model) : model) : {})
      if (responseCode === '000000') {
        next(actionWith({
          response: res,
          type: successType,
        }))
        return res
      } else if (responseCode === 'IEN0201') {
        message.warning('请登录后重试')
        setTimeout(() => {
          hashHistory.replace('/signin')
        }, 1000)
        next(actionWith({ type: 'CLEARLOGIN' }))
        return Promise.reject(res)
      } else if (responseCode === 'INTF0201') {
        message.warning('请登录后重试')
        setTimeout(() => {
          hashHistory.replace('/signin')
        }, 1000)
        next(actionWith({ type: 'CLEARLOGIN' }))
        return Promise.reject(res)
      }

      notification.error({
        message: 'ERROR',
        description: responseMsg,
      })
      next(actionWith({
        response: res,
        type: failureType,
      }))
      return Promise.reject(res)
    }, (error) => {
      message.error('通讯失败')

      next(actionWith({ response: error, type: failureType }))
      return Promise.reject(error)
    })
  }
  return next(action)
}
