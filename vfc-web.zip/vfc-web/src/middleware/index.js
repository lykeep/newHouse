export const FETCH = Symbol('FETCH ACTION')
export const NAVIGATE = Symbol('NAVIGATE ACTION')
