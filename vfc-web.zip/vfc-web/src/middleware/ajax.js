import message from 'lbc-wrapper/lib/message'
import notification from 'lbc-wrapper/lib/notification'
import createHashHistory from 'history/createHashHistory'
import axios from 'axios'
import { FETCH } from './index'

import { APP_HOST_NAME } from '../utils/consts'
import { md5, aesEnc, aesDec } from '../utils/security'

import convertPropToString from '../utils/convertPropToString'

const hashHistory = createHashHistory()

const API_ROOT1 = `${APP_HOST_NAME}/los/`

const buildCustomHeader = (data) => {
  if (data) {
    if (typeof data === 'object') {
      data = JSON.stringify(data)
    }
    return {
      summary: md5(data),
    }
  } else {
    return {}
  }
}

export const buildData = (payload = {}, key, enc) => {
  if (typeof payload === 'object') {
    payload = JSON.stringify(convertPropToString(payload))
  }
  console.log('data to be sent', payload)
  console.log('data to be sent [key]: [', key, ']')
  if (enc) {
    try {
      payload = aesEnc(payload, key)
    } catch (e) {
      console.log('error')
    }
  }
  return Object.assign({
    _channel_id: '0101',
  }, (payload ? {reqData: payload} : {}))
}

const checkResSummary = (res, summary) => {
  const m = md5(res)

  console.log('m: ', m)
  console.log('summary: ', summary)
  return summary === m
  // return true
}

const buildResponse = (res, key) => {
  if (res.model) {
    let model = res.model
    if (typeof model === 'string') {
      const r = aesDec(model, key)
      model = JSON.parse(r)
    }

    console.log('buildResponse: ', model)
    return Object.assign(res, {model: model})
  } else {
    return res
  }
}

export default ({ getState }) => next => (action) => {
  if (typeof action === 'undefined') {
    console.log('ajax', action)
  }
  if (typeof action === 'object') {
    const ajaxAPI = action[FETCH]
    if (typeof ajaxAPI === 'undefined') {
      return next(action)
    }

    let { url } = ajaxAPI
    const { options, type, payload } = ajaxAPI

    if (typeof url === 'function') {
      url = url(getState())
    }

    if (typeof url !== 'string') {
      throw new Error('Specify a string url URL.')
    }

    const showLoader = options ? !options.NO_LOADER : true
    if (showLoader) {
      // loader(true)
    }

    if (options && Object.prototype.hasOwnProperty.call(options, 'NO_LOADER')) {
      delete options.NO_LOADER
    }

    const requestType = `${type}_REQUEST`
    const successType = `${type}_SUCCESS`
    const failureType = `${type}_FAILURE`

    const actionWith = (data) => {
      const finalAction = Object.assign({}, action, data)
      delete finalAction[FETCH]
      return finalAction
    }
    next(actionWith({ type: requestType }))

    const ulktypes = ['GETOTPSMS', 'LOGIN']
    const sendkey = ulktypes.some(i => i===type) ? getState().core._ulk : getState().core._k
    console.log('core._ulk:', getState().core._ulk)
    console.log('core._k: ', getState().core._k)

    const sendData = buildData(payload, sendkey, type !== 'UPDATE_SESSION_K')

    const fullUrl = url.indexOf(API_ROOT1) === -1 ? API_ROOT1 + url : url
    return axios({
      method: 'post',
      url: fullUrl,
      data: sendData,
      headers: buildCustomHeader(sendData),
    }).then((response) => {
      let { data } = response

      if (!checkResSummary(response.request.responseText, response.headers.summary)) {
        return Promise.reject({ response })
        message.error('摘要校验失败!')
        return next(actionWith({ response, type: failureType }))
      }

      if (data.responseCode === '000000') {
        try {
          const ulkt = ['UPDATE_SESSION_K', 'GETOTPSMS']
          const resKey = ulkt.some(i => i === type) ? getState().core._ulk : getState().core._k
          data = buildResponse(data, resKey)
        } catch (e) {
          Promise.reject({
            data
          })
          message.error('解析报文失败')
          return next(actionWith({ data, type: failureType }))
        }

        const { responseCode, responseMsg, model } = data
        const res = Object.assign({ responseCode, responseMsg }, model ? (typeof model === 'string' ? JSON.parse(model) : model) : {})

        next(actionWith({
          response: res,
          type: successType,
        }))
        return Promise.resolve(res)
      } else if (data.responseCode === 'INTF0201') {
        message.warning('请登录后重试')
        setTimeout(() => {
          hashHistory.replace('/signin')
        }, 1000)
        next(actionWith({ type: 'CLEARLOGIN' }))
        return Promise.reject(data)
      }

      notification.error({
        message: 'ERROR',
        description: data.responseMsg,
      })
      next(actionWith({
        response: data,
        type: failureType,
      }))
      return Promise.reject(data)
    }, (error) => {
      message.error('通讯失败')

      next(actionWith({ response: error, type: failureType }))
      return Promise.reject(error)
    })
  }
  return next(action)
}
