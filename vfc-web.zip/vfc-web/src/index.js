import React from 'react'
import ReactDOM from 'react-dom'
import { Provider } from 'react-redux'
import { HashRouter } from 'react-router-dom'
import { renderRoutes } from 'react-router-config'
import createStore from './store/createStore'
import ErrorBoundaries from './components/ErrorBoundaries'

const store = createStore(window.__INITIAL_STATE__)
const routes = require('./routes').default(store)

const APP = (
    <ErrorBoundaries>
      <Provider store={store}>
        <HashRouter>{renderRoutes(routes)}</HashRouter>
      </Provider>
    </ErrorBoundaries>
)
ReactDOM.render(APP, document.getElementById('root'))
