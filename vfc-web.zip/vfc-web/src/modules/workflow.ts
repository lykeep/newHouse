import { createFetchAction } from './common'

// 发起工作流
const WORKFLOW_COMMON_START_PROCESS = 'WORKFLOW_COMMON_START_PROCESS'

//  完成任务
const WORKFLOW_COMMON_TASK_COMPLETE = 'WORKFLOW_COMMON_TASK_COMPLETE'

// 工作流详细信息查询
const WORKFLOW_COMMON_QUERY_FLOW_DETAIL = 'WORKFLOW_COMMON_QUERY_FLOW_DETAIL'

// 获取下一个节点参与者
const WORKFLOW_COMMON_QUERY_NEXT_NODE_PART = 'WORKFLOW_COMMON_QUERY_NEXT_NODE_PART'

// 获取业务编号+申请单编号
const WORKFLOW_COMMON_QUERY_BID_AND_BPID = 'WORKFLOW_COMMON_QUERY_BID_AND_BPID'

// 领取任务
const WORKFLOW_COMMON_TASK_CLAIM = 'WORKFLOW_COMMON_TASK_CLAIM'

// 流转记录查询
const WORKFLOW_COMMON_TASK_FLOW_LIST = 'WORKFLOW_COMMON_TASK_FLOW_LIST'

// 获取流程图
const WORKFLOW_COMMON_TASK_FLOW_CHART = 'WORKFLOW_COMMON_TASK_FLOW_CHART'


export const processDefStart = createFetchAction(WORKFLOW_COMMON_START_PROCESS, 'vfc-intf-ent-base.processStart')
export const taskCompleted = createFetchAction(WORKFLOW_COMMON_TASK_COMPLETE, 'vfc-intf-ent-base.taskCompleted')
export const queryWorkflowDetail = createFetchAction(WORKFLOW_COMMON_QUERY_FLOW_DETAIL, 'vfc-intf-ent-base.taskRunDetail')
export const taskNextNodePart = createFetchAction(WORKFLOW_COMMON_QUERY_NEXT_NODE_PART, 'vfc-intf-ent-base.taskNextNodePart')
export const getBidAndBpid = createFetchAction(WORKFLOW_COMMON_QUERY_BID_AND_BPID, 'vfc-intf-ent-base.reqBusiKeyAndBusiNo')
export const taskClaim = createFetchAction(WORKFLOW_COMMON_TASK_CLAIM, 'vfc-intf-ent-base.taskClaim')
export const taskFlowList = createFetchAction(WORKFLOW_COMMON_TASK_FLOW_LIST, 'vfc-intf-ent-base.taskFlowList')
export const processFlowChart = createFetchAction(WORKFLOW_COMMON_TASK_FLOW_CHART, 'vfc-intf-ent-base.processFlowChart')
