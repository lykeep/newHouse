import { createAction, createFetchAction, createHandlers, createReducer } from './common'
import moment from 'moment'

/**
 * 定义action type常量
 * @type {string}
 */
const USER = 'USER'
const LOGIN = 'LOGIN'
const UPDATEAUTH = 'UPDATEAUTH'
const MENUQUERY = 'MENUQUERY'
const LOGOUT = 'LOGOUT'
const CLEARLOGIN = 'CLEARLOGIN'

const GETTOKEN = 'GETTOKEN'
const GETOTPSMS = 'GETOTPSMS'
const QUERYSYSDATE = 'QUERYSYSDATE'

const BEGIN_LOADING = 'BEGIN_LOADING'
const END_LOADING = 'END_LOADING'

const QURY_COMMON_PAGE_INFO = 'QURY_COMMON_PAGE_INFO'

const UPDATE_SESSION_K = 'UPDATE_SESSION_K'
const UPDATE_KEY = 'UPDATE_KEY'
const UPDATE_UNLOGIN_KEY = 'UPDATE_UNLOGIN_KEY'

const PENDING_TASK_STATISTICS = 'PENDING_TASK_STATISTICS'
const PROCESS_IN_HANDLIST_SUCCESS = 'PROCESS_IN_HANDLIST_SUCCESS'
const PROCESS_IN_HANDLIST_FAIL = 'PROCESS_IN_HANDLIST_FAIL'

/**
 * 创建action事件函数
 * @type {function}
 */

export const setUser = createAction(USER)

export const login = createFetchAction(LOGIN, 'vfc-intf-ent-login.login')

export const logout = createFetchAction(LOGOUT, 'vfc-intf-ent-login.logout')

export const clearLogin = createAction(CLEARLOGIN)

export const updateAuth = createAction(UPDATEAUTH)

export const menuQuery = createFetchAction(MENUQUERY, 'vfc-intf-ent-crm.queryUserMenuList')

export const pendingTaskStatistics = createFetchAction(PENDING_TASK_STATISTICS, 'vfc-intf-ent-login.pendingTaskStatistics')
export const processInHandListSuccess = createFetchAction(PROCESS_IN_HANDLIST_SUCCESS, 'vfc-intf-ent-login.processInHandListSuccess')
export const processInHandListFail = createFetchAction(PROCESS_IN_HANDLIST_FAIL, 'vfc-intf-ent-login.processInHandListFail')

export const getToken = createFetchAction(GETTOKEN, '/esa/nts_cfb_order_prod.getToken')

export const getOTPSms = createFetchAction(GETOTPSMS, 'vfc-intf-ent-login.otpSmsSend')

export const queryDate = createFetchAction(QUERYSYSDATE, '/esa/nts_cfb_prod_order.queryDate')

export const beginLoading = createAction(BEGIN_LOADING)
export const endLoading = createAction(END_LOADING)

export const queryCommonPageInfo = createFetchAction(QURY_COMMON_PAGE_INFO, '/los/lo-console.queryConstants')

export const updateKey = createAction(UPDATE_KEY)
export const updateUnloginKey = createAction(UPDATE_UNLOGIN_KEY)
export const updateSessionKey = createFetchAction(UPDATE_SESSION_K, 'vfc-intf-ent-login.updateSessionKey')

export const auth = {
  getSelf: () => sessionStorage.self && JSON.parse(sessionStorage.self),
  logout: (cb) => {
    delete sessionStorage.loggedIn
    sessionStorage._ulk = ''
    delete sessionStorage.self
    if (cb) cb()
    // this.onChange(false)
  },
  loggedIn: () => !!sessionStorage.loggedIn,
  onChange: () => {},
}

/**
 * 如需要批量导出方便引用则可定义此常量，否则可以忽略
 */
export const actions = {
  setUser,
  login,
  logout,
}

const ACTION_HANDLERS = {
  [UPDATEAUTH]: (state, payload) => Object.assign({}, state, { loggedIn: payload }),
  [LOGIN]: (state, payload) => {
    const userinfo = {
      loggedIn: true,
      USER: {
        loginName: payload.loginName,
        userName: payload.userName,
        mobilePhone: payload.mobilePhone,
        employeeNumber: payload.employeeNumber,
        officeId: payload.officeId,
        officeName: payload.officeName,
        subOfficeId: payload.subOfficeId,
        subOfficeName: payload.subOfficeName,
      },
    }
    sessionStorage.self = JSON.stringify(userinfo.USER)
    sessionStorage.loggedIn = userinfo.loggedIn
    return Object.assign({}, state, userinfo)
  },
  [LOGOUT]: (state, payload) => {
    auth.logout()
    sessionStorage._ulk = ''
    return Object.assign({}, state, { loggedIn: false, USER: {} })
  },
  [CLEARLOGIN]: (state, payload) => {
    auth.logout()
    sessionStorage._ulk = ''
    return Object.assign({}, state, { loggedIn: false, USER: {} })
  },
  [QUERYSYSDATE]: (state, payload) => {
    moment.locale('zh-CN')
    return Object.assign({}, state, { sysDate: moment(payload.sysDate).format('LL') })
  },
  [BEGIN_LOADING]: (state, payload) => Object.assign({}, state, { loading: Math.max(state.loading + 1, 0) }),
  [END_LOADING]: (state, payload) => Object.assign({}, state, { loading: Math.max(state.loading - 1, 0) }),
  [QURY_COMMON_PAGE_INFO]: (state, payload) => Object.assign({}, state, { commonPageInfo: payload.model }),
  [UPDATE_KEY]: (state, payload) => {
    sessionStorage._k = payload.payload.key
    return Object.assign({}, state, { _k: payload.payload.key })
  },
  [UPDATE_UNLOGIN_KEY]: (state, payload) => Object.assign({}, state, { _ulk: payload.payload.key }),
}

/**
 * 创建reducer函数
 * 参数一（必输）：设置默认store对象属性，无需设置可传入空对象{}
 * 参数二（必输）：传入触发action事件后调用的回调函数，可以使用createHandlers函数批量生成也可自定义
 * @type {function}
 */
export default createReducer(
  {
    _k: sessionStorage._k,
    _ulk: '',
    _pt: '', // timestamp
    loggedIn: auth.loggedIn(),
    sysDate: '',
    USER: auth.getSelf() || {},
    loading: 0,
    commonPageInfo: {},
  },
  createHandlers(ACTION_HANDLERS),
)
