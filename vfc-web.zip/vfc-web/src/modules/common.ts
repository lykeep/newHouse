import { FETCH } from '../middleware/index'
import { Action, Reducer } from 'redux'

/**
 * Our SyncAction must extend redux's Action, and our SyncAction has a field 'payload'
 *
 * @export
 * @interface SyncAction
 * @extends {Action}
 */
export interface SyncAction extends Action {
  payload: any
}

export interface AsyncAction extends SyncAction {
  url: string
}

export const buildState = (state: any, newData: any, id: string) => {
  const newState = Object.assign({}, state, newData)
  sessionStorage[id] = JSON.stringify(newState)
  return newState
}

export type AjaxAction<T = any> = (params: any) => Promise<T>

export const buildStoreFromSessionStorage = (id: any, extraJob: any) => {
  // if (sessionStorage[id]) {
  //   const state = JSON.parse(sessionStorage[id])
  //
  //   const extraPart = extraJob ? extraJob(state) : {}
  //
  //   return Object.assign({}, state, extraPart)
  // } else {
  //   return null
  // }
  return null
}

export function createConstants(...constants: any[]) {
  return constants.reduce((acc, constant) => {
    acc[constant] = constant
    return acc
  }, {})
}

export function createAction(actionType: string): (value: any) => SyncAction {
  return (value) => {
    return {
      type: actionType,
      payload: value
    }
  }
}

export function createFetchAction (actionType: string, url: string): (value: any) => any {
  // here the type of dispatch is ANY, not redux's Dispatch
  // because redux's Dispatch accept AnyAction which must have a proptye named 'type'
  return (value) => (dispatch: any, getState: any) => dispatch({
    [FETCH]: {
      type: actionType,
      url,
      payload: value || {}
    }
  })
}

export interface ReducerHandlers {
  [index: string]: Reducer
}

export function createReducer(initialState: any, ACTION_HANDLERS: ReducerHandlers): (state: any, action: any) => any {
  return (state = initialState, action) => {
    let handler = ACTION_HANDLERS[action.type]

    /* ie does not support endsWith */
    const requestType = action.type.match(/.*_REQUEST$/g)
    const successType = action.type.match(/.*_SUCCESS$/g)
    const failureType = action.type.match(/.*_FAILURE$/g)

    if (requestType) {
      // nogthing
    }

    if (successType) {
      if (action.response) {
        handler = ACTION_HANDLERS[action.type.split('_SUCCESS')[0]]
        return handler ? handler(state, action.response) : state
      }
    }

    if (failureType) {
      // nothing
    }

    return handler ? handler(state, action) : state
  }
}

export function createSimpleReducer(initialState: any, ACTION_HANDLERS: ReducerHandlers): any {
  return (state = initialState, action: Action) => {
    const handler = ACTION_HANDLERS[action.type]

    return handler ? handler(state, action) : state
  }
}

export function createHandler(ACTION_TYPE: string): Reducer {
  return (state, action) => {
    return Object.assign({}, state, {
      [ACTION_TYPE]: action.payload
    })
  }
}

export function createHandlers(...ACTION_TYPES: ReducerHandlers[]): any {
  return ACTION_TYPES.reduce((ACTION_HANDLERS, param) => {
    if (typeof param === 'string') {
      ACTION_HANDLERS[param] = (state, action) => Object.assign({}, state, {
        [param]: action
      })
    }
    if (typeof param === 'object') {
      for (const item in param) {
        if (Object.prototype.hasOwnProperty.call(param, item)) {
          ACTION_HANDLERS[item] = (state, action) => param[item](state, action)
        }
      }
    }
    return ACTION_HANDLERS
  }, {})
}
