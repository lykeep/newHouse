// import Immutable from 'seamless-immutable'
import { createAction, createSimpleReducer, createHandlers, ReducerHandlers } from './common'

const INIT_FORM = '@@LB_INIT_FORM@@'
const UPDATE_FORM_FIELDS = '@@LB_UPDATE_FORM_FIELDS@@'
const REMOVE_ACTIVE_FORM = '@@REMOVE_ACTIVE_FORM@@'
const UPDATE_ACTIVE_FORM = '@@LB_UPDATE_ACTIVE_FORM@@'
const DESTROY_FORM = '@@LB_DESTROY_FORM@@'

// in @types/seamless-immutable@7.1.3, Immutable.ImmutableObject and Immutable.ImmutableArray are removed
// Immutable.Immutable<> is introduced.
// Immutable.ImmutableObject = Immutable.Immutable<{}>
// Immutable.ImmutableArray = Immutable.Immutable<[]>
export interface FormDef {
  [index: string]: any
}

export const initForm = createAction(INIT_FORM)
export const updateFormFields = createAction(UPDATE_FORM_FIELDS)
export const removeFormFields = createAction(REMOVE_ACTIVE_FORM)
export const updateActiveForm = createAction(UPDATE_ACTIVE_FORM)
export const destroyForm = createAction(DESTROY_FORM)

export const getFormsFromStore = (store: any) => store.pageForms

export const getElement = (state: any, names = '') => {
  const levels = names.split('.')

  if (levels.length === 0) {
    return state
  }

  return levels.reduce((preV, currLevel) => (preV ? preV[currLevel] : null), state)
}


export const getFormFiels = (state: any, name = '') => getElement(state.formFields, name)

export const getActiveForms = (state: any, name = '') => (name ? getElement(state.activeForms, name) : state.activeForms)
export const getMustValidateForms = (state: any, name = '') => (name ? getElement(state.mustValidateForms, name) : state.mustValidateForms)

const ACTION_HANDLERS: ReducerHandlers = {
  [INIT_FORM]: (state, { payload }) => {
    const { formFields, activeForms, mustValidateForms } = state
    const { name } = payload

    const newFormFields = Object.assign({}, formFields)
    const newActiveForms = Object.assign({}, activeForms, { [ name ]: {} })
    const newMustValidateForms = Object.assign({}, mustValidateForms, { [ name ]: {} })
    newFormFields[name] = {}
    // newActiveForms[name] = []

    return Object.assign({}, state, {
      formFields: newFormFields,
      activeForms: newActiveForms,
      mustValidateForms: newMustValidateForms,
    })
  },
  [UPDATE_FORM_FIELDS]: (state, { payload }) => {
    const { formFields } = state
    const { name, data } = payload
    const newFormFields = Object.assign({}, formFields)

    const levels = name.split('.')
    levels.reduce((preV: any, currLevel: any, index: number, array: any[]) => {
      if (index === array.length - 1) {
        preV[currLevel] = Object.assign(preV[currLevel], data)
      }

      return preV[currLevel]
    }, newFormFields)

    return Object.assign({}, state, { formFields: newFormFields })
  },
  [UPDATE_ACTIVE_FORM]: (state, { payload }) => {
    const { pageName, name, data, mustValidate } = payload
    const { activeForms, mustValidateForms } = state
    // const newActiveForms = activeForms.update(pageName, (forms: Immutable.Immutable<FormDef>) => forms.set(name, () => data))
    // remove original
    let newActiveForms = Object.assign({}, activeForms, { [pageName]: Object.assign({}, activeForms[pageName], { [name]: null }) })
    newActiveForms = Object.assign({}, activeForms, { [pageName]: Object.assign({}, activeForms[pageName], { [name]: () => data }) })



    // const newMustValidateForms = mustValidateForms.update(pageName, (forms: Immutable.Immutable<FormDef>) => forms.set(name, mustValidate))
    let newMustValidateForms = Object.assign({}, mustValidateForms, { [pageName]: Object.assign({}, mustValidateForms[pageName], { [name]: null }) })
    newMustValidateForms = Object.assign({}, mustValidateForms, { [pageName]: Object.assign({}, mustValidateForms[pageName], { [name]: mustValidate }) })


    const ret = Object.assign({}, state, { activeForms: newActiveForms, mustValidateForms: newMustValidateForms })
    return ret
  },
  [REMOVE_ACTIVE_FORM]: (state, { payload }) => {
    const { pageName, name } = payload
    const { activeForms, mustValidateForms } = state
    // const newActiveForms = activeForms.update(pageName, (forms: Immutable.Immutable<FormDef>) => forms.without(name))
    const newActiveForms = Object.assign({}, activeForms, { [pageName]: Object.assign({}, activeForms[pageName], { [name]: null }) })
    const newMustValidateForms = Object.assign({}, mustValidateForms, { [pageName]: Object.assign({}, mustValidateForms[pageName], { [name]: null }) })
    // const newMustValidateForms = mustValidateForms.update(pageName, (forms: Immutable.Immutable<FormDef>) => forms.without(name))
    return Object.assign({}, state, { activeForms: newActiveForms, mustValidateForms: newMustValidateForms })
  },
  [DESTROY_FORM]: (state, { payload }) => {
    const { name } = payload

    const { activeForms, mustValidateForms } = state
    const e = activeForms[name]
    if (e) {
      Object.keys(e).forEach(k => e[k] = null)
    }

    const v = mustValidateForms[name]
    if (v) {
      Object.keys(v).forEach(k => v[k] = null)
    }

    let newActiveForms = Object.assign({}, activeForms, { [name]: null }) // Immutable.update(activeForms, name, forms => Immutable.set(forms, name, null))
    let newMustValidateForms = Object.assign({}, mustValidateForms, { [name]: null })

    newActiveForms = Object.assign({}, activeForms, { [name]: {} })
    newMustValidateForms = Object.assign({}, mustValidateForms, { [name]: {} })
    const ret = Object.assign({}, state, { activeForms: newActiveForms, mustValidateForms: newMustValidateForms })
    return ret
  },
}

interface FormStore {
  formFields: any
  activeForms: object
  mustValidateForms: object
}

const initState: FormStore = {
  formFields: {},
  activeForms: {},
  mustValidateForms: {},
}


export default createSimpleReducer(initState, createHandlers(ACTION_HANDLERS))
