const express = require('express')
const compression = require('compression')

const port = 10001
const app = express()
app.use(compression())
app.use(express.static('build'))

app.post('/test.test.test', (req, res) => {
  res.json({
    responseCode: 'user.invalid',
  })
})

app.listen(port)
console.log(`test server started on ${port}...`)
