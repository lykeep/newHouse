const { injectBabelPlugin } = require('react-app-rewired')
const rewireLess = require('react-app-rewire-less')
const rewireSass = require('./rewired/addSassLoader')
const path = require('path')
const webpack = require('webpack')
const StatsPlugin = require('stats-webpack-plugin')

const vendors = [
  'react',
  'redux',
  'react-redux',
  'react-router-dom',
  'history',
  'rc-table',
  'rc-select',
  'rc-form',
  'async-validator',
  'rc-pagination',
  'rc-calendar',
  'rc-tree',
  'antd/es/table',
  'antd/es/date-picker',
]

const primaryColorNormal = '#2C648E' // 主色
const primaryColorDWY = '#BE1E1E' // 戴维营的主色

const baseLinkColor = '#2C648E' // 链接的主色，所有的链接都是这个颜色

const btnBorderColorNormal = '#96B2C7'
const btnBorderColorDWY = '#DF8F8F' // 戴维营的按钮边框色



const textColor = '#ced4da' // 普通字体色
const titleColor = '#adb5bd' // 标题字体色
const headerBg = '#ffffff' // header区域背景色
const siderBg = '#ffffff' // sider区域背景色
const bodyBg = '#3c4452' // content区域背景色
const compBg = '#353c48' // 组件背景色
const borderColor = '#4F5467' // 边框色
const inputBg = '#272c36' // input背景色
const hoverBg = '#303641' // 选中背景色


// ------------------------------------
// Utilities
// ------------------------------------
const resolve = path.resolve
const base = (...args) => Reflect.apply(resolve, null, [path.resolve(__dirname), ...args])

module.exports = function override(config, env) {
  // 设置antd
  config = injectBabelPlugin(['import', { libraryName: 'antd', libraryDirectory: 'es', style: true }], config)

  const primaryColor = process.env.REACT_APP_DWY ? primaryColorDWY : primaryColorNormal
  const btnBorderColor = process.env.REACT_APP_DWY ? btnBorderColorDWY : btnBorderColorNormal
  config = rewireLess.withLoaderOptions({
    modifyVars: {
      '@primary-color': primaryColor,
      '@link-color': baseLinkColor, // 链接的颜色
      '@tabs-card-active-color': baseLinkColor, // tab选中的颜色
      '@btn-default-color': primaryColor, // default类型的按钮的文字颜色
      '@btn-default-border': btnBorderColor, // default类型的按钮的边框颜色
      // '@text-color': textColor,
      // '@heading-color': titleColor,
      // '@disabled-color': textColor,
      '@layout-header-background': headerBg,
      // '@layout-body-background': bodyBg,
      // '@component-background': compBg,
      '@layout-sider-background': siderBg,
      // '@menu-dark-bg': 'transparent',
      // '@card-head-color': titleColor,
      // '@border-color-split': borderColor,
      // '@border-color-base': inputBg,
      // '@input-color': textColor,
      // '@input-border-color': inputBg,
      // '@input-bg': inputBg,
      // '@table-header-bg': compBg,
      // '@table-row-hover-bg': compBg,
      // '@text-color-secondary': textColor,
      // '@item-hover-bg': hoverBg,
      // '@background-color-light': primaryColor,
      // '@item-active-bg': primaryColor,
      // '@btn-default-bg': compBg,
      // '@popover-bg': compBg,
      // '@tabs-card-head-background': bodyBg,
    },
  })(config, env)

  // 增加scss loader
  config = rewireSass.withLoaderOptions({})(config, env)

  // 设置import的module路径
  config.resolve.modules.push(path.join(__dirname, 'src'))

  // 设置外部引用
  config.externals = {
    CryptoJS: 'CryptoJS',
    moment: 'moment',
    lodash: 'lodash',
  }


  if (process.env.NODE_ENV !== 'development') {
    // 设置common chunk
    // 设置entry
    if (Array.isArray(config.entry)) {
      config.entry = {
        main: config.entry,
        vendor: vendors,
        // common: [base('src', 'components', 'form', 'inputs', 'TableField', 'index.jsx')]
        // antdb: antdbase,
        // moment: ['moment']
      }
    } else {
      config.entry.vendor = vendors
    }

    // 增加common chunk
    config.plugins.push(new webpack.optimize.CommonsChunkPlugin({
      names: ['vendor'/*, 'common'*/],
    }))

    // remove this currently, this will cause out of memory while building
    // config.plugins.push(new StatsPlugin('stats.json', {
    //   chunkModules: true,
    // }))

    // config.output = {
    //   filename: `[name].[chunkhash].js`,
    //   path: base('build'),
    //   publicPath: './'
    // }
  }

  config.profile = true

  return config
}
