#!/bin/sh

# "usage: $0 uc"
# "       u: only upload ${toFile}"
# "       c: only compile"

echo "**********************CALL $0**********************"

compile=1
upload=1
preresult=0

distDir=build
nginx_user=app
nginx_password="app@123456"
nginx_htmlDir=/data/web/dwy

nginx_server1=10.0.61.20
nginx_server2=10.0.61.21

if [ "$1"x = "u"x ];then
  compile=0
fi

if [ "$1"x = "c"x ];then
  upload=0
fi


if [ ${compile} -eq 1 ];then
  echo "Clean files..."
  rm -rf ${distDir}

  echo "start compile project..."
  build_time=`date "+%Y-%m-%d %H:%M:%S"`
  export NODE_ENV="production"
  export REACT_APP_ENV="PRD"
  export REACT_APP_BUILD_TIME=${build_time}

  time npm run build:prod:dwy
  preresult=$?
fi
echo ${build_time} > version.txt
if [ ${upload} -eq 1 ]; then
  if [ ${preresult} -eq 0 ];then
    echo "upload file to server..."

    cd ${distDir}

    for svr in ${nginx_server1} ${nginx_server2}
    do
        echo "sending data to ${svr}"

        expect -c "
          spawn scp -r . ${nginx_user}@${svr}:${nginx_htmlDir}
          set timeout 900
          expect {
            \"*assword\" {sleep 1; send \"${nginx_password}\r\";}
            \"yes/no\" {send \"yes\r\"; exp_continue;}
          }
          expect eof"
        echo "ddd$?"
    done
  fi
fi

if [ ${preresult} -eq 0 ];then
  echo "**********************$0 DONE**********************"
else
  echo "!!!!!!!!!!!!!!!!!!!!!!$0 FAIL!!!!!!!!!!!!!!!!!!!!!!"
  exit 1
fi
