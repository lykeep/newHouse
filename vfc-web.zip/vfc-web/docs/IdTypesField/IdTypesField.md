# IdTypesField

![IdTypesField](./IdTypesField.png)

根据不同证件类型验证证件号

组件地址：
/src/components/form/inputs/IdTypesField

## Props
* form 
* name 数据项名称  array ['证件类型', '证件号码'] 注：顺序不能变
* label 标签的文本  array ['证件类型', '证件号码'] 注：顺序不能变
* colSpan 栅格占位格数  number
* required 是否必填 boolean 
* fieldProps 赋值给getFieldDecorator的第二个参数


例
``` js
<IdTypesField
    form={form}
    authority={authority}
    name={['idtype', 'idNumber']}
    label={['证件类型', '证件号码']}
    colSpan={16}
    required
    fieldProps={{
        // initialValue: { idtype: 'hz', idNumber: '2302291993' },
    }}
/>
```
