# TextareaField

### 封装组件

#### 路径
文件路径: src/components/form/inputs/TextareaField.jsx

#### 模式
所有的组件，都要实现以下2种模式：
1. editable, 可编辑模式
2. read, 非可编辑，阅读模式

#### props
* form
* name 组件名称，会传递给getFieldDecorator的第一个参数
* formItemProps 传递给Form.Item的参数
* fieldProps 传递给getFieldDecorator的参数,initialValue是设置初始值的
* inputProps 传递给组件的参数
* colSpan 整个控件所在Col的span，默认24

#### 例子
```js
import TextareaField from '../../../../components/form/inputs/TextareaField'

render() {
  const { form } = this.props
  const { getFieldDecorator } = form

  return (
    <div>
      <Form>
        <Row type="flex" align="top">
          {
            counts.map(c => (
              <TextareaField
                key={`${c}d`}
                form={form}
                name={`d${c}`}
                formItemProps={{ label: `多行输入框${c}`, required: true }}
                fieldProps={{
                  initialValue: '',
                  rules: [
                    { required: true, message: 'required' },
                  ]
                }}
              />
            ))
          }
        </Row>
      </Form>
    </div>
  )
}
