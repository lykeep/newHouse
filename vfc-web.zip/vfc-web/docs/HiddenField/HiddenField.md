# HiddenField
隐藏字段

组件地址：'src/components/form/inputs/HiddenField'
## Props
* form
* name  对应的字段名称，会赋值给getFieldDecorator()的第一个参数
* fieldProps  赋值给getFieldDecorator()的第二个参数

引用实例
```js
import HiddenField from './HiddenField'

render() {
  const { form } = this.props
  return (
    <HiddenField
      form={form}
      name="fieldName"
      fieldProps={{
        initialValue: [],
      }}
    />
  )
}
```
