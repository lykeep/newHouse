# SelectedDataField

弹窗展示所有数据，选择后显示在table中

/src/components/SelectedDataField

## 多条数据
![NameFilterModal](./multiple.png)

## 单条数据
![NameFilterModal](./alone.png)


## Props

| prop | type | desc | required |
| ---- | ---- | ---- | -------- |
| name | string | button显示的文本 | true |
| modelKey | string | 返回的数据中 model中取值的key| true |
| columns | object | {modalColumns：[],tableColumns:[]}modalColumns：弹窗的columns，tableColumns：table中的columns| true |
| receivekey | array | 返回model中要获取的名称，ID 顺序不能变 | true |
| action | function | modal中列表的接口方法| true |
| onChange | function | 返回table中数据 | true |
| multiple | boolean | 默认false table中展示单条数据 | false |

``` js
<SelectedDataField
  multiple
  name="点击"
  modelKey="creditDepositList"
  authority={authority}
  columns={{
    modalColumns: this.columns,
    tableColumns,
  }}
  receivekey={['copartnerName', 'copartnerNo']}
  action={action}
  onChange={this.onChange}
/>
```