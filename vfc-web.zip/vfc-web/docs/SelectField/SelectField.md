# SelectMultiField

![SelectMultiField](./SelectMultiField.png)

组件地址 /src/components/form/TableField


## Props
* form
* name 对应的字段名称，会赋值给getFieldDecorator()的第一个参数
* fieldProps 赋值给getFieldDecorator的第二个参数
* inputProps 赋值给option的参数
* async 是否异步获取options
* optionsLoader 异步获取options的回调
* optionFormatter 格式化options数据结构

### inputProps
* options options数据的主键名称，必输

### async
options是通过```optionsLoader```从后台读取的

### optionsLoader
读取options的方法，需要返回一个Promise，resolve的参数就是options
options的数据结构为
```js
[
  {
    key: 'key',
    value: 'value',
    title: '标题'
  },
  ...
]
```

### optionFormatter(opts)
格式化options的方法，这个方法需要返回：
```js
[
  {
    key: 'key',
    value: 'value',
    title: '标题'
  },
  ...
]
```


## 例子
``` js

this.options = [{
      key: '1OP',
      title: 'OP1s',
      value: 'OP1',
    }, {
      key: '2OP',
      title: 'OP2s',
      value: 'OP2',
    }]

render() {
  const { form } = this.props
  return (
    <SelectMultiField
      form={form}
      name="select"
      formItemProps={{ label: 'SELECT', required: true }}
      fieldProps={{
        initialValue: ['OP1'],
        rules: [
            { type: 'array', required: true, message: 'required' },
         ],
      }}
      inputProps={{
         options: this.options,
      }}
    />
  )
}
```
