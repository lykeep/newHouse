# MoneyField

![MoneyField](./MoneyField.png)

适用于表单金额输入，展示。


/src/components/form/inputs/MoneyField

要求lb-components版本大于0.0.2

## Props
* form
* name 对应的字段名称，会赋值给getFieldDecorator()的第一个参数
* formItemProps 赋值给字段Item的参数
* fieldProps 赋值给getFieldDecorator的第二个参数
* inputProps 赋值给MoneyField的参数

### formItemProps
* lable 字段显示名称
* required 是否标识为必输字段

### fieldProps
* initialValue 组件初始值
* rules 组件校验规则
* onChange 组件改变后的回调

### inputProps
* min 金额组件 最小值限定 默认为0
* precision 金额精确度设定 默认为4位有效数值
* colSpan 组件所在Col的span，默认8

例子
``` js
import ContractSigningContainer from './ContractSigningContainer'

 return (
      <div>
        <Form>
          <Row type="flex" align="top">
            {
              counts.map(c => (
                <MoneyField
                  key={`${c}d`}
                  form={form}
                  name={`d${c}`}
                  formItemProps={{ label: `合同金额${c}`, required: true }}
                  fieldProps={{
                    initialValue: this.state.data[c],
                    rules: [
                      { required: true, message: 'required' },
                    ],
                  }}
                />
              ))
            }
          </Row>
        </Form>
      </div>
    )
```
