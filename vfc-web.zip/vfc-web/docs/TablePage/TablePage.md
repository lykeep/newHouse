
# TablePage

![TablePage](./TablePage.png)

/src/components/form/inputs/TablePage

## Props
* doPagination 是否分页  boolean 默认false
* columns 表格列的配置描 array 必填
* total 总页数  number 必填
* dataSource 列表数据  array 必填
* query 回调函数 返回当前页的页号、每页条数，如果不需要分页可以不用传
* pageSize 每页展示条数  默认 10条/页
* rowSelection 列表项是否可选择 用法参考ant Design中Table
* size 表格尺寸 
* className  


例子
``` js

  pageInfo = (params) => {
    console.log('pageNo', params.pageNo) // 当前页码
    console.log('recordsPerPage', params.recordsPerPage) // 每页条数
  }

<TablePage
    rowSelection={null}
    doPagination={true}
    columns={newColumns}
    dataSource={data}
    query={this.pageInfo}
    pageSize={5}
    total={total}
/>

```