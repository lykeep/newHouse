# NameFilterModal

适用于在列表中搜索要的显示名称。

/src/components/form/inputs/nameFilterModal/NameFilterModal

## type为input
![NameFilterModal](./input.png)
## type为button
![NameFilterModal](./button.png)
![NameFilterModal](./modal.png)
## 需要查看详情
![NameFilterModal](./showIcon.png)


### 共用Props
* modalData 必输项 modal中要展示的数据和表头  [{dataSource: '展示的数据', columns: '展示的表头'}]
* name array 数据项名称  例：['name', 'name对应的id']  注：顺序不能变
* action modal中列表的接口方法
* useForm  Boolean  默认true  使用表单保存值
* formItemProps 赋值给字段Item的参数
* colSpan 所占栅格数
* modelKey 返回的数据中 model中取值的key
* type 展示形式
* showIcon boolean 默认false 是否展示icon（eye）查看详情
* onClickIcon function 点击icon的回调，会返回已选择项的名称和ID

### 不使用表单的参数 Props
* value  object  设置默认值
* status  boolean 验证，手动通过onChange返回值判断是否符合要求


### 使用表单的参数 Props
* form
* fieldProps 赋值给getFieldDecorator的第二个参数
* inputProps 赋值给CheckboxField的参数

### type object
* {type: button || input，name: 如果type=button，输入展示的名字；否则无须填写 } 默认为input

### onChange 类型：function  
* type == input，当useForm = false  可以取到 名称，ID
* type == button, 返回被选中的完整数据

###  modalData  数据格式为{dataSource: [], columns: []} 
*  columns 数据格式为[{title: '名称', dataIndex: 'name'}]  注：操作列只有“选择” 不需要传

### formItemProps
* lable 字段显示名称
* required 是否标识为必输字段

### fieldProps
* initialValue 组件初始值 object 例：{ legalId: '1', legalName: '111' }

### receivekey  array  
* 必输 返回model中要获取的对应项 顺序不能变 ['数据中过滤项的key', '对应的id'] 


例
``` js
//

this.columns = [{
    title: '名称',
    dataIndex: 'name',
}, {
    title: 'id',
    dataIndex: 'id',
}, {
    title: '时间',
    dataIndex: 'date',
}, {
    title: '天气',
    dataIndex: 'weather',
}]

////  type == 'input'
// 使用表单保存
<NameFilterModal
    form={form}
    useForm={true}
    authority={authority}
    name={['legalName', 'legalId']}
    action={queryList}
    modelKey="creditDepositList"
    modalData={{
        columns: this.columns,
    }}
    receivekey={['copartnerName', 'copartnerNo']}
    formItemProps={{ label: '法人名称' }}
    fieldProps={{
        initialValue: { legalId: '1', legalName: '111' },
        rules: [
            { required: true, message: '法人必输！' },
        ],
    }}
    inputProps={{
        placeholder: '请输入',
    }}
/>

// 不使用表单取值
<NameFilterModal
    useForm={false}
    colSpan={12}
    onChange={this.nameFilter}
    value={{ legalId: '1', legalName: 'ys' }}
    authority={authority}
    modelKey="creditDepositList"
    name={['legalName', 'legalId']}
    modalData={{
        columns: this.columns,
    }}
    receivekey={['name', 'id']}
    formItemProps={{ label: '法人名称' }}
/>


//// type == 'button'
<NameFilterModal
    colSpan={12}
    authority={authority}
    modalData={{
        columns: this.columns,
    }}
    showIcon // 是否展示icon
    onClickIcon={this.onClickIcon} //点击icon的回调
    useForm={false}
    type={{ type: 'button', name: '选择法人' }}
    action={action}
    name={['legalName', 'legalId']}
    modelKey="creditDepositList"
    receivekey={['copartnerName', 'copartnerNo']}
    formItemProps={{ label: '法人名称' }}
    onChange={this.onChange}
/>

//


```

![NameFilterModal](./data.png)
