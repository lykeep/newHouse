# TabField

![TabField](./TabField.jpg)


/src/components/tabs/TabsField


## Props
* componentProps   tabs列表                               必传
* defaultActiveKey 初始化选中面板的 key, 默认第一个面板 0
* onChange         切换面板时回调  


## Options 数据格式
* name  选项卡头显示文字   必传字段
* type  要显示的组件名称   必传字段
* props 需要接收的props   必传字段

options: [
            {
                name: '基本信息',
                type: QueryComp,
                props: {},
            },
            {
                name: '股东信息',
                type: InputNumber,
                props: {defaultValue: 33},
            }
        ]


例子
``` js
class TabMenus extends Component {
  constructor(props) {
    super(props)
    this.state = {}
    this.changeMenu = this.changeMenu.bind(this)
  }

  changeMenu = (e) => {
    console.log('tabs', e)
  }


  render() {

    const list = [
      {
        name: '基本信息',
        type: QueryComp,
        props: {},
      },
      {
        name: '股东信息',
        type: InputNumber,
        props: { defaultValue: 33 },
      },
    ]

    return (
      <div>
        <TabsField componentProps={list} onChange={this.changeMenu} />
      </div>
    )
  }
}
```