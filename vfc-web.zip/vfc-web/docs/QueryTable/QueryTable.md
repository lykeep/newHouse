# Query Table

包含查询条件输入框，操作按钮，列操作等数据显示table

![queryTable](./queryTable.png)

扩展查询条件：
![fields2](fields2.png)

## 属性：
### fields
定义查询条件
一个包含2个array的array，第一个array定义常用查询条件，第二个array定义扩展查询条件(可选)

| prop | type | desc | required |
| ---- | ---- | ---- | -------- |
| id | String/array | 接口中对应的字段。array对应DateRangeAddon | true |
| component | String/ReactComponent | 查询条件控件的类型：Input/Select/queryTableAddons。addon的使用详见addon部分。 | false |
| label | String | 输入框的label | true |
| defaultValue | any | 缺省值 | false |
| required | boolean | 是否必输 | false |
| colSpan | number or object| 该输入框对应的col span，默认为 ```{ sm: { span: 24 }, md: { span: 24 / COLUMNS_NUMBER } }``` | false |
| onChange | function | onChange回调 | false |

### actions
定义列表的操作

| prop | type | desc | required | default |
| ---- | ---- | ---- | -------- | ------- |
| key | String | action的唯一标识 | true | 无 |
| label | String | label of button | true | 无 |
| icon | String | button的icon | false | 无 |
| minSelect | number | 当最少选择多少行时，这个button是可用的（不会被disabled) | false | 0 |
| maxSelect | number | 当最多选择多少行时，这个button是可用的（不会被disabled) | false | 0 |
| disableFunc | function | the button is disabled while disableFunc return true | false | 无 |
| confirm | boolean | 当点击按钮时，会弹出确认对话框 | false | 无 |
| message | String | 确认对话框的内容 | false | 无 |
| action | function(selectedRowKeys, selectedRows) | 点击button的回调 | true | 无 |

### operations
定义行尾的操作，现在支持三种操作：
* OPERATIONS.VIEW
* OPERATIONS.MODIFY
* OPERATIONS.DELETE

如果operation数组未赋值或未空数组，则不现实该列

注意，这个operation列是在初始化的时候加上的，如果table已经渲染，再更改operatoins属性或者columns属性，则不生效。

#### viewHandler
点击view按钮的回调

#### modifyHandler
点击modify按钮的回调

#### deleteHandler
点击delete按钮的回调

### query
点击查询时的回调函数，需要返回一个Promise对象
function (queryParams): Promise

### loadOnMount
是否在组件didMount以后就调用查询接口
boolean

### columns
定义table的列，同antd的table的columns

### pagination
定义table的分页，同antd的pagination，通常不需要设置这个属性
如果想仅用分页，则设置这个属性为```false```

### totalCount
定义总共记录的数量

### data
表格的数据

### rowSelection
设置表格的选择模式
* checkbox 多选
* radio 单选
* null 无选择

## Addons
QueryTable默认支持2中查询条件类型：Input和Select，并不支持DatePicker，因为DatePicker打包大小太大，默认不包含。
但有些情况下是要查询日期的，这样就通过addon的方式加载：只在需要的时候加载DatePicker

使用addon，需要把相应的field的component属性设置为相关的Addon组件：

```js
import DatePickerAddon from 'components/queryTable/addons/DatePickerAddon'
import DateRangeAddon from 'components/queryTable/addons/DateRangeAddon'

this.fields = [
  [
    { id: 'name', label: '法人名称', component: 'Input' },
    { id: 'idNo', label: '证件号码' },
    { id: 'singleDate', label: '日期', component: DatePickerAddon },
    { id: ['rangeStart', 'rangeEnd'], label: '日期范围', component: DateRangeAddon },
  ],
]
```

## example

``` js
constructor(props) {
  super(props)

  this.query = this.query.bind(this)

  this.columns = [
    {
      title: '账户地址',
      dataIndex: 'accountAddress',
      key: 'accountAddress',
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      filters: [
        { text: 'OK', value: 1 },
        { text: 'Failed', value: 2 },
      ],
      render: value => (value === 1 ? '成功' : '失败'),
    },
  ]

  this.fields = [
    [
      { id: 'nodeId', label: '节点ID', component: 'Input', required: false },
      { id: 'host', label: '节点IP' },
    ],
    [
      { id: 'nodeId1', label: '节点ID1', component: 'Input' },
      { id: 'host1', label: '节点IP1' },
      { id: 'nodeId2', label: '节点ID2', component: 'Input' },
      { id: 'host2', label: '节点IP2' },
    ],
  ]

  this.actions = [
    {
      label: '导入节点',
      action: this.openImportModal,
      icon: 'plus',
      key: 'add',
    },
    {
      label: '导出节点',
      action: this.openImportModal,
      key: 'export',
    },
  ]

  this.state = {
    data: [],
    totalCount: 0,
  }

  this.operations = [
    OPERATIONS.VIEW,
    OPERATIONS.MODIFY,
    OPERATIONS.DELETE,
  ]
}

render() {
  return (
    <QueryTable
      columns={this.columns}
      fields={this.fields}
      actions={this.actions}
      query={this.query}
      data={this.state.data}
      rowKey="accountAddress"
      totalCount={this.state.totalCount}
      operations={this.operations}
      viewHandler={(record) => console.log(record)}
      modifyHandler={(record) => console.log(record)}
      deleteHandler={(record) => console.log(record)}
    />
  )
}
```
