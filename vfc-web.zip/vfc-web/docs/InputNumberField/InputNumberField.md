# InputNumberField

![InputNumberField](./InputNumberField.png)

纯数字输入框

组件地址：/src/components/form/inputs/InputNumberField
## Props
* form
* name 对应的字段名称，会赋值给getFieldDecorator()的第一个参数
* fieldProps 赋值给getFieldDecorator的第二个参数
* inputProps 赋值给table的参数
### inputProps
* format  数字是否格式化显示，true:格式化显示

引用实例
``` js
import InputNumberField from './InputNumberField'

render() {
  const { form } = this.props
  return (
    <InputNumberField
      form={form}
      name="fieldId"
      formItemProps={{label: `输入数字`, required: true}}
      fieldProps={{
        initialValue: [],
      }}
      inputProps={{
        format: true
      }}
    />
  )
}
```
