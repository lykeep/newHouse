# DateRangeField

![DateRangeField](./datepicker.png)

纯数字输入框

组件地址：/src/components/form/inputs/DateRangeField/DateRangeField
## Props
* form
* fieldProps 赋值给getFieldDecorator的第二个参数
* inputProps 赋值给table的参数

## fieldProps
* initialValue   object  默认开始、结束时间的 例：initialValue: {start: '2018-05-11', end: '2018-05-30'},

## inputProps
* dateKey   object  必传字段  定义开始、结束时间的key   例：dateKey: { start: '定义开始时间的key', end: '定义结束时间的key' }

## Option 
* 接收数据格式   {startValue: YYYY-MM-DD, endValue: YYYY-MM-DD}
* 返回数据格式   {startValue: YYYY-MM-DD, endValue: YYYY-MM-DD}



引用实例
``` js

// 验证
render() {
  const { form, authority } = this.props
  return (
    <DateRangeField
      form={form}
      authority={authority}
      formItemProps={{ label: '时间周期' }}
      fieldProps={{
        initialValue: {startTime: '2018-05-11', endTime: '2018-05-30'},
        rules: [
          { required: true, message: '请输入完整时间周期！' },
        ],
      }}
      inputProps={{
        dateKey: { start: 'startTime', end: 'endTime' }
      }}
    />
  )
}
```
![DateRangeField](./code.png)

