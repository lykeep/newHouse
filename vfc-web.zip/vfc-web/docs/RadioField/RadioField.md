# SelectMultiField

![RadioField](./RadioField.png)

组件地址 /src/components/form/RadioField


## Props
* form
* name 对应的字段名称，会赋值给getFieldDecorator()的第一个参数
* fieldProps 赋值给getFieldDecorator的第二个参数
* inputProps 赋值给option的参数

### inputProps
* options options数据

例子
``` js

this.options = [
      { label: 'Apples', value: 'Apple' },
      { label: 'Pears', value: 'Pear' },
      { label: 'Oranges', value: 'Orange' },
    ];
    
render() {
  const { form } = this.props
  return (
    <RadioField
      form={form}
      name="radios"
      formItemProps={{ label: '单选', required: true }}
      fieldProps={{
        initialValue: 'Apple',
        rules: [
            { required: true, message: 'required' },
         ],
      }}
      inputProps={{
         options: this.options,
      }}
    />
  )
}
```
