# TableField

![TableField](./TableField.png)

适用于列表操作，增删改查。

图片中的标题，是由wrapFormContainer生成的。

/src/components/form/TableField

要求lb-components版本大于0.0.4

## Props
* form
* name 对应的字段名称，会赋值给getFieldDecorator()的第一个参数
* fieldProps 赋值给getFieldDecorator的第二个参数
* inputProps 赋值给table的参数

### inputProps
* rowKey table数据的主键名称，必输
* columns table的列定义
* colSpan 整个控件所在Col的span，默认24
* component 这个列表页增改查时弹出的modal的内容，必需使用Form.create包装，这个form的values会作为表的一行数据，必输

例子
``` js
import BasicInfoFormContainer from './BasicInfoFormContainer'

render() {
  const { form } = this.props
  return (
    <TableField
      form={form}
      name="fieldId"
      fieldProps={{
        initialValue: [],
      }}
      inputProps={{
        columns: this.columns,
        component: BasicInfoFormContainer,
        rowKey: 'd0',
      }}
    />
  )
}
```
