# CheckboxField

![CheckboxField](./CheckboxField.png)

适用于选择多个选项。


/src/components/form/inputs/CheckboxField


## Props
* form
* name 对应的字段名称，会赋值给getFieldDecorator()的第一个参数
* formItemProps 赋值给字段Item的参数
* fieldProps 赋值给getFieldDecorator的第二个参数
* inputProps 赋值给CheckboxField的参数

### formItemProps
* lable 字段显示名称
* required 是否标识为必输字段

### fieldProps
* initialValue 组件初始值
* onChange 组件改变后的回调

### inputProps
* options 传递给组件的数据

options 数据格式

options: [
          { label: 'Apple', value: 'Apple1', },
          { label: 'Pear', value: 'Pear2',  },
          { label: 'Orange', value: 'Orange', },
        ]
        


例子
``` js
import ContractSigningContainer from './ContractSigningContainer'

 return (
      <div>
        <Form>
          <row> 
            <CheckboxField
              form={form}
              name='CheckboxField'
              formItemProps={{
               label: '请选择会签人员',
              }}
              fieldProps={{
                initialValue: this.optionFilter(this.state.defaultValue),
                onChange: (value) => {
                  console.log(value)
                },
              }}
              inputProps={{
                options: this.state.options,
              }}
            />
          </row>
        </Form>
      </div>
    )
```
